"""
Vertical Lines
==============

Draw static vertical marker lines on a 1-D plot with
:meth:`~anyplotlib.plot1d.Plot1D.add_vlines`.
Use ``markers["vlines"]["name"].set(...)`` to update them live.
"""
import numpy as np
import anyplotlib as apl

x      = np.linspace(0, 4 * np.pi, 512)
signal = np.sin(x)

fig, ax = apl.subplots(1, 1, figsize=(560, 300))
v = ax.plot(signal, axes=[x], units="rad")

v.add_vlines([np.pi, 2 * np.pi, 3 * np.pi], name="pi_mult",
             color="#00e5ff", linewidths=1.5,
             label="pi multiples", labels=["\u03c0", "2\u03c0", "3\u03c0"])

fig

# %%
# Live update
# -----------

v.markers["vlines"]["pi_mult"].set(color="#ff9100", linewidths=2.0)
fig
