"""
plot3d/_plot3d.py
=================
3-D surface / scatter / line plot panel.
"""

from __future__ import annotations

from typing import Callable

import numpy as np

from anyplotlib._base_plot import _BasePlot
from anyplotlib.callbacks import CallbackRegistry
from anyplotlib._utils import (_arr_to_b64, _build_colormap_lut,
                               _image_to_data_url)


def _triangulate_grid(rows: int, cols: int) -> list:
    """Return a flat list of [i0, i1, i2] triangle indices for an (rows×cols) grid."""
    faces = []
    for r in range(rows - 1):
        for c in range(cols - 1):
            i = r * cols + c
            faces.append([i,       i + 1,       i + cols])
            faces.append([i + 1,   i + cols + 1, i + cols])
    return faces


def _colors_to_u8(colors, n: int) -> np.ndarray:
    """Convert per-point colours to an (N, 3) uint8 RGB array.

    Accepts a sequence of CSS hex strings (``"#rrggbb"``) or an (N, 3)
    numeric array (floats 0–1, or 0–255).
    """
    if isinstance(colors, (list, tuple)) and colors and isinstance(colors[0], str):
        out = np.empty((len(colors), 3), dtype=np.uint8)
        for i, c in enumerate(colors):
            h = c.lstrip("#")
            if len(h) != 6:
                raise ValueError(f"colors[{i}]: expected '#rrggbb', got {c!r}")
            out[i] = [int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)]
    else:
        arr = np.asarray(colors)
        if arr.ndim != 2 or arr.shape[1] != 3:
            raise ValueError(f"colors must be (N, 3) or a list of hex strings, "
                             f"got shape {arr.shape}")
        if arr.dtype != np.uint8:
            arr = arr.astype(np.float64)
            if arr.max() <= 1.0:
                arr = arr * 255.0
            arr = np.clip(arr, 0, 255)
        out = arr.astype(np.uint8)
    if len(out) != n:
        raise ValueError(f"got {len(out)} colors for {n} points")
    return out


def _geometry_state(geom_type: str, x, y, z, bounds=None) -> dict:
    """Validate x/y/z for *geom_type* and return the wire-format state fields.

    Shared by ``Plot3D.__init__`` and ``Plot3D.set_data`` so geometry
    validation and encoding live in exactly one place.

    Parameters
    ----------
    bounds : ((xmin, xmax), (ymin, ymax), (zmin, zmax)) or None
        Override the auto-computed data bounds.  The JS renderer normalises
        geometry into these bounds, so fixing them keeps the origin and
        scale stable — essential for direction vectors on a unit sphere
        (use ``((-1, 1),) * 3``) or when streaming data of varying extent.
    """
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    z = np.asarray(z, dtype=float)

    if geom_type == "surface":
        # Accept 2-D grid arrays (meshgrid style) or 1-D flat arrays
        if x.ndim == 2 and y.ndim == 2 and z.ndim == 2:
            rows, cols = z.shape
            xf, yf, zf = x.ravel(), y.ravel(), z.ravel()
        elif x.ndim == 1 and y.ndim == 1 and z.ndim == 2:
            rows, cols = z.shape
            if len(x) != cols or len(y) != rows:
                raise ValueError(
                    "For surface with 1-D x/y: x must have length ncols "
                    "and y must have length nrows")
            XX, YY = np.meshgrid(x, y)
            xf, yf, zf = XX.ravel(), YY.ravel(), z.ravel()
        else:
            raise ValueError(
                "Surface x/y/z must be 2-D grids of the same shape, "
                "or 1-D x/y centre arrays with 2-D z.")
        faces_list = _triangulate_grid(rows, cols)
    else:
        if x.ndim != 1 or y.ndim != 1 or z.ndim != 1:
            raise ValueError(f"{geom_type} x, y, z must be 1-D arrays")
        if not (len(x) == len(y) == len(z)):
            raise ValueError("x, y, z must have the same length")
        xf, yf, zf = x, y, z
        faces_list = []
        rows = cols = 0

    # Encode geometry as b64 (float32 saves 50 % wire size vs float64)
    verts_arr = np.column_stack([xf, yf, zf]).astype(np.float32)   # (N, 3)
    zvals_arr = zf.astype(np.float32)                              # (N,)
    faces_arr = (np.asarray(faces_list, dtype=np.int32).reshape(-1, 3)
                 if faces_list else np.empty((0, 3), dtype=np.int32))

    if bounds is not None:
        (bx0, bx1), (by0, by1), (bz0, bz1) = bounds
        data_bounds = {"xmin": float(bx0), "xmax": float(bx1),
                       "ymin": float(by0), "ymax": float(by1),
                       "zmin": float(bz0), "zmax": float(bz1)}
    else:
        data_bounds = {
            "xmin": float(xf.min()), "xmax": float(xf.max()),
            "ymin": float(yf.min()), "ymax": float(yf.max()),
            "zmin": float(zf.min()), "zmax": float(zf.max()),
        }

    return {
        "vertices_b64":   _arr_to_b64(verts_arr, np.float32),
        "vertices_count": len(verts_arr),
        "faces_b64":      _arr_to_b64(faces_arr, np.int32),
        "faces_count":    len(faces_arr),
        "z_values_b64":   _arr_to_b64(zvals_arr, np.float32),
        "data_bounds":    data_bounds,
        # Parametric grid shape (0 for non-surface geometry) — texture UVs
        # default to this grid's normalised (col, row) coordinates.
        "grid_rows":      int(rows),
        "grid_cols":      int(cols),
    }


_IDENTITY_ROTATION = [1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0]


def _rotation_to_wire(matrix) -> list:
    """Validate a proper rotation matrix and flatten it row-major.

    A matrix that is not orthonormal would shear or scale the geometry, and
    one with determinant −1 would mirror it (turning a right-handed crystal
    into its enantiomorph), so both are rejected rather than silently drawn.
    """
    m = np.asarray(matrix, dtype=float)
    if m.shape != (3, 3) or not np.all(np.isfinite(m)):
        raise ValueError(f"rotation must be a finite 3×3 matrix, got shape {m.shape}")
    if not np.allclose(m @ m.T, np.eye(3), atol=1e-6):
        raise ValueError("rotation must be orthonormal (R @ R.T == I)")
    if np.linalg.det(m) < 0:
        raise ValueError("rotation must have determinant +1; "
                         "a determinant of -1 is a reflection")
    return [float(v) for v in m.ravel()]


#: Largest angle one segment of a geodesic patch edge spans.  At 2° a great
#: circle on a 400 px sphere deviates from its chord by under 0.1 px.
_GEODESIC_STEP_DEG = 2.0


def _geodesic_path(points: np.ndarray, centre: np.ndarray,
                   closed: bool) -> np.ndarray:
    """Join consecutive *points* by great-circle arcs about *centre*.

    The radius is interpolated linearly along each arc, so points on one
    sphere stay on it and points at different radii blend smoothly.
    """
    offsets = points - centre
    radii = np.linalg.norm(offsets, axis=1)
    if np.any(radii < 1e-12):
        raise ValueError("a geodesic patch cannot have a point at the centre; "
                         "pass geodesic=False for straight edges")
    units = offsets / radii[:, None]
    n = len(points)
    pieces = []
    for i in range(n if closed else n - 1):
        j = (i + 1) % n
        angle = float(np.arccos(np.clip(units[i] @ units[j], -1.0, 1.0)))
        if angle > np.radians(179.9):
            raise ValueError(
                f"points {i} and {j} are on opposite sides of the centre, so "
                "no single great circle joins them; add a point in between")
        steps = max(1, int(np.ceil(np.degrees(angle) / _GEODESIC_STEP_DEG)))
        t = np.arange(steps) / steps
        if angle < 1e-9:
            arc = np.repeat(units[i][None], steps, axis=0)
        else:
            arc = (np.sin((1 - t) * angle)[:, None] * units[i]
                   + np.sin(t * angle)[:, None] * units[j]) / np.sin(angle)
        pieces.append(arc * (radii[i] + (radii[j] - radii[i]) * t)[:, None])
    if not closed:
        pieces.append(offsets[-1:])
    return np.vstack(pieces) + centre


class Patch3D:
    """A region or path drawn on a 3-D panel; returned by :meth:`Plot3D.add_patch`.

    Change it in place with :meth:`set` and take it off with :meth:`remove`.
    """

    def __init__(self, plot: "Plot3D", name: str):
        self._plot = plot
        self.name = name

    def set(self, **kwargs) -> None:
        """Change any argument :meth:`Plot3D.add_patch` takes, by name."""
        self._plot._update_patch(self.name, kwargs)

    def remove(self) -> None:
        """Take the patch off its panel."""
        self._plot.remove_patch(self.name)

    def __repr__(self) -> str:
        return f"Patch3D(name={self.name!r})"


def _uv_to_b64(uv, rows: int, cols: int, n: int, flip_v: bool) -> str:
    """Validate texture coordinates and encode them as float32 ``(N, 2)`` b64.

    ``uv=None`` builds the default parametric mapping: ``u`` runs 0→1 across
    the grid's columns and ``v`` 0→1 down its rows, so an equirectangular
    image lands on a sphere parameterised the same way.  Otherwise *uv* is
    either a ``(U, V)`` pair (each 2-D grid- or flat-shaped) or a single
    ``(N, 2)`` array of per-vertex coordinates.
    """
    if uv is None:
        if rows < 2 or cols < 2:
            raise ValueError(
                "default texture coordinates need a parametric grid surface; "
                "pass uv=(U, V) explicitly")
        u = np.tile(np.linspace(0.0, 1.0, cols), rows)
        v = np.repeat(np.linspace(0.0, 1.0, rows), cols)
    elif isinstance(uv, (tuple, list)) and len(uv) == 2:
        u = np.asarray(uv[0], dtype=float).ravel()
        v = np.asarray(uv[1], dtype=float).ravel()
        if len(u) != n or len(v) != n:
            raise ValueError(
                f"uv=(U, V) must each hold {n} values (one per vertex), "
                f"got {len(u)} and {len(v)}")
    else:
        arr = np.asarray(uv, dtype=float)
        if arr.ndim != 2 or arr.shape != (n, 2):
            raise ValueError(
                f"uv must be a (U, V) pair or an ({n}, 2) array, "
                f"got shape {arr.shape}")
        u, v = arr[:, 0], arr[:, 1]

    if flip_v:
        v = 1.0 - v
    return _arr_to_b64(np.column_stack([u, v]).astype(np.float32), np.float32)


class Plot3D(_BasePlot):
    """3-D plot panel.

    Supports four geometry types:

    * ``'surface'``  – triangulated surface, Z-coloured via colormap, or
      wrapped in an image with :meth:`set_texture` (globes, star charts).
    * ``'scatter'``  – point cloud; single colour or per-point ``colors``.
    * ``'line'``     – connected line through 3-D points.
    * ``'voxels'``   – shaded translucent cubes at the given centres;
      voxels lying on a :class:`~anyplotlib.PlaneWidget` slice render more
      opaque.

    A single point can be emphasised with :meth:`set_highlight` (e.g. the
    "current" orientation in an IPF explorer), and ``bounds=`` fixes the
    axes extents for origin-true geometry such as unit vectors on a sphere.
    Draggable :class:`~anyplotlib.PlaneWidget` slice selectors are added
    with :meth:`add_widget`.

    Created by :meth:`Axes.plot_surface`, :meth:`Axes.scatter3d`,
    and :meth:`Axes.plot3d`.

    Not an anywidget.  Holds state in ``_state`` dict; every mutation
    calls ``_push()`` which writes to the parent Figure's panel trait.
    """

    #: Heavy, rarely-changing state keys routed to the separate geometry
    #: channel — re-sent only when their content changes, so view updates
    #: (highlight / camera / planes) never re-transmit them.
    _GEOM_KEYS = frozenset({
        "vertices_b64", "faces_b64", "z_values_b64", "point_colors_b64",
        "colormap_data", "texture_url", "texture_uv_b64", "key_images",
    })

    def __init__(self, geom_type: str,
                 x, y, z, *,
                 colormap: str = "viridis",
                 color: str = "#4fc3f7",
                 colors=None,
                 point_size: float = 4.0,
                 linewidth: float = 1.5,
                 x_label: str = "x",
                 y_label: str = "y",
                 z_label: str = "z",
                 azimuth: float = -60.0,
                 elevation: float = 30.0,
                 zoom: float = 1.0,
                 bounds=None,
                 voxel_size: float = 1.0,
                 alpha: float | None = None,
                 texture=None,
                 gpu: str | bool = "auto"):
        self._id:  str = ""
        self._fig: object = None
        self._gpu_active: bool = False
        #: True while the texture UVs are the auto parametric mapping, so
        #: set_data() can rebuild them for the new grid shape.  When they are
        #: explicit instead, _texture_uv_n records how many vertices they
        #: cover so a shape-changing set_data can reject them.  _texture_flip_v
        #: is the flip the mapping was built with — a rebuild has to reapply it
        #: or a streaming surface flips vertically on its first update.
        self._texture_uv_auto: bool = True
        self._texture_uv_n: int = 0
        self._texture_flip_v: bool = False

        geom_type = geom_type.lower()
        if geom_type not in ("surface", "scatter", "line", "voxels"):
            raise ValueError(
                "geom_type must be 'surface', 'scatter', 'line', or 'voxels'")

        cmap_lut = _build_colormap_lut(colormap)
        self._bounds = bounds
        geom = _geometry_state(geom_type, x, y, z, bounds=bounds)

        point_colors_b64 = ""
        if colors is not None:
            if geom_type not in ("scatter", "voxels"):
                raise ValueError(
                    "per-point colors are only supported for scatter/voxels")
            point_colors_b64 = _arr_to_b64(
                _colors_to_u8(colors, geom["vertices_count"]), np.uint8)

        # The canvas budget is ~20k cubes; WebGPU (gpu="auto"/True) handles
        # far more, so only warn when GPU is explicitly disabled.
        gpu_off = gpu is False or str(gpu) == "off"
        if geom_type == "voxels" and gpu_off and geom["vertices_count"] > 20_000:
            import warnings
            warnings.warn(
                f"Rendering {geom['vertices_count']:,} voxels with gpu=False — "
                f"the canvas renderer budgets roughly 3–6 µs per cube, so "
                f"interactive frame rates need ≤ ~20k. Either allow WebGPU "
                f"(gpu='auto'), downsample the volume (stride slicing) or "
                f"extract boundary voxels, and show full-resolution data in "
                f"linked 2-D slice panels instead.",
                RuntimeWarning, stacklevel=3)

        self._state: dict = {
            "kind":          "3d",
            "geom_type":     geom_type,
            **geom,
            "colormap_name": colormap,
            "colormap_data": cmap_lut,
            "color":         color,
            "point_colors_b64": point_colors_b64,
            # Image texture wrapped onto a surface (see set_texture).  The
            # image rides as a data: URL and the per-vertex UVs as float32
            # pairs; both are geometry-channel keys.
            "texture_url":     "",
            "texture_uv_b64":  "",
            "texture_alpha":   1.0,
            "texture_shade":   False,
            "texture_cull":    False,
            # Highlight point: {"x","y","z","color","size"} or None
            "highlight":     None,
            # Reference sphere: {"radius","color","alpha","wireframe"} or None
            "sphere":        None,
            # Regions and paths (add_patch), drawn over the geometry.
            "patches":       [],
            # WebGPU activation policy: 'auto' (GPU above a point threshold),
            # 'always', or 'off'.  Falls back to Canvas2D whenever the GPU is
            # unavailable; query the result via the gpu_active property.
            "gpu_mode":          ("always" if gpu is True else
                                  "off" if gpu is False else str(gpu)),
            # Voxel rendering (geom_type == 'voxels')
            "voxel_size":        float(voxel_size),
            "voxel_alpha":       float(alpha) if alpha is not None else 0.3,
            "voxel_slice_alpha": 0.95,
            # Interactive overlay widgets (PlaneWidget slice selectors)
            "overlay_widgets":   [],
            "point_size":    float(point_size),
            "linewidth":     float(linewidth),
            "title":         "",
            "x_label":       x_label,
            "y_label":       y_label,
            "z_label":       z_label,
            "axis_visible":  True,
            "azimuth":       float(azimuth),
            "elevation":     float(elevation),
            "zoom":          float(zoom),
            # Model rotation (row-major 3×3) applied to the data before the
            # camera — see set_rotation.  "rotate" drags edit it; "orbit"
            # drags move the camera.
            "rotation":      list(_IDENTITY_ROTATION),
            "drag_mode":     "orbit",
            "_default_azimuth":   float(azimuth),
            "_default_elevation": float(elevation),
            "_default_zoom":      float(zoom),
            "_view_from_python":  False,
            "_rotation_from_python": False,
            "pointer_settled_ms":    0,
            "pointer_settled_delta": 4,
        }
        self.callbacks = CallbackRegistry()
        self._widgets: dict = {}
        #: name → (Patch3D, the arguments it was made with)
        self._patches: dict = {}

        if texture is not None:
            self.set_texture(texture)

    # ------------------------------------------------------------------
    def _push(self) -> None:
        if self._fig is None:
            return
        self._state["overlay_widgets"] = [w._wire_dict() for w in self._widgets.values()]
        self._fig._push(self._id)

    def _push_fields(self, **fields) -> None:
        """Targeted update of small state fields without re-sending geometry.

        For a heavy voxel/scatter panel, moving the highlight or camera would
        otherwise re-transmit hundreds of KB of unchanged ``vertices_b64`` —
        this ships only *fields* via the lightweight event channel.
        """
        self._state.update(fields)
        if self._fig is not None:
            self._fig._push_panel_fields(self._id, fields)

    # ------------------------------------------------------------------
    # Interactive widgets (3-D)
    # ------------------------------------------------------------------
    def add_widget(self, kind: str, **kwargs):
        """Add an interactive overlay widget to this 3-D panel.

        Currently supports ``"plane"`` — a draggable axis-aligned slice
        plane (see :class:`~anyplotlib.PlaneWidget`)::

            pw = vol.add_widget("plane", axis="z", position=24)

            @pw.add_event_handler("pointer_move")
            def on_drag(event):
                resliced(int(round(pw.position)))
        """
        if kind.lower() != "plane":
            raise ValueError("3-D panels currently support only 'plane' widgets")
        from anyplotlib.widgets import PlaneWidget
        widget = PlaneWidget(lambda: None, **kwargs)
        widget._push_fn = self._make_widget_push_fn(widget)
        self._widgets[widget.id] = widget
        self._push()
        return widget

    def remove_widget(self, wid) -> None:
        """Remove a widget by ID string or Widget instance."""
        from anyplotlib.widgets import Widget
        if isinstance(wid, Widget):
            wid = wid.id
        if wid not in self._widgets:
            raise KeyError(wid)
        self._widgets.pop(wid)._plot = None   # Widget.plot -> None once detached
        self._push()

    def list_widgets(self) -> list:
        """Return a list of all active widget objects on this panel."""
        return list(self._widgets.values())

    # ------------------------------------------------------------------
    def set_voxel_alpha(self, alpha: float, slice_alpha: float | None = None) -> None:
        """Set voxel transparency (geom_type ``'voxels'``).

        Parameters
        ----------
        alpha : float
            Base opacity (0–1) for voxels not on any plane widget.
        slice_alpha : float, optional
            Opacity for voxels lying on a :class:`~anyplotlib.PlaneWidget`
            slice.  ``None`` keeps the current value (default 0.95).
        """
        self._state["voxel_alpha"] = float(alpha)
        if slice_alpha is not None:
            self._state["voxel_slice_alpha"] = float(slice_alpha)
        self._push()

    def to_state_dict(self) -> dict:
        # Always serialise the live overlay widgets, so *every* push path
        # (full _push, targeted _push_fields, batched) carries the current
        # plane positions.  Without this, a view-only push (set_highlight /
        # set_view) re-serialises a stale overlay_widgets snapshot and clobbers
        # an in-progress plane drag in JS — the "snap-back" symptom.
        d = dict(self._state)
        if self._widgets:
            d["overlay_widgets"] = [w._wire_dict() for w in self._widgets.values()]
        return d

    # ------------------------------------------------------------------
    @property
    def gpu_active(self) -> bool:
        """``True`` if this panel is currently rendering geometry on the GPU.

        Reflects the JS renderer's decision after the first frame: WebGPU is
        used only when available and when the panel's ``gpu`` policy and
        point count call for it.  Always ``False`` on the Canvas2D fallback
        path (no ``navigator.gpu``, no adapter, device lost, or ``gpu=False``).
        """
        return self._gpu_active

    def _set_gpu_active(self, active: bool) -> None:
        """Internal: called from the Figure's gpu_status event dispatch."""
        self._gpu_active = bool(active)

    # ------------------------------------------------------------------
    # Display settings
    # ------------------------------------------------------------------
    def set_colormap(self, name: str) -> None:
        """Set the surface colormap (ignored for scatter/line)."""
        self._state["colormap_name"] = name
        self._state["colormap_data"] = _build_colormap_lut(name)
        self._push()

    def set_view(self, azimuth: float | None = None,
                 elevation: float | None = None) -> None:
        """Set the camera azimuth (°) and/or elevation (°).

        Uses a targeted field push so re-aiming the camera never re-transmits
        the panel's geometry — important for large voxel/scatter panels.
        """
        fields = {"_view_from_python": True}
        if azimuth   is not None: fields["azimuth"]   = float(azimuth)
        if elevation is not None: fields["elevation"] = float(elevation)
        self._push_fields(**fields)
        self._state["_view_from_python"] = False

    def set_rotation(self, matrix=None) -> None:
        """Orient the data with a rotation matrix, independent of the camera.

        The camera's azimuth and elevation can only aim it — two degrees of
        freedom.  An orientation has three: a crystal, a molecule, or a
        sample on a stage turns about every axis.  *matrix* rotates the data
        about the centre of its bounds, and the camera then looks at the
        result, so ``set_rotation`` says how the object is turned and
        :meth:`set_view` says where you stand to look at it.

        Like :meth:`set_view`, this is a targeted push: rotating a large
        surface or point cloud never re-sends its geometry or texture.

        Parameters
        ----------
        matrix : (3, 3) array-like, optional
            A proper rotation (orthonormal, determinant +1).  Column ``j`` is
            where the data's ``j``-th axis points after rotating, so
            ``matrix @ v`` maps a data-frame direction into the rotated frame.
            ``None`` restores the identity.

        Raises
        ------
        ValueError
            If *matrix* is not 3×3, not orthonormal, or a reflection.

        See Also
        --------
        rotation : The current matrix, including drags made in the viewer.
        set_drag_mode : Let the viewer edit the rotation by dragging.
        """
        wire = (list(_IDENTITY_ROTATION) if matrix is None
                else _rotation_to_wire(matrix))
        self._push_fields(rotation=wire, _rotation_from_python=True)
        self._state["_rotation_from_python"] = False

    @property
    def rotation(self) -> np.ndarray:
        """The current model rotation as a ``(3, 3)`` array.

        Follows drags made in ``"rotate"`` mode (see :meth:`set_drag_mode`)
        as well as :meth:`set_rotation`.
        """
        return np.asarray(self._state["rotation"], dtype=float).reshape(3, 3)

    def _set_rotation_from_js(self, wire) -> None:
        """Internal: record a rotation the viewer's drag produced."""
        try:
            self._state["rotation"] = [float(v) for v in wire]
        except (TypeError, ValueError):
            pass

    def set_drag_mode(self, mode: str) -> None:
        """Choose what a left-button drag on the panel does.

        Parameters
        ----------
        mode : ``"orbit"`` | ``"rotate"``
            ``"orbit"`` (the default) moves the camera around the data.
            ``"rotate"`` turns the data under a fixed camera instead, editing
            :attr:`rotation`: horizontal and vertical motion roll the surface
            under the cursor like a trackball, and a drag with **Shift** held
            spins it about the line of sight — the third degree of freedom an
            orbit cannot reach.  Every drag frame fires ``pointer_move`` and
            the release fires ``pointer_up``, both with ``event.rotation``
            set, so keep the ``pointer_move`` handler fast and do expensive
            work (re-simulating a pattern, say) on ``pointer_up``.
        """
        mode = str(mode).lower()
        if mode not in ("orbit", "rotate"):
            raise ValueError(f"drag mode must be 'orbit' or 'rotate', got {mode!r}")
        self._push_fields(drag_mode=mode)

    def set_zoom(self, zoom: float) -> None:
        self._push_fields(zoom=float(zoom), _view_from_python=True)
        self._state["_view_from_python"] = False

    def reset_view(self) -> None:
        """Restore the camera to the angles/zoom set at construction time."""
        with self._python_view_push():
            self._state["azimuth"]   = self._state["_default_azimuth"]
            self._state["elevation"] = self._state["_default_elevation"]
            self._state["zoom"]      = self._state["_default_zoom"]

    def set_xlabel(self, label: str, fontsize: float | None = None) -> None:
        """Set the x-axis label (mini-TeX allowed; default size 11 px)."""
        self._set_label("x_label", label, "x_label_size", fontsize)

    def set_ylabel(self, label: str, fontsize: float | None = None) -> None:
        """Set the y-axis label (mini-TeX allowed; default size 11 px)."""
        self._set_label("y_label", label, "y_label_size", fontsize)

    def set_zlabel(self, label: str, fontsize: float | None = None) -> None:
        """Set the z-axis label (mini-TeX allowed; default size 11 px)."""
        self._set_label("z_label", label, "z_label_size", fontsize)

    def get_xlim(self) -> tuple:
        """Return the data x range as ``(xmin, xmax)``."""
        b = self._state["data_bounds"]
        return (b["xmin"], b["xmax"])

    def get_ylim(self) -> tuple:
        """Return the data y range as ``(ymin, ymax)``."""
        b = self._state["data_bounds"]
        return (b["ymin"], b["ymax"])

    def get_zlim(self) -> tuple:
        """Return the data z range as ``(zmin, zmax)``."""
        b = self._state["data_bounds"]
        return (b["zmin"], b["zmax"])

    def set_data(self, x, y, z) -> None:
        """Replace the geometry data (same shape rules as the constructor).

        Bounds given at construction time (``bounds=``) are preserved.  An
        auto-mapped texture (:meth:`set_texture` without ``uv=``) follows the
        new grid, keeping the ``flip_v`` it was applied with; explicit UVs are
        kept and must still match the vertex count.
        """
        self._state.update(_geometry_state(
            self._state["geom_type"], x, y, z, bounds=self._bounds))
        if self._state["texture_url"]:
            n = self._state["vertices_count"]
            if self._texture_uv_auto:
                self._state["texture_uv_b64"] = _uv_to_b64(
                    None, self._state["grid_rows"], self._state["grid_cols"],
                    n, self._texture_flip_v)
                self._texture_uv_n = n
            elif self._texture_uv_n != n:
                raise ValueError(
                    "the explicit texture coordinates set by set_texture(uv=…) "
                    f"cover {self._texture_uv_n} vertices but the new data has "
                    f"{n}; call set_texture again with matching uv=")
        self._push()

    # ------------------------------------------------------------------
    # Image textures (surface only)
    # ------------------------------------------------------------------
    def set_texture(self, image, *, uv=None, alpha: float = 1.0,
                    shade: bool = False, cull_backfaces: bool = False,
                    flip_v: bool = False) -> None:
        """Wrap an image around this surface (``geom_type == 'surface'``).

        Each triangle is filled with the matching patch of *image*, so the
        picture follows the geometry as you orbit — a globe, a planet, or a
        star chart on the celestial sphere.  By default the image is mapped
        parametrically: its left edge to the surface grid's first column, its
        right edge to the last, its top row to the grid's first row.  Build the
        sphere with longitude along the columns and latitude down the rows and
        an equirectangular (plate-carrée) image lands exactly right.

        Rendering goes through WebGPU when it is available and the surface has
        more than ~2k triangles (see the ``gpu`` argument to
        :meth:`Axes.plot_surface`), which lifts the practical grid size from a
        few thousand triangles to hundreds of thousands.  Without a GPU — or
        with ``alpha`` below 1, which needs the Canvas2D compositing path —
        every triangle is texture-mapped on the CPU instead, so prefer a
        coarse grid there and let the image carry the detail.

        Parameters
        ----------
        image : array-like, bytes, or path
            An ``(H, W, 3|4)`` colour array (uint8, or float 0–1 — a PIL image
            works too), the raw bytes of a PNG/JPEG/GIF/WebP, or a path to
            such a file.  Encoded input is passed through untouched; arrays
            are PNG-compressed.  Very large images cost wire size and decode
            time — 2048×1024 is plenty for a sphere.
        uv : (U, V) or (N, 2) array, optional
            Explicit texture coordinates in 0–1, one per vertex, instead of
            the default parametric mapping.  ``U``/``V`` may be given in the
            grid's 2-D shape or already flattened.
        alpha : float, optional
            Opacity of the whole textured surface, 0–1.  Default 1.  Below 1
            the surface is composited as one translucent skin — whatever the
            panel draws behind it (a reference sphere, a scatter cloud) shows
            through, but the surface's own far side does not.
        shade : bool, optional
            Modulate the texture with diffuse lighting from the upper left.
            Default False (the image is reproduced faithfully); True gives a
            sphere its familiar lit look and makes relief read as relief.
        cull_backfaces : bool, optional
            Skip triangles facing away from the camera.  Default False.  Set
            True for a *closed* surface (sphere, ellipsoid, blob) — it halves
            the drawing work with no visual change.  On an open surface it
            makes the back side invisible, which is usually not what you want.
            Ignored on the WebGPU path, where the depth buffer resolves
            occlusion exactly and culling buys nothing.
        flip_v : bool, optional
            Mirror the mapping vertically (``v → 1 - v``).  Use when the image
            is stored bottom-up relative to the grid's row order.  Remembered
            for the auto mapping, so a later :meth:`set_data` rebuilds the UVs
            with the same flip.

        Raises
        ------
        ValueError
            If this is not a ``'surface'`` panel, ``alpha`` is outside
            ``[0, 1]``, *image* is not a decodable image, or *uv* does not
            cover every vertex.

        See Also
        --------
        clear_texture : Remove the texture and fall back to colormapped Z.

        Examples
        --------
        ::

            lat = np.linspace(np.pi / 2, -np.pi / 2, 180)    # rows: N → S
            lon = np.linspace(-np.pi, np.pi, 360)            # cols: W → E
            LON, LAT = np.meshgrid(lon, lat)
            X = np.cos(LAT) * np.cos(LON)
            Y = np.cos(LAT) * np.sin(LON)
            Z = np.sin(LAT)

            globe = ax.plot_surface(X, Y, Z, bounds=((-1, 1),) * 3)
            globe.set_texture("earth.jpg", shade=True, cull_backfaces=True)
        """
        if self._state["geom_type"] != "surface":
            raise ValueError("textures are only supported for surface plots")
        alpha = float(alpha)
        if not 0.0 <= alpha <= 1.0:
            raise ValueError(f"alpha must be in [0, 1], got {alpha}")
        url = _image_to_data_url(image)
        uv_b64 = _uv_to_b64(uv, self._state["grid_rows"],
                            self._state["grid_cols"],
                            self._state["vertices_count"], flip_v)
        self._texture_uv_auto = uv is None
        self._texture_uv_n = self._state["vertices_count"]
        self._texture_flip_v = bool(flip_v)
        self._state.update(
            texture_url=url,
            texture_uv_b64=uv_b64,
            texture_alpha=alpha,
            texture_shade=bool(shade),
            texture_cull=bool(cull_backfaces),
        )
        self._push()

    def clear_texture(self) -> None:
        """Remove the image texture; the surface reverts to colormapped Z."""
        self._texture_uv_auto = True
        self._texture_flip_v = False
        self._state.update(texture_url="", texture_uv_b64="")
        self._push()

    @property
    def has_texture(self) -> bool:
        """``True`` when an image texture is currently applied."""
        return bool(self._state["texture_url"])

    def set_point_colors(self, colors) -> None:
        """Set (or clear) per-point colours on a scatter or voxels panel.

        Parameters
        ----------
        colors : list of "#rrggbb" strings, (N, 3) array, or None
            One colour per point / voxel.  Floats are interpreted as 0–1 (or
            0–255 when the max exceeds 1).  ``None`` reverts to the single
            ``color`` for all elements.
        """
        if self._state["geom_type"] not in ("scatter", "voxels"):
            raise ValueError(
                "per-point colors are only supported for scatter/voxels")
        if colors is None:
            self._state["point_colors_b64"] = ""
        else:
            n = self._state["vertices_count"]
            self._state["point_colors_b64"] = _arr_to_b64(
                _colors_to_u8(colors, n), np.uint8)
        self._push()

    def set_highlight(self, x: float, y: float, z: float, *,
                      color: str = "#ff1744", size: float = 7.0) -> None:
        """Mark one 3-D point with an emphasised dot drawn on top.

        The highlight is independent of the panel's geometry — use it to
        flag the "current" item in a point cloud or on a surface (e.g. the
        orientation under a crosshair in an IPF explorer).  Points on the
        far side of the data are drawn semi-transparent as a depth cue.

        Parameters
        ----------
        x, y, z : float
            Position in data coordinates.
        color : str, optional
            CSS colour of the dot and ring.  Default ``"#ff1744"``.
        size : float, optional
            Dot radius in pixels.  Default 7.

        See Also
        --------
        clear_highlight : Remove the highlight.
        """
        self._push_fields(highlight={
            "x": float(x), "y": float(y), "z": float(z),
            "color": str(color), "size": float(size),
        })

    def clear_highlight(self) -> None:
        """Remove the highlight point set by :meth:`set_highlight`."""
        self._push_fields(highlight=None)

    def set_sphere(self, radius: float = 1.0, *,
                   color: str = "#9e9e9e",
                   alpha: float = 0.15,
                   wireframe: bool = True) -> None:
        """Draw an origin-centred reference sphere behind the data.

        Rendered as a shaded silhouette disk plus latitude/longitude
        wireframe arcs (far-side arcs dimmed).  Scatter points on the far
        side of the sphere are also dimmed, so a point cloud on the sphere
        reads with correct depth — ideal for inverse-pole-figure /
        orientation plots of unit vectors.

        Assumes origin-centred, isotropic bounds — pass
        ``bounds=((-r, r),) * 3`` to the constructor so the sphere's
        screen silhouette is a true circle.

        Parameters
        ----------
        radius : float, optional
            Sphere radius in data units.  Default 1 (unit sphere).
        color : str, optional
            Base CSS colour of the shading and wireframe.  Default grey.
        alpha : float, optional
            Opacity of the shaded silhouette (0–1).  Default 0.15.
        wireframe : bool, optional
            Draw latitude/longitude arcs.  Default True.

        See Also
        --------
        clear_sphere : Remove the reference sphere.
        """
        self._state["sphere"] = {
            "radius": float(radius), "color": str(color),
            "alpha": float(alpha), "wireframe": bool(wireframe),
        }
        self._push()

    def clear_sphere(self) -> None:
        """Remove the reference sphere set by :meth:`set_sphere`."""
        self._state["sphere"] = None
        self._push()

    # ------------------------------------------------------------------
    # Patches: regions and paths drawn over the geometry
    # ------------------------------------------------------------------
    def add_patch(self, points, *, frame: str = "data", closed: bool = True,
                  geodesic: bool = True, facecolor: str = "#4fc3f7",
                  edgecolor: str | None = None, alpha: float = 0.3,
                  back_alpha: float = 0.3, linewidth: float = 1.5,
                  label: str = "", name: str | None = None) -> Patch3D:
        """Draw a region (or, with ``closed=False``, a path) on this panel.

        Made for spheres: the region a detector sees on a master pattern, a
        grain's spread of orientations on a pole sphere, the trace of a band.
        By default each edge follows the great circle between its two corners
        — the shortest way round the sphere, and exactly the shape a flat
        detector's straight edge makes when projected onto it — so four
        corners are enough for a detector's footprint.

        The part of the patch behind the centre of the data is drawn dimmer
        (``back_alpha``), and where a geodesic patch wraps behind the sphere
        its outline follows the sphere's edge rather than cutting across it.

        Parameters
        ----------
        points : (N, 3) array-like
            Corners (or path points) in data coordinates.
        frame : ``"data"`` | ``"world"``
            ``"data"`` (default) turns the patch with the data when
            :meth:`set_rotation` changes — a feature of the object.
            ``"world"`` keeps it fixed while the data turns under it — a
            detector, a beam, anything that belongs to the instrument.  Both
            move with the camera.
        closed : bool
            Join the last point back to the first and fill the inside.
            ``False`` draws an open path with no fill.
        geodesic : bool
            Join points by great-circle arcs about the centre of the data
            bounds (default).  ``False`` joins them with straight lines.
        facecolor, edgecolor : str
            Fill and outline colours; ``edgecolor`` defaults to ``facecolor``.
        alpha : float
            Opacity of the fill, 0–1.  The outline is drawn opaque.
        back_alpha : float
            Opacity multiplier for the part behind the centre, 0–1.
        linewidth : float
            Outline width in pixels; 0 hides the outline.
        label : str
            Text drawn at the patch's centre while it faces the camera.
        name : str, optional
            Key in :attr:`patches`.  Re-using a name replaces that patch.

        Returns
        -------
        Patch3D
            Handle with :meth:`~Patch3D.set` and :meth:`~Patch3D.remove`.
        """
        if name is None:
            name = f"patch{len(self._patches)}"
            while name in self._patches:
                name += "_"
        args = dict(points=points, frame=frame, closed=closed,
                    geodesic=geodesic, facecolor=facecolor, edgecolor=edgecolor,
                    alpha=alpha, back_alpha=back_alpha, linewidth=linewidth,
                    label=label)
        wire = self._patch_wire(name, args)        # validate before storing
        handle = Patch3D(self, name)
        self._patches[name] = (handle, args, wire)
        self._push_patches()
        return handle

    def remove_patch(self, patch) -> None:
        """Take off a patch, given its handle or its name."""
        name = patch.name if isinstance(patch, Patch3D) else patch
        if name not in self._patches:
            raise KeyError(name)
        del self._patches[name]
        self._push_patches()

    @property
    def patches(self) -> dict:
        """The panel's patches by name, as :class:`Patch3D` handles."""
        return {name: entry[0] for name, entry in self._patches.items()}

    def _update_patch(self, name: str, changes: dict) -> None:
        handle, args, _ = self._patches[name]
        unknown = set(changes) - set(args)
        if unknown:
            raise TypeError(f"unknown patch argument(s): {sorted(unknown)}")
        args = {**args, **changes}
        self._patches[name] = (handle, args, self._patch_wire(name, args))
        self._push_patches()

    def _push_patches(self) -> None:
        self._push_fields(patches=[wire for _, _, wire in self._patches.values()])

    def _patch_wire(self, name: str, args: dict) -> dict:
        points = np.asarray(args["points"], dtype=float)
        if points.ndim != 2 or points.shape[1] != 3:
            raise ValueError(f"patch points must be (N, 3), got {points.shape}")
        closed = bool(args["closed"])
        if len(points) < (3 if closed else 2):
            raise ValueError("a closed patch needs at least 3 points, "
                             "an open path at least 2")
        if not np.all(np.isfinite(points)):
            raise ValueError("patch points must be finite")
        frame = str(args["frame"]).lower()
        if frame not in ("data", "world"):
            raise ValueError(f"frame must be 'data' or 'world', got {frame!r}")
        if args["geodesic"]:
            b = self._state["data_bounds"]
            centre = np.array([(b["xmin"] + b["xmax"]) / 2,
                               (b["ymin"] + b["ymax"]) / 2,
                               (b["zmin"] + b["zmax"]) / 2])
            points = _geodesic_path(points, centre, closed)
        return {
            "id": name,
            "points": [round(float(v), 6) for v in points.ravel()],
            "frame": frame,
            "closed": closed,
            "geodesic": bool(args["geodesic"]),
            "facecolor": str(args["facecolor"]),
            "edgecolor": str(args["edgecolor"] or args["facecolor"]),
            "alpha": float(np.clip(args["alpha"], 0.0, 1.0)),
            "back_alpha": float(np.clip(args["back_alpha"], 0.0, 1.0)),
            "linewidth": float(args["linewidth"]),
            "label": str(args["label"]),
        }

    def __repr__(self) -> str:
        geom = self._state.get("geom_type", "?")
        n = self._state.get("vertices_count", 0)
        return f"Plot3D(geom={geom!r}, n_vertices={n})"
