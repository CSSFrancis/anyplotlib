"""
_repr_utils.py
==============

Produces a self-contained HTML page that renders anywidget Widgets
interactively without a live Jupyter kernel.

Strategy
--------
1. Serialise every synced traitlet value to a plain JSON dict.
2. Embed that dict and the widget's ``_esm`` source directly in the page.
3. Provide a minimal model shim (get/set/on/save_changes) so the ESM's
   render() function works without any Jupyter comm infrastructure.
4. Import the ESM as a Blob URL and call render({ model, el }).

When resizable=False (the default for documentation) the resize handle is
hidden via CSS and the iframe is sized exactly to the widget's own dimensions,
producing a tight, centred embed with no dead space.
"""

from __future__ import annotations

import json
from html import escape
from uuid import uuid4

# Maximum display width (px) for the non-resizable notebook embed.
# Figures wider than this are scaled down proportionally via CSS transform.
# 860 px fits comfortably in a standard JupyterLab / VS Code notebook cell.
MAX_NOTEBOOK_WIDTH = 860


# ---------------------------------------------------------------------------
# Trait serialisation
# ---------------------------------------------------------------------------

def script_json(obj) -> str:
    """Return *obj* as a JSON literal that is safe inside a ``<script>`` block.

    An HTML parser ends a script element at the first ``</`` in its text and
    treats ``<!--`` as a comment opener, and it does not care that the sequence
    is inside a JavaScript string.  So a figure title, an axis label read from
    file metadata, or any other value carrying ``</script>`` would close the
    block early and run whatever followed it as markup.  Both sequences are
    escaped through the ``<``, which JSON spells ``\u003c``, so ``JSON.parse``
    and a script literal read back exactly the character that went in.
    """
    return (json.dumps(obj, default=str)
            .replace("</", "\\u003c/")
            .replace("<!--", "\\u003c!--"))



def _widget_state(widget) -> dict:
    """Return a {name: value} dict of every synced traitlet.

    A widget that keeps state outside its traits between renders may define
    ``_sync_for_export()`` to reconcile it first.  ``Figure`` uses this to fold
    widget geometry — pushed to JS as targeted events that never touch the
    panel traits — back in, so a snapshot captures widgets where they are
    rather than where they were created.
    """
    sync = getattr(widget, "_sync_for_export", None)
    if callable(sync):
        sync()
    state: dict = {}
    for name, trait in widget.traits(sync=True).items():
        if name.startswith("_"):
            continue
        raw = getattr(widget, name)
        if isinstance(raw, (bytes, bytearray)):
            import base64
            raw = {"buffer": base64.b64encode(raw).decode("ascii")}
        state[name] = raw
    return state


def _widget_px(widget) -> tuple[int, int]:
    """Return (width_px, height_px) for the widget's full rendered size.

    These are the *outer* pixel dimensions of the widget's root DOM element,
    including any padding the widget JS adds around the canvas grid.
    """
    try:
        kind = type(widget).__name__
        if kind == "Figure":
            # figure_esm.js: gridDiv has padding:8px on all sides → +16 each axis
            return int(widget.fig_width) + 16, int(widget.fig_height) + 16
        # Viewer1D / Viewer2D — the outerContainer has padding:10px
        w = int(getattr(widget, "viewer_width",  480))
        h = int(getattr(widget, "viewer_height", 256))
        PAD = 20  # 10px padding each side
        if kind == "Viewer2D":
            # Add axis canvas gutters (AXIS_SIZE = 40 in viewer2d JS)
            AXIS = 40
            w += AXIS + PAD
            h += AXIS + PAD
            if getattr(widget, "histogram_visible", False):
                h_gap = int(getattr(widget, "gap", 10))
                h_hw  = int(getattr(widget, "histogram_width", 120))
                w    += h_hw + h_gap
        else:
            # Viewer1D: PAD_L=58, PAD_R=12, PAD_T=12, PAD_B=36 + outer 10px pad each side
            w += 58 + 12 + 20   # PAD_L + PAD_R + outer
            h += 12 + 36 + 20   # PAD_T + PAD_B + outer
        return w, h
    except Exception:
        return 560, 340


# ---------------------------------------------------------------------------
# HTML builder
# ---------------------------------------------------------------------------

# Extra CSS injected when resizable=False:
# - hides every resize-handle div
# - locks the outermost container to exact pixel dims so it can't grow
_NO_RESIZE_CSS = """\
  /* ── resizable=False overrides ─────────────────────────────── */
  /* Hide all resize handles rendered by the widget JS */
  div[style*="nwse-resize"],
  div[title="Drag to resize"],
  div[title="Drag to resize figure"] {{
    display: none !important;
  }}
  /* Remove any bottom-right padding that was reserved for the handle */
  #widget-root > div {{
    padding-bottom: 0 !important;
    padding-right:  0 !important;
  }}
"""

_PAGE_TEMPLATE = """\
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<style>
  html, body {{
    margin: 0;
    padding: 0;
    background: transparent;
    overflow: hidden;
    /* Size the document exactly to the widget so scrollHeight == widget height */
    width:  {width}px;
    height: {height}px;
  }}
  #widget-root {{
    display: inline-block;
    line-height: 0;
  }}
{extra_css}\
</style>
</head>
<body>
<div id="widget-root"></div>
<script type="module">
const STATE = {state_json};
// Identifies this iframe to the parent-page anywidget bridge.
// null → no Pyodide wiring (plain notebook / static docs embed).
const FIG_ID = {fig_id_json};

// Loop-prevention flag: set while applying a parent-originated update so
// set() doesn't double-fire callbacks that save_changes() will also fire.
let _fromParent = false;
// Dirty flag: true only when model.set('event_json', ...) was called in the
// current transaction.
let _eventJsonDirty = false;

function makeModel(state) {{
  const _data   = Object.assign({{}}, state);
  const _cbs    = {{}};
  const _anyCbs = [];
  // Keys set() has touched while _fromParent (an inbound awi_state push) is
  // in effect, awaiting the matching save_changes() flush. Mirrors the
  // dirty-set pattern figure_esm.js's own createLocalModel() uses (see
  // mount()): the _fromParent branch below defers listener firing from
  // set() to save_changes() (see the comment there), but save_changes() was
  // firing EVERY registered change:* callback instead of only the key(s)
  // that changed. Concretely: a single set('event_json', ...) (the Python
  // targeted-widget-update side channel, _push_widget) also re-fired every
  // panel's change:panel_<id>_json listener, which re-parses that panel's
  // (untouched, stale) trait and overwrites p.state wholesale — silently
  // reverting the very widget edit event_json just applied, in the same
  // synchronous cascade. Only the _fromParent path needs tracking — the
  // local (!_fromParent) path already fires synchronously in set() itself.
  const _parentDirty = new Set();
  return {{
    get(key)      {{ return _data[key]; }},
    set(key, val) {{
      _data[key] = val;
      if (key === 'event_json') _eventJsonDirty = true;
      // Only fire synchronously when NOT processing an inbound awi_state
      // message (save_changes() will fire listeners once in that path).
      if (!_fromParent) {{
        const ev = 'change:' + key;
        if (_cbs[ev]) for (const cb of [..._cbs[ev]]) try {{ cb({{ new: val }}); }} catch(_) {{}}
        for (const cb of [..._anyCbs]) try {{ cb(); }} catch(_) {{}}
      }} else {{
        _parentDirty.add(key);
      }}
    }},
    save_changes() {{
      if (_parentDirty.size) {{
        // Fire only listeners for keys an inbound awi_state set() actually
        // touched since the last flush (each at most once) — not the whole
        // _cbs table. Snapshot + clear BEFORE invoking callbacks, since a
        // callback may itself call set()/save_changes() (re-entrant-safe).
        const keys = [..._parentDirty];
        _parentDirty.clear();
        for (const key of keys) {{
          const ev = 'change:' + key;
          if (_cbs[ev]) for (const cb of [..._cbs[ev]]) try {{ cb({{ new: _data[key] }}); }} catch(_) {{}}
        }}
        for (const cb of [..._anyCbs]) try {{ cb(); }} catch(_) {{}}
      }} else {{
        // Local (!_fromParent) path — unchanged: set() already fired
        // synchronously per-key, so this refires the full table (matches the
        // pre-existing local-set behaviour; harmless since _cbs entries are
        // typically no-ops for a key that hasn't just changed).
        for (const [ev, cbs] of Object.entries(_cbs))
          for (const cb of cbs) try {{ cb({{ new: _data[ev.slice(7)] }}); }} catch(_) {{}}
        for (const cb of _anyCbs) try {{ cb(); }} catch(_) {{}}
      }}
      // Forward interaction events to the parent-page Pyodide instance.
      if (!_fromParent && FIG_ID && window.parent !== window && _eventJsonDirty) {{
        _eventJsonDirty = false;
        try {{
          const ev = JSON.parse(_data.event_json || '{{}}');
          if (ev && ev.source !== 'python') {{
            window.parent.postMessage(
              {{ type: 'awi_event', figId: FIG_ID, data: _data.event_json }}, '*');
          }}
        }} catch(_) {{}}
      }} else {{
        _eventJsonDirty = false;
      }}
    }},
    on(event, cb)  {{
      if (event === "change") {{ _anyCbs.push(cb); return; }}
      (_cbs[event] = _cbs[event] || []).push(cb);
    }},
    off(event, cb) {{
      if (!event) {{ for (const k in _cbs) _cbs[k]=[]; _anyCbs.length=0; return; }}
      if (_cbs[event]) _cbs[event] = _cbs[event].filter(c => c !== cb);
    }},
    get model() {{ return this; }},
  }};
}}

const esmSource = {esm_json};
const blob    = new Blob([esmSource], {{ type: "text/javascript" }});
const blobUrl = URL.createObjectURL(blob);
const el      = document.getElementById("widget-root");
const model   = makeModel(STATE);

// render() returns an internal API ({{ panels, exportPNG, ... }}) that the PNG
// export protocol below needs.  Held here so the message listener can reach it.
let _aplRenderApi = null;

import(blobUrl).then(mod => {{
  const renderFn = mod.default?.render ?? mod.render;
  if (typeof renderFn === "function") {{
    _aplRenderApi = renderFn({{ model, el }});
    // Module scope is not global scope: without this, page.evaluate() and any
    // host page script cannot reach exportPNG (only the postMessage protocol
    // below can). anyplotlib.savefig() drives the export through this handle.
    window._aplRenderApi = _aplRenderApi;
    globalThis.__aplExportPNG = (o) => _aplRenderApi.exportPNG(o);
  }} else {{
    el.textContent = "ESM has no render() export";
  }}
}}).catch(err => {{
  el.textContent = "Widget load error: " + err;
  console.error(err);
}});

// ── Inbound state updates from parent-page Pyodide ───────────────────────────
window.addEventListener('message', (e) => {{
  if (!e.data) return;
  if (e.data.type === 'awi_state') {{
    _fromParent = true;
    const _t0 = performance.now();
    model.set(e.data.key, e.data.value);
    model.save_changes();
    if (e.data.key === 'image_b64') {{
      try {{
        globalThis.__apl_paint_ms = performance.now() - _t0;
        globalThis.__apl_paint_n = (globalThis.__apl_paint_n || 0) + 1;
        globalThis.__apl_paint_kind = 'base64';
      }} catch (_) {{}}
    }}
    _fromParent = false;
    return;
  }}
  // Binary image frame (raw pixels, no base64). Set the bytes under a parallel
  // `<key>_bytes` trait (a Uint8Array) that the draw path uses directly — no atob.
  // We also bump the base64 key to a short token so listeners keyed on it still
  // fire, without carrying the (large) base64 string.
  if (e.data.type === 'awi_state_binary') {{
    _fromParent = true;
    const _t0 = performance.now();
    const hdr = e.data.header || {{}};
    const bytes = e.data.buffer instanceof Uint8Array
      ? e.data.buffer : new Uint8Array(e.data.buffer);
    // Stash the raw bytes in a global side-table (the anywidget model does NOT
    // round-trip a Uint8Array set on an ad-hoc trait — model.get returns
    // undefined), then bump a small TOKEN trait to fire the ESM's change: event,
    // which reads the bytes from the side-table. Key = "<geom_trait>::<pixelKey>".
    const slot = (hdr.geom ? hdr.geom : 'fig') + '::' + e.data.key;
    (globalThis.__apl_pixbytes || (globalThis.__apl_pixbytes = {{}}))[slot] = bytes;
    model.set(slot, (bytes ? bytes.length : 0) + ':' + (globalThis.__apl_paint_n || 0));
    model.save_changes();                            // triggers the paint synchronously
    // Paint-latency telemetry (message receipt → draw done) for the binary path.
    try {{
      globalThis.__apl_paint_ms = performance.now() - _t0;
      globalThis.__apl_paint_n = (globalThis.__apl_paint_n || 0) + 1;
      globalThis.__apl_paint_kind = 'binary';
    }} catch (_) {{}}
    _fromParent = false;
    return;
  }}
}});

{png_harvest}
</script>
</body>
</html>
"""


# A host page (or the SpyDE report harvester) asks an embedded figure for a
# composite PNG over postMessage.  Both the standalone page and the navigated
# embed install this listener; each assigns ``globalThis.__aplExportPNG`` once
# its figure is mounted, which is also what makes "not ready yet" answerable.
PNG_HARVEST_LISTENER = '''\
// ── PNG export protocol ──────────────────────────────────────────────────────
// A parent page (or the SpyDE report harvester) asks this frame over
// postMessage for a composite PNG of the whole figure:
//   → { type: 'anyplotlib_export_png', requestId, opts }
// and receives back, on event.source (targetOrigin '*'):
//   ← { type: 'anyplotlib_export_png_result', requestId, dataUrl, width, height }
//   ← { type: 'anyplotlib_export_png_result', requestId, error }   (on failure)
// `opts` is forwarded verbatim to exportPNG:
//   { scale?, includeWidgets?, panelId?, source?, theme? }
//   source: 'view' | 'full' | 'native'   theme: 'current' | 'light' | 'dark'
window.addEventListener('message', (e) => {
  if (!e.data || e.data.type !== 'anyplotlib_export_png') return;
  const requestId = e.data.requestId;
  const source = e.source;
  const reply = (msg) => {
    try {
      if (source && typeof source.postMessage === 'function') {
        source.postMessage(Object.assign(
          { type: 'anyplotlib_export_png_result', requestId }, msg), '*');
      }
    } catch (_) {}
  };
  try {
    const exportPNG = globalThis.__aplExportPNG;
    if (typeof exportPNG !== 'function') {
      reply({ error: 'figure not ready (exportPNG unavailable)' });
      return;
    }
    Promise.resolve(exportPNG(e.data.opts || {}))
      .then((res) => reply({
        dataUrl: res.dataUrl, width: res.width, height: res.height }))
      .catch((err) => reply({ error: String(err && err.message || err) }));
  } catch (err) {
    reply({ error: String(err && err.message || err) });
  }
});
'''


def build_standalone_html(widget, *, resizable: bool = True,
                           fig_id: str | None = None) -> str:
    """Return a self-contained HTML page that renders *widget* interactively.

    Parameters
    ----------
    widget :
        Any ``anywidget.AnyWidget`` subclass with ``_esm`` defined.
    resizable : bool
        When ``True`` (default) the widget's built-in resize handle is
        preserved.  When ``False`` the handle is hidden via CSS and the page
        is sized exactly to the widget's natural dimensions.
    fig_id : str or None
        When provided, embedded as ``FIG_ID`` so the parent-page bridge
        can route ``postMessage`` state updates to this iframe.
    """
    state = _widget_state(widget)

    esm = getattr(widget, "_esm", "") or ""
    if hasattr(esm, "read_text"):
        esm = esm.read_text(encoding="utf-8")
    esm = str(esm)

    w, h = _widget_px(widget)
    extra_css = _NO_RESIZE_CSS.format() if not resizable else ""

    return _PAGE_TEMPLATE.format(
        width=w,
        height=h,
        extra_css=extra_css,
        state_json=script_json(state),
        esm_json=script_json(esm),
        fig_id_json=script_json(fig_id),
        png_harvest=PNG_HARVEST_LISTENER,
    )


def repr_html_iframe(widget, *, resizable: bool = False,
                     max_width: int = MAX_NOTEBOOK_WIDTH,
                     max_height: int = 800) -> str:
    """Return a centred, responsive ``<iframe srcdoc=...>`` embedding *widget*.

    Parameters
    ----------
    widget :
        Any ``anywidget.AnyWidget`` subclass.
    resizable : bool
        Passed to :func:`build_standalone_html`.  Default ``False`` for
        documentation embeds — hides the resize handle and sizes the iframe
        exactly to the widget.
    max_width : int
        Maximum display width in pixels.  Figures wider than this are scaled
        down proportionally via ``transform:scale()`` so they never overflow
        the notebook cell.  Default ``MAX_NOTEBOOK_WIDTH`` (860 px).
    max_height : int
        Upper bound on iframe height in pixels (only used when
        ``resizable=True``).
    """
    inner_html = build_standalone_html(widget, resizable=resizable)
    escaped    = escape(inner_html, quote=True)
    uid        = str(uuid4()).replace("-", "")

    w, h = _widget_px(widget)

    if not resizable:
        # ── Responsive fixed-size embed ────────────────────────────────────
        # The iframe always renders at its native resolution so the widget
        # is pixel-perfect on wide screens.  On narrower cells a CSS
        # transform:scale() shrinks it proportionally — CSS transforms
        # correctly route pointer events so interaction still works.
        #
        # The static scale (baked into the style attribute) renders correctly
        # before JS runs.  requestAnimationFrame defers the first JS
        # measurement until after layout is complete so offsetWidth is
        # always valid; the !avail guard prevents a not-yet-reflowed parent
        # from collapsing the wrapper.
        init_scale = min(1.0, max_width / w)
        init_w     = round(w * init_scale)
        init_h     = round(h * init_scale)
        scale_css  = f"{init_scale:.6f}".rstrip("0").rstrip(".")

        js = (
            f"(function(){{"
            f"var wrap=document.getElementById('vw-{uid}'),"
            f"ifr=wrap.querySelector('iframe'),"
            f"nw={w},nh={h};"
            f"function r(){{"
            f"var avail=wrap.parentElement?wrap.parentElement.offsetWidth:0;"
            f"if(!avail)return;"
            f"var s=Math.min(1,avail/nw);"
            f"wrap.style.width=Math.round(nw*s)+'px';"
            f"wrap.style.height=Math.round(nh*s)+'px';"
            f"ifr.style.transform='scale('+s+')';"
            f"}}"
            f"requestAnimationFrame(r);window.addEventListener('resize',r);"
            f"}})()"
        )

        return (
            f'<div style="display:block;text-align:center;line-height:0;margin:8px 0;">'
            f'<div id="vw-{uid}" style="display:inline-block;overflow:hidden;'
            f'position:relative;width:{init_w}px;height:{init_h}px;">'
            f'<iframe srcdoc="{escaped}" frameborder="0" scrolling="no" '
            f'allow="clipboard-write" '
            f'style="width:{w}px;height:{h}px;border:none;overflow:hidden;display:block;'
            f'transform-origin:top left;transform:scale({scale_css});'
            f'position:absolute;top:0;left:0;">'
            f'</iframe>'
            f'</div>'
            f'<script>{js}</script>'
            f'</div>'
        )
    else:
        # ── Resizable embed (fills cell width, auto-sizes height) ──────────
        return (
            f'<iframe id="vw-{uid}" srcdoc="{escaped}" frameborder="0" '
            f'allow="clipboard-write" '
            f'style="width:100%;height:{h}px;border:none;overflow:hidden;" '
            f'onload="setTimeout(function(){{'
            f'var f=document.getElementById(\'vw-{uid}\');'
            f'if(f&&f.contentWindow&&f.contentWindow.document.body){{'
            f'f.style.height=Math.min('
            f'f.contentWindow.document.body.scrollHeight+20,{max_height})+\'px\''
            f'}}}},'
            f'300)"></iframe>'
        )

