"""
widgets/_widgets2d.py
=====================
Interactive overlay widgets for 2-D image panels (Plot2D / InsetAxes).

Every 2-D widget accepts ``show_handles`` (default ``True``). When ``False``
the widget body still draws and stays fully hit-testable / draggable, but the
small square grab-handle dots are omitted — a cleaner look for a finished
annotation. It rides along in ``_data`` so it serialises into the panel state's
``overlay_widgets`` list and reaches the JS renderer unchanged.
"""

from __future__ import annotations
from anyplotlib.widgets._base import Widget


class RectangleWidget(Widget):
    """Draggable rectangle overlay widget for 2-D plots.

    Parameters
    ----------
    push_fn : Callable
        Update callback.
    x, y : float
        Top-left corner position in pixel/data coordinates.
    w, h : float
        Width and height in pixel/data coordinates.
    color : str, optional
        CSS colour for the rectangle outline. Default ``"#00e5ff"``.
    linewidth : float, optional
        Outline stroke width in px. Default 2.
    show_handles : bool, optional
        Draw the corner grab handles. Default ``True``.
    max_extent : float or (float, float), optional
        Maximum width/height in the widget's coordinates. A scalar caps both
        axes; a ``(max_w, max_h)`` pair caps them separately. When set, the
        rectangle physically stops growing at the cap while dragging — the
        dragged corner pins and the opposite corner stays put. ``None``
        (default) leaves it unbounded.

        Use this when the rectangle's area costs real work downstream — e.g. an
        integrating ROI whose size is a number of frames to read.
    """
    def __init__(self, push_fn, *, x, y, w, h, color="#00e5ff",
                 linewidth=2, show_handles=True, max_extent=None):
        if max_extent is None:
            max_w = max_h = None
        elif isinstance(max_extent, (tuple, list)):
            max_w, max_h = (float(max_extent[0]), float(max_extent[1]))
        else:
            max_w = max_h = float(max_extent)
        super().__init__("rectangle", push_fn,
                         x=float(x), y=float(y),
                         w=float(w), h=float(h), color=color,
                         linewidth=float(linewidth),
                         show_handles=bool(show_handles),
                         max_w=max_w, max_h=max_h)


class CircleWidget(Widget):
    """Draggable circle overlay widget for 2-D plots.

    Parameters
    ----------
    push_fn : Callable
        Update callback.
    cx, cy : float
        Center position in pixel/data coordinates.
    r : float
        Radius in pixel/data coordinates.
    color : str, optional
        CSS colour for the circle outline. Default ``"#00e5ff"``.
    linewidth : float, optional
        Outline stroke width in px. Default 2.
    show_handles : bool, optional
        Draw the radius grab handle. Default ``True``.
    """
    def __init__(self, push_fn, *, cx, cy, r, color="#00e5ff",
                 linewidth=2, show_handles=True):
        super().__init__("circle", push_fn,
                         cx=float(cx), cy=float(cy), r=float(r), color=color,
                         linewidth=float(linewidth),
                         show_handles=bool(show_handles))


class AnnularWidget(Widget):
    """Draggable annular (ring) overlay widget for 2-D plots.

    Parameters
    ----------
    push_fn : Callable
        Update callback.
    cx, cy : float
        Center position in pixel/data coordinates.
    r_outer, r_inner : float
        Outer and inner radii in pixel/data coordinates.
        Inner radius must be less than outer radius.
    color : str, optional
        CSS colour for the ring outline. Default ``"#00e5ff"``.
    linewidth : float, optional
        Outline stroke width in px. Default 2.
    show_handles : bool, optional
        Draw the inner/outer radius grab handles. Default ``True``.

    Raises
    ------
    ValueError
        If r_inner >= r_outer.
    """
    def __init__(self, push_fn, *, cx, cy, r_outer, r_inner, color="#00e5ff",
                 linewidth=2, show_handles=True):
        if r_inner >= r_outer:
            raise ValueError("r_inner must be < r_outer")
        super().__init__("annular", push_fn,
                         cx=float(cx), cy=float(cy),
                         r_outer=float(r_outer), r_inner=float(r_inner),
                         color=color, linewidth=float(linewidth),
                         show_handles=bool(show_handles))


class LineWidget(Widget):
    """Draggable two-endpoint line segment overlay widget for 2-D plots.

    A plain segment from ``(x1, y1)`` to ``(x2, y2)``: drag either endpoint
    handle to move that end, or drag the shaft to translate the whole
    segment.  Unlike :class:`ArrowWidget` it has no head, and unlike
    :class:`PolygonWidget` it does not close the path — this is the widget for
    a line profile, a cross-section cut, or a two-point measurement.

    Parameters
    ----------
    push_fn : Callable
        Update callback.
    x1, y1 : float
        First endpoint in pixel/data coordinates.
    x2, y2 : float
        Second endpoint in pixel/data coordinates.
    color : str, optional
        CSS colour for the segment. Default ``"#00e5ff"``.
    linewidth : float, optional
        Stroke width in px. Default 2.
    show_handles : bool, optional
        Draw the endpoint grab handles. Default ``True``.
    """
    def __init__(self, push_fn, *, x1, y1, x2, y2, color="#00e5ff",
                 linewidth=2, show_handles=True):
        super().__init__("line", push_fn,
                         x1=float(x1), y1=float(y1),
                         x2=float(x2), y2=float(y2),
                         color=color, linewidth=float(linewidth),
                         show_handles=bool(show_handles))

    @property
    def length(self) -> float:
        """Euclidean length of the segment in data coordinates."""
        return float(
            ((self.x2 - self.x1) ** 2 + (self.y2 - self.y1) ** 2) ** 0.5
        )


class CrosshairWidget(Widget):
    """Draggable crosshair overlay widget for 2-D plots.

    Parameters
    ----------
    push_fn : Callable
        Update callback.
    cx, cy : float
        Center position in pixel/data coordinates.
    color : str, optional
        CSS colour for the crosshair. Default ``"#00e5ff"``.
    linewidth : float, optional
        Line stroke width in px. Default 2.
    show_handles : bool, optional
        Draw the centre dot handle. Default ``True``.
    """
    def __init__(self, push_fn, *, cx, cy, color="#00e5ff", linewidth=2,
                 show_handles=True):
        super().__init__("crosshair", push_fn,
                         cx=float(cx), cy=float(cy), color=color,
                         linewidth=float(linewidth),
                         show_handles=bool(show_handles))


class PolygonWidget(Widget):
    """Draggable polygon overlay widget for 2-D plots.

    Parameters
    ----------
    push_fn : Callable
        Update callback.
    vertices : list of tuple
        Polygon vertices ``[(x0, y0), (x1, y1), ...]`` in pixel/data coordinates.
        Must have at least 3 vertices.
    color : str, optional
        CSS colour for the polygon outline. Default ``"#00e5ff"``.
    linewidth : float, optional
        Outline stroke width in px. Default 2.
    show_handles : bool, optional
        Draw the per-vertex grab handles. Default ``True``.

    Raises
    ------
    ValueError
        If fewer than 3 vertices provided.
    """
    def __init__(self, push_fn, *, vertices, color="#00e5ff", linewidth=2,
                 show_handles=True):
        verts = [[float(x), float(y)] for x, y in vertices]
        if len(verts) < 3:
            raise ValueError("polygon needs >= 3 vertices")
        super().__init__("polygon", push_fn, vertices=verts, color=color,
                         linewidth=float(linewidth),
                         show_handles=bool(show_handles))


class LabelWidget(Widget):
    """Text label overlay widget for 2-D plots.

    Parameters
    ----------
    push_fn : Callable
        Update callback.
    x, y : float
        Label position in pixel/data coordinates.
    text : str, optional
        Label text. Default ``"Label"``.
    fontsize : int, optional
        Font size in points. Default 14.
    color : str, optional
        CSS colour for the text. Default ``"#00e5ff"``.
    show_handles : bool, optional
        Draw the anchor grab handle. Default ``True``.
    """
    def __init__(self, push_fn, *, x, y, text="Label", fontsize=14,
                 color="#00e5ff", show_handles=True):
        super().__init__("label", push_fn,
                         x=float(x), y=float(y),
                         text=str(text), fontsize=int(fontsize), color=color,
                         show_handles=bool(show_handles))


class ArrowWidget(Widget):
    """Draggable arrow overlay widget for 2-D plots.

    The arrow tail sits at ``(x, y)`` and the head at ``(x + u, y + v)``, all in
    image-pixel coordinates. Dragging the body moves the whole arrow; dragging
    the head handle re-aims it (updates ``u``/``v``).

    Parameters
    ----------
    push_fn : Callable
        Update callback.
    x, y : float
        Tail position in pixel/data coordinates.
    u, v : float
        Arrow vector (head = tail + (u, v)) in pixel/data coordinates.
    color : str, optional
        CSS colour for the arrow. Default ``"#00e5ff"``.
    linewidth : float, optional
        Shaft line width in px. Default 2.
    show_handles : bool, optional
        Draw the tail/head grab handles. Default ``True``.
    """
    def __init__(self, push_fn, *, x, y, u, v, color="#00e5ff",
                 linewidth=2, show_handles=True):
        super().__init__("arrow", push_fn,
                         x=float(x), y=float(y),
                         u=float(u), v=float(v), color=color,
                         linewidth=float(linewidth),
                         show_handles=bool(show_handles))
