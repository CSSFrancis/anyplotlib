// figure_esm.js
// Unified JS renderer for the Figure widget.
// Each panel gets its own three-canvas stack (plot / overlay / markers).
// Panels are drawn independently; only the changed panel's listener fires.

function render({ model, el, onResize, onReadout }) {
  const dpr = window.devicePixelRatio || 1;

  // ── shared plot-area padding (mirrors 1D drawing constants) ─────────────
  // The image/plot area for BOTH 1D and 2D panels sits at:
  //   x: PAD_L → pw-PAD_R,   y: PAD_T → ph-PAD_B
  // This guarantees pixel-perfect alignment of all panels in a row/column.
  const PAD_L=58, PAD_R=12, PAD_T=12, PAD_B=42;

  // Tile-mode render diagnostics. OFF by default — a console.warn PER ANIMATION
  // FRAME per panel floods the teed renderer console (and the host app's log
  // relay) in normal use. Opt in with globalThis.__apl_tiledbg=true when
  // debugging a render decision ("why is it blurry / white / flashing"): it logs
  // which texture/passes drew, the detail region, and the contrast window.
  if (globalThis.__apl_tiledbg === undefined) globalThis.__apl_tiledbg = false;
  function _tiledbg(tag, msg) {
    if (!globalThis.__apl_tiledbg) return;
    try { console.warn(`[TILEDBG-JS:${tag}] ${msg}`); } catch (_) {}
  }

  // ── theme ────────────────────────────────────────────────────────────────
  function _isDarkBg(node) {
    while (node && node !== document.body) {
      const bg = window.getComputedStyle(node).backgroundColor;
      const m  = bg.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
      if (m) {
        const [r,g,b] = [+m[1],+m[2],+m[3]];
        if (!(r===0&&g===0&&b===0&&bg.includes('0)')))
          return (0.299*r + 0.587*g + 0.114*b) < 128;
      }
      node = node.parentElement;
    }
    return window.matchMedia('(prefers-color-scheme: dark)').matches;
  }

  function _makeTheme(dark) {
    return dark ? {
      bg:'#1e1e2e', bgPlot:'#181825', bgCanvas:'#181825',
      border:'#44475a', axisBg:'#1e1e2e',
      axisStroke:'rgba(98,114,164,0.5)', gridStroke:'rgba(98,114,164,0.18)',
      tickStroke:'#6272a4', tickText:'rgba(205,214,244,0.75)',
      unitText:'rgba(98,114,164,0.85)', dark:true,
    } : {
      bg:'#f0f0f0', bgPlot:'#ffffff', bgCanvas:'#ffffff',
      border:'#cccccc', axisBg:'#f0f0f0',
      axisStroke:'rgba(0,0,0,0.35)', gridStroke:'rgba(0,0,0,0.07)',
      tickStroke:'#666666', tickText:'rgba(40,40,40,0.85)',
      unitText:'rgba(100,100,100,0.85)', dark:false,
    };
  }

  let theme = _makeTheme(_isDarkBg(el));
  const _mq = window.matchMedia('(prefers-color-scheme: dark)');
  _mq.addEventListener('change', () => { theme = _makeTheme(_isDarkBg(el)); redrawAll(); });
  new MutationObserver(() => { theme = _makeTheme(_isDarkBg(el)); redrawAll(); })
    .observe(document.documentElement, { attributes:true,
      attributeFilter:['data-jp-theme-name','data-vscode-theme-kind','class'] });

  // ── shared math helpers ──────────────────────────────────────────────────
  function findNice(t) {
    if (t<=0) return 1;
    const mag = Math.pow(10, Math.floor(Math.log10(t)));
    let best=mag, bd=Math.abs(t-mag);
    for (const n of [1,2,2.5,5,10]) { const v=n*mag,d=Math.abs(t-v); if(d<bd){best=v;bd=d;} }
    return best;
  }
  function fmtVal(v) {
    const a=Math.abs(v);
    if(a===0) return '0';
    if(a>=1e4) return v.toExponential(1);
    if(a>=100) return v.toFixed(0);
    // Strip trailing zeros so a "nice" value reads compactly (2.00 → 2,
    // 0.2500 → 0.25) instead of overflowing labels/scale bar with dead digits.
    if(a>=1)   return stripZeros(v.toFixed(2));
    if(a>=1e-2)return stripZeros(v.toFixed(4));
    return v.toExponential(1);
  }
  function stripZeros(s){ return s.indexOf('.')<0 ? s : s.replace(/\.?0+$/,''); }
  // One format for BOTH ends of a range, so "0.02" never sits beside
  // "-5.0e-3": exponent notation when the larger magnitude is outside
  // [1e-2, 1e4), else fixed with enough decimals to show the ends exactly
  // (three significant digits of the span, so +/-1.25 reads 1.25 and not 1.3;
  // at most four decimals).  Non-finite ends format as '' and are not drawn.
  // Mirrored by Python's colorbar_texts.
  function fmtRange(lo, hi) {
    if(!Number.isFinite(lo)||!Number.isFinite(hi)) return ['',''];
    const big=Math.max(Math.abs(lo),Math.abs(hi));
    if(big===0) return ['0','0'];
    if(big>=1e4||big<1e-2) return [lo.toExponential(1), hi.toExponential(1)];
    const span=Math.abs(hi-lo)||big;
    const decimals=Math.min(4,Math.max(0,Math.ceil(-Math.log10(span))+2));
    return [stripZeros(lo.toFixed(decimals)), stripZeros(hi.toFixed(decimals))];
  }
  function _axisValToFrac(arr,val) {
    if(arr.length<2) return 0;
    const n=arr.length, asc=arr[n-1]>=arr[0];
    if(asc?val<=arr[0]:val>=arr[0]) return 0;
    if(asc?val>=arr[n-1]:val<=arr[n-1]) return 1;
    let lo=0,hi=n-2;
    while(lo<hi){const mid=(lo+hi)>>1;const ok=asc?(arr[mid]<=val&&val<arr[mid+1]):(arr[mid]>=val&&val>arr[mid+1]);if(ok){lo=mid;break;}if(asc?arr[mid+1]<=val:arr[mid+1]>=val)lo=mid+1;else hi=mid;}
    return (lo+(val-arr[lo])/(arr[lo+1]-arr[lo]))/(n-1);
  }
  function _axisFracToVal(arr,frac) {
    if(arr.length<2) return arr.length?arr[0]:0;
    const n=arr.length, pos=Math.max(0,Math.min(1,frac))*(n-1), lo=Math.min(Math.floor(pos),n-2), t=pos-lo;
    return arr[lo]+t*(arr[lo+1]-arr[lo]);
  }
  // Blend a #rrggbb / #rgb colour toward white by `amt` (0=unchanged, 1=white).
  function _brightenColor(hex, amt=0.45) {
    if(!hex||hex[0]!=='#') return hex;
    let r,g,b;
    if(hex.length===4){r=parseInt(hex[1]+hex[1],16);g=parseInt(hex[2]+hex[2],16);b=parseInt(hex[3]+hex[3],16);}
    else{r=parseInt(hex.slice(1,3),16);g=parseInt(hex.slice(3,5),16);b=parseInt(hex.slice(5,7),16);}
    if(isNaN(r)||isNaN(g)||isNaN(b)) return hex;
    r=Math.min(255,Math.round(r+(255-r)*amt));g=Math.min(255,Math.round(g+(255-g)*amt));b=Math.min(255,Math.round(b+(255-b)*amt));
    return `#${r.toString(16).padStart(2,'0')}${g.toString(16).padStart(2,'0')}${b.toString(16).padStart(2,'0')}`;
  }

  // ── b64 array decode helpers ─────────────────────────────────────────────
  // Convert a base-64 string (little-endian raw bytes) to a JS TypedArray.
  // TypedArrays support .length and [i] indexing so they are drop-in
  // replacements for plain arrays in all draw / hit-test functions.
  function _decodeF64(b64) {
    const bin = atob(b64);
    const buf = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) buf[i] = bin.charCodeAt(i);
    return new Float64Array(buf.buffer);
  }
  function _decodeF32(b64) {
    const bin = atob(b64);
    const buf = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) buf[i] = bin.charCodeAt(i);
    return new Float32Array(buf.buffer);
  }
  function _decodeI32(b64) {
    const bin = atob(b64);
    const buf = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) buf[i] = bin.charCodeAt(i);
    return new Int32Array(buf.buffer);
  }

  // ── rich-text (mini-TeX) label engine ───────────────────────────────────
  // Canvas cannot run MathJax, so labels support a small TeX subset that
  // covers scientific axis labels.  Inside $...$ delimiters:
  //   ^{...} / ^x      superscript (exponents)        $10^{-3}$, $x^2$
  //   _{...} / _x      subscript                      $E_F$, $k_{B}T$
  //   \alpha ... \Omega  Greek letters                $\mu m$, $\Delta E$
  //   \times \cdot \pm \degree \AA \infty \propto \approx \leq \geq \neq
  //   \partial \nabla \hbar \rightarrow \leftarrow \sum \int \sqrt \prime
  //   \mathrm{...}     upright (non-italic) text inside math
  // Letters in math mode render italic; text outside $...$ is untouched.
  // \$ renders a literal dollar sign.  Nested scripts are flattened to one
  // level.  Python passes label strings through verbatim — all parsing
  // happens here at draw time.
  const _TEX_SYM = {
    alpha:'α', beta:'β', gamma:'γ', delta:'δ', epsilon:'ε', varepsilon:'ε',
    zeta:'ζ', eta:'η', theta:'θ', vartheta:'ϑ', iota:'ι', kappa:'κ',
    lambda:'λ', mu:'μ', nu:'ν', xi:'ξ', pi:'π', rho:'ρ', sigma:'σ',
    tau:'τ', upsilon:'υ', phi:'φ', varphi:'φ', chi:'χ', psi:'ψ', omega:'ω',
    Gamma:'Γ', Delta:'Δ', Theta:'Θ', Lambda:'Λ', Xi:'Ξ', Pi:'Π',
    Sigma:'Σ', Upsilon:'Υ', Phi:'Φ', Psi:'Ψ', Omega:'Ω',
    times:'×', cdot:'·', pm:'±', mp:'∓', deg:'°', degree:'°', circ:'°',
    AA:'Å', angstrom:'Å', infty:'∞', propto:'∝', approx:'≈', sim:'~',
    le:'≤', leq:'≤', ge:'≥', geq:'≥', ne:'≠', neq:'≠',
    rightarrow:'→', to:'→', leftarrow:'←', leftrightarrow:'↔',
    partial:'∂', nabla:'∇', hbar:'ℏ', ell:'ℓ', prime:'′',
    sqrt:'√', sum:'Σ', int:'∫', langle:'⟨', rangle:'⟩',
  };

  // Parse a label into runs: [{t, lvl, it}] — lvl 0 normal / +1 sup / -1 sub.
  function _texRuns(text) {
    const runs = [];
    const s = String(text);
    const n = s.length;
    let i = 0, math = false;
    let buf = '', bufLvl = 0, bufIt = false;
    const flush = () => { if (buf) { runs.push({ t: buf, lvl: bufLvl, it: bufIt }); buf = ''; } };
    const emit = (t, lvl, it) => {
      if (lvl !== bufLvl || it !== bufIt) { flush(); bufLvl = lvl; bufIt = it; }
      buf += t;
    };
    // Read a {…} group (brace-balanced), a \command, or a single char.
    // Assumes i points just past the ^ / _ that introduced the group.
    function readGroup() {
      if (i < n && s[i] === '{') {
        let depth = 1, g = ''; i++;
        while (i < n) {
          const c = s[i];
          if (c === '{') depth++;
          else if (c === '}') { depth--; if (!depth) { i++; break; } }
          g += c; i++;
        }
        return g;
      }
      if (i < n && s[i] === '\\') {
        let j = i + 1, name = '';
        while (j < n && /[A-Za-z]/.test(s[j])) { name += s[j]; j++; }
        i = j;
        return '\\' + name;
      }
      return i < n ? s[i++] : '';
    }
    while (i < n) {
      const c = s[i];
      if (c === '\\' && s[i + 1] === '$') { emit('$', 0, false); i += 2; continue; }
      if (c === '$') { math = !math; i++; continue; }
      if (!math) { emit(c, 0, false); i++; continue; }
      if (c === '^' || c === '_') {
        i++;
        const lvl = c === '^' ? 1 : -1;
        // Re-parse group content in math mode so \symbols work inside {…};
        // nested scripts collapse to this run's level.
        for (const r of _texRuns('$' + readGroup() + '$')) emit(r.t, lvl, r.it);
        continue;
      }
      if (c === '\\') {
        let j = i + 1, name = '';
        while (j < n && /[A-Za-z]/.test(s[j])) { name += s[j]; j++; }
        if (name === 'mathrm' && s[j] === '{') {
          i = j;
          emit(readGroup(), 0, false);
          continue;
        }
        const sym = _TEX_SYM[name];
        emit(sym !== undefined ? sym : name, 0, false);
        i = j;
        if (s[i] === ' ') i++;   // TeX swallows the space after a command
        continue;
      }
      emit(c, 0, /[A-Za-z]/.test(c));   // math-mode letters are italic
      i++;
    }
    flush();
    return runs;
  }

  // Measure + position runs left-to-right at base size px.
  function _texLayout(ctx, text, px, weight, family) {
    const out = [];
    let xOff = 0;
    for (const r of _texRuns(text)) {
      const size = r.lvl ? Math.max(7, px * 0.68) : px;
      // Offsets are relative to the shared alphabetic baseline: superscripts
      // rise so their top roughly aligns with the base cap height (avoids
      // clipping in the 12-px title strip); subscripts drop below baseline.
      const dy   = r.lvl === 1 ? -px * 0.28 : r.lvl === -1 ? px * 0.16 : 0;
      const font = (r.it ? 'italic ' : '') + (weight ? weight + ' ' : '')
                 + size.toFixed(1) + 'px ' + family;
      ctx.font = font;
      out.push({ t: r.t, x: xOff, dy, font });
      xOff += ctx.measureText(r.t).width;
    }
    return { runs: out, w: xOff };
  }

  // Draw a (possibly TeX-formatted) label.  Respects the caller's fillStyle
  // and textBaseline; alignment is handled internally via opts.align so it
  // stays correct for multi-run TeX strings.
  //   _drawTex(ctx, '$10^{-3}$ counts', x, y, 12, {align:'right', weight:'bold'})
  function _drawTex(ctx, text, x, y, px, opts) {
    const o = opts || {};
    const family = o.family || 'sans-serif';
    const weight = o.weight || '';
    const t = text == null ? '' : String(text);
    if (!t) return;
    ctx.save();
    if (t.indexOf('$') === -1) {          // fast path — no math segments
      ctx.font = (weight ? weight + ' ' : '') + px + 'px ' + family;
      ctx.textAlign = o.align || 'center';
      ctx.fillText(t, x, y);
      ctx.restore();
      return;
    }
    const lay = _texLayout(ctx, t, px, weight, family);
    const align = o.align || 'center';
    let x0 = x;
    if (align === 'center') x0 = x - lay.w / 2;
    else if (align === 'right') x0 = x - lay.w;
    // Draw all runs on one shared alphabetic baseline so sup/sub offsets are
    // consistent across font sizes.  Convert the caller's baseline so TeX
    // text sits at exactly the same height a plain fillText would.
    // TextMetrics.fontBoundingBoxAscent is measured RELATIVE TO the current
    // textBaseline, so the alphabetic-baseline offset is the difference of
    // the ascent measured under each baseline.
    ctx.font = (weight ? weight + ' ' : '') + px + 'px ' + family;
    let yb = y;
    const fmCur = ctx.measureText('Mg');
    if (fmCur.fontBoundingBoxAscent != null) {
      const ascCur = fmCur.fontBoundingBoxAscent;
      ctx.textBaseline = 'alphabetic';
      yb = y + (ctx.measureText('Mg').fontBoundingBoxAscent - ascCur);
    } else {
      const bl = ctx.textBaseline;   // heuristic fallback (old browsers)
      if (bl === 'middle') yb = y + px * 0.30;
      else if (bl === 'top' || bl === 'hanging') yb = y + px * 0.78;
      else if (bl === 'bottom' || bl === 'ideographic') yb = y - px * 0.20;
      ctx.textBaseline = 'alphabetic';
    }
    ctx.textAlign = 'left';
    for (const r of lay.runs) {
      ctx.font = r.font;
      ctx.fillText(r.t, x0 + r.x, yb + r.dy);
    }
    ctx.restore();
  }

  // ── 2D gutter geometry helpers ───────────────────────────────────────────
  // The colorbar's rotated-label gutter: the label's font size plus a margin.
  function _cbLabelW(st) {
    return st && st.colorbar_label
      ? Math.round((st.colorbar_label_size || 10) + 8) : 0;
  }

  // Characters budgeted for the display_min / display_max values beside the
  // strip.  fmtRange is at most 7 characters in ordinary use ("-0.1234",
  // "-1.2e+5"); the budget is fixed at that so the image does not wobble as the
  // contrast handles are dragged, and grows only for the rare longer strings
  // (a three-digit exponent, "-1.2e+308"), which would otherwise be clipped.
  // Mirrored by Python's _colorbar_value_chars.
  function _cbValueChars(st) {
    let chars = 7;
    if (st && st.display_min != null && st.display_max != null) {
      const [lo, hi] = fmtRange(st.display_min, st.display_max);
      chars = Math.max(chars, lo.length, hi.length);
    }
    return chars;
  }

  // Below this many px of image, the value gutter is dropped (strip and label
  // stay) so a narrow grid cell does not push the colorbar over its neighbour.
  const CB_MIN_IMAGE_W = 40;

  // Width of the gutter the display_min / display_max values are written in,
  // right of the strip: the character budget at ~0.6 em of the tick size,
  // plus a 3 px gap off the strip.  With `availW` (the width the image and
  // colorbar share, after the axis gutters) it is 0 when the values would not
  // leave CB_MIN_IMAGE_W for the image.  Mirrored in Python's plot_box.
  function _cbTickW(st, availW) {
    const tick = (st && st.tick_size) || 10;
    const w = Math.round(_cbValueChars(st) * 0.6 * tick) + 3;
    if (availW != null && availW - _cbGap(st) - 16 - _cbLabelW(st) - w < CB_MIN_IMAGE_W)
      return 0;
    return w;
  }

  // Total width reserved for the colorbar (strip + value gutter + rotated-
  // label gutter).  0 when the colorbar is hidden.  The image area shrinks by
  // this amount so the strip, its numbers and its label always fit inside the
  // panel.
  function _cbWidth(st, availW) {
    if (!st || !st.show_colorbar || st.is_rgb) return 0;
    return 16 + _cbTickW(st, availW) + _cbLabelW(st);
  }

  // Gap between the right edge of the image and the colorbar strip. Without a
  // real gap the strip reads as part of the image — most plots have no
  // colorbar_label, so the label gutter that would otherwise separate them is
  // zero-width. Overridable per panel via colorbar_pad (set_colorbar_pad).
  const CB_GAP = 6;
  function _cbGap(st) {
    const v = st && st.colorbar_pad;
    return (v == null) ? CB_GAP : Math.max(0, v);
  }

  // Height of the title strip.  Stays at PAD_T for default-size plain titles
  // so existing layouts are pixel-identical; grows for title_size > 11 and
  // for TeX titles (superscripts rise above the cap height) so 2D titles are
  // never clipped.  1D/bar use the fixed strip and clamp the drawn size
  // instead (see _titlePx).
  function _padT(st) {
    if (!st || !st.title) return PAD_T;
    const ts = st.title_size || 11;
    const hasTex = String(st.title).indexOf('$') !== -1;
    if (ts <= 11 && !hasTex) return PAD_T;
    return Math.max(PAD_T, Math.ceil(ts * 1.3) + (hasTex ? 4 : 2));
  }

  // Drawn title size for panels with a fixed PAD_T strip (1D / bar): clamp
  // so ascenders, descenders, and TeX superscripts always fit.
  function _titlePx(st) {
    const ts = st.title_size || 11;
    const hasTex = st.title && String(st.title).indexOf('$') !== -1;
    return Math.min(ts, hasTex ? 10 : 11);
  }

  // ── shared constants ──────────────────────────────────────────────────────
  const STATS_DIV_CSS =
    'position:absolute;top:4px;left:4px;padding:4px 7px;' +
    'background:rgba(0,0,0,0.65);color:#e0e0e0;font-size:10px;' +
    'font-family:monospace;border-radius:4px;pointer-events:none;' +
    'white-space:pre;line-height:1.5;z-index:20;display:none;';

  // ── shared helpers ────────────────────────────────────────────────────────

  // Preserve JS-side view state when Python pushes data without requesting a
  // view change (_view_from_python === false).
  function _preserveView(p2, newState) {
    if (!p2.state) return;
    if (p2.kind === '2d' && !newState._view_from_python) {
      newState.zoom     = p2.state.zoom;
      newState.center_x = p2.state.center_x;
      newState.center_y = p2.state.center_y;
    } else if ((p2.kind === '1d' || p2.kind === 'bar') && !newState._view_from_python) {
      newState.view_x0 = p2.state.view_x0;
      newState.view_x1 = p2.state.view_x1;
    } else if (p2.kind === '3d' && !newState._view_from_python) {
      newState.azimuth   = p2.state.azimuth;
      newState.elevation = p2.state.elevation;
      newState.zoom      = p2.state.zoom;
    }
  }

  // Geometry channel: heavy keys (vertices/image/colormap) travel in a
  // separate panel_<id>_geom trait, re-sent only when they change.  The light
  // view payload carries _geom_rev; we cache the decoded geom per panel and
  // splice it into the state before drawing, so view-only updates (highlight,
  // camera, planes) never re-parse or re-transmit geometry.
  function _applyGeom(p2, state) {
    if (state._geom_rev === undefined) return state;   // panel has no geom channel
    // Splice the last-decoded geometry into the view state.  The geom trait
    // is sent before (or with) the first view payload and only re-sent on
    // change, so the cache is the authoritative geometry for every frame;
    // _geom_rev is carried for diagnostics / future invalidation but we
    // always apply the cache when present (never drop geometry on a rev skew).
    if (p2._geomCache) Object.assign(state, p2._geomCache);
    return state;
  }

  // Serialise a panel's VIEW state for the light `panel_<id>_json` trait,
  // EXCLUDING the heavy geometry keys that `_applyGeom` splices in from the
  // cache (`image_b64`, `colormap_data`, `*_b64`, and their binary `*_bytes`
  // companions).  The interaction handlers (wheel/pan/orbit) write the view
  // state back on every mouse tick; without this strip they re-serialise —
  // and re-transmit — the full frame each tick.  For the BINARY path that is
  // `JSON.stringify` of a Uint8Array → a `{"0":..,"1":..}` object with one
  // key per byte (millions of entries), which stalls zoom on large images.
  // Python's `_push` already keeps geometry off this trait; the echo-back
  // listener re-splices geom from `_geomCache`, so dropping it here is safe
  // (the geometry is never actually lost — only kept out of the light path).
  function _viewStateJson(p2) {
    const st = p2.state;
    if (!st) return '{}';
    const geom = p2._geomCache;
    if (!geom) return JSON.stringify(st);
    // Fast path: shallow-clone without the cached geom keys (and their
    // `_bytes` variants).  Object.keys(geom) is exactly what _applyGeom
    // merged in, so this auto-tracks any future geom key with no hardcoded
    // list to drift out of sync with the Python-side _GEOM_KEYS.
    const skip = new Set(Object.keys(geom));
    const view = {};
    for (const k in st) { if (!skip.has(k)) view[k] = st[k]; }
    return JSON.stringify(view);
  }

  // Parse the geom trait into the per-panel cache. PRESERVES any binary pixel
  // bytes (`*_bytes`, delivered on the companion trait) — the slimmed geom JSON
  // carries only the LUT/flags now, and it may arrive AFTER the binary frame, so
  // replacing the cache wholesale would drop the pixels. Re-splice them.
  function _loadGeom(p2, raw, rev) {
    try {
      const prev = p2._geomCache || {};
      const next = JSON.parse(raw || '{}');
      for (const k in prev) {
        if (k.endsWith('_bytes') && next[k] === undefined) next[k] = prev[k];
      }
      // A live binary frame (setImage, or a PLOTBIN push) is drawn from
      // `image_b64_bytes`, and the token in `image_b64` is the cache key for
      // exactly those bytes. A geom push carrying base64 would replace the key
      // while the bytes stay, freezing the display on whatever was last drawn.
      // A push with its own token is newer and wins.
      if (typeof prev.image_b64 === 'string' && prev.image_b64.startsWith('\u0000bin:')
          && next.image_b64_bytes
          && !(typeof next.image_b64 === 'string' && next.image_b64.startsWith('\u0000bin:')))
        next.image_b64 = prev.image_b64;
      p2._geomCache = next;
      p2._geomRev = rev;
    } catch (_) {}
  }

  // Factory: returns a debounced commit function.
  // onCommit is called once per animation frame after the last request.
  function _makeCommitter(onCommit) {
    let pending = false;
    return function() {
      if (pending) return; pending = true;
      requestAnimationFrame(() => { pending = false; onCommit(); });
    };
  }

  // Factory: returns { clear(), arm(mx, my, e, extraFields?) } for the
  // pointer_settled dwell-timer pattern.  extraFields is an optional
  // zero-arg callback that returns extra fields to merge into the event.
  function _makeSettledScheduler(p) {
    let timer = null, startX = 0, startY = 0, startTs = 0;
    return {
      clear() { clearTimeout(timer); timer = null; },
      arm(mx, my, e, extraFields) {
        const ms = p.state?.pointer_settled_ms ?? 0;
        if (ms <= 0) return;
        const delta = p.state?.pointer_settled_delta ?? 4;
        clearTimeout(timer);
        startX = mx; startY = my; startTs = performance.now();
        const mods = _modifiers(e);
        timer = setTimeout(() => {
          if (Math.hypot(p.mouseX - startX, p.mouseY - startY) <= delta) {
            const _now = performance.now();
            _emitEvent(p.id, 'pointer_settled', null, {
              time_stamp: _now / 1000, modifiers: mods,
              button: null, buttons: 0,
              x: Math.round(p.mouseX), y: Math.round(p.mouseY),
              dwell_ms: _now - startTs,
              ...(extraFields ? extraFields() : {}),
            });
          }
        }, ms);
      }
    };
  }

  // ── per-panel frame timing ────────────────────────────────────────────────
  // Called at the entry of every draw function (draw2d / draw1d / draw3d /
  // drawBar).  Records a high-resolution timestamp in a 60-entry rolling
  // buffer on the panel object, then:
  //   • updates window._aplTiming[p.id]  — always, for Playwright readback
  //   • updates p.statsDiv text          — only when display_stats is true
  //
  // Placing the call at the *start* of each draw function means we measure
  // the inter-trigger interval: how often the CPU initiates a render, which
  // is the right metric for both interactive (pan/zoom) and data-push paths.
  const _FRAME_BUF = 60;

  function _recordFrame(p) {
    const now = performance.now();
    p.frameTimes.push(now);
    if (p.frameTimes.length > _FRAME_BUF) p.frameTimes.shift();

    const n = p.frameTimes.length;

    // Always keep the global timing dict fresh so Playwright can read it back
    // at any point via window._aplTiming[panelId].
    if (!window._aplTiming) window._aplTiming = {};

    if (n >= 2) {
      let sum = 0, minDt = Infinity, maxDt = -Infinity;
      for (let i = 1; i < n; i++) {
        const dt = p.frameTimes[i] - p.frameTimes[i - 1];
        sum += dt; if (dt < minDt) minDt = dt; if (dt > maxDt) maxDt = dt;
      }
      const mean_ms = sum / (n - 1);
      const fps     = 1000 * (n - 1) / (now - p.frameTimes[0]);
      window._aplTiming[p.id] = {
        count: n, fps, mean_ms, min_ms: minDt, max_ms: maxDt,
      };

      if (p.statsDiv && model.get('display_stats')) {
        p.statsDiv.style.display = 'block';
        p.statsDiv.textContent   =
          `FPS  ${fps.toFixed(1)}\n` +
          ` dt  ${mean_ms.toFixed(1)} ms\n` +
          `min  ${minDt.toFixed(1)} ms\n` +
          `max  ${maxDt.toFixed(1)} ms`;
      }
    }
  }
  // Static layout styles live in the _css traitlet (.apl-scale-wrap /
  // .apl-outer).  Only the two dynamic properties — transform and
  // marginBottom — are ever written here at runtime.
  const scaleWrap = document.createElement('div');
  scaleWrap.classList.add('apl-scale-wrap');
  el.appendChild(scaleWrap);

  const outerDiv = document.createElement('div');
  outerDiv.classList.add('apl-outer');
  // .apl-outer only supplies position:relative on the anywidget path (it lives
  // in Figure._css). A bare mount() page would leave outerDiv static and every
  // absolutely-positioned child would anchor elsewhere. No-op when the class applies.
  outerDiv.style.position = 'relative';
  scaleWrap.appendChild(outerDiv);

  const gridDiv = document.createElement('div');
  gridDiv.style.cssText = `display:grid;gap:4px;background:${theme.bg};padding:8px;border-radius:4px;`;
  outerDiv.appendChild(gridDiv);

  // ── Inset overlay container ───────────────────────────────────────────────
  // Covers the grid content area (inside gridDiv's 8 px padding).
  // Individual insetDivs restore pointer-events:all so they capture mouse events.
  const insetsContainer = document.createElement('div');
  insetsContainer.style.cssText =
    'position:absolute;top:8px;left:8px;pointer-events:none;z-index:20;overflow:visible;';
  outerDiv.appendChild(insetsContainer);

  // ── Callout overlay canvas ────────────────────────────────────────────────
  // A figure-level canvas covering the grid content area (inside gridDiv's
  // 8 px padding), used to draw mark_inset-style region indications: a dashed
  // source rectangle on the parent panel + leader lines out to the inset.
  // It spans the whole figure because leaders cross panel boundaries.  Sits
  // ABOVE panel content / insets but BELOW the maximized-inset float (z 45) and
  // the resize handle (z 100); pointer-events:none so it never eats clicks.
  const calloutCanvas = document.createElement('canvas');
  calloutCanvas.style.cssText =
    'position:absolute;top:8px;left:8px;pointer-events:none;z-index:30;';
  outerDiv.appendChild(calloutCanvas);
  const calloutCtx = calloutCanvas.getContext('2d');

  // ── Figure-level annotation overlay canvas ────────────────────────────────
  // Content annotations (text / circle / rect / arrow) positioned in FIGURE
  // FRACTIONS, drawn OVER all panels + insets + callouts.  These are CONTENT
  // (always exported), unlike the hover/selection outlines (DOM chrome, never
  // exported).  pointer-events default OFF so normal panel interaction is
  // untouched; toggled ON only while edit_chrome is active so the markers can
  // be dragged.  Sits above callouts (z 30) but below the resize handle (z 100).
  const figMarkerCanvas = document.createElement('canvas');
  figMarkerCanvas.style.cssText =
    'position:absolute;top:8px;left:8px;pointer-events:none;z-index:35;';
  outerDiv.appendChild(figMarkerCanvas);
  const figMarkerCtx = figMarkerCanvas.getContext('2d');

  // Inset layout constants
  const INSET_TITLE_H = 22;   // px — title bar height
  const INSET_GAP     = 8;    // px — gap between stacked insets in same corner
  const INSET_MARGIN  = 10;   // px — distance from figure edge to first inset
  const INSET_RESIZE_PX = 12; // px — edit-mode bottom-right resize handle
  const INSET_MIN_PX  = 64;   // px — min inset dim on drag (matches Python clamp)
  const INSET_DRAG_THRESH = 3;// px — move before a pointerdown becomes a drag

  // An inset with no title (empty/whitespace) hides its title-bar strip
  // entirely — the content fills the whole box, no useless empty header.
  // This is the ONE place that decides "does this inset have a bar"; every
  // layout computation (stack height, drag/resize clamps) reads through it
  // instead of the raw INSET_TITLE_H constant so a title-less inset's box
  // height equals its content height exactly (no phantom gap at the top).
  function _hasInsetTitle(spec) {
    return !!(spec && spec.title && String(spec.title).trim());
  }
  function _insetTitleH(spec) {
    return _hasInsetTitle(spec) ? INSET_TITLE_H : 0;
  }
  // Active inset move / resize drag (edit mode). See _wireInsetDrag.
  // {p, mode:'move'|'resize', snap:{layout,spec}, ...} or null.
  let _insetDrag = null;

  // Resize handle (figure-level)
  const resizeHandle = document.createElement('div');
  resizeHandle.style.cssText =
    'position:absolute;bottom:2px;right:2px;width:16px;height:16px;cursor:nwse-resize;' +
    'background:linear-gradient(135deg,transparent 50%,#888 50%);border-radius:0 0 4px 0;z-index:100;';
  resizeHandle.title = 'Drag to resize figure';
  outerDiv.appendChild(resizeHandle);

  const sizeLabel = document.createElement('div');
  sizeLabel.style.cssText =
    'position:absolute;bottom:22px;right:22px;padding:7px 14px;background:rgba(0,0,0,0.65);' +
    'color:white;font-size:12px;font-family:monospace;border-radius:5px;display:none;pointer-events:none;z-index:21;';
  outerDiv.appendChild(sizeLabel);

  // ── Help badge (figure-level) ─────────────────────────────────────────────
  // A small '?' button in the top-right corner of the figure.
  //   • Hidden until the mouse enters outerDiv (plot "active").
  //   • Stays visible while the help card is open, even after mouse-leave.
  //   • Rounded square, tucked into the right padding band so it never
  //     overlaps plot content.
  //   • Clicking toggles the help card; click again (or mouse-leave with
  //     card closed) hides the button again.
  const _BTN_BG        = 'rgba(100,100,120,0.72)';
  const _BTN_BG_ACTIVE = 'rgba(75,120,210,0.92)';

  const helpBtn = document.createElement('div');
  helpBtn.style.cssText =
    'position:absolute;top:9px;right:6px;width:20px;height:20px;' +
    'border-radius:4px;background:' + _BTN_BG + ';color:#fff;' +
    'font-size:12px;font-weight:bold;font-family:sans-serif;' +
    'display:none;align-items:center;justify-content:center;' +
    'cursor:pointer;z-index:50;user-select:none;line-height:1;' +
    'box-shadow:0 1px 4px rgba(0,0,0,0.35);';
  helpBtn.textContent = '?';
  helpBtn.title = 'Show help';
  outerDiv.appendChild(helpBtn);

  // Export badge. Hosts (JupyterLab, PyCharm, VS Code) routinely swallow
  // `contextmenu` and Cmd+C before the page sees them, so the menu must also be
  // reachable by an ordinary left click.
  const exportBtn = document.createElement('div');
  exportBtn.style.cssText =
    'position:absolute;top:9px;right:30px;width:20px;height:20px;' +
    'border-radius:4px;background:' + _BTN_BG + ';color:#fff;' +
    'font-size:12px;font-family:sans-serif;' +
    'display:flex;align-items:center;justify-content:center;' +
    'cursor:pointer;z-index:50;user-select:none;line-height:1;' +
    'box-shadow:0 1px 4px rgba(0,0,0,0.35);' +
    // Hidden by opacity, NOT display:none — the latter drops the badge out of
    // the tab order, so a keyboard-only user could never reach it. At opacity 0
    // it paints nothing, so screenshots stay clean either way.
    'opacity:0;pointer-events:none;transition:opacity 120ms linear;';
  exportBtn.textContent = '\u2913';           // ⤓ downwards arrow to bar
  exportBtn.title = 'Copy or save this figure';
  exportBtn.setAttribute('role', 'button');
  exportBtn.setAttribute('aria-label', 'Copy or save this figure');
  exportBtn.setAttribute('aria-haspopup', 'menu');
  exportBtn.tabIndex = 0;
  outerDiv.appendChild(exportBtn);

  function _showExportBtn(on) {
    exportBtn.style.opacity = on ? '1' : '0';
    exportBtn.style.pointerEvents = on ? 'auto' : 'none';
  }

  const helpCard = document.createElement('div');
  helpCard.style.cssText =
    'position:absolute;top:33px;right:6px;padding:10px 14px;' +
    'background:rgba(28,28,38,0.95);color:#e0e0e8;font-size:12px;' +
    'font-family:sans-serif;border-radius:6px;line-height:1.7;' +
    'white-space:pre-wrap;max-width:300px;display:none;z-index:51;' +
    'box-shadow:0 4px 14px rgba(0,0,0,0.55);pointer-events:none;' +
    'border:1px solid rgba(120,120,160,0.3);';
  outerDiv.appendChild(helpCard);

  let _helpExists  = false;   // true when help_text is non-empty
  let _helpHovered = false;   // true while mouse is inside outerDiv
  let _helpOpen    = false;   // true while the card is shown

  function _updateHelp() {
    const txt = model.get('help_text') || '';
    _helpExists          = !!txt;
    helpCard.textContent = txt;
    if (!txt) {
      // Help removed — hide everything immediately.
      helpBtn.style.display    = 'none';
      helpCard.style.display   = 'none';
      helpBtn.style.background = _BTN_BG;
      _helpOpen = false;
    } else if (_helpHovered || _helpOpen) {
      // Already hovered or card open — make badge visible.
      helpBtn.style.display = 'flex';
    }
  }
  _updateHelp();

  outerDiv.addEventListener('mouseenter', () => {
    _helpHovered = true;
    if (_helpExists) helpBtn.style.display = 'flex';
  });

  // Reveal the badge on real pointer MOVEMENT, not on mouseenter: a browser may
  // synthesise an enter for a stationary cursor when the layout changes under
  // it, which would put hover chrome into screenshots — the scraper's gallery
  // thumbnails and the visual baselines both go through that path.
  outerDiv.addEventListener('mousemove', () => {
    _showExportBtn(true);
  });

  outerDiv.addEventListener('mouseleave', () => {
    _helpHovered = false;
    if (!_menuDiv && document.activeElement !== exportBtn) _showExportBtn(false);
    // Only hide the button if the card is also closed.
    if (!_helpOpen) helpBtn.style.display = 'none';
  });

  helpBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    _helpOpen = !_helpOpen;
    helpCard.style.display   = _helpOpen ? 'block' : 'none';
    helpBtn.style.background = _helpOpen ? _BTN_BG_ACTIVE : _BTN_BG;
    // If closing the card while the mouse has already left, hide the button too.
    if (!_helpOpen && !_helpHovered) helpBtn.style.display = 'none';
  });

  model.on('change:help_text', _updateHelp);
  const tooltip = document.createElement('div');
  tooltip.style.cssText =
    'position:fixed;padding:5px 9px;font-size:12px;font-family:sans-serif;' +
    'background:rgba(30,30,30,0.92);color:#fff;border-radius:4px;' +
    'pointer-events:none;white-space:pre;display:none;z-index:9999;' +
    'box-shadow:0 2px 6px rgba(0,0,0,0.4);max-width:260px;';
  document.body.appendChild(tooltip);

  function _showTooltip(text,cx,cy) {
    tooltip.textContent=text; tooltip.style.display='block';
    const tw=tooltip.offsetWidth||160, th=tooltip.offsetHeight||28;
    const vw=window.innerWidth, vh=window.innerHeight;  // both used below
    let lx=cx+14, ly=cy-th-8;
    if(lx+tw>vw-8) lx=cx-tw-14;
    if(ly<8) ly=cy+18;
    if(ly+th>vh-8) ly=vh-th-8;
    tooltip.style.left=lx+'px'; tooltip.style.top=ly+'px';
  }

  // ── coordinate helper: undo CSS transform:scale() ───────────────────────
  // _applyScale() shrinks outerDiv with transform:scale(s).  After that,
  // getBoundingClientRect() reports *visual* (CSS-pixel) dimensions, while
  // canvas drawing coordinates live in the *native* (un-scaled) space.
  // Every event handler that does (e.clientX - rect.left) therefore receives
  // a value in [0, nativeW*s] instead of [0, nativeW].
  //
  // _clientPos converts one mouse event back to canvas-pixel space:
  //   sfX = nativeW / rect.width  = 1/s   (1.0 when no scale is active)
  //   mx  = (e.clientX - rect.left) * sfX
  //
  // Usage:
  //   const {mx, my} = _clientPos(e, overlayCanvas, p.pw, p.ph);   // 1D / bar
  //   const {mx, my} = _clientPos(e, overlayCanvas, imgW, imgH);   // 2D
  function _clientPos(e, canvas, nativeW, nativeH) {
    const rect = canvas.getBoundingClientRect();
    const sfX  = rect.width  > 0 ? nativeW / rect.width  : 1;
    const sfY  = rect.height > 0 ? nativeH / rect.height : 1;
    return { mx: (e.clientX - rect.left) * sfX,
             my: (e.clientY - rect.top ) * sfY, sfX, sfY };
  }

  // ── per-panel state maps ──────────────────────────────────────────────────
  const panels = new Map();
  let _suppressLayoutUpdate = false;  // block re-entry during live resize
  let _pixArrivalSeq = 0;  // monotonic binary-pixel-frame arrival counter

  // Binary transport: raw pixel bytes ride a global side-table (`__apl_pixbytes`,
  // keyed `panel_<id>_geom::<pixelKey>`) because the model can't carry a
  // Uint8Array. Splice ANY currently-present bytes for this panel's geom trait
  // into `p2._geomCache` under `<pixelKey>_bytes`, stamping a monotonic arrival
  // sequence so _imageBytes gets a collision-proof cache key. Returns true if
  // any bytes were spliced. Used by BOTH the per-key change listener AND the
  // panel's INITIAL paint — the latter is load-bearing: a first pixel frame that
  // arrived (via the awi_state_binary postMessage handler) BEFORE render()
  // registered the change listener sits in the side-table with nothing to
  // consume it; without this splice the panel stays permanently blank (the
  // initial _loadGeom only parses the slimmed geom JSON, which carries the
  // LUT/flags, NOT the bytes). Idempotent: re-splicing the same buffer keeps the
  // same __aplSeq, so it does not force a spurious re-upload on the normal path.
  function _spliceBinaryBytes(p2, geomTrait) {
    const tbl = globalThis.__apl_pixbytes;
    if (!tbl) return false;
    let spliced = false;
    // Fixed base-image / mask / detail keys PLUS every DYNAMIC layer pixel key
    // (`layer_<id>_b64`) currently present in the side-table for this panel's
    // geom trait — layer keys aren't enumerable ahead of time, so scan by the
    // `<geomTrait>::` prefix. Splices each into the cache as `<pixelKey>_bytes`.
    const prefix = `${geomTrait}::`;
    for (const slot in tbl) {
      if (!slot.startsWith(prefix)) continue;
      const pixelKey = slot.slice(prefix.length);
      const b = tbl[slot];
      if (!b) continue;
      if (b.__aplSeq === undefined) {
        try { b.__aplSeq = ++_pixArrivalSeq; } catch (_) {}
      }
      if (!p2._geomCache) p2._geomCache = {};
      p2._geomCache[pixelKey + '_bytes'] = b;
      spliced = true;
    }
    return spliced;
  }

  // Register the per-pixel-key binary-bytes change listeners for a panel's geom
  // trait. The FIXED base-image / mask / detail keys each get a dedicated
  // listener (their slot fires `change:<slot>` when new bytes arrive). DYNAMIC
  // layer keys (layer_<id>_b64) are NOT enumerable here — their bytes are picked
  // up by the geom-JSON re-splice (the geom trait always re-pushes when layers
  // change) and by _spliceBinaryBytes's prefix scan, so they need no per-slot
  // listener. Shared by _createPanelDOM and _createInsetDOM.
  function _registerBinaryPixelListeners(id, geomTrait) {
    for (const pixelKey of ['image_b64', 'overlay_mask_b64', 'detail_b64']) {
      const slot = `${geomTrait}::${pixelKey}`;
      model.on(`change:${slot}`, () => {
        const p2 = panels.get(id);
        if (!p2) return;
        _spliceBinaryBytes(p2, geomTrait);
        if (p2.state) { _applyGeom(p2, p2.state); _redrawPanel(p2); }
      });
    }
  }

  // ── layout application ───────────────────────────────────────────────────
  function applyLayout() {
    if (_suppressLayoutUpdate) return;
    let layout;
    try { layout = JSON.parse(model.get('layout_json')); } catch(_) { return; }

    const { nrows, ncols, panel_specs } = layout;

    // Build grid tracks directly from panel pixel sizes.
    // Python already guarantees all panels in a row share the same height,
    // and all panels in a col share the same width.
    const colPx = new Array(ncols).fill(0);
    const rowPx = new Array(nrows).fill(0);
    for (const spec of panel_specs) {
      const perCol = Math.round(spec.panel_width  / (spec.col_stop - spec.col_start));
      const perRow = Math.round(spec.panel_height / (spec.row_stop - spec.row_start));
      for (let c = spec.col_start; c < spec.col_stop; c++) colPx[c] = Math.max(colPx[c], perCol);
      for (let r = spec.row_start; r < spec.row_stop; r++) rowPx[r] = Math.max(rowPx[r], perRow);
    }

    gridDiv.style.gridTemplateColumns = colPx.map(px => px + 'px').join(' ');
    gridDiv.style.gridTemplateRows    = rowPx.map(px => px + 'px').join(' ');
    gridDiv.style.width  = '';
    gridDiv.style.height = '';
    const meanColPx = colPx.length ? colPx.reduce((a,b)=>a+b,0)/colPx.length : 0;
    const meanRowPx = rowPx.length ? rowPx.reduce((a,b)=>a+b,0)/rowPx.length : 0;
    // Only override the default gap:4px when the Python caller explicitly set a value.
    if (layout.wspace != null) gridDiv.style.columnGap = (meanColPx ? Math.round(layout.wspace*meanColPx) : 0)+'px';
    if (layout.hspace != null) gridDiv.style.rowGap    = (meanRowPx ? Math.round(layout.hspace*meanRowPx) : 0)+'px';

    const seen = new Set();
    for (const spec of panel_specs) {
      seen.add(spec.id);
      if (!panels.has(spec.id)) {
        _createPanelDOM(spec.id, spec.kind, spec.panel_width, spec.panel_height, spec);
      } else {
        _resizePanelDOM(spec.id, spec.panel_width, spec.panel_height);
      }
    }

    // Handle inset panels
    const insetSpecs = layout.inset_specs || [];
    for (const spec of insetSpecs) {
      seen.add(spec.id);
      const existing = panels.get(spec.id);
      if (!existing) {
        _createInsetDOM(spec);
      } else {
        existing.insetSpec = spec;
      }
    }

    for (const [id, p] of panels) {
      if (!seen.has(id)) {
        // Free GPU resources before dropping the panel (2D image textures +
        // 3D geometry buffers), else they leak on re-layout / panel close.
        try { _gpuDisposeImagePanel(p); _gpuDisposePanel(p); } catch (_) {}
        p.cell.remove(); panels.delete(id);
      }
    }

    // Update insetsContainer size and reposition all insets
    insetsContainer.style.width  = (layout.fig_width  || 640) + 'px';
    insetsContainer.style.height = (layout.fig_height || 480) + 'px';
    if (insetSpecs.length) _applyAllInsetStates(layout);
    // Region indications depend on the browser having laid out the panels +
    // insets (getBoundingClientRect must be real). During the synchronous
    // applyLayout the DOM isn't measured yet, so draw once on the next frame.
    if ((layout.indications || []).length) {
      requestAnimationFrame(() => _drawCallouts());
    } else {
      _drawCallouts();  // clears any stale indication canvas
    }
    // Figure-level annotation layer tracks the figure size (fractions → px) and
    // re-binds per-panel edit-chrome hover handlers for any newly-created cells.
    _drawFigureMarkers();
    _applyPanelChrome();
  }

  // ── _buildCanvasStack ─────────────────────────────────────────────────────
  // Creates the canvas/element stack for one panel kind and appends the
  // top-level wrapper to `outerContainer`.  Returns all canvas/element refs.
  // Used by both _createPanelDOM (cell → gridDiv) and _createInsetDOM
  // (contentDiv → insetDiv).
  function _buildCanvasStack(kind, pw, ph, outerContainer) {
    let plotCanvas, overlayCanvas, markersCanvas, statusBar;
    let xAxisCanvas=null, yAxisCanvas=null, scaleBar=null;
    let cbCanvas=null, cbCtx=null, plotWrap=null, wrapNode=null;
    let titleCanvas=null;
    let stack3dGpuCanvas=null;   // WebGPU geometry canvas (3D only)
    let stack2dGpuCanvas=null;   // WebGPU image canvas (2D large-image path)

    if (kind === '2d') {
      plotWrap = document.createElement('div');
      plotWrap.style.cssText = `position:relative;display:inline-block;vertical-align:top;line-height:0;` +
        `width:${pw}px;height:${ph}px;overflow:visible;flex-shrink:0;`;

      // gpuCanvas (WebGPU image) draws the image raster BELOW plotCanvas (via
      // z-index 0) when GPU mode is active, while plotCanvas keeps drawing all
      // decorations (axes/colorbar/scale-bar/mask/markers) over a now-transparent
      // background. Hidden until/unless the GPU image path activates. It is
      // appended AFTER plotCanvas (below) so DOM order keeps plotCanvas first —
      // callers/tests that grab `querySelector('canvas')` still get the image
      // canvas; z-index (not DOM order) controls the visual stacking.
      var gpu2d = document.createElement('canvas');
      gpu2d.style.cssText =
        `position:absolute;top:0;left:0;display:none;border-radius:2px;z-index:0;`;
      stack2dGpuCanvas = gpu2d;

      plotCanvas = document.createElement('canvas');
      plotCanvas.style.cssText =
        `position:absolute;display:block;border-radius:2px;background:${theme.bgCanvas};z-index:1;`;
      overlayCanvas = document.createElement('canvas');
      overlayCanvas.style.cssText =
        'position:absolute;z-index:5;cursor:default;pointer-events:all;outline:none;touch-action:none;';
      overlayCanvas.tabIndex = 0;
      markersCanvas = document.createElement('canvas');
      markersCanvas.style.cssText = 'position:absolute;pointer-events:none;z-index:6;';
      scaleBar = document.createElement('canvas');
      scaleBar.style.cssText = 'position:absolute;pointer-events:none;display:none;z-index:7;';
      statusBar = document.createElement('div');
      statusBar.style.cssText =
        'position:absolute;padding:7px 14px;background:rgba(0,0,0,0.65);color:white;' +
        'font-size:12px;font-family:monospace;border-radius:5px;pointer-events:none;' +
        'white-space:nowrap;display:none;z-index:9;';
      yAxisCanvas = document.createElement('canvas');
      yAxisCanvas.style.cssText =
        `position:absolute;display:none;background:${theme.axisBg};`;
      xAxisCanvas = document.createElement('canvas');
      xAxisCanvas.style.cssText =
        `position:absolute;display:none;background:${theme.axisBg};`;
      cbCanvas = document.createElement('canvas');
      cbCanvas.style.cssText =
        'position:absolute;display:none;pointer-events:none;border-radius:0 2px 2px 0;';
      cbCtx = cbCanvas.getContext('2d');

      titleCanvas = document.createElement('canvas');
      titleCanvas.style.cssText = `position:absolute;pointer-events:none;z-index:8;background:transparent;display:none;`;

      plotWrap.appendChild(plotCanvas);
      plotWrap.appendChild(gpu2d);      // below plotCanvas via z-index, after in DOM
      plotWrap.appendChild(overlayCanvas);
      plotWrap.appendChild(markersCanvas);
      plotWrap.appendChild(yAxisCanvas);
      plotWrap.appendChild(xAxisCanvas);
      plotWrap.appendChild(cbCanvas);
      plotWrap.appendChild(scaleBar);
      plotWrap.appendChild(statusBar);
      plotWrap.appendChild(titleCanvas);
      outerContainer.appendChild(plotWrap);
      wrapNode = plotWrap;

    } else if (kind === '3d') {
      const wrap3 = document.createElement('div');
      wrap3.style.cssText = 'position:relative;display:inline-block;line-height:0;';
      // gpuCanvas (WebGPU geometry) sits BELOW plotCanvas; plotCanvas draws
      // decorations (axes/labels/sphere/planes/highlight) over a transparent
      // background when GPU mode is active.  Hidden until/unless GPU activates.
      var gpuCanvas = document.createElement('canvas');
      gpuCanvas.style.cssText =
        `position:absolute;top:0;left:0;display:none;border-radius:2px;` +
        `background:${theme.bgPlot};z-index:0;`;
      wrap3.appendChild(gpuCanvas);
      plotCanvas = document.createElement('canvas');
      plotCanvas.style.cssText =
        `position:relative;display:block;border-radius:2px;background:${theme.bgPlot};z-index:1;`;
      wrap3.appendChild(plotCanvas);
      outerContainer.appendChild(wrap3);
      stack3dGpuCanvas = gpuCanvas;
      overlayCanvas = document.createElement('canvas');
      overlayCanvas.style.cssText =
        'position:absolute;top:0;left:0;z-index:5;pointer-events:all;outline:none;touch-action:none;';
      wrap3.appendChild(overlayCanvas);
      markersCanvas = document.createElement('canvas');
      markersCanvas.style.cssText =
        'position:absolute;top:0;left:0;pointer-events:none;z-index:6;display:none;';
      wrap3.appendChild(markersCanvas);
      statusBar = document.createElement('div');
      statusBar.style.cssText =
        'position:absolute;bottom:4px;right:4px;padding:2px 6px;display:none;';
      wrap3.appendChild(statusBar);
      wrapNode = wrap3;

    } else {
      // 1D / bar
      plotCanvas = document.createElement('canvas');
      plotCanvas.tabIndex = 1;
      plotCanvas.style.cssText =
        'outline:none;cursor:crosshair;display:block;border-radius:2px;';
      const wrap = document.createElement('div');
      wrap.style.cssText = 'position:relative;display:inline-block;line-height:0;';
      wrap.appendChild(plotCanvas);
      outerContainer.appendChild(wrap);
      overlayCanvas = document.createElement('canvas');
      overlayCanvas.style.cssText =
        'position:absolute;top:0;left:0;z-index:5;cursor:crosshair;pointer-events:all;touch-action:none;';
      wrap.appendChild(overlayCanvas);
      markersCanvas = document.createElement('canvas');
      markersCanvas.style.cssText =
        'position:absolute;top:0;left:0;pointer-events:none;z-index:6;';
      wrap.appendChild(markersCanvas);
      statusBar = document.createElement('div');
      statusBar.style.cssText =
        'position:absolute;bottom:4px;right:4px;padding:7px 14px;' +
        'background:rgba(0,0,0,0.65);color:white;font-size:12px;font-family:monospace;' +
        'border-radius:5px;pointer-events:none;white-space:nowrap;display:none;z-index:9;';
      wrap.appendChild(statusBar);
      wrapNode = wrap;
    }

    // Floating image keys (Plot.add_key) — ONE canvas per panel holding every
    // key, covering the whole panel box, appended last so it sits above the
    // scale bar. Built generically for all three kinds: every branch above
    // ends with a positioned wrap in `wrapNode`, and a key means the same
    // thing over a 2-D map as over a 3-D scatter.
    const keyCanvas = document.createElement('canvas');
    keyCanvas.style.cssText =
      'position:absolute;top:0;left:0;pointer-events:none;z-index:7;display:none;';
    if (wrapNode) wrapNode.appendChild(keyCanvas);

    return { plotCanvas, overlayCanvas, markersCanvas, statusBar,
             xAxisCanvas, yAxisCanvas, scaleBar, keyCanvas,
             cbCanvas, cbCtx, plotWrap, wrapNode, titleCanvas,
             gpuCanvas: stack3dGpuCanvas || stack2dGpuCanvas };
  }

  function _createPanelDOM(id, kind, pw, ph, spec) {
    const cell = document.createElement('div');
    cell.style.cssText =
      'position:relative;overflow:visible;line-height:0;' +
      'display:flex;justify-content:center;align-items:flex-start;';
    cell.style.gridRow    = `${spec.row_start+1} / ${spec.row_stop+1}`;
    cell.style.gridColumn = `${spec.col_start+1} / ${spec.col_stop+1}`;
    gridDiv.appendChild(cell);

    const stack = _buildCanvasStack(kind, pw, ph, cell);

    const plotCtx = stack.plotCanvas.getContext('2d');
    const ovCtx   = stack.overlayCanvas.getContext('2d');
    const mkCtx   = stack.markersCanvas.getContext('2d');
    const xCtx    = stack.xAxisCanvas ? stack.xAxisCanvas.getContext('2d') : null;
    const yCtx    = stack.yAxisCanvas ? stack.yAxisCanvas.getContext('2d') : null;
    const titleCtx = stack.titleCanvas ? stack.titleCanvas.getContext('2d') : null;

    const blitCache = { bitmap:null, bytesKey:null, lutKey:null, w:0, h:0 };

    const statsDiv = document.createElement('div');
    statsDiv.style.cssText = STATS_DIV_CSS;
    if (stack.wrapNode) stack.wrapNode.appendChild(statsDiv);

    const p = {
      id, kind, cell, pw, ph,
      plotCanvas:    stack.plotCanvas,
      overlayCanvas: stack.overlayCanvas,
      markersCanvas: stack.markersCanvas,
      plotCtx, ovCtx, mkCtx,
      xAxisCanvas:   stack.xAxisCanvas,
      yAxisCanvas:   stack.yAxisCanvas,
      xCtx, yCtx,
      titleCanvas:   stack.titleCanvas || null,
      titleCtx,
      scaleBar:      stack.scaleBar,
      keyCanvas:     stack.keyCanvas,
      statusBar:     stack.statusBar,
      statsDiv,
      frameTimes: [],
      blitCache,
      ovDrag: null, ovDrag2d: null,
      isPanning: false, panStart: {},
      state: null,
      _hoverSi: -1, _hoverI: -1,
      _hovBar: null,
      lastWidgetId: null,
      mouseX: 0, mouseY: 0,
      cbCanvas:  stack.cbCanvas,
      cbCtx:     stack.cbCtx,
      sbLine:    null,
      sbLabel:   null,
      plotWrap:  stack.plotWrap,
      gpuCanvas: stack.gpuCanvas || null,
      _gpu:      undefined,   // undefined | 'pending' | 'active' | 'unavailable'
    };
    panels.set(id, p);

    _resizePanelDOM(id, pw, ph);
    _attachPanelEvents(p);

    // Geometry channel (only when this panel declared one on the Python side).
    const _geomTrait = `panel_${id}_geom`;
    const _hasGeom = model.get(_geomTrait) !== undefined;
    if (_hasGeom) {
      model.on(`change:${_geomTrait}`, () => {
        const p2 = panels.get(id);
        if (!p2) return;
        const rev = (p2.state && p2.state._geom_rev !== undefined)
          ? p2.state._geom_rev : ((p2._geomRev || 0) + 1);
        _loadGeom(p2, model.get(_geomTrait), rev);
        // Re-splice any binary pixel bytes present for this panel — including
        // DYNAMIC layer keys (layer_<id>_b64) that have no dedicated per-slot
        // listener. The geom JSON always re-pushes when layers change, so this
        // guarantees a layer's bytes are consumed regardless of arrival order.
        _spliceBinaryBytes(p2, _geomTrait);
        if (p2.state) { _applyGeom(p2, p2.state); _redrawPanel(p2); }
      });
      // Binary transport: raw pixel bytes for this panel arrive on a companion
      // trait `panel_<id>_geom::<pixelKey>` (a Uint8Array). Merge them into the
      // geomCache under `<pixelKey>_bytes` so _imageBytes uses them (no atob), and
      // redraw. Fires INDEPENDENTLY of the geom JSON trait (which now carries only
      // the small LUT/flags), so pixels + LUT converge in the cache.
      _registerBinaryPixelListeners(id, _geomTrait);
    }

    model.on(`change:panel_${id}_json`, () => {
      const p2 = panels.get(id);
      if (!p2) return;
      // Skip the echo of our own interaction writes (orbit / plane drags):
      // the state is already current and a second parse+redraw per mouse
      // event doubles the frame cost.
      if (p2._selfWrite) return;
      try {
        const newState = JSON.parse(model.get(`panel_${id}_json`));
        _preserveView(p2, newState);
        _applyGeom(p2, newState);
        p2.state = newState;
      }
      catch(_) { return; }
      p2._hoverSi = -1; p2._hoverI = -1;
      _redrawPanel(p2);
      // The new state may carry the exact-value answer for the pixel the cursor is
      // resting on (see _armValueProbe) — refresh the readout in place, since no
      // mousemove follows a stationary cursor. A push may also be a NEW frame (whose
      // pixels void the previous answer), so clear "already asked" and re-arm: the
      // dwell timer restarts per push, which means a fast scrub never fires a probe
      // and the one that lands after it settles is for the frame on screen.
      p2._probeSent = '';
      if (p2.kind === '2d' && p2._hoverIn) {
        const rInfo = _updateStatus2d(p2);
        if (rInfo) _armValueProbe(p2, rInfo.img_x, rInfo.img_y);
      }
    });

    if (_hasGeom) {
      _loadGeom(p, model.get(_geomTrait), 1);
      // First-paint race fix: consume any binary pixel bytes that already
      // arrived (before this render registered the change listeners above) so
      // the INITIAL paint below shows them instead of leaving the panel blank
      // until an organic second frame. No-op on the normal path (side-table
      // empty until the first frame lands).
      _spliceBinaryBytes(p, _geomTrait);
    }
    try {
      p.state = JSON.parse(model.get(`panel_${id}_json`));
      _applyGeom(p, p.state);
    } catch(_) {}
    _redrawPanel(p);
  }

  // ── _createInsetDOM ───────────────────────────────────────────────────────
  // Builds a floating inset panel:
  //   insetDiv (position:absolute inside insetsContainer)
  //     ├── titleBar  — visible only when spec.title is non-empty; click to
  //     │    │          toggle min/normal. A title-less inset (the common
  //     │    │          "callout" case) has NO title bar at all — the content
  //     │    │          div fills the whole box, just a clean bordered plot.
  //     │    └── titleSpan
  //     └── contentDiv — canvas stack; display:none when minimized
  //          └── _buildCanvasStack(kind, pw, ph)
  function _createInsetDOM(spec) {
    const { id, kind, panel_width: pw, panel_height: ph, title, inset_state } = spec;
    const hasTitle = _hasInsetTitle(spec);

    const insetDiv = document.createElement('div');
    insetDiv.style.cssText =
      'position:absolute;pointer-events:all;border-radius:4px;overflow:hidden;' +
      `box-shadow:0 2px 14px rgba(0,0,0,0.55);border:1px solid ${theme.border};z-index:25;background:${theme.bg};`;
    insetsContainer.appendChild(insetDiv);

    // Title bar — laid out even when empty (kept as a DOM node so later specs
    // that DO carry a title can reveal it), but display:none + zero height
    // when there is no title so the content fills the whole inset box.
    const tbBg = theme.dark ? 'rgba(30,32,46,0.97)' : 'rgba(210,213,224,0.97)';
    const titleBar = document.createElement('div');
    titleBar.style.cssText =
      `display:${hasTitle ? 'flex' : 'none'};align-items:center;height:${INSET_TITLE_H}px;` +
      `cursor:pointer;padding:0 5px 0 8px;user-select:none;background:${tbBg};` +
      `border-bottom:1px solid ${theme.border};box-sizing:border-box;flex-shrink:0;`;
    insetDiv.appendChild(titleBar);

    const titleSpan = document.createElement('span');
    titleSpan.style.cssText =
      `flex:1;font-size:11px;font-family:sans-serif;overflow:hidden;` +
      `text-overflow:ellipsis;white-space:nowrap;color:${theme.tickText};`;
    titleSpan.textContent = title || '';
    titleBar.appendChild(titleSpan);


    // Content div — wraps the canvas stack
    const contentDiv = document.createElement('div');
    contentDiv.style.cssText =
      `overflow:hidden;display:${inset_state === 'minimized' ? 'none' : 'block'};`;
    insetDiv.appendChild(contentDiv);

    // Edit-mode resize handle — a small grabber pinned to the inset's
    // bottom-right corner. Hidden by default; shown/hidden by _applyEditMode
    // (like the panel move-grip). Sits above the canvas stack (z 5) and the
    // content div so it stays grabbable; cursor is the diagonal resize arrow.
    const resizeGrip = document.createElement('div');
    resizeGrip.className = 'apl-inset-resize';
    resizeGrip.style.cssText =
      `position:absolute;right:0;bottom:0;width:${INSET_RESIZE_PX}px;` +
      `height:${INSET_RESIZE_PX}px;z-index:14;cursor:nwse-resize;display:none;` +
      `background:${theme.bg || '#1e1e2e'};border-top:1px solid ${EDIT_ACCENT};` +
      `border-left:1px solid ${EDIT_ACCENT};border-top-left-radius:4px;` +
      `box-shadow:-1px -1px 3px rgba(0,0,0,0.35);`;
    resizeGrip.title = 'Drag to resize this inset';
    insetDiv.appendChild(resizeGrip);

    // Canvas stack inside contentDiv
    const stack = _buildCanvasStack(kind, pw, ph, contentDiv);

    const plotCtx = stack.plotCanvas.getContext('2d');
    const ovCtx   = stack.overlayCanvas.getContext('2d');
    const mkCtx   = stack.markersCanvas.getContext('2d');
    const xCtx    = stack.xAxisCanvas ? stack.xAxisCanvas.getContext('2d') : null;
    const yCtx    = stack.yAxisCanvas ? stack.yAxisCanvas.getContext('2d') : null;

    const blitCache = { bitmap:null, bytesKey:null, lutKey:null, w:0, h:0 };

    const statsDiv = document.createElement('div');
    statsDiv.style.cssText = STATS_DIV_CSS;
    if (stack.wrapNode) stack.wrapNode.appendChild(statsDiv);

    const p = {
      id, kind, pw, ph,
      cell: insetDiv,   // stale-cleanup compatibility (p.cell.remove())
      isInset: true, insetDiv, contentDiv, titleBar, resizeGrip,
      insetSpec: spec,
      plotCanvas:    stack.plotCanvas,
      overlayCanvas: stack.overlayCanvas,
      markersCanvas: stack.markersCanvas,
      plotCtx, ovCtx, mkCtx,
      xAxisCanvas:   stack.xAxisCanvas,
      yAxisCanvas:   stack.yAxisCanvas,
      xCtx, yCtx,
      scaleBar:      stack.scaleBar,
      keyCanvas:     stack.keyCanvas,
      statusBar:     stack.statusBar,
      statsDiv,
      frameTimes: [], blitCache,
      ovDrag: null, ovDrag2d: null,
      isPanning: false, panStart: {},
      state: null,
      _hoverSi: -1, _hoverI: -1,
      _hovBar: null,
      lastWidgetId: null, mouseX: 0, mouseY: 0,
      cbCanvas:  stack.cbCanvas,
      cbCtx:     stack.cbCtx,
      sbLine:    null, sbLabel: null,
      plotWrap:  stack.plotWrap,
    };
    panels.set(id, p);

    _resizePanelDOM(id, pw, ph);
    _attachPanelEvents(p);

    // Title bar click: toggle normal ↔ minimized.  A completed move drag on
    // the inset sets p._dragSuppressClick so the release click here does NOT
    // also flip the minimize state (drag-to-move and click-to-minimize share
    // the title bar).
    titleBar.addEventListener('click', (e) => {
      if (p._dragSuppressClick) { p._dragSuppressClick = false; return; }
      const cur = p.insetSpec ? p.insetSpec.inset_state : 'normal';
      _applyButtonState(p, cur === 'minimized' ? 'normal' : 'minimized');
    });

    // Edit-mode drag-to-move (whole inset) and drag-to-resize (corner grip).
    _wireInsetDrag(p);


    // Geometry channel (only when this panel declared one on the Python side).
    const _geomTrait = `panel_${id}_geom`;
    const _hasGeom = model.get(_geomTrait) !== undefined;
    if (_hasGeom) {
      model.on(`change:${_geomTrait}`, () => {
        const p2 = panels.get(id);
        if (!p2) return;
        const rev = (p2.state && p2.state._geom_rev !== undefined)
          ? p2.state._geom_rev : ((p2._geomRev || 0) + 1);
        _loadGeom(p2, model.get(_geomTrait), rev);
        // Re-splice binary bytes incl. dynamic layer keys — see _createPanelDOM.
        _spliceBinaryBytes(p2, _geomTrait);
        if (p2.state) { _applyGeom(p2, p2.state); _redrawPanel(p2); }
      });
      // Binary transport: raw pixel bytes for this panel arrive on a companion
      // trait `panel_<id>_geom::<pixelKey>` (a Uint8Array). Merge them into the
      // geomCache under `<pixelKey>_bytes` so _imageBytes uses them (no atob), and
      // redraw. Fires INDEPENDENTLY of the geom JSON trait (which now carries only
      // the small LUT/flags), so pixels + LUT converge in the cache.
      _registerBinaryPixelListeners(id, _geomTrait);
    }

    model.on(`change:panel_${id}_json`, () => {
      const p2 = panels.get(id);
      if (!p2) return;
      // Skip the echo of our own interaction writes (orbit / plane drags):
      // the state is already current and a second parse+redraw per mouse
      // event doubles the frame cost.
      if (p2._selfWrite) return;
      try {
        const newState = JSON.parse(model.get(`panel_${id}_json`));
        _preserveView(p2, newState);
        _applyGeom(p2, newState);
        p2.state = newState;
      }
      catch(_) { return; }
      p2._hoverSi = -1; p2._hoverI = -1;
      _redrawPanel(p2);
      // The new state may carry the exact-value answer for the pixel the cursor is
      // resting on (see _armValueProbe) — refresh the readout in place, since no
      // mousemove follows a stationary cursor. A push may also be a NEW frame (whose
      // pixels void the previous answer), so clear "already asked" and re-arm: the
      // dwell timer restarts per push, which means a fast scrub never fires a probe
      // and the one that lands after it settles is for the frame on screen.
      p2._probeSent = '';
      if (p2.kind === '2d' && p2._hoverIn) {
        const rInfo = _updateStatus2d(p2);
        if (rInfo) _armValueProbe(p2, rInfo.img_x, rInfo.img_y);
      }
    });

    if (_hasGeom) {
      _loadGeom(p, model.get(_geomTrait), 1);
      // First-paint race fix (see _createPanelDOM): splice any binary pixel
      // bytes that arrived before render() registered the listeners above.
      _spliceBinaryBytes(p, _geomTrait);
    }
    try {
      p.state = JSON.parse(model.get(`panel_${id}_json`));
      _applyGeom(p, p.state);
    } catch(_) {}
    _redrawPanel(p);
  }

  // Optimistic local state update + Python notification.
  function _applyButtonState(p, newState) {
    try {
      const layout = JSON.parse(model.get('layout_json'));
      const spec = (layout.inset_specs || []).find(s => s.id === p.id);
      if (spec) {
        spec.inset_state = newState;
        p.insetSpec = spec;
        _applyAllInsetStates(layout);
      }
    } catch(_) {}
    _emitEvent(p.id, 'inset_state_change', null, { new_state: newState });
  }

  // ── inset drag-to-move / drag-to-resize (edit mode only) ──────────────────
  // Wires two pointer gestures on an inset, both gated on _editOn():
  //   • move   — a capture-phase pointerdown anywhere on the inset (except the
  //              resize grip) drags the whole inset. A corner-stacked inset is
  //              converted to a free anchor on drag start (reading its current
  //              DOM position) so it floats and its corner siblings re-stack.
  //   • resize — a pointerdown on the bottom-right grip resizes the inset,
  //              clamped to INSET_MIN_PX per dim.
  // Both work on a LOCAL layout snapshot (like _applyButtonState) so the DOM
  // updates optimistically; on pointerup an 'inset_geometry_change' carries the
  // final anchor + size fractions to Python, which echoes an authoritative
  // layout_json back. A 3 px threshold distinguishes a move-drag from a click
  // (so the title-bar minimize toggle still works on a plain click).
  function _wireInsetDrag(p) {
    const fig = () => {
      const fw = Number(model.get('fig_width'))  || 640;
      const fh = Number(model.get('fig_height')) || 480;
      return [fw, fh];
    };
    // Snapshot layout_json and return {layout, spec} for THIS inset (a private
    // copy we mutate during the drag).
    const snapshot = () => {
      let layout;
      try { layout = JSON.parse(model.get('layout_json')); } catch (_) { return null; }
      const spec = (layout.inset_specs || []).find(s => s.id === p.id);
      if (!spec) return null;
      return { layout, spec };
    };

    // ── MOVE: capture-phase pointerdown on the whole inset ──────────────────
    p.insetDiv.addEventListener('pointerdown', (e) => {
      if (!_editOn() || e.button !== 0) return;
      // The resize grip owns its own gesture.
      if (e.target === p.resizeGrip) return;
      // Don't drag a maximized inset (it is centred / not anchor-positioned).
      const st = p.insetSpec ? p.insetSpec.inset_state : 'normal';
      if (st === 'maximized') return;

      const snap = snapshot();
      if (!snap) return;
      const [fw, fh] = fig();
      // Current top-left in figure px (DOM is already positioned).
      const startLeft = parseFloat(p.insetDiv.style.left) || 0;
      const startTop  = parseFloat(p.insetDiv.style.top)  || 0;

      _insetDrag = {
        p, mode: 'move', snap,
        fw, fh,
        startPX: e.clientX, startPY: e.clientY,
        startLeft, startTop,
        pw: snap.spec.panel_width, ph: snap.spec.panel_height,
        moved: false,
      };
      try { p.insetDiv.setPointerCapture(e.pointerId); } catch (_) {}
      // Capture phase + stopPropagation so the panel event handlers underneath
      // don't also react to this pointerdown.
      e.preventDefault(); e.stopPropagation();
    }, true);

    // ── RESIZE: pointerdown on the bottom-right grip ────────────────────────
    p.resizeGrip.addEventListener('pointerdown', (e) => {
      if (!_editOn() || e.button !== 0) return;
      const st = p.insetSpec ? p.insetSpec.inset_state : 'normal';
      if (st === 'maximized' || st === 'minimized') return;  // nothing to resize
      const snap = snapshot();
      if (!snap) return;
      const [fw, fh] = fig();
      _insetDrag = {
        p, mode: 'resize', snap,
        fw, fh,
        startPX: e.clientX, startPY: e.clientY,
        startW: snap.spec.panel_width, startH: snap.spec.panel_height,
        moved: false,
      };
      try { p.resizeGrip.setPointerCapture(e.pointerId); } catch (_) {}
      e.preventDefault(); e.stopPropagation();
    });

    // Move / up handlers are attached to the same elements so pointer capture
    // routes them here even when the cursor leaves the inset.
    const onMove = (e) => {
      if (!_insetDrag || _insetDrag.p !== p) return;
      _doInsetDrag(e);
    };
    const onUp = (e) => {
      if (!_insetDrag || _insetDrag.p !== p) return;
      _endInsetDrag(e);
    };
    p.insetDiv.addEventListener('pointermove', onMove);
    p.insetDiv.addEventListener('pointerup', onUp);
    p.insetDiv.addEventListener('pointercancel', onUp);
    p.resizeGrip.addEventListener('pointermove', onMove);
    p.resizeGrip.addEventListener('pointerup', onUp);
    p.resizeGrip.addEventListener('pointercancel', onUp);
  }

  // Per-move handler for an in-progress inset move / resize (see _wireInsetDrag).
  // rAF-throttles the callout redraw so leader lines re-aim live without a draw
  // per pointer event.
  let _insetCalloutRAF = 0;
  function _doInsetDrag(e) {
    const d = _insetDrag;
    const p = d.p;
    const dx = e.clientX - d.startPX;
    const dy = e.clientY - d.startPY;
    if (!d.moved && Math.hypot(dx, dy) < INSET_DRAG_THRESH) return;
    const th = _insetTitleH(d.snap.spec);  // 0 for a title-less inset

    if (d.mode === 'move') {
      // On the FIRST real move: convert a corner-stacked inset to a free anchor
      // at its current DOM position so it floats and its corner siblings
      // re-stack. Mutate the LOCAL snapshot spec only.
      if (!d.moved && d.snap.spec.corner) {
        d.snap.spec.anchor = [d.startLeft / d.fw, d.startTop / d.fh];
        d.snap.spec.corner = null;
        p.insetSpec = d.snap.spec;
      }
      d.moved = true;
      // New top-left, clamped inside the figure box exactly like
      // _applyAllInsetStates (the inset must stay fully visible).
      const stackH = (d.snap.spec.inset_state === 'minimized')
        ? th : th + d.ph;
      let left = d.startLeft + dx;
      let top  = d.startTop  + dy;
      left = Math.max(0, Math.min(left, d.fw - d.pw));
      top  = Math.max(0, Math.min(top,  d.fh - stackH));
      d.curLeft = left; d.curTop = top;
      d.snap.spec.anchor = [left / d.fw, top / d.fh];
      _applyAllInsetStates(d.snap.layout);
    } else {  // resize
      d.moved = true;
      let w = Math.round(d.startW + dx);
      let h = Math.round(d.startH + dy);
      // Min size (both dims) + keep the inset inside the figure from its
      // current top-left.
      const left = parseFloat(p.insetDiv.style.left) || 0;
      const top  = parseFloat(p.insetDiv.style.top)  || 0;
      w = Math.max(INSET_MIN_PX, Math.min(w, d.fw - left));
      h = Math.max(INSET_MIN_PX, Math.min(h, d.fh - top - th));
      d.curW = w; d.curH = h;
      d.snap.spec.panel_width  = w;
      d.snap.spec.panel_height = h;
      // Track the DOM box live; the canvas re-render is deferred to pointerup.
      p.insetDiv.style.width  = w + 'px';
      p.insetDiv.style.height = (th + h) + 'px';
      p.contentDiv.style.height = h + 'px';
    }

    // Re-aim callout leaders live (rAF-throttled).
    if (!_insetCalloutRAF) {
      _insetCalloutRAF = requestAnimationFrame(() => {
        _insetCalloutRAF = 0;
        _drawCallouts([d.fw, d.fh]);
      });
    }
    e.preventDefault();
  }

  // Finalise an inset move / resize: emit the geometry to Python and clear the
  // drag. A move sets _dragSuppressClick so the title-bar click that follows a
  // move-release does not also toggle minimize.
  function _endInsetDrag(e) {
    const d = _insetDrag; _insetDrag = null;
    const p = d.p;
    try { p.insetDiv.releasePointerCapture(e.pointerId); } catch (_) {}
    try { p.resizeGrip.releasePointerCapture(e.pointerId); } catch (_) {}
    if (_insetCalloutRAF) { cancelAnimationFrame(_insetCalloutRAF); _insetCalloutRAF = 0; }

    if (!d.moved) { e.preventDefault(); return; }  // sub-threshold → a click

    if (d.mode === 'move') p._dragSuppressClick = true;

    // Resolve the final geometry in figure fractions.
    const fw = d.fw, fh = d.fh;
    let left, top, pw, ph;
    if (d.mode === 'move') {
      left = d.curLeft != null ? d.curLeft : (parseFloat(p.insetDiv.style.left) || 0);
      top  = d.curTop  != null ? d.curTop  : (parseFloat(p.insetDiv.style.top)  || 0);
      pw = d.pw; ph = d.ph;
    } else {  // resize
      left = parseFloat(p.insetDiv.style.left) || 0;
      top  = parseFloat(p.insetDiv.style.top)  || 0;
      pw = d.curW != null ? d.curW : d.startW;
      ph = d.curH != null ? d.curH : d.startH;
      // Re-render the inset's canvas stack at the new size (deferred to now).
      _resizePanelDOM(p.id, pw, ph);
      _redrawPanel(p);
    }

    _emitEvent(p.id, 'inset_geometry_change', null, {
      anchor: [left / fw, top / fh],
      w_frac: pw / fw,
      h_frac: ph / fh,
    });
    e.preventDefault();
  }

  // ── _applyAllInsetStates ──────────────────────────────────────────────────
  // Positions every inset for the given layout snapshot.
  // Corner-placed insets are grouped by corner and stacked with INSET_GAP
  // spacing (minimized ones contribute only their title-bar height, 0 for a
  // title-less inset, to the stack).
  // Anchor-placed insets (spec.anchor != null) float at their anchor fraction.
  // Maximized insets float centred at z-index:45, outside any stack.
  function _applyAllInsetStates(layout) {
    const insetSpecs = layout.inset_specs || [];
    const fw = layout.fig_width  || 640;
    const fh = layout.fig_height || 480;

    insetsContainer.style.width  = fw + 'px';
    insetsContainer.style.height = fh + 'px';

    // Split anchored insets from corner insets. Anchored ones are placed
    // directly at their fraction; corner ones stack per-corner as before.
    const anchored = [];
    const byCorner = {};
    for (const spec of insetSpecs) {
      if (spec.anchor) { anchored.push(spec); continue; }
      (byCorner[spec.corner] = byCorner[spec.corner] || []).push(spec);
    }

    // Sync each inset's title-bar visibility to its (possibly just-changed)
    // spec before computing any geometry below — every stackH/height below
    // reads through _insetTitleH(spec), so this must run first.
    for (const spec of insetSpecs) {
      const p = panels.get(spec.id);
      if (!p || !p.isInset || !p.titleBar) continue;
      const hasTitle = _hasInsetTitle(spec);
      p.titleBar.style.display = hasTitle ? 'flex' : 'none';
      // A title-less inset has no minimize affordance; guard against a
      // stale/programmatic 'minimized' state wedging it at zero height by
      // treating it as 'normal' for layout purposes (no crash, sane visual).
      if (!hasTitle && spec.inset_state === 'minimized') spec.inset_state = 'normal';
    }

    // ── anchor-placed insets ────────────────────────────────────────────────
    for (const spec of anchored) {
      const p = panels.get(spec.id);
      if (!p || !p.isInset) continue;
      const pw = spec.panel_width;
      const ph = spec.panel_height;
      const state = spec.inset_state;
      const th = _insetTitleH(spec);
      const stackH = state === 'minimized' ? th : th + ph;

      // Maximized floats centred (same treatment as corner insets below).
      if (state === 'maximized') {
        const mw = Math.round(fw * 0.72), mh = Math.round(fh * 0.72);
        p.insetDiv.style.left = Math.round((fw - mw) / 2) + 'px';
        p.insetDiv.style.top  = Math.round((fh - mh) / 2) + 'px';
        p.insetDiv.style.width  = mw + 'px';
        p.insetDiv.style.height = (th + mh) + 'px';
        p.insetDiv.style.zIndex = '45';
        p.contentDiv.style.display = 'block';
        p.contentDiv.style.height  = mh + 'px';
        if (p.pw !== mw || p.ph !== mh) {
          p.pw = mw; p.ph = mh; _resizePanelDOM(spec.id, mw, mh); _redrawPanel(p);
        }
        continue;
      }

      // Normal / minimized: top-left corner sits at the anchor fraction,
      // clamped so the inset stays inside the figure.
      let left = Math.round(spec.anchor[0] * fw);
      let top  = Math.round(spec.anchor[1] * fh);
      left = Math.max(0, Math.min(left, fw - pw));
      top  = Math.max(0, Math.min(top,  fh - stackH));
      p.insetDiv.style.left   = left + 'px';
      p.insetDiv.style.top    = top  + 'px';
      p.insetDiv.style.width  = pw   + 'px';
      p.insetDiv.style.height = stackH + 'px';
      p.insetDiv.style.zIndex = '25';
      if (state === 'minimized') {
        p.contentDiv.style.display = 'none';
      } else {
        p.contentDiv.style.display = 'block';
        p.contentDiv.style.height  = ph + 'px';
        if (p.pw !== pw || p.ph !== ph) {
          p.pw = pw; p.ph = ph; _resizePanelDOM(spec.id, pw, ph); _redrawPanel(p);
        }
      }
    }

    for (const [corner, group] of Object.entries(byCorner)) {
      const isBottom = corner.startsWith('bottom');
      const isRight  = corner.endsWith('right');
      // Bottom corners: first-added is closest to the corner (stack upward),
      // so reverse for the position loop (offset grows from the corner outward).
      const walk = isBottom ? [...group].reverse() : group;
      let offset = INSET_MARGIN;

      for (const spec of walk) {
        const p = panels.get(spec.id);
        if (!p || !p.isInset) continue;

        const pw    = spec.panel_width;
        const ph    = spec.panel_height;
        const state = spec.inset_state;


        // Normal or minimized: compute position from corner
        const th = _insetTitleH(spec);
        const stackH = state === 'minimized' ? th : th + ph;
        const left   = isRight ? fw - pw - INSET_MARGIN : INSET_MARGIN;
        const top    = isBottom ? fh - offset - stackH  : offset;

        p.insetDiv.style.left   = left + 'px';
        p.insetDiv.style.top    = top  + 'px';
        p.insetDiv.style.width  = pw   + 'px';
        p.insetDiv.style.height = stackH + 'px';
        p.insetDiv.style.zIndex = '25';

        if (state === 'minimized') {
          p.contentDiv.style.display = 'none';
        } else {
          p.contentDiv.style.display = 'block';
          p.contentDiv.style.height  = ph + 'px';
          if (p.pw !== pw || p.ph !== ph) {
            p.pw = pw; p.ph = ph;
            _resizePanelDOM(spec.id, pw, ph);
            _redrawPanel(p);
          }
        }

        offset += stackH + INSET_GAP;
      }
    }
    // Inset positions changed → refresh leader lines / rects.  Use the layout's
    // own size (may be a live-resize snapshot ahead of the model).
    _drawCallouts([fw, fh]);
  }

  // ── _drawCallouts ─────────────────────────────────────────────────────────
  // Draw every mark_inset-style region indication onto the figure-level
  // calloutCanvas.  Called after any parent redraw / inset move / resize, so
  // the dashed source rect tracks the parent's zoom+pan (region is mapped
  // through _imgToCanvas2d every draw) and the leaders follow the inset's
  // current DOM rect (leaders hide while the inset is minimized).
  //
  // Coordinate space: everything is mapped into calloutCanvas CSS px via each
  // element's getBoundingClientRect relative to the canvas's own rect — so no
  // layout math is duplicated and the leaders line up across panel boundaries.
  function _drawCallouts(sizeOverride) {
    let layout;
    try { layout = JSON.parse(model.get('layout_json')); } catch (_) { return; }
    const inds = layout.indications || [];

    // Nothing to draw → collapse the overlay to a 0×0 backing store instead of
    // sizing it to the full figure. An empty full-figure transparent canvas
    // would otherwise be the LARGEST canvas in the DOM (it spans the whole
    // figure, wider than any single panel), shadowing the panel content for
    // any consumer/test that samples "the largest canvas". Setting width/height
    // to 0 also clears any prior drawing, so no clearRect is needed here.
    if (!inds.length) {
      if (calloutCanvas.width || calloutCanvas.height) {
        calloutCanvas.width = 0; calloutCanvas.height = 0;
        calloutCanvas.style.width = '0px'; calloutCanvas.style.height = '0px';
      }
      return;
    }

    // Size the canvas to the figure content (fig size + no padding — it is
    // already offset by 8 px like insetsContainer).  During a live figure
    // resize the model hasn't been written yet, so accept an explicit size.
    const fw = sizeOverride ? sizeOverride[0]
             : (Number(model.get('fig_width'))  || layout.fig_width  || 640);
    const fh = sizeOverride ? sizeOverride[1]
             : (Number(model.get('fig_height')) || layout.fig_height || 480);
    if (calloutCanvas.width !== Math.round(fw * dpr) ||
        calloutCanvas.height !== Math.round(fh * dpr)) {
      calloutCanvas.style.width  = fw + 'px';
      calloutCanvas.style.height = fh + 'px';
      calloutCanvas.width  = Math.round(fw * dpr);
      calloutCanvas.height = Math.round(fh * dpr);
    }
    calloutCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
    calloutCtx.clearRect(0, 0, fw, fh);

    const base = calloutCanvas.getBoundingClientRect();

    for (const ind of inds) {
      const parent = panels.get(ind.parent_id);
      const inset  = panels.get(ind.inset_id);
      if (!parent || !parent.state || !inset || !inset.isInset) continue;

      // ── shared data→figure-px mapping + stroke setup ──────────────────────
      // Map data-space coords through the parent's data→canvas transform
      // (tracks zoom/pan), then offset by the parent markers canvas's position
      // relative to the callout canvas.
      const st = parent.state;
      const imgW = parent.imgW || 1, imgH = parent.imgH || 1;
      const mkRect = (parent.markersCanvas || parent.plotCanvas).getBoundingClientRect();
      const offX = mkRect.left - base.left;
      const offY = mkRect.top  - base.top;
      const toFig = (dx, dy) => {
        const [cx, cy] = _imgToCanvas2d(dx, dy, st, imgW, imgH);
        return [offX + cx, offY + cy];
      };

      const color = ind.color || '#ff9800';
      const lw    = ind.linewidth != null ? ind.linewidth : 1.5;
      const dash  = ind.linestyle === 'solid'  ? []
                  : ind.linestyle === 'dotted' ? [2, 3]
                  : [6, 4];  // dashed (default)

      calloutCtx.save();
      calloutCtx.strokeStyle = color;
      calloutCtx.lineWidth   = lw;
      calloutCtx.setLineDash(dash);

      // ── POINT indication (indicate_point): marker + single leader ────────
      // A small solid circle-with-cross at the data point (clipped to the
      // parent's image area, like the region rect) plus one leader from the
      // marker's edge to the inset's nearest corner (hidden while minimized).
      if (ind.point) {
        const [mx, my] = toFig(ind.point[0], ind.point[1]);
        const ms = ind.marker_size != null ? ind.marker_size : 5;
        calloutCtx.save();
        calloutCtx.beginPath();
        calloutCtx.rect(offX, offY, imgW, imgH);
        calloutCtx.clip();
        calloutCtx.setLineDash([]);          // the marker itself is solid
        calloutCtx.beginPath();
        calloutCtx.arc(mx, my, ms, 0, Math.PI * 2);
        calloutCtx.stroke();
        calloutCtx.beginPath();              // centre cross
        calloutCtx.moveTo(mx - ms * 0.6, my); calloutCtx.lineTo(mx + ms * 0.6, my);
        calloutCtx.moveTo(mx, my - ms * 0.6); calloutCtx.lineTo(mx, my + ms * 0.6);
        calloutCtx.stroke();
        calloutCtx.restore();

        const insSpecP = (layout.inset_specs || []).find(s => s.id === ind.inset_id);
        const minimizedP = insSpecP && insSpecP.inset_state === 'minimized';
        if (!minimizedP) {
          const iRect = inset.insetDiv.getBoundingClientRect();
          const iL = iRect.left - base.left, iT = iRect.top - base.top;
          const iR = iL + iRect.width,       iB = iT + iRect.height;
          // Nearest inset corner to the marker → shortest, non-crossing leader.
          let best = null, bd = Infinity;
          for (const [qx, qy] of [[iL, iT], [iR, iT], [iR, iB], [iL, iB]]) {
            const dd = (qx - mx) * (qx - mx) + (qy - my) * (qy - my);
            if (dd < bd) { bd = dd; best = [qx, qy]; }
          }
          // Start at the marker's rim (not its centre) toward the corner.
          const ang = Math.atan2(best[1] - my, best[0] - mx);
          calloutCtx.beginPath();
          calloutCtx.moveTo(mx + Math.cos(ang) * ms, my + Math.sin(ang) * ms);
          calloutCtx.lineTo(best[0], best[1]);
          calloutCtx.stroke();
        }
        calloutCtx.restore();
        continue;
      }

      // ── REGION indication: the region's four data-space corners ──────────
      const [rx, ry, rw, rh] = ind.region;
      const [x0, y0] = toFig(rx,      ry);
      const [x1, y1] = toFig(rx + rw, ry);
      const [x2, y2] = toFig(rx + rw, ry + rh);
      const [x3, y3] = toFig(rx,      ry + rh);
      // Axis-aligned bounds of the (untransformed) rect in figure px.
      const rL = Math.min(x0, x1, x2, x3), rR = Math.max(x0, x1, x2, x3);
      const rT = Math.min(y0, y1, y2, y3), rB = Math.max(y0, y1, y2, y3);

      // Dashed source rectangle (drawn as the 4 transformed corners so it
      // stays correct even if a future transform rotates/skews it).  Clipped
      // to the parent's image area so a zoomed-in region that runs off the
      // panel doesn't paint over neighbouring panels (the leaders below are
      // intentionally NOT clipped — they cross panel boundaries).
      calloutCtx.save();
      calloutCtx.beginPath();
      calloutCtx.rect(offX, offY, imgW, imgH);
      calloutCtx.clip();
      calloutCtx.beginPath();
      calloutCtx.moveTo(x0, y0);
      calloutCtx.lineTo(x1, y1);
      calloutCtx.lineTo(x2, y2);
      calloutCtx.lineTo(x3, y3);
      calloutCtx.closePath();
      calloutCtx.stroke();
      calloutCtx.restore();

      // ── leader lines to the inset (skip while minimized) ─────────────────
      const insSpec = (layout.inset_specs || []).find(s => s.id === ind.inset_id);
      const minimized = insSpec && insSpec.inset_state === 'minimized';
      if (!minimized) {
        const iRect = inset.insetDiv.getBoundingClientRect();
        const iL = iRect.left - base.left, iT = iRect.top  - base.top;
        const iR = iL + iRect.width,       iB = iT + iRect.height;

        // Pick which pair of rect corners face the inset (mark_inset loc1/loc2
        // auto): compare the inset's centre to the rect's centre and connect
        // the two corners on the facing side(s).  Deterministic and simple.
        const rcx = (rL + rR) / 2, rcy = (rT + rB) / 2;
        const icx = (iL + iR) / 2, icy = (iT + iB) / 2;
        const dxc = icx - rcx, dyc = icy - rcy;

        // Rect corners (TL, TR, BR, BL) paired with the inset corner nearest
        // to each, so each leader is short and non-crossing.
        const rectCorners = {
          TL: [rL, rT], TR: [rR, rT], BR: [rR, rB], BL: [rL, rB],
        };
        const insCorners = {
          TL: [iL, iT], TR: [iR, iT], BR: [iR, iB], BL: [iL, iB],
        };
        // Choose the two rect corners on the side facing the inset.
        let pair;
        if (Math.abs(dxc) >= Math.abs(dyc)) {
          // Inset predominantly left/right of the rect → connect that vertical edge.
          pair = dxc >= 0 ? [['TR', 'TL'], ['BR', 'BL']]
                          : [['TL', 'TR'], ['BL', 'BR']];
        } else {
          // Inset predominantly above/below → connect that horizontal edge.
          pair = dyc >= 0 ? [['BL', 'TL'], ['BR', 'TR']]
                          : [['TL', 'BL'], ['TR', 'BR']];
        }
        for (const [rc, ic] of pair) {
          const [px, py] = rectCorners[rc];
          const [qx, qy] = insCorners[ic];
          calloutCtx.beginPath();
          calloutCtx.moveTo(px, py);
          calloutCtx.lineTo(qx, qy);
          calloutCtx.stroke();
        }
      }
      calloutCtx.restore();
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // Figure-level annotation layer + edit chrome (Report Builder edit mode)
  // ═══════════════════════════════════════════════════════════════════════════
  const EDIT_ACCENT = '#4b78d2';   // outline / handle accent for edit chrome
  let _figMarkers = [];            // parsed figure_markers_json (fractions)
  let _figMarkerDrag = null;       // active drag: {id, mode, snap, startMX/MY}

  function _editOn() { return !!model.get('edit_chrome'); }

  function _loadFigMarkers() {
    try { _figMarkers = JSON.parse(model.get('figure_markers_json') || '[]') || []; }
    catch (_) { _figMarkers = []; }
    if (!Array.isArray(_figMarkers)) _figMarkers = [];
  }

  // Current figure content size in CSS px (grid content, no padding).
  function _figSizePx() {
    const fw = Number(model.get('fig_width'))  || 640;
    const fh = Number(model.get('fig_height')) || 480;
    return [fw, fh];
  }

  // Fraction (0..1) → figure-content CSS px.
  function _fracToFigPx(fx, fy, fw, fh) { return [fx * fw, fy * fh]; }

  // ── _drawFigureMarkers ────────────────────────────────────────────────────
  // Draw every figure-level annotation onto figMarkerCanvas.  Fraction→px uses
  // the figure content size; circle radius scales with min(fw,fh) so it stays
  // round under a non-square figure.  Handles are drawn only in edit mode.
  function _drawFigureMarkers(sizeOverride, forceNoHandles) {
    const [fw, fh] = sizeOverride || _figSizePx();
    // No markers → collapse the overlay to a 0×0 backing store rather than
    // sizing it to the full figure (same rationale as _drawCallouts: an empty
    // full-figure transparent canvas is the largest canvas in the DOM and
    // shadows panel content for "largest canvas" pixel probes). Zeroing the
    // size also clears any prior drawing.
    if (!_figMarkers.length) {
      if (figMarkerCanvas.width || figMarkerCanvas.height) {
        figMarkerCanvas.width = 0; figMarkerCanvas.height = 0;
        figMarkerCanvas.style.width = '0px'; figMarkerCanvas.style.height = '0px';
      }
      return;
    }
    if (figMarkerCanvas.width !== Math.round(fw * dpr) ||
        figMarkerCanvas.height !== Math.round(fh * dpr)) {
      figMarkerCanvas.style.width  = fw + 'px';
      figMarkerCanvas.style.height = fh + 'px';
      figMarkerCanvas.width  = Math.round(fw * dpr);
      figMarkerCanvas.height = Math.round(fh * dpr);
    }
    figMarkerCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
    figMarkerCtx.clearRect(0, 0, fw, fh);
    const rmin = Math.min(fw, fh);
    const edit = _editOn() && !forceNoHandles;

    for (const m of _figMarkers) {
      const color = m.color || EDIT_ACCENT;
      const lw = m.linewidth != null ? m.linewidth : 2;
      figMarkerCtx.save();
      figMarkerCtx.strokeStyle = color;
      figMarkerCtx.fillStyle   = color;
      figMarkerCtx.lineWidth   = lw;
      if (m.kind === 'text') {
        const [px, py] = _fracToFigPx(m.x, m.y, fw, fh);
        const fs = m.fontsize || 16;
        figMarkerCtx.font = `${fs}px sans-serif`;
        figMarkerCtx.textAlign = 'left';
        figMarkerCtx.textBaseline = 'top';
        figMarkerCtx.fillText(m.text || '', px, py);
        if (edit) _drawHandle2d(figMarkerCtx, px, py, color);
      } else if (m.kind === 'circle') {
        const [px, py] = _fracToFigPx(m.x, m.y, fw, fh);
        const r = (m.r || 0) * rmin;
        figMarkerCtx.beginPath(); figMarkerCtx.arc(px, py, r, 0, Math.PI*2); figMarkerCtx.stroke();
        if (edit) _drawHandle2d(figMarkerCtx, px, py, color);
      } else if (m.kind === 'rect') {
        // x,y = CENTRE; w,h = fractions of figure size.
        const [cx, cy] = _fracToFigPx(m.x, m.y, fw, fh);
        const rw = (m.w || 0) * fw, rh = (m.h || 0) * fh;
        figMarkerCtx.strokeRect(cx - rw/2, cy - rh/2, rw, rh);
        if (edit) _drawHandle2d(figMarkerCtx, cx, cy, color);
      } else if (m.kind === 'arrow') {
        const [tx, ty] = _fracToFigPx(m.x, m.y, fw, fh);
        const [hx, hy] = _fracToFigPx(m.x + (m.u||0), m.y + (m.v||0), fw, fh);
        const ang = Math.atan2(hy-ty, hx-tx), HL = 12;
        figMarkerCtx.beginPath(); figMarkerCtx.moveTo(tx, ty); figMarkerCtx.lineTo(hx, hy); figMarkerCtx.stroke();
        figMarkerCtx.beginPath(); figMarkerCtx.moveTo(hx, hy);
        figMarkerCtx.lineTo(hx-HL*Math.cos(ang-Math.PI/6), hy-HL*Math.sin(ang-Math.PI/6));
        figMarkerCtx.lineTo(hx-HL*Math.cos(ang+Math.PI/6), hy-HL*Math.sin(ang+Math.PI/6));
        figMarkerCtx.closePath(); figMarkerCtx.fill();
        if (edit) { _drawHandle2d(figMarkerCtx, tx, ty, color); _drawHandle2d(figMarkerCtx, hx, hy, color); }
      }
      figMarkerCtx.restore();
    }
  }

  // Mouse (figMarkerCanvas CSS px) for a pointer event.
  function _figMarkerMouse(e) {
    const r = figMarkerCanvas.getBoundingClientRect();
    const sx = r.width  ? figMarkerCanvas.width  / dpr / r.width  : 1;
    const sy = r.height ? figMarkerCanvas.height / dpr / r.height : 1;
    return [(e.clientX - r.left) * sx, (e.clientY - r.top) * sy];
  }

  // Hit-test the figure markers (topmost first). Returns {id, mode} or null.
  function _figMarkerHitTest(mx, my) {
    const [fw, fh] = _figSizePx();
    const rmin = Math.min(fw, fh);
    const HR = 9;
    for (let i = _figMarkers.length - 1; i >= 0; i--) {
      const m = _figMarkers[i];
      if (m.kind === 'arrow') {
        const [tx, ty] = _fracToFigPx(m.x, m.y, fw, fh);
        const [hx, hy] = _fracToFigPx(m.x + (m.u||0), m.y + (m.v||0), fw, fh);
        if (Math.hypot(mx-hx, my-hy) <= HR) return { id: m.id, mode: 'resize_head' };
        if (Math.hypot(mx-tx, my-ty) <= HR) return { id: m.id, mode: 'move' };
        if (_distToSegment2d(mx, my, tx, ty, hx, hy) <= HR) return { id: m.id, mode: 'move' };
      } else if (m.kind === 'circle') {
        const [px, py] = _fracToFigPx(m.x, m.y, fw, fh);
        const r = (m.r || 0) * rmin;
        if (Math.abs(Math.hypot(mx-px, my-py) - r) <= Math.max(HR, r*0.18) ||
            Math.hypot(mx-px, my-py) <= HR) return { id: m.id, mode: 'move' };
      } else if (m.kind === 'rect') {
        const [cx, cy] = _fracToFigPx(m.x, m.y, fw, fh);
        const rw = (m.w||0) * fw, rh = (m.h||0) * fh;
        if (mx >= cx-rw/2-HR && mx <= cx+rw/2+HR && my >= cy-rh/2-HR && my <= cy+rh/2+HR)
          return { id: m.id, mode: 'move' };
      } else if (m.kind === 'text') {
        const [px, py] = _fracToFigPx(m.x, m.y, fw, fh);
        // Approximate text box: measure width, one line tall.
        figMarkerCtx.save();
        figMarkerCtx.font = `${m.fontsize||16}px sans-serif`;
        const tw = figMarkerCtx.measureText(m.text || '').width;
        figMarkerCtx.restore();
        const th = m.fontsize || 16;
        if (mx >= px-HR && mx <= px+tw+HR && my >= py-HR && my <= py+th+HR)
          return { id: m.id, mode: 'move' };
      }
    }
    return null;
  }

  function _figMarkerById(id) { return _figMarkers.find(m => m.id === id) || null; }

  // Persist the current _figMarkers to the model (no event emission).
  function _writeFigMarkers() {
    model.set('figure_markers_json', JSON.stringify(_figMarkers));
    model.save_changes();
  }

  // Apply a drag delta (in figure fractions) to the dragged marker.
  function _doFigMarkerDrag(e) {
    const d = _figMarkerDrag; if (!d) return;
    const [fw, fh] = _figSizePx();
    const [mx, my] = _figMarkerMouse(e);
    const m = _figMarkerById(d.id); if (!m) return;
    const s = d.snap;
    const dfx = (mx - d.startMX) / fw, dfy = (my - d.startMY) / fh;
    if (d.mode === 'move') {
      m.x = s.x + dfx; m.y = s.y + dfy;
    } else if (d.mode === 'resize_head' && m.kind === 'arrow') {
      m.u = (mx / fw) - m.x; m.v = (my / fh) - m.y;
    }
    _drawFigureMarkers();
    e.preventDefault();
  }

  // ── Panel drag-swap (edit mode) ───────────────────────────────────────────
  // A ~16px "⋮⋮" move grip in each panel cell's top-left corner (edit mode
  // only).  Dragging it starts a swap: the source panel dims, the panel under
  // the cursor is highlighted as the drop target, and releasing over a
  // DIFFERENT panel emits a figure-level {panel_swap} event.  anyplotlib does
  // NOT reorder anything itself — the host swaps + rebuilds the layout.  The
  // grip only exists / captures events under edit_chrome; off-edit it is
  // display:none so it never steals a widget drag or a panel selection click.
  const GRIP_PX = 16;
  let _panelSwapDrag = null;   // {sourceId, startX, startY} while dragging

  function _panelAt(clientX, clientY) {
    // Topmost panel cell containing the point (grid cells don't overlap).
    for (const p of panels.values()) {
      const cell = p.cell; if (!cell) continue;
      // Skip insets — swap is grid-panel only.
      if (p.isInset) continue;
      const r = cell.getBoundingClientRect();
      if (clientX >= r.left && clientX <= r.right &&
          clientY >= r.top  && clientY <= r.bottom) return p;
    }
    return null;
  }

  function _clearSwapFeedback() {
    for (const p of panels.values()) {
      if (!p.cell) continue;
      p.cell.style.opacity = '';
      // Restore the panel's normal chrome (selection/hover outline).
    }
    _applyPanelChrome();
  }

  function _ensureGrip(p) {
    if (p.grip || !p.cell) return;
    const g = document.createElement('div');
    g.className = 'apl-panel-grip';
    // Dark-theme dotted-grid affordance; grab cursor; sits above the canvas
    // stack (canvases are z 5) but is display:none unless edit mode is on.
    g.style.cssText =
      `position:absolute;top:2px;left:2px;width:${GRIP_PX}px;height:${GRIP_PX}px;` +
      `z-index:12;cursor:grab;display:none;border-radius:3px;` +
      `align-items:center;justify-content:center;font-size:12px;line-height:1;` +
      `color:${theme.fg||'#cdd6f4'};background:${theme.bg||'#1e1e2e'};` +
      `border:1px solid ${theme.border||'#44475a'};` +
      `box-shadow:0 1px 3px rgba(0,0,0,0.4);user-select:none;`;
    g.textContent = '⠿';  // ⠿ braille dots — a clean "grab" grid glyph
    g.title = 'Drag to swap this panel';
    g.addEventListener('mousedown', (e) => {
      if (!_editOn() || e.button !== 0) return;
      // Grip wins over panel selection / marker grab within its own bounds.
      e.preventDefault(); e.stopPropagation();
      _panelSwapDrag = { sourceId: p.id, startX: e.clientX, startY: e.clientY };
      g.style.cursor = 'grabbing';
      p.cell.style.opacity = '0.4';   // ghost the source
    });
    p.cell.appendChild(g);
    p.grip = g;
  }

  // Global move / up handlers for an in-progress panel swap.
  document.addEventListener('mousemove', (e) => {
    if (!_panelSwapDrag) return;
    const target = _panelAt(e.clientX, e.clientY);
    // Highlight the drop target (not the source) with a solid accent outline.
    for (const p of panels.values()) {
      if (!p.cell || p.isInset) continue;
      if (p.id === _panelSwapDrag.sourceId) continue;
      if (target && p.id === target.id) {
        p.cell.style.outline = `2px solid ${EDIT_ACCENT}`;
        p.cell.style.outlineOffset = '-2px';
      } else {
        // Clear any transient swap highlight (leave the source alone).
        p.cell.style.outline = '';
        p.cell.style.outlineOffset = '';
      }
    }
    e.preventDefault();
  });

  document.addEventListener('mouseup', (e) => {
    if (!_panelSwapDrag) return;
    const d = _panelSwapDrag; _panelSwapDrag = null;
    if (d.sourceId && panels.get(d.sourceId) && panels.get(d.sourceId).grip)
      panels.get(d.sourceId).grip.style.cursor = 'grab';
    const target = _panelAt(e.clientX, e.clientY);
    // Emit ONLY when released over a different, non-inset panel.
    if (target && !target.isInset && target.id !== d.sourceId) {
      _emitEvent('', 'pointer_up', null, {
        panel_swap: true,
        source_panel_id: d.sourceId,
        target_panel_id: target.id,
        ..._pointerFields(e), button: e.button,
      });
    }
    // Released on the source panel / empty space → cancel cleanly (no emit).
    _clearSwapFeedback();
    e.preventDefault();
  });

  // ── Edit chrome: per-panel hover + selection outlines ─────────────────────
  // Purely JS-local DOM styling; never exported.  Hover uses a dashed accent
  // outline via a data-attr-driven inline style; selection a solid one.
  function _applyPanelChrome() {
    const edit = _editOn();
    const sel = model.get('selected_panel') || '';
    for (const p of panels.values()) {
      const cell = p.cell; if (!cell) continue;
      // Move grip: created lazily, shown only in edit mode on grid panels.
      if (!p.isInset) {
        _ensureGrip(p);
        if (p.grip) p.grip.style.display = edit ? 'flex' : 'none';
      }
      // Insets: the bottom-right resize grip + an accent outline are edit-only
      // affordances; off-edit the inset is inert (no handle, no drag) because
      // _wireInsetDrag's handlers all gate on _editOn(). The outline is a
      // box-shadow (not `outline`) so it doesn't fight the maximized-float /
      // selection styling and rides the inset's own rounded corners.
      if (p.isInset) {
        if (p.resizeGrip) p.resizeGrip.style.display = edit ? 'block' : 'none';
        p.insetDiv.style.boxShadow = edit
          ? `0 2px 14px rgba(0,0,0,0.55), inset 0 0 0 1px ${EDIT_ACCENT}`
          : '0 2px 14px rgba(0,0,0,0.55)';
        continue;   // insets skip the grid-panel selection/hover chrome below
      }
      // Selection outline (persistent, solid) wins over hover.
      // outline-offset is fully NEGATIVE (−width) so the whole ring is inset
      // INSIDE the cell bounds — otherwise an edge/corner panel's outline is
      // clipped at the figure's right/bottom edge (half the stroke spills out).
      if (edit && p.id === sel) {
        cell.style.outline = `2px solid ${EDIT_ACCENT}`;
        cell.style.outlineOffset = '-2px';
      } else if (!p._editHover || !edit) {
        cell.style.outline = '';
        cell.style.outlineOffset = '';
      }
      // (Re)bind hover handlers exactly once per cell.
      if (!p._editHoverBound) {
        p._editHoverBound = true;
        cell.addEventListener('mouseenter', () => {
          p._editHover = true;
          if (_editOn() && p.id !== (model.get('selected_panel') || '')) {
            cell.style.outline = `2px dashed ${EDIT_ACCENT}`;
            cell.style.outlineOffset = '-2px';
          }
        });
        cell.addEventListener('mouseleave', () => {
          p._editHover = false;
          if (p.id !== (model.get('selected_panel') || '')) {
            cell.style.outline = '';
            cell.style.outlineOffset = '';
          }
        });
      }
    }
  }

  // Edit mode redraws the marker layer (so handles appear/disappear) and the
  // panel chrome.  figMarkerCanvas ALWAYS stays pointer-events:none — a
  // full-figure canvas set to `auto` would sit above every panel's overlay
  // (z 35 > z 5) and swallow all panel interaction.  Instead the outerDiv
  // capture handler below hit-tests markers itself, so a marker is grabbable
  // where it lies and panels stay fully interactive everywhere else.
  function _applyEditMode() {
    _applyPanelChrome();
    _drawFigureMarkers();
  }

  document.addEventListener('mousemove', (e) => {
    if (!_figMarkerDrag) return;
    _doFigMarkerDrag(e);
  });
  document.addEventListener('mouseup', (e) => {
    if (!_figMarkerDrag) return;
    const d = _figMarkerDrag; _figMarkerDrag = null;
    const m = _figMarkerById(d.id);
    // Persist + emit a figure_marker pointer_up carrying the updated FRACTIONS.
    _writeFigMarkers();
    const upd = { figure_marker: true, marker_id: d.id };
    if (m) { for (const k of ['x','y','u','v','r','w','h']) if (m[k] !== undefined) upd[k] = m[k]; }
    _emitEvent('', 'pointer_up', null, { ...upd, ..._pointerFields(e), button: e.button });
    e.preventDefault();
  });

  // ── Edit-mode mousedown capture on outerDiv ───────────────────────────────
  // Runs BEFORE any panel handler (capture phase).  Two jobs, both edit-only:
  //   1. If a figure marker is under the cursor → start a marker drag and
  //      STOP propagation so the panel underneath doesn't also react.
  //   2. Else, if the target is NOT inside any panel cell / inset / chrome →
  //      emit a figure-background pointer_down.
  // A plain click inside a panel does neither (its own path handles it).
  outerDiv.addEventListener('mousedown', (e) => {
    if (!_editOn() || e.button !== 0) return;

    // (0) A panel move-grip owns its own bounds — let its own mousedown handler
    // start the swap; do not marker-grab or background-emit here.
    if (e.target && e.target.classList &&
        e.target.classList.contains('apl-panel-grip')) return;

    const [mx, my] = _figMarkerMouse(e);

    // (1) Marker grab — highest priority, even over a panel underneath.
    const hit = _figMarkerHitTest(mx, my);
    if (hit) {
      const m = _figMarkerById(hit.id);
      _figMarkerDrag = { id: hit.id, mode: hit.mode, snap: {...m},
                         startMX: mx, startMY: my };
      e.preventDefault(); e.stopPropagation();
      return;
    }

    // (2) Background detection.
    const t = e.target;
    for (const p of panels.values()) {
      if (p.cell && p.cell.contains(t)) return;   // inside a panel / inset
    }
    if (t === resizeHandle || (helpBtn && helpBtn.contains(t)) ||
        (helpCard && helpCard.contains(t))) return;
    _emitEvent('', 'pointer_down', null, { figure_background: true, ..._pointerFields(e), button: e.button });
  }, true);

  function _resizePanelDOM(id, pw, ph) {
    const p = panels.get(id);
    if (!p) return;
    p.pw = pw; p.ph = ph;

    // Backing-store scale. A native export sets p._dprOv = 1 so canvases are sized
    // in exact data pixels. draw2d re-invokes this on every state push, so the
    // override lives on the panel rather than being a parameter.
    const D = p._dprOv || dpr;

    function _sz(c, ctx, w, h) {
      c.style.width=w+'px'; c.style.height=h+'px';
      c.width=w*D; c.height=h*D;
      // ctx is null for a WebGPU canvas (no 2D context to transform).
      if (ctx) ctx.setTransform(D,0,0,D,0,0);
    }

    if (p.kind === '2d') {
      // ── 2D: all elements absolutely positioned within pw×ph container ──
      // When physical axes are present, reserve PAD gutters for tick labels.
      // When there are no axes (plain imshow) use the full canvas area so
      // no dead space appears on the left / bottom.
      const st = p.state;
      const hasPhysAxis = st && (st.is_mesh || st.has_axes)
                       && st.x_axis && st.x_axis.length >= 2
                       && st.y_axis && st.y_axis.length >= 2;
      // Always reserve the top strip for the title (mirrors 1D behaviour).
      // Left/right/bottom gutters are only used when physical axes are present.
      // The colorbar (strip + values + label gutter) takes space from the
      // image width so it is never clipped at the panel's right edge; in a
      // cell too narrow for all three the values go first (_cbTickW).
      const availW = hasPhysAxis ? pw - PAD_L - PAD_R : pw;
      const cbW  = _cbWidth(st, availW);
      const padT = _padT(st);
      const imgX = hasPhysAxis ? PAD_L : 0;
      const imgY = padT;
      const imgW = Math.max(1, availW - (cbW ? cbW + _cbGap(st) : 0));
      let   imgH = Math.max(1, ph - padT - (hasPhysAxis ? PAD_B : 0));
      // Enforce aspect ratio (st.aspect = number or "equal" → 1.0).
      if (st && st.aspect != null) {
        const asp = (st.aspect === 'equal') ? 1.0 : parseFloat(st.aspect);
        if (Number.isFinite(asp) && asp > 0) imgH = Math.max(1, Math.round(imgW / asp));
      }
      // Store on panel so event handlers and draw functions don't recompute.
      // _cbW/_padT let draw2d detect when a state push requires a re-layout.
      p.imgX = imgX; p.imgY = imgY; p.imgW = imgW; p.imgH = imgH;
      p._cbW = cbW;  p._padT = padT;
      p._cbTickW = _cbTickW(st, availW);   // what drawColorbar2d may write

      // Title canvas: sits in the title strip above the image area
      if (p.titleCanvas && p.titleCtx) {
        p.titleCanvas.style.left    = imgX + 'px';
        p.titleCanvas.style.top     = '0px';
        p.titleCanvas.style.display = 'block';
        p.titleCanvas.style.width   = imgW + 'px';
        p.titleCanvas.style.height  = padT + 'px';
        p.titleCanvas.width  = imgW * D;
        p.titleCanvas.height = padT * D;
        p.titleCtx.setTransform(D, 0, 0, D, 0, 0);
      }

      if (p.plotWrap) {
        p.plotWrap.style.width  = pw + 'px';
        p.plotWrap.style.height = ph + 'px';
      }

      // Image canvas at the inner plot area
      p.plotCanvas.style.left = imgX + 'px';
      p.plotCanvas.style.top  = imgY + 'px';
      _sz(p.plotCanvas, p.plotCtx, imgW, imgH);

      // The 2D WebGPU image canvas (if present) sits under plotCanvas and matches
      // the image area exactly. _sz sets CSS size + D backing; the WebGPU
      // context reconfigures to this size on the next GPU draw.
      if (p.gpuCanvas) {
        p.gpuCanvas.style.left = imgX + 'px';
        p.gpuCanvas.style.top  = imgY + 'px';
        _sz(p.gpuCanvas, null, imgW, imgH);
      }

      // Overlay and markers match the image canvas exactly
      p.overlayCanvas.style.left = imgX + 'px';
      p.overlayCanvas.style.top  = imgY + 'px';
      _sz(p.overlayCanvas, p.ovCtx, imgW, imgH);
      p.markersCanvas.style.left = imgX + 'px';
      p.markersCanvas.style.top  = imgY + 'px';
      _sz(p.markersCanvas, p.mkCtx, imgW, imgH);

      // Status bar: 4px above bottom of image area, 4px right of left edge
      if (p.statusBar) {
        p.statusBar.style.left   = (imgX + 4) + 'px';
        p.statusBar.style.bottom = (ph - imgY - imgH + 4) + 'px';
        p.statusBar.style.top    = '';
      }

      // Scale bar: 12px above bottom-right of image area
      if (p.scaleBar) {
        p.scaleBar.style.right  = (pw - imgX - imgW + 12) + 'px';
        p.scaleBar.style.bottom = (ph - imgY - imgH + 12) + 'px';
        p.scaleBar.style.left   = '';
        p.scaleBar.style.top    = '';
      }


      // y-axis: left gutter [0, PAD_T]..[PAD_L, ph-PAD_B]
      if (p.yAxisCanvas && p.yCtx) {
        if (hasPhysAxis) {
          p.yAxisCanvas.style.display = 'block';
          p.yAxisCanvas.style.left = '0px';
          p.yAxisCanvas.style.top  = imgY + 'px';
          p.yAxisCanvas.style.width  = PAD_L + 'px';
          p.yAxisCanvas.style.height = imgH + 'px';
          p.yAxisCanvas.width  = PAD_L * D;
          p.yAxisCanvas.height = imgH * D;
          p.yCtx.setTransform(D, 0, 0, D, 0, 0);
        } else {
          p.yAxisCanvas.style.display = 'none';
        }
      }

      // x-axis: bottom gutter [PAD_L, ph-PAD_B]..[pw-PAD_R, ph]
      if (p.xAxisCanvas && p.xCtx) {
        if (hasPhysAxis) {
          p.xAxisCanvas.style.display = 'block';
          p.xAxisCanvas.style.left = imgX + 'px';
          p.xAxisCanvas.style.top  = (ph - PAD_B) + 'px';
          p.xAxisCanvas.style.width  = imgW + 'px';
          p.xAxisCanvas.style.height = PAD_B + 'px';
          p.xAxisCanvas.width  = imgW * D;
          p.xAxisCanvas.height = PAD_B * D;
          p.xCtx.setTransform(D, 0, 0, D, 0, 0);
        } else {
          p.xAxisCanvas.style.display = 'none';
        }
      }

      // Colorbar: strip + label gutter in the space reserved by _cbWidth.
      // The strip spans the IMAGE — its letterboxed fit rect — not the whole
      // image area, so a wide image's numbers sit beside its pixels rather
      // than floating far above and below them.
      if (p.cbCanvas && p.cbCtx) {
        if (cbW) {
          const fit = _cbFitRect(st, imgW, imgH);
          p._cbH = fit.h;
          p.cbCanvas.style.display = 'block';
          p.cbCanvas.style.left = (imgX + imgW + _cbGap(st)) + 'px';
          p.cbCanvas.style.top  = (imgY + fit.y) + 'px';
          _sz(p.cbCanvas, p.cbCtx, cbW, fit.h);
        } else {
          p.cbCanvas.style.display = 'none';
        }
      }

    } else if (p.kind === '3d') {
      // ── 3D: full-panel canvases ──
      _sz(p.plotCanvas,    p.plotCtx, pw, ph);
      _sz(p.overlayCanvas, p.ovCtx,   pw, ph);
    } else {
      // ── 1D: canvas is the full pw×ph, padding is drawn internally ──
      _sz(p.plotCanvas,    p.plotCtx,    pw, ph);
      _sz(p.overlayCanvas, p.ovCtx,      pw, ph);
      _sz(p.markersCanvas, p.mkCtx,      pw, ph);
    }
  }

  // ── 2D drawing ───────────────────────────────────────────────────────────

  // Largest rect with the image's natural aspect that fits inside cw×ch,
  // centred.  All 2-D coordinate functions derive from this single rect so
  // draw, hit-test, and coordinate conversion are always consistent.
  // s = uniform scale factor (canvas px per image px).
  function _imgFitRect(iw, ih, cw, ch) {
    const s = Math.min(cw / iw, ch / ih);
    const fw = iw * s, fh = ih * s;
    return { x: (cw - fw) / 2, y: (ch - fh) / 2, w: fw, h: fh, s };
  }

  // The vertical extent the colorbar strip spans: the image's letterboxed
  // fit rect inside the image area, in whole px (the whole area when the
  // image size is not known yet).
  function _cbFitRect(st, imgW, imgH) {
    const iw = st && st.image_width, ih = st && st.image_height;
    if (!(iw > 0 && ih > 0)) return { y: 0, h: Math.max(1, imgH) };
    const fit = _imgFitRect(iw, ih, imgW, imgH);
    return { y: Math.round(fit.y), h: Math.max(1, Math.round(fit.h)) };
  }

  // On-screen rect occupied by image pixels at the current zoom.
  // zoom>=1: full fit-rect; zoom<1: centred shrunken rect inside the fit-rect.
  function _imgVisibleRect2d(st, pw, ph) {
    const fr = _imgFitRect(st.image_width, st.image_height, pw, ph);
    const z = st.zoom || 1.0;
    if (z >= 1.0) return fr;
    const w = fr.w * z, h = fr.h * z;
    return { x: fr.x + (fr.w - w) / 2, y: fr.y + (fr.h - h) / 2, w, h, s: fr.s * z };
  }

  // Clamp a destination rect and its UV mapping to a clip rect.
  // Returns null when fully outside the clip.
  function _clipRectUv(dx, dy, dw, dh, u0, v0, u1, v1, cx, cy, cw, ch) {
    if (!(dw > 0) || !(dh > 0) || !(cw > 0) || !(ch > 0)) return null;
    const ox0 = dx, oy0 = dy, ox1 = dx + dw, oy1 = dy + dh;
    const nx0 = Math.max(ox0, cx), ny0 = Math.max(oy0, cy);
    const nx1 = Math.min(ox1, cx + cw), ny1 = Math.min(oy1, cy + ch);
    if (nx1 <= nx0 || ny1 <= ny0) return null;
    const tx0 = (nx0 - ox0) / dw, tx1 = (nx1 - ox0) / dw;
    const ty0 = (ny0 - oy0) / dh, ty1 = (ny1 - oy0) / dh;
    const du = u1 - u0, dv = v1 - v0;
    return {
      dx: nx0, dy: ny0, dw: nx1 - nx0, dh: ny1 - ny0,
      u0: u0 + du * tx0, u1: u0 + du * tx1,
      v0: v0 + dv * ty0, v1: v0 + dv * ty1,
    };
  }

  // The quantisation band the uint8 image bytes were encoded over, as [lo, hi].
  // A DEGENERATE band (raw_max <= raw_min) means DIFFERENT things on the two
  // encoder paths, and the LUT has to read it the way the bytes were written:
  //
  //   plain (_normalize_image): a constant frame quantises to ALL-ZERO bytes and
  //     reports (c, c) — the band NAMES the single value code 0 stands for, and
  //     hMin + raw/255 * (range||1) reconstructs it. Keep honouring it.
  //   tile (_tile_quant_clim): a degenerate band is treated as UNSET and the
  //     bytes are quantised over the DISPLAY window instead — so they are already
  //     display-mapped and the LUT must be the identity window over them.
  //
  // Reading a tiled degenerate band the plain way is GH #60: a plot that entered
  // tile mode on a flat placeholder carries the band (0, 0), every code maps to
  // hMin + raw/255 * 1 in [0, 1], lands below any sane display floor, and the
  // panel renders solid black beside perfectly healthy stats.
  function _rawBand(st) {
    const lo=st.raw_min, hi=st.raw_max;
    if(lo==null||hi==null) return [st.display_min, st.display_max];
    if(hi>lo) return [lo,hi];
    return st.tile_enabled ? [st.display_min, st.display_max] : [lo,hi];
  }

  // The fraction of the colormap a value maps to through the display window
  // and scale mode — the ONE rule the image LUT and the colorbar strip share,
  // so the strip's colours are the image's (saturated beyond the window).
  function _displayFrac(st, val) {
    const dMin=st.display_min, dMax=st.display_max;
    const mode=st.scale_mode||'linear';
    if(mode==='log'){const dMC=Math.max(dMin,1e-10),dXC=Math.max(dMax,dMC+1e-10);return (Math.log10(Math.max(val,1e-10))-Math.log10(dMC))/(Math.log10(dXC)-Math.log10(dMC));}
    if(mode==='symlog'){const lt=Math.max((dMax-dMin)*0.01,1e-10);const sl=v=>v>=0?(v<=lt?v/lt:1+Math.log10(v/lt)):-(Math.abs(v)<=lt?Math.abs(v)/lt:1+Math.log10(Math.abs(v)/lt));return (sl(val)-sl(dMin))/((sl(dMax)-sl(dMin))||1);}
    return (val-dMin)/((dMax-dMin)||1);
  }

  function _buildLut32(st) {
    const [hMin,hMax]=_rawBand(st);
    const range=hMax-hMin||1;
    const cmapData=st.colormap_data||[];
    let cmapFlat=null;
    if(cmapData.length===256){
      cmapFlat=new Uint8Array(256*4);
      for(let i=0;i<256;i++){cmapFlat[i*4]=cmapData[i][0];cmapFlat[i*4+1]=cmapData[i][1];cmapFlat[i*4+2]=cmapData[i][2];cmapFlat[i*4+3]=255;}
    }
    const lut=new Uint32Array(256);
    const buf=new ArrayBuffer(4); const dv=new DataView(buf); const u32=new Uint32Array(buf);
    for(let raw=0;raw<256;raw++){
      const t=_displayFrac(st,hMin+(raw/255)*range);
      const idx=Math.max(0,Math.min(255,Math.round(t*255)));
      if(cmapFlat){dv.setUint8(0,cmapFlat[idx*4]);dv.setUint8(1,cmapFlat[idx*4+1]);dv.setUint8(2,cmapFlat[idx*4+2]);dv.setUint8(3,255);}
      else{dv.setUint8(0,idx);dv.setUint8(1,idx);dv.setUint8(2,idx);dv.setUint8(3,255);}
      lut[raw]=u32[0];
    }
    return lut;
  }

  function _lutKey(st) {
    return [st.display_min,st.display_max,st.raw_min,st.raw_max,st.scale_mode,st.colormap_name].join('|');
  }

  function _imgToCanvas2d(ix, iy, st, pw, ph) {
    const { x, y, w, h } = _imgFitRect(st.image_width, st.image_height, pw, ph);
    const zoom = st.zoom, cx = st.center_x, cy = st.center_y;
    const iw = st.image_width, ih = st.image_height;
    // +0.5: image coordinate i is the centre of pixel i, which renders at
    // (i + 0.5) * scale in the canvas — not the leading edge (i * scale).
    if (zoom < 1.0) {
      const dstW = w * zoom, dstH = h * zoom;
      const dstX = x + (w - dstW) / 2, dstY = y + (h - dstH) / 2;
      return [dstX + (ix + 0.5) / iw * dstW, dstY + (iy + 0.5) / ih * dstH];
    }
    const visW = iw / zoom, visH = ih / zoom;
    const srcX = Math.max(0, Math.min(iw - visW, cx * iw - visW / 2));
    const srcY = Math.max(0, Math.min(ih - visH, cy * ih - visH / 2));
    return [x + (ix + 0.5 - srcX) / visW * w, y + (iy + 0.5 - srcY) / visH * h];
  }

  // Returns canvas-px per image-px at the current zoom (uniform in x and y).
  function _imgScale2d(st, pw, ph) {
    return _imgFitRect(st.image_width, st.image_height, pw, ph).s * st.zoom;
  }

  // Build (and cache on the panel) the Canvas2D bitmap for the detail tile —
  // LUT-colormapped like the base. Returns null if no tile. Cached by the tile's
  // content key so it rebuilds only when the tile or LUT changes.
  function _detailBitmap(p, st) {
    if (st.is_rgb) return null;
    const d = _detailBytes(st);
    if (!d.bytes || !st.detail_width || !st.detail_height) return null;
    const dw = st.detail_width, dh = st.detail_height;
    const lk = _lutKey(st);
    const cache = (p._detailBlit ||= {});
    if (cache.bitmap && cache.key === d.key && cache.lutKey === lk
        && cache.w === dw && cache.h === dh) return cache.bitmap;
    if (d.bytes.length < dw * dh) return null;
    const imgData = new ImageData(dw, dh);
    const lut = _buildLut32(st);
    const out32 = new Uint32Array(imgData.data.buffer);
    for (let i = 0; i < dw * dh; i++) out32[i] = lut[d.bytes[i]];
    const oc = new OffscreenCanvas(dw, dh);
    oc.getContext('2d').putImageData(imgData, 0, 0);
    cache.bitmap = oc; cache.key = d.key; cache.lutKey = lk;
    cache.w = dw; cache.h = dh;
    return oc;
  }

  // Brief alpha ramp when detail-overlay mode changes (none/partial/full).
  const _DETAIL_BLEND_MS = 90;

  function _detailBlendAlpha(p, mode) {
    const now = performance.now();
    const b = (p._detailBlend ||= { mode: 'none', t0: now });
    if (b.mode !== mode) { b.mode = mode; b.t0 = now; }
    if (mode === 'none') return 0;
    return Math.max(0, Math.min(1, (now - b.t0) / _DETAIL_BLEND_MS));
  }

  // ── Image layers (multi-image overlay) ─────────────────────────────────────
  // Raw single-channel pixel bytes for ONE layer. Prefers the BINARY bytes
  // (`layer_<id>_b64_bytes`, spliced into the geomCache under `<key>_bytes`) over
  // the base64 string in the layer entry's `image_b64`. Returns {bytes, key} where
  // `key` is a cheap identity for the "unchanged → skip rebuild" check.
  function _layerBytes(st, layer) {
    const pk = `layer_${layer.id}_b64`;
    const raw = st[pk + '_bytes'];
    if (raw && (raw instanceof Uint8Array || raw.byteLength !== undefined)) {
      const u8 = raw instanceof Uint8Array ? raw : new Uint8Array(raw);
      let key = layer.image_b64;            // the "\x00bin:<adler>" content token
      if (!key && u8.__aplSeq !== undefined) key = `binseq:${u8.__aplSeq}`;
      if (!key) key = `layerbin:${u8.length}`;
      return { bytes: u8, key };
    }
    const b64 = layer.image_b64 || '';
    if (!b64 || b64.charCodeAt(0) === 0) return { bytes: null, key: '' };  // token, no bytes yet
    try {
      const bin = atob(b64);
      const u8 = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
      return { bytes: u8, key: b64 };
    } catch (_) { return { bytes: null, key: '' }; }
  }

  // Build (and cache on the panel) the LUT-colormapped RGBA OffscreenCanvas for
  // one layer. Cached per layer id by (pixel key, cmap, clim) so a live scrub only
  // rebuilds when the layer's data/appearance actually changes. Returns null when
  // the bytes aren't available or the size is wrong.
  function _layerBitmap(p, st, layer) {
    const d = _layerBytes(st, layer);
    const lw = layer.width || st.image_width;
    const lh = layer.height || st.image_height;
    if (!d.bytes || !lw || !lh || d.bytes.length < lw * lh) return null;
    const cmap = layer.cmap || 'gray';
    const dMin = layer.clim_min, dMax = layer.clim_max;
    // A LUT may carry a 4th (alpha) channel — a clear→colour TINT ramp from
    // Python's _build_tint_lut. Both the tint colour and the presence of alpha
    // go into lutKey so toggling tint ↔ cmap invalidates the cached bitmap.
    const cmapData = layer.colormap_data || st.colormap_data || [];
    const hasAlpha = cmapData.length === 256 && cmapData[0]
                     && cmapData[0].length > 3;
    const lutKey = [cmap, layer.tint || '', hasAlpha ? 'a' : '',
                    dMin, dMax].join('|');
    const cache = (p._layerBlit ||= {});
    const c = cache[layer.id];
    if (c && c.key === d.key && c.lutKey === lutKey && c.w === lw && c.h === lh)
      return c.bitmap;
    // Build a 256-entry uint32 LUT from the layer's own colormap + clim. The layer
    // bytes are quantised over [clim_min, clim_max] (Python side), so code i maps
    // linearly through that window; the LUT bakes clim→colour like the base path.
    // Per-texel alpha (4-channel LUT) rides the ImageData (unpremultiplied) and
    // multiplies naturally with the per-layer ctx.globalAlpha at drawImage time.
    let cmapFlat = null;
    if (cmapData.length === 256) {
      cmapFlat = new Uint8Array(256 * 4);
      for (let i = 0; i < 256; i++) {
        cmapFlat[i*4] = cmapData[i][0]; cmapFlat[i*4+1] = cmapData[i][1];
        cmapFlat[i*4+2] = cmapData[i][2];
        cmapFlat[i*4+3] = cmapData[i][3] ?? 255;
      }
    }
    const lut = new Uint32Array(256);
    const buf = new ArrayBuffer(4); const dv = new DataView(buf);
    const u32 = new Uint32Array(buf);
    for (let raw = 0; raw < 256; raw++) {
      // Bytes are already the normalised index over the layer's clim (Python
      // _normalize_image), so idx == raw — identity into the colormap.
      const idx = raw;
      if (cmapFlat) {
        dv.setUint8(0, cmapFlat[idx*4]); dv.setUint8(1, cmapFlat[idx*4+1]);
        dv.setUint8(2, cmapFlat[idx*4+2]); dv.setUint8(3, cmapFlat[idx*4+3]);
      } else { dv.setUint8(0, idx); dv.setUint8(1, idx); dv.setUint8(2, idx); dv.setUint8(3, 255); }
      lut[raw] = u32[0];
    }
    const imgData = new ImageData(lw, lh);
    const out32 = new Uint32Array(imgData.data.buffer);
    for (let i = 0; i < lw * lh; i++) out32[i] = lut[d.bytes[i]];
    const oc = new OffscreenCanvas(lw, lh);
    oc.getContext('2d').putImageData(imgData, 0, 0);
    cache[layer.id] = { bitmap: oc, key: d.key, lutKey, w: lw, h: lh };
    return oc;
  }

  // Composite every VISIBLE layer over the base image on plotCanvas, bottom-up,
  // using the SAME zoom/pan/fit-rect transform as the base blit (so zoom/pan track
  // exactly) at each layer's own globalAlpha. Layers draw AFTER the base + overlay
  // mask and BEFORE axes/markers/widgets, so they sit under annotations + widgets.
  // Works identically over a WebGPU base (which lives on the gpuCanvas beneath the
  // transparent plotCanvas): the layers just paint onto plotCanvas above it.
  function _drawLayers2d(p, st, imgW, imgH, ctx, iw, ih) {
    const layers = st.layers;
    if (!layers || !layers.length) { if (p._layerBlit) p._layerBlit = {}; return; }
    // Drop cache entries for layers that were removed.
    if (p._layerBlit) {
      const live = new Set(layers.map(l => l.id));
      for (const k in p._layerBlit) if (!live.has(k)) delete p._layerBlit[k];
    }
    const { x, y, w, h } = _imgFitRect(iw, ih, imgW, imgH);
    const z = st.zoom, cx = st.center_x, cy = st.center_y;
    for (const layer of layers) {
      if (layer.visible === false) continue;
      const bmp = _layerBitmap(p, st, layer);
      if (!bmp) continue;
      const alpha = layer.alpha != null ? layer.alpha : 1.0;
      const bw = bmp.width, bh = bmp.height;
      const kx = bw / iw, ky = bh / ih;    // logical→layer-texel scale (==1 here)
      ctx.save();
      ctx.globalAlpha = alpha;
      ctx.imageSmoothingEnabled = false;
      if (z >= 1.0) {
        const visW = iw / z, visH = ih / z;
        const sx = Math.max(0, Math.min(iw - visW, cx * iw - visW / 2));
        const sy = Math.max(0, Math.min(ih - visH, cy * ih - visH / 2));
        ctx.drawImage(bmp, sx * kx, sy * ky, visW * kx, visH * ky, x, y, w, h);
      } else {
        const dw = w * z, dh = h * z;
        ctx.drawImage(bmp, 0, 0, bw, bh, x + (w - dw) / 2, y + (h - dh) / 2, dw, dh);
      }
      ctx.restore();
    }
  }

  function _blit2d(p, bitmap, st, pw, ph, ctx, detailBitmap) {
    const { x, y, w, h } = _imgFitRect(st.image_width, st.image_height, pw, ph);
    const zoom = st.zoom, cx = st.center_x, cy = st.center_y;
    const iw = st.image_width, ih = st.image_height;
    ctx.clearRect(0, 0, pw, ph);
    ctx.fillStyle = theme.bgCanvas;
    ctx.fillRect(0, 0, pw, ph);
    ctx.imageSmoothingEnabled = false;
    // Base pass (overview or full frame) always draws first; detail layers blend over it.
    if (zoom >= 1.0) {
      // Zoomed in: show a portion of the image filling the fit-rect. The visible
      // window is in LOGICAL px; scale it to the bitmap's OWN texels (the base may
      // be a smaller overview: bitmap.width may be < image_width).
      const bw = bitmap.width, bh = bitmap.height;
      const kx = bw / iw, ky = bh / ih;   // logical→bitmap texel scale
      const visW = iw / zoom, visH = ih / zoom;
      const srcX = Math.max(0, Math.min(iw - visW, cx * iw - visW / 2));
      const srcY = Math.max(0, Math.min(ih - visH, cy * ih - visH / 2));
      ctx.drawImage(bitmap, srcX * kx, srcY * ky, visW * kx, visH * ky, x, y, w, h);
    } else {
      // Zoomed out: shrink the fit-rect proportionally, keep it centred. Source is
      // the whole bitmap (overview or full).
      const dstW = w * zoom, dstH = h * zoom;
      ctx.drawImage(bitmap, 0, 0, bitmap.width, bitmap.height,
        x + (w - dstW) / 2, y + (h - dstH) / 2, dstW, dstH);
    }
    const det = detailBitmap ? _detailUV(st) : null;
    const ov = (!det && detailBitmap) ? _detailOverlayRect(st, x, y, w, h) : null;
    const mode = det ? 'full' : (ov ? 'partial' : 'none');
    const alpha = _detailBlendAlpha(p, mode);
    if (mode !== 'none' && alpha < 1 && !p._detailBlendRAF) {
      p._detailBlendRAF = requestAnimationFrame(() => {
        p._detailBlendRAF = 0;
        if (p.state) draw2d(p);
      });
    }
    if (!(alpha > 0) || !detailBitmap) return;

    if (det) {
      const dw = detailBitmap.width, dh = detailBitmap.height;
      const sx = det.u0 * dw, sy = det.v0 * dh;
      const sw = (det.u1 - det.u0) * dw, sh = (det.v1 - det.v0) * dh;
      ctx.save();
      ctx.globalAlpha = alpha;
      ctx.drawImage(detailBitmap, sx, sy, sw, sh, x, y, w, h);
      ctx.restore();
      return;
    }

    const vr = _imgVisibleRect2d(st, pw, ph);
    const cl = _clipRectUv(ov.dx, ov.dy, ov.dw, ov.dh,
      0, 0, 1, 1, vr.x, vr.y, vr.w, vr.h);
    if (!cl) return;
    const dw = detailBitmap.width, dh = detailBitmap.height;
    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.drawImage(detailBitmap,
      cl.u0 * dw, cl.v0 * dh, (cl.u1 - cl.u0) * dw, (cl.v1 - cl.v0) * dh,
      cl.dx, cl.dy, cl.dw, cl.dh);
    ctx.restore();
  }

  function draw2d(p) {
    const st=p.state;
    if(!st) return;
    _recordFrame(p);
    // Re-sync axis/histogram canvas visibility whenever state changes
    _resizePanelDOM(p.id, p.pw, p.ph);
    const {pw,ph,plotCtx:ctx,blitCache} = p;
    // p.imgW/imgH are set by _resizePanelDOM above (full panel when no axes,
    // padded inner area when physical axes are present).
    const imgW = p.imgW || Math.max(1, pw - PAD_L - PAD_R);
    const imgH = p.imgH || Math.max(1, ph - PAD_T - PAD_B);

    // Image bytes: prefer the binary trait (image_bytes, no atob) over base64.
    const _img = _imageBytes(st);
    const b64 = _img.key;                    // cache identity (b64 string or bin token)
    // The base bitmap is built at the OVERVIEW texel size (base_width/height in tile
    // mode; else the full image). _blit2d then draws it over the fit-rect using the
    // LOGICAL image_width/height for the zoom math, so the overview scales to the
    // full extent (lower-res until a detail tile covers the view).
    const iw=st.base_width||st.image_width, ih=st.base_height||st.image_height;

    if(!_img.bytes||iw===0||ih===0){ctx.clearRect(0,0,imgW,imgH);return;}

    const isRgb=!!st.is_rgb;   // bytes are RGBA (4/px) — no LUT applies
    const lk=isRgb?'__rgb__':_lutKey(st);

    // ── WebGPU image path (large scalar images) ─────────────────────────────
    // If the GPU path is active for this panel, draw the image raster on the
    // gpuCanvas (shader-LUT colormap on a texture) and CLEAR the plotCanvas image
    // area so the 2D decorations below (axes/colorbar/scale bar/mask/markers)
    // composite over the GPU image. Any failure reverts to the Canvas2D blit for
    // this frame (and the panel is marked unavailable on hard errors).
    // Test/diagnostic hook: record what the GPU path decided this frame.
    try { (globalThis.__apl_gpu2d ||= {})[p.id] =
      { wanted: _gpuWanted2d(st), gpu: p._gpu, hasImg: !!p._gpuImg,
        iw: st.image_width, ih: st.image_height, active: false }; } catch (_) {}
    let _gpuPainted = false;
    if (_gpuWanted2d(st) && p._gpu === 'active' && p._gpuImg) {
      if (_gpuDraw2dImage(p, st, imgW, imgH)) {
        if (p.gpuCanvas.style.display === 'none') p.gpuCanvas.style.display = 'block';
        // plotCanvas holds only decorations now → transparent, cleared each frame.
        p.plotCanvas.style.background = 'transparent';
        ctx.clearRect(0, 0, imgW, imgH);
        _gpuPainted = true;
        try { globalThis.__apl_gpu2d[p.id].active = true; } catch (_) {}
      } else {
        _tiledbg('path', `panel=${p.id} GPU draw returned FALSE → Canvas2D fallback ` +
          `(tile_enabled=${st.tile_enabled})`);
      }
    } else if (p.gpuCanvas && p.gpuCanvas.style.display !== 'none'
               && (!_gpuWanted2d(st) || p._gpu !== 'active')) {
      // GPU not painting this frame (shrank below threshold, RGB image, a
      // zoom/pan, or device lost) → hide the GPU layer, restore the opaque plot
      // canvas. gpu_active (capability) is echoed only on PERMANENT loss (the
      // device-lost handler); a transient zoom/shrink is reversible so the flag
      // stays as-is rather than flapping per frame.
      p.gpuCanvas.style.display = 'none';
      p.plotCanvas.style.background = theme.bgCanvas;
      try { globalThis.__apl_gpu2d[p.id].active = false; } catch (_) {}
    }

    if (!_gpuPainted) {
    if (globalThis.__apl_tiledbg && st.tile_enabled) {
      const reg = st.detail_region || [];
      const uv = _detailUV(st);
      _tiledbg('canvas', `panel=${p.id} CANVAS2D blit (NOT gpu) ` +
        `zoom=${(st.zoom||1).toFixed(2)} base[${st.base_width}x${st.base_height}] ` +
        `image[${st.image_width}x${st.image_height}] detail_region=[${reg.join(',')}] ` +
        `detailUV=${uv?'COVERS':'partial/none'} hasDetailBmp=${!!_detailBitmap(p, st)}`);
    }
    const needRebuild = b64!==blitCache.bytesKey || lk!==blitCache.lutKey
                     || !blitCache.bitmap || blitCache.w!==iw || blitCache.h!==ih;
    if(!needRebuild && blitCache.bitmap){
      _blit2d(p, blitCache.bitmap, st, imgW, imgH, ctx, _detailBitmap(p, st));
    } else {
      const bytes = _img.bytes;
      if (!bytes) return;
      const imgData=new ImageData(iw,ih);
      if(isRgb){
        imgData.data.set(bytes.subarray(0, iw*ih*4));
      } else {
        const lut=_buildLut32(st);
        const out32=new Uint32Array(imgData.data.buffer);
        for(let i=0;i<iw*ih;i++) out32[i]=lut[bytes[i]];
      }
      const oc=new OffscreenCanvas(iw,ih);
      oc.getContext('2d').putImageData(imgData,0,0);
      blitCache.bitmap=oc; blitCache.bytesKey=b64; blitCache.lutKey=lk;
      blitCache.w=iw; blitCache.h=ih;
      _blit2d(p, oc, st, imgW, imgH, ctx, _detailBitmap(p, st));
    }
    }

    // Kick off async GPU activation if wanted but not yet tried (first frame is
    // always Canvas2D; the device resolves, the panel builds its pipeline, and a
    // redraw flips to GPU). Mirrors the 3D path's async-init contract.
    if (_gpuWanted2d(st) && p.gpuCanvas && p._gpu === undefined) {
      p._gpu = 'pending';
      _gpuDevice().then((device) => {
        // The panel may have been removed while the device promise was pending
        // (guard like the 3D path) — don't init/report/draw on a detached panel.
        if (!device || !panels.has(p.id)) { p._gpu = 'unavailable'; return; }
        try { _gpuInitImagePanel(p, device); p._gpu = 'active'; _reportGpu(p); }
        catch (e) { p._gpu = 'unavailable';
                    console.warn('[anyplotlib] GPU image init failed:', e); }
        _redrawPanel(p);
      });
    }

    // Tile mode: once the panel has a real on-screen size, emit ONE view_changed so
    // the Python tile consumer can size the overview / initial tile to the actual
    // panel px (imgW/imgH are only known after the first layout). Fires immediately
    // (not debounced) so the first crisp tile appears without a user gesture.
    if (st.tile_enabled && !p._didInitialView && p.imgW > 0 && p.imgH > 0) {
      p._didInitialView = true;
      _emitViewChanged(p, true);
    }

    // ── Overlay mask compositing ─────────────────────────────────────────────
    // overlay_mask_b64: base64 uint8 bytes (0|255), same iw×ih as image.
    // Rendered at overlay_mask_alpha on top of the base image without clearing.
    const mob64=st.overlay_mask_b64||'';
    if(!mob64){
      // Mask cleared — release cached bitmap so memory can be reclaimed.
      if(p.maskCache) p.maskCache=null;
    } else {
      const mColor=st.overlay_mask_color||'#ff4444';
      const mAlpha=st.overlay_mask_alpha!=null?st.overlay_mask_alpha:0.4;
      // Compare fields individually to avoid building a large concatenated key
      // on every redraw during pan/zoom (mob64 can be very large).
      if(!p.maskCache||p.maskCache.b64!==mob64||p.maskCache.color!==mColor||p.maskCache.alpha!==mAlpha){
        // Parse hex colour → r,g,b
        let mr=255,mg=68,mb=68;
        if(mColor.startsWith('#')&&mColor.length===7){
          mr=parseInt(mColor.slice(1,3),16);
          mg=parseInt(mColor.slice(3,5),16);
          mb=parseInt(mColor.slice(5,7),16);
        }
        // Binary transport ships the mask bytes on the companion trait (the
        // geom then carries only a "\x00bin:" content token in mob64) — prefer
        // them; atob is the base64-in-JSON fallback.
        let mBytes;
        const mraw=st.overlay_mask_b64_bytes;
        if(mraw&&(mraw instanceof Uint8Array||mraw.byteLength!==undefined)){
          mBytes=mraw instanceof Uint8Array?mraw:new Uint8Array(mraw);
        }else{
          try{const bin=atob(mob64);mBytes=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)mBytes[i]=bin.charCodeAt(i);}catch(_){mBytes=null;}
        }
        if(mBytes&&mBytes.length===iw*ih){
          const mImg=new ImageData(iw,ih);
          // Write colour where mask=255; transparent where mask=0.
          // Store full-alpha pixel; globalAlpha controls final transparency.
          const buf4=new ArrayBuffer(4);const dv4=new DataView(buf4);const u32m=new Uint32Array(buf4);
          dv4.setUint8(0,mr);dv4.setUint8(1,mg);dv4.setUint8(2,mb);dv4.setUint8(3,255);
          const opaque=u32m[0];
          const out32m=new Uint32Array(mImg.data.buffer);
          for(let i=0;i<mBytes.length;i++)out32m[i]=mBytes[i]?opaque:0;
          const moc=new OffscreenCanvas(iw,ih);
          moc.getContext('2d').putImageData(mImg,0,0);
           p.maskCache={b64:mob64,color:mColor,alpha:mAlpha,bitmap:moc};
        }else{p.maskCache=null;}
      }
      if(p.maskCache&&p.maskCache.bitmap){
        // Blit at the same zoom/pan as the base image (inline, no clearRect).
        const {x:_mx,y:_my,w:_mw,h:_mh}=_imgFitRect(iw,ih,imgW,imgH);
        const _mz=st.zoom,_mcx=st.center_x,_mcy=st.center_y;
        ctx.save();ctx.globalAlpha=mAlpha;ctx.imageSmoothingEnabled=false;
        if(_mz>=1.0){
          const _vw=iw/_mz,_vh=ih/_mz;
          const _sx=Math.max(0,Math.min(iw-_vw,_mcx*iw-_vw/2));
          const _sy=Math.max(0,Math.min(ih-_vh,_mcy*ih-_vh/2));
          ctx.drawImage(p.maskCache.bitmap,_sx,_sy,_vw,_vh,_mx,_my,_mw,_mh);
        }else{
          const _dw=_mw*_mz,_dh=_mh*_mz;
          ctx.drawImage(p.maskCache.bitmap,0,0,iw,ih,_mx+(_mw-_dw)/2,_my+(_mh-_dh)/2,_dw,_dh);
        }
        ctx.restore();
      }
    }
    // ── Image layers ─────────────────────────────────────────────────────────
    // Composited over the base image (+ overlay mask) at each layer's own
    // colormap/clim/alpha, using the same zoom/pan transform, UNDER axes/markers/
    // widgets. For a WebGPU base the layers paint on the transparent plotCanvas
    // that sits above the gpuCanvas. iw/ih == the logical image size here (tiling
    // is forbidden when layers exist, so base_width is 0 and iw == image_width).
    _drawLayers2d(p, st, imgW, imgH, ctx, iw, ih);

    // Axes / scalebar / colorbar
    _drawAxes2d(p);
    drawScaleBar2d(p);
    drawColorbar2d(p);
    drawOverlay2d(p);
    drawMarkers2d(p);
  }

  function drawScaleBar2d(p) {
    const st=p.state; if(!st||!p.scaleBar) return;
    // pcolormesh panels have non-uniform axes: no meaningful single pixel scale
    if(st.is_mesh){p.scaleBar.style.display='none';return;}
    const units=st.units||'px';
    const scaleX=st.scale_x||0;
    if(!scaleX||units==='px'){p.scaleBar.style.display='none';return;}

    const imgW=p.imgW||Math.max(1,p.pw-PAD_L-PAD_R);
    const imgH=p.imgH||Math.max(1,p.ph-PAD_T-PAD_B);

    // Compute bar width in the fit-rect pixel space
    const zoom=st.zoom||1;
    const iw=st.image_width||imgW;
    const fr=_imgFitRect(iw, st.image_height||imgH, imgW, imgH);
    const visDataW=(zoom>=1?iw/zoom:iw)*scaleX;
    const targetDataWidth=visDataW*0.2;
    const niceWidth=findNice(targetDataWidth);
    const barPx=Math.round((niceWidth/visDataW)*fr.w);  // use fit-rect width
    if(barPx<4){p.scaleBar.style.display='none';return;}

    // Layout constants (CSS pixels)
    const fontSize  = 11;
    const lineH     = 3;
    const gap       = 6;   // space between bottom of text and top of line
    const padX      = 8;
    const padTop    = 5;
    const padBot    = 5;

    // Measure text to size the canvas
    const label=`${fmtVal(niceWidth)} ${units}`;
    const cvW=Math.max(barPx, fontSize*label.length*0.6|0) + padX*2;
    const cvH=padTop + fontSize + gap + lineH + padBot;

    const sb=p.scaleBar;
    if(sb.width!==Math.round(cvW*dpr)||sb.height!==Math.round(cvH*dpr)){
      sb.width=Math.round(cvW*dpr);
      sb.height=Math.round(cvH*dpr);
      sb.style.width=cvW+'px';
      sb.style.height=cvH+'px';
    }
    const ctx=sb.getContext('2d');
    ctx.setTransform(dpr,0,0,dpr,0,0);
    ctx.clearRect(0,0,cvW,cvH);

    // Colours. Default is the original white-on-black pill; scalebar_color
    // recolours the bar and its label, and scalebar_bgcolor the pill —
    // 'none' drops the pill entirely, for a bar drawn straight onto a light
    // image where the dark slab is the thing that looks wrong.
    const sbFg = st.scalebar_color || 'white';
    const sbBg = st.scalebar_bgcolor === undefined || st.scalebar_bgcolor === null
      ? 'rgba(0,0,0,0.60)' : st.scalebar_bgcolor;

    // Background pill
    if(sbBg !== 'none'){
      ctx.fillStyle=sbBg;
      const r=5;
      ctx.beginPath();
      ctx.moveTo(r,0);ctx.lineTo(cvW-r,0);ctx.arcTo(cvW,0,cvW,r,r);
      ctx.lineTo(cvW,cvH-r);ctx.arcTo(cvW,cvH,cvW-r,cvH,r);
      ctx.lineTo(r,cvH);ctx.arcTo(0,cvH,0,cvH-r,r);
      ctx.lineTo(0,r);ctx.arcTo(0,0,r,0,r);
      ctx.closePath();ctx.fill();
    }

    // Label (centred over the bar line)
    const lineX=(cvW-barPx)/2;
    const textY=padTop+fontSize;
    ctx.fillStyle=sbFg;
    ctx.font=`bold ${fontSize}px sans-serif`;
    ctx.textAlign='center';
    ctx.textBaseline='alphabetic';
    ctx.fillText(label, cvW/2, textY);

    // Bar line
    const lineY=padTop+fontSize+gap;
    ctx.fillStyle=sbFg;
    ctx.fillRect(lineX, lineY, barPx, lineH);

    // End ticks
    ctx.fillRect(lineX, lineY-3, 2, lineH+3);
    ctx.fillRect(lineX+barPx-2, lineY-3, 2, lineH+3);

    sb.style.display='block';
  }

  // ── Floating image keys (Plot.add_key) ────────────────────────────────────
  // The scale bar's sibling: a picture pinned in SCREEN space over the plot
  // area, so it neither pans nor zooms with the data. Every key on a panel
  // shares one canvas (p.keyCanvas, z 7). Because that canvas is separate from
  // plotCanvas, an ordinary data redraw does NOT erase it — keys are redrawn
  // only when the key state, the panel size, or the hover flag changes, which
  // is what makes `hover_only` free.
  //
  // Images decode asynchronously, exactly like a 3-D surface texture: the
  // first frame that sees a new URL draws nothing for that key and schedules
  // a redraw from onload.
  const _keyCache = new Map();          // url -> {img, ready, w, h}

  function _keyEnsure(url, onReady) {
    let e = _keyCache.get(url);
    if (e) return e.ready ? e : null;
    e = { img: null, ready: false, w: 0, h: 0 };
    _keyCache.set(url, e);
    const img = new Image();
    img.onload = () => {
      e.img = img;
      e.w = img.naturalWidth || img.width;
      e.h = img.naturalHeight || img.height;
      e.ready = e.w > 0 && e.h > 0;
      if (e.ready) onReady();
    };
    img.onerror = () => console.warn('[anyplotlib] key image failed to decode');
    img.src = url;
    return null;
  }

  // The rect keys are placed against — the panel's IMAGE / plot area, the same
  // box the scale bar pins itself to (see _resizePanelDOM, which drives the
  // scale bar off exactly these four numbers). Deliberately not the letterbox
  // fit-rect: a key belongs to the axes box, so it stays put when the data's
  // aspect ratio changes, which is what you want while stepping frames.
  function _keyRect(p) {
    if (p.kind === '2d' && p.imgW && p.imgH) {
      return { x: p.imgX || 0, y: p.imgY || 0, w: p.imgW, h: p.imgH };
    }
    if (p.kind === '3d') return { x: 0, y: 0, w: p.pw, h: p.ph };
    return { x: PAD_L, y: p._padT || PAD_T,
             w: Math.max(1, p.pw - PAD_L - PAD_R),
             h: Math.max(1, p.ph - (p._padT || PAD_T) - PAD_B) };
  }

  // `target` overrides p.keyCanvas — used by the export path to re-render the
  // keys onto a scratch canvas with hover suppressed. Returns true if it drew
  // anything, so the caller can skip compositing an empty canvas.
  function drawKeys(p, target) {
    const kc = target || p.keyCanvas; if (!kc) return false;
    const st = p.state || {};
    const keys = st.keys || [];
    const imgs = st.key_images || {};
    // `hover_only` keys are drawn only while the pointer is over the panel.
    // p._hover is set by the panel's mouseenter/mouseleave handlers.
    // Two filters, and the difference matters. `declared` decides whether the
    // canvas EXISTS on screen; `shown` decides what gets painted on it. A panel
    // whose only keys are hover_only still keeps a sized, displayed (but empty)
    // canvas, because the export path measures against its bounding rect — and
    // a display:none canvas measures 0x0, which would silently drop the key.
    const declared = keys.filter(k => k && k.visible !== false);
    if (!declared.length) { if (!target) kc.style.display = 'none'; return false; }
    const shown = declared.filter(k => !k.hover_only || p._hover);

    const pw = p.pw, ph = p.ph;
    const W = Math.round(pw * dpr), H = Math.round(ph * dpr);
    if (kc.width !== W || kc.height !== H) { kc.width = W; kc.height = H; }
    if (!target) {
      kc.style.width = pw + 'px'; kc.style.height = ph + 'px';
      kc.style.display = 'block';
    }
    const ctx = kc.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, pw, ph);

    // Start decoding EVERY declared key, not just the ones drawn this frame.
    // A hover_only key that has never been on screen would otherwise not have
    // begun decoding, so the first hover would reveal nothing until a second
    // redraw — and an export would silently omit it, since the export path
    // renders once with no chance to wait for onload.
    for (const k of declared) {
      const u = imgs[k.id];
      if (u) _keyEnsure(u, () => drawKeys(p));
    }

    const R = _keyRect(p);
    let drew = false;
    for (const k of shown) {
      const url = imgs[k.id]; if (!url) continue;
      const e = _keyEnsure(url, () => drawKeys(p));
      if (!e) continue;                       // still decoding
      drew = true;

      // `size` is a fraction of the SHORTER side, so a key keeps its
      // proportions when the panel is resized to any aspect ratio.
      const kw = Math.max(1, (k.size != null ? k.size : 0.22) * Math.min(R.w, R.h));
      const kh = kw * (e.h / e.w);
      const lblSize = k.label ? (k.label_size || 10) : 0;
      const lblGap  = k.label ? 3 : 0;
      const pad     = (k.bgcolor && k.bgcolor !== 'none') || k.border ? 5 : 0;
      const cardW = kw + pad * 2;
      const cardH = kh + lblSize + lblGap + pad * 2;

      let cx, cy;                              // card top-left, panel coords
      if (k.anchor) {                          // free placement: anchor = CENTRE
        cx = R.x + k.anchor[0] * R.w - cardW / 2;
        cy = R.y + k.anchor[1] * R.h - cardH / 2;
      } else {
        const m = k.margin != null ? k.margin : 10;
        const corner = k.corner || 'top-right';
        cx = corner.endsWith('left') ? R.x + m : R.x + R.w - cardW - m;
        cy = corner.startsWith('top') ? R.y + m : R.y + R.h - cardH - m;
      }

      ctx.save();
      ctx.globalAlpha = k.alpha != null ? k.alpha : 1;
      const rad = k.radius != null ? k.radius : 4;
      if ((k.bgcolor && k.bgcolor !== 'none') || k.border) {
        ctx.beginPath();
        if (ctx.roundRect) ctx.roundRect(cx, cy, cardW, cardH, rad);
        else ctx.rect(cx, cy, cardW, cardH);
        if (k.bgcolor && k.bgcolor !== 'none') {
          ctx.fillStyle = k.bgcolor; ctx.fill();
        }
        if (k.border) {
          ctx.strokeStyle = k.border;
          ctx.lineWidth = k.border_width != null ? k.border_width : 1;
          ctx.stroke();
        }
      }
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = 'high';
      ctx.drawImage(e.img, cx + pad, cy + pad, kw, kh);

      // Text drawn INSIDE the picture — an IPF triangle's corner indices, a
      // wheel's compass points. Positions are fractions of the image box, so
      // they track the picture through a resize. Drawn over the image with a
      // thin dark halo, because a key's own colours are arbitrary and there is
      // no background colour to key the text off.
      for (const L of (k.labels || [])) {
        const tx = cx + pad + (L.x || 0) * kw, ty = cy + pad + (L.y || 0) * kh;
        const ts = L.size || 9;
        ctx.textBaseline = 'middle';
        ctx.lineWidth = 2.5;
        ctx.strokeStyle = 'rgba(0,0,0,0.55)';
        ctx.lineJoin = 'round';
        const prevFill = ctx.fillStyle;
        // _drawTex strokes nothing, so lay a halo down with the same call
        // under a stroke-only style, then paint the glyphs on top.
        ctx.fillStyle = 'rgba(0,0,0,0.55)';
        for (const [ox, oy] of [[-1,0],[1,0],[0,-1],[0,1]]) {
          _drawTex(ctx, L.text, tx + ox, ty + oy, ts,
                   { align: L.align || 'center' });
        }
        ctx.fillStyle = L.color || '#ffffff';
        _drawTex(ctx, L.text, tx, ty, ts, { align: L.align || 'center' });
        ctx.fillStyle = prevFill;
      }

      if (k.label) {
        // A caption on a card follows the card, not the figure: the usual card
        // is a translucent dark slab, and theme.tickText is near-black under a
        // light theme, which would put dark text on a dark pill. With no card
        // the label sits on the figure and takes the tick colour as usual.
        const onCard = k.bgcolor && k.bgcolor !== 'none';
        ctx.fillStyle = k.label_color || (onCard ? '#f0f0f0' : theme.tickText);
        ctx.textBaseline = 'top';
        _drawTex(ctx, k.label, cx + cardW / 2, cy + pad + kh + lblGap,
                 lblSize, { align: 'center' });
      }
      ctx.restore();
    }
    return drew;
  }

  // Export helper: an exported figure shows EVERY key, `hover_only` included —
  // the export renders the panel as though the pointer were over it, so what
  // you save is what you would see while reading the plot. The live canvas
  // already shows them when the pointer happens to be there; otherwise
  // re-render onto a scratch with the flag forced on, mirroring the
  // _drawPanelWidgetsNoHandles precedent. Returns null when the live canvas is
  // already correct (the common case), undefined when there is nothing to draw.
  function _drawPanelKeysForExport(p) {
    const st = p.state || {};
    if (p._hover || !(st.keys || []).some(k => k && k.hover_only)) return null;
    const scratch = document.createElement('canvas');
    const saved = p._hover;
    p._hover = true;
    let drew;
    try { drew = drawKeys(p, scratch); } finally { p._hover = saved; }
    return drew ? scratch : undefined;
  }

  function drawColorbar2d(p) {
    const st=p.state; if(!st||!p.cbCanvas||!p.cbCtx) return;
    const vis=(st.show_colorbar&&!st.is_rgb)||false;   // no LUT for RGB images
    p.cbCanvas.style.display = vis ? 'block' : 'none';
    if(!vis) return;

    const cbStripW=16;
    const cbLabel=st.colorbar_label||'';
    // The value gutter the layout reserved for this panel (0 in a cell too
    // narrow for it); the strip and label always fit.
    const tickW=(p._cbTickW!=null)?p._cbTickW:_cbTickW(st);
    const labelW=_cbLabelW(st);
    const cbW=cbStripW+tickW+labelW;
    // The strip is as tall as the image's letterboxed rect (_resizePanelDOM),
    // not the whole image area, so its numbers sit beside the pixels.
    const imgH=p._cbH||p.imgH||Math.max(1,p.ph-PAD_T-PAD_B);
    const ctx=p.cbCtx;
    ctx.clearRect(0,0,cbW,imgH);

    // display_min / display_max, and the raw band the strip's rows span.
    const dMin=st.display_min, dMax=st.display_max;
    const [hMin,hMax]=_rawBand(st);
    const vRange=(hMax-hMin)||1;

    // Gradient strip: each row's raw value coloured the way the image colours
    // it — through the display window, saturated beyond it — so the numbers
    // written at the marks are the values of the colours beside them.
    if(st.colormap_data&&st.colormap_data.length===256){
      for(let py=0;py<imgH;py++){
        const frac=1-py/(imgH-1||1);
        const t=_displayFrac(st,hMin+frac*vRange);
        const ci=Math.max(0,Math.min(255,Math.round(t*255)));
        const [r2,g2,b2]=st.colormap_data[ci];
        ctx.fillStyle=`rgb(${r2},${g2},${b2})`;
        ctx.fillRect(0,py,cbStripW,1);
      }
    } else {
      ctx.fillStyle=theme.dark?'#444':'#ccc';
      ctx.fillRect(0,0,cbStripW,imgH);
    }

    // Border
    ctx.strokeStyle=theme.border||'#888';
    ctx.lineWidth=0.5;
    ctx.strokeRect(0,0,cbStripW,imgH);

    // display_min / display_max tick marks
    function _vToY(v){return imgH-1-((v-hMin)/vRange)*(imgH-1);}
    ctx.strokeStyle='rgba(255,255,255,0.85)'; ctx.lineWidth=1.5;
    ctx.beginPath();ctx.moveTo(0,_vToY(dMax));ctx.lineTo(cbStripW,_vToY(dMax));ctx.stroke();
    ctx.beginPath();ctx.moveTo(0,_vToY(dMin));ctx.lineTo(cbStripW,_vToY(dMin));ctx.stroke();

    // The values at those marks, so the strip says how much and not only
    // which way.  Same format as the axis ticks; kept inside the strip's
    // height by the glyphs' measured extent, held apart when a tiny display
    // range would stack them, and reduced to the maximum alone — or nothing —
    // on a strip too short to hold both.
    // Where the rotated label is centred: after the values when there are
    // any (the reserved gutter is a budget, the text is usually shorter, and
    // a label floating 30 px from "1" reads as unrelated), else after the
    // strip.
    let labelCentre=cbStripW+tickW+labelW/2+1;
    const [loText,hiText]=fmtRange(dMin,dMax);
    if(tickW>0&&loText&&hiText){
      const tickPx=st.tick_size||10;
      ctx.fillStyle=theme.tickText;
      ctx.font=tickPx+'px sans-serif';
      ctx.textAlign='left';
      ctx.textBaseline='middle';
      // Extent above/below the middle baseline plus a 2 px margin, so an
      // antialiased edge never reaches the canvas edge; the fallback is half
      // the size.
      const extent=t=>{const m=ctx.measureText(t);
        return {asc:(m.actualBoundingBoxAscent||tickPx*0.5)+2,
                desc:(m.actualBoundingBoxDescent||tickPx*0.5)+2,
                w:m.width};};
      const hi=extent(hiText), lo=extent(loText);
      const top=hi.asc, bottom=imgH-lo.desc;
      if(bottom>=top){
        const clampY=y=>Math.min(Math.max(y,top),bottom);
        let yHi=clampY(_vToY(dMax)), yLo=clampY(_vToY(dMin));
        const need=hi.desc+lo.asc;             // no overlap between the two
        if(yLo-yHi<need){
          const mid=(yLo+yHi)/2;
          yHi=mid-need/2; yLo=mid+need/2;
          if(yHi<top){yHi=top; yLo=top+need;}
          if(yLo>bottom){yLo=bottom; yHi=bottom-need;}
        }
        // Both fit, or the maximum alone at its own clamped place — never a
        // maximum pushed off the top to make room for a minimum that then
        // is not drawn either.
        const both=yHi>=top&&yLo<=bottom;
        ctx.fillText(hiText,cbStripW+3,both?yHi:clampY(_vToY(dMax)));
        if(both) ctx.fillText(loText,cbStripW+3,yLo);
        const textW=Math.max(hi.w,lo.w);
        labelCentre=Math.min(labelCentre,cbStripW+3+textW+4+labelW/2);
      }
    }

    // Colorbar label (rotated −90°, centred right of the values)
    if(cbLabel){
      ctx.save();
      ctx.translate(labelCentre, imgH/2);
      ctx.rotate(-Math.PI/2);
      ctx.textBaseline='middle';
      ctx.fillStyle=theme.unitText;
      _drawTex(ctx,cbLabel,0,0,st.colorbar_label_size||10,{align:'center'});
      ctx.restore();
    }
  }


  function _drawAxes2d(p) {
    const st=p.state; if(!st) return;
    const {pw,ph} = p;
    const imgW = p.imgW||Math.max(1, pw - PAD_L - PAD_R);
    const imgH = p.imgH||Math.max(1, ph - PAD_T - PAD_B);
    const xArr=st.x_axis||[], yArr=st.y_axis||[];
    const TICK=6;
    const zoom=st.zoom, cx=st.center_x, cy=st.center_y;
    const units=st.units||'px';
    const hasPhysAxis = (st.is_mesh || st.has_axes) && xArr.length>=2 && yArr.length>=2;
    if(st.axis_visible===false){
      if(p.xAxisCanvas) p.xAxisCanvas.style.display='none';
      if(p.yAxisCanvas) p.yAxisCanvas.style.display='none';
    } else if(hasPhysAxis){
      if(st.x_ticks_visible===false&&p.xAxisCanvas) p.xAxisCanvas.style.display='none';
      if(st.y_ticks_visible===false&&p.yAxisCanvas) p.yAxisCanvas.style.display='none';
    }
    const hasX=hasPhysAxis&&st.axis_visible!==false&&st.x_ticks_visible!==false&&p.xCtx&&p.xAxisCanvas&&p.xAxisCanvas.style.display!=='none';
    const hasY=hasPhysAxis&&st.axis_visible!==false&&st.y_ticks_visible!==false&&p.yCtx&&p.yAxisCanvas&&p.yAxisCanvas.style.display!=='none';

    function _visFrac(z,c){
      if(z>=1.0){const h=0.5/z;const cc=Math.max(h,Math.min(1-h,c));return[cc-h,cc+h];}
      return[0,1];
    }
    function _fracToPx(frac, z, center, span) {
      if(z>=1.0){
        const h=0.5/z, cc=Math.max(h,Math.min(1-h,center));
        return (frac-(cc-h))/(2*h)*span;
      }
      return (span-span*z)/2+frac*span*z;
    }

    // ── X axis canvas: imgW × PAD_B, origin at top-left ─────────────────
    // x=0 aligns with the left edge of the image, spans imgW pixels
    if(hasX){
      const aw=imgW, ah=PAD_B;
      p.xCtx.clearRect(0,0,aw,ah);
      p.xCtx.fillStyle=theme.axisBg; p.xCtx.fillRect(0,0,aw,ah);
      p.xCtx.strokeStyle=theme.axisStroke; p.xCtx.lineWidth=1;
      p.xCtx.beginPath(); p.xCtx.moveTo(0,0); p.xCtx.lineTo(aw,0); p.xCtx.stroke();
      const [xF0,xF1]=_visFrac(zoom,cx);
      const xVMin=_axisFracToVal(xArr,xF0), xVMax=_axisFracToVal(xArr,xF1);
      const step=findNice((xVMax-xVMin)/Math.max(3,Math.floor(imgW/60)));
      p.xCtx.strokeStyle=theme.tickStroke;
      p.xCtx.fillStyle=theme.tickText; p.xCtx.font=(st.tick_size||10)+'px sans-serif';
      p.xCtx.textAlign='center'; p.xCtx.textBaseline='top';
      // Generate nice tick values; place each at its true canvas position
      // via binary-search into the axis array (works for both linear and
      // non-linear / pcolormesh edge arrays).
      const xTicks=[];
      for(let v=Math.ceil(xVMin/step)*step; v<=xVMax+step*0.01; v+=step) xTicks.push(v);
      // Clamp first/last label so it doesn't overflow the canvas edges
      const minLabelGap=28; // px — minimum gap between adjacent labels
      let lastPx=-Infinity;
      for(let ti=0;ti<xTicks.length;ti++){
        const v=xTicks[ti];
        const frac=_axisValToFrac(xArr,v);
        const px2=_fracToPx(frac,zoom,cx,imgW);
        if(px2<0||px2>imgW) continue;
        p.xCtx.beginPath(); p.xCtx.moveTo(px2,0); p.xCtx.lineTo(px2,TICK); p.xCtx.stroke();
        // Skip label if too close to the previous one
        if(px2-lastPx>=minLabelGap){
          const txt=fmtVal(v);
          // Nudge edge labels inward so they are never clipped by the canvas
          const hw=p.xCtx.measureText(txt).width/2;
          p.xCtx.fillText(txt, Math.min(Math.max(px2,hw), aw-hw), TICK+2);
          lastPx=px2;
        }
      }
      p.xCtx.textAlign='right'; p.xCtx.textBaseline='bottom';
      p.xCtx.fillStyle=theme.unitText; p.xCtx.font='9px sans-serif';
      p.xCtx.fillText(units, aw-2, ah-1);
      const xlabel=st.x_label||'';
      if(xlabel){p.xCtx.fillStyle=theme.tickText;p.xCtx.textBaseline='bottom';_drawTex(p.xCtx,xlabel,aw/2,ah-2,st.x_label_size||11,{align:'center'});}
    }

    // ── Y axis canvas: PAD_L × imgH, origin at top-left ─────────────────
    // y=0 aligns with the top edge of the image, spans imgH pixels
    if(hasY){
      const aw=PAD_L, ah=imgH;
      p.yCtx.clearRect(0,0,aw,ah);
      p.yCtx.fillStyle=theme.axisBg; p.yCtx.fillRect(0,0,aw,ah);
      p.yCtx.strokeStyle=theme.axisStroke; p.yCtx.lineWidth=1;
      p.yCtx.beginPath(); p.yCtx.moveTo(aw,0); p.yCtx.lineTo(aw,ah); p.yCtx.stroke();
      const [yF0,yF1]=_visFrac(zoom,cy);
      const yVMin=_axisFracToVal(yArr,yF0), yVMax=_axisFracToVal(yArr,yF1);
      const step=findNice((yVMax-yVMin)/Math.max(3,Math.floor(imgH/60)));
      p.yCtx.strokeStyle=theme.tickStroke;
      p.yCtx.fillStyle=theme.tickText; p.yCtx.font=(st.tick_size||10)+'px sans-serif';
      p.yCtx.textAlign='right'; p.yCtx.textBaseline='middle';
      const yTicks=[];
      for(let v=Math.ceil(yVMin/step)*step; v<=yVMax+step*0.01; v+=step) yTicks.push(v);
      const minLabelGapY=14; // px
      let lastPy=-Infinity;
      for(let ti=0;ti<yTicks.length;ti++){
        const v=yTicks[ti];
        const frac=_axisValToFrac(yArr,v);
        const py2=_fracToPx(frac,zoom,cy,imgH);
        if(py2<0||py2>imgH) continue;
        p.yCtx.beginPath(); p.yCtx.moveTo(aw,py2); p.yCtx.lineTo(aw-TICK,py2); p.yCtx.stroke();
        if(py2-lastPy>=minLabelGapY){
          // Nudge edge labels inward so digits are never cut by the canvas
          const vh=(st.tick_size||10)*0.5+1;
          p.yCtx.fillText(fmtVal(v), aw-TICK-2, Math.min(Math.max(py2,vh), ah-vh));
          lastPy=py2;
        }
      }
      // Units label: top-left corner of y-axis gutter
      p.yCtx.textAlign='left'; p.yCtx.textBaseline='top';
      p.yCtx.fillStyle=theme.unitText; p.yCtx.font='9px sans-serif';
      p.yCtx.fillText(units, 2, 1);
      const ylabel=st.y_label||'';
      if(ylabel){
        p.yCtx.save();
        // Keep the rotated label's full height inside the gutter at large sizes
        const ylpx=st.y_label_size||11;
        p.yCtx.translate(Math.max(Math.round(aw*0.15), Math.ceil(ylpx*0.62)+1), ah/2);
        p.yCtx.rotate(-Math.PI/2);
        p.yCtx.textBaseline='middle';
        p.yCtx.fillStyle=theme.tickText;
        _drawTex(p.yCtx,ylabel,0,0,ylpx,{align:'center'});
        p.yCtx.restore();
      }
    }
    const title2d = st.title || '';
    if (p.titleCanvas && p.titleCtx) {
      const tw   = p.imgW || imgW;
      const padT = p._padT || PAD_T;   // strip grows with title_size > 11
      p.titleCtx.clearRect(0, 0, tw, padT);
      if (title2d) {
        // Clamp the drawn size so even the tallest glyphs (caps, descenders,
        // TeX superscripts) fit the strip WITH clear top/bottom margin on
        // every platform.  Font hinting varies — macOS Chromium renders ~1px
        // taller than Windows at the same px — so a strip-tight title was
        // clipped at row 0 on macOS CI.  Reserve ~4px total vertical margin;
        // padT grows for large/TeX titles (see _padT) so this only bites the
        // 12px default strip, capping an 11px title to ~8px — a sub-pixel
        // change well within the visual-regression tolerance.
        const px = Math.min(st.title_size || 11, padT - 4);
        p.titleCtx.fillStyle = theme.tickText;
        p.titleCtx.textBaseline = 'middle';
        _drawTex(p.titleCtx, title2d, tw / 2, padT / 2,
                 px, { align: 'center', weight: 'bold' });
      }
    }
  }

  // opts (optional): { ctx, imgW, imgH, forceNoHandles }
  //   ctx/imgW/imgH default to the panel's own live overlay canvas/dims — pass
  //   an offscreen ctx + matching dims to redraw the SAME widgets elsewhere
  //   (e.g. exportPNG's handle-free export redraw; see _drawOverlay2dNoHandles).
  //   forceNoHandles suppresses the handle dots regardless of each widget's
  //   own show_handles (mirrors _drawFigureMarkers(sizeOverride, forceNoHandles)).
  function drawOverlay2d(p, opts) {
    const st=p.state; if(!st) return;
    const o = opts || {};
    const {pw,ph} = p;
    const ovCtx = o.ctx || p.ovCtx;
    const imgW = o.imgW || p.imgW || Math.max(1,pw-PAD_L-PAD_R);
    const imgH = o.imgH || p.imgH || Math.max(1,ph-PAD_T-PAD_B);
    ovCtx.clearRect(0,0,imgW,imgH);
    const widgets=st.overlay_widgets||[];
    const scale=_imgScale2d(st,imgW,imgH);
    const vr = _imgVisibleRect2d(st, imgW, imgH);
    ovCtx.save();
    ovCtx.beginPath(); ovCtx.rect(vr.x, vr.y, vr.w, vr.h); ovCtx.clip();
    for(const w of widgets){
      if(w.visible === false) continue;
      // Handle dots are drawn unless the widget opts out (show_handles:false),
      // or the caller forces them off entirely (export redraw).
      const _handles = !o.forceNoHandles && w.show_handles !== false;
      ovCtx.save(); ovCtx.strokeStyle=w.color||'#00e5ff'; ovCtx.lineWidth=(w.linewidth!=null?w.linewidth:2);
      if(w.type==='circle'){
        const [ccx,ccy]=_imgToCanvas2d(w.cx,w.cy,st,imgW,imgH);
        ovCtx.beginPath(); ovCtx.arc(ccx,ccy,w.r*scale,0,Math.PI*2); ovCtx.stroke();
        if(_handles){
          // Centre node = move; east-point node = resize radius.
          _drawHandle2d(ovCtx,ccx,ccy,w.color);
          _drawHandle2d(ovCtx,ccx+w.r*scale,ccy,w.color);
        }
      } else if(w.type==='annular'){
        const [ccx,ccy]=_imgToCanvas2d(w.cx,w.cy,st,imgW,imgH);
        ovCtx.beginPath();ovCtx.arc(ccx,ccy,w.r_outer*scale,0,Math.PI*2);ovCtx.stroke();
        ovCtx.beginPath();ovCtx.arc(ccx,ccy,w.r_inner*scale,0,Math.PI*2);ovCtx.stroke();
        if(_handles){
          _drawHandle2d(ovCtx,ccx+w.r_outer*scale,ccy,w.color);
          _drawHandle2d(ovCtx,ccx+w.r_inner*scale,ccy-w.r_inner*scale*0.3,w.color);
        }
      } else if(w.type==='rectangle'){
        const [rx,ry]=_imgToCanvas2d(w.x,w.y,st,imgW,imgH);
        const rw=w.w*scale, rh=w.h*scale;
        ovCtx.strokeRect(rx,ry,rw,rh);
        // Canvas-space geometry readback for Playwright (same role as
        // window._aplTiming). A test cannot derive a handle's page position from
        // figure padding: the image->canvas mapping depends on the zoom/extent
        // state, and the grab radius is only HR px — so a hard-coded corner
        // silently grabs the BODY instead, and a resize test then asserts
        // nothing. Publishing the drawn corners lets a test aim at a real handle.
        if(!window._aplWidgetGeom) window._aplWidgetGeom={};
        if(!window._aplWidgetGeom[p.id]) window._aplWidgetGeom[p.id]={};
        window._aplWidgetGeom[p.id][w.id]={type:'rectangle',rx,ry,rw,rh};
        if(_handles){
          _drawHandle2d(ovCtx,rx,ry,w.color);_drawHandle2d(ovCtx,rx+rw,ry,w.color);
          _drawHandle2d(ovCtx,rx,ry+rh,w.color);_drawHandle2d(ovCtx,rx+rw,ry+rh,w.color);
        }
      } else if(w.type==='crosshair'){
        const [ccx,ccy]=_imgToCanvas2d(w.cx,w.cy,st,imgW,imgH);
        ovCtx.beginPath();ovCtx.moveTo(0,ccy);ovCtx.lineTo(imgW,ccy);ovCtx.stroke();
        ovCtx.beginPath();ovCtx.moveTo(ccx,0);ovCtx.lineTo(ccx,imgH);ovCtx.stroke();
        if(_handles){ovCtx.beginPath();ovCtx.arc(ccx,ccy,4,0,Math.PI*2);ovCtx.fillStyle=w.color||'#00e5ff';ovCtx.fill();}
      } else if(w.type==='vline'){
        // Full-height rule at image x. No handle dot: the whole line is the
        // grab target, so a dot would only add clutter.
        const [vx]=_imgToCanvas2d(w.x,0,st,imgW,imgH);
        ovCtx.beginPath();ovCtx.moveTo(vx,0);ovCtx.lineTo(vx,imgH);ovCtx.stroke();
      } else if(w.type==='hline'){
        const [,hy]=_imgToCanvas2d(0,w.y,st,imgW,imgH);
        ovCtx.beginPath();ovCtx.moveTo(0,hy);ovCtx.lineTo(imgW,hy);ovCtx.stroke();
      } else if(w.type==='line'){
        // Bare segment: no arrowhead (that's 'arrow'), no closed path
        // (that's 'polygon'). Handles mark the two draggable endpoints.
        const [ax,ay]=_imgToCanvas2d(w.x1,w.y1,st,imgW,imgH);
        const [bx,by]=_imgToCanvas2d(w.x2,w.y2,st,imgW,imgH);
        ovCtx.beginPath();ovCtx.moveTo(ax,ay);ovCtx.lineTo(bx,by);ovCtx.stroke();
        // Canvas-space readback for Playwright, same role as the rectangle
        // branch above: a test cannot derive an endpoint's page position from
        // figure padding, because the image->canvas mapping depends on the
        // zoom/extent state.
        if(!window._aplWidgetGeom) window._aplWidgetGeom={};
        if(!window._aplWidgetGeom[p.id]) window._aplWidgetGeom[p.id]={};
        window._aplWidgetGeom[p.id][w.id]={type:'line',ax,ay,bx,by};
        if(_handles){_drawHandle2d(ovCtx,ax,ay,w.color);_drawHandle2d(ovCtx,bx,by,w.color);}
      } else if(w.type==='polygon'){
        const verts=w.vertices||[];
        if(verts.length>=2){
          ovCtx.beginPath();
          const [px0,py0]=_imgToCanvas2d(verts[0][0],verts[0][1],st,imgW,imgH);
          ovCtx.moveTo(px0,py0);
          for(let k=1;k<verts.length;k++){const[px,py]=_imgToCanvas2d(verts[k][0],verts[k][1],st,imgW,imgH);ovCtx.lineTo(px,py);}
          ovCtx.closePath();ovCtx.stroke();
          if(_handles) for(const v of verts){const[px,py]=_imgToCanvas2d(v[0],v[1],st,imgW,imgH);_drawHandle2d(ovCtx,px,py,w.color);}
        }
      } else if(w.type==='brush'){
        // Freehand painted strokes (region labelling). Each stroke is a polyline
        // of IMAGE-pixel points; `radius` is the brush RADIUS, so the band is
        // 2*radius image px wide — the same disk the erase hit-test uses and a
        // downstream rasteriser must use, so what is drawn is what is labelled.
        // Round cap+join is what makes a polyline read as a brush stroke rather
        // than a chain of mitred segments.
        // A stroke IN PROGRESS lives in the panel scratch, not in the widget
        // dict (see _brushLiveBegin) — prefer it, so the live stroke keeps
        // drawing even through the redraw an unrelated model echo triggers.
        const _bL=(p._brushLive&&p._brushLive.wid===w.id)?p._brushLive:null;
        const _bs=(_bL?_bL.strokes:w.strokes)||[];
        const _bc=(_bL?_bL.classes:w.stroke_classes)||[];
        const _bcols=w.colors||[];
        const _brad=(w.radius!=null?w.radius:8);
        const _blw=Math.max(1,_brad*2*scale);
        ovCtx.lineCap='round'; ovCtx.lineJoin='round'; ovCtx.lineWidth=_blw;
        ovCtx.globalAlpha=(w.alpha!=null?w.alpha:0.6);
        const _bgeom=[];
        for(let s=0;s<_bs.length;s++){
          const pts=_bs[s]; if(!pts||!pts.length) continue;
          const _col=_bcols[_bc[s]|0]||w.color||'#00e5ff';
          ovCtx.strokeStyle=_col; ovCtx.fillStyle=_col;
          const cpts=[];
          for(let k=0;k<pts.length;k++) cpts.push(_imgToCanvas2d(pts[k][0],pts[k][1],st,imgW,imgH));
          if(cpts.length===1){
            // A tap with no motion is one dot. A zero-length subpath is not
            // portably stroked, so draw the round cap explicitly.
            ovCtx.beginPath();ovCtx.arc(cpts[0][0],cpts[0][1],_blw/2,0,Math.PI*2);ovCtx.fill();
          } else {
            ovCtx.beginPath();ovCtx.moveTo(cpts[0][0],cpts[0][1]);
            for(let k=1;k<cpts.length;k++) ovCtx.lineTo(cpts[k][0],cpts[k][1]);
            ovCtx.stroke();
          }
          _bgeom.push(cpts);
        }
        // Canvas-space readback for Playwright, same role as the rectangle
        // branch — but a brush has no handle to aim at, and with zero strokes
        // nothing is drawn at all. So publish the image->canvas TRANSFORM too
        // (origin of image px (0,0) plus canvas-px-per-image-px), which is what
        // a test actually needs to start a stroke at a known image coordinate.
        if(!window._aplWidgetGeom) window._aplWidgetGeom={};
        if(!window._aplWidgetGeom[p.id]) window._aplWidgetGeom[p.id]={};
        const _borg=_imgToCanvas2d(0,0,st,imgW,imgH);
        window._aplWidgetGeom[p.id][w.id]={type:'brush',ox:_borg[0],oy:_borg[1],
          scale,radius_px:_blw/2,n_strokes:_bgeom.length,strokes:_bgeom};
      } else if(w.type==='label'){
        const [lx,ly]=_imgToCanvas2d(w.x,w.y,st,imgW,imgH);
        ovCtx.font=`${w.fontsize||14}px sans-serif`;ovCtx.fillStyle=w.color||'#00e5ff';
        ovCtx.textAlign='left';ovCtx.textBaseline='top';ovCtx.fillText(w.text||'',lx,ly);
        if(_handles) _drawHandle2d(ovCtx,lx,ly,w.color);
      } else if(w.type==='arrow'){
        // Shaft from tail (x,y) to head (x+u,y+v), then a filled arrowhead —
        // reusing the head math from the static 'arrows' marker branch.
        const [tx,ty]=_imgToCanvas2d(w.x,w.y,st,imgW,imgH);
        const [hx,hy]=_imgToCanvas2d(w.x+w.u,w.y+w.v,st,imgW,imgH);
        ovCtx.fillStyle=w.color||'#00e5ff';
        const ang=Math.atan2(hy-ty,hx-tx), HL=10;
        ovCtx.beginPath();ovCtx.moveTo(tx,ty);ovCtx.lineTo(hx,hy);ovCtx.stroke();
        ovCtx.beginPath();ovCtx.moveTo(hx,hy);
        ovCtx.lineTo(hx-HL*Math.cos(ang-Math.PI/6),hy-HL*Math.sin(ang-Math.PI/6));
        ovCtx.lineTo(hx-HL*Math.cos(ang+Math.PI/6),hy-HL*Math.sin(ang+Math.PI/6));
        ovCtx.closePath();ovCtx.fill();
        if(_handles){_drawHandle2d(ovCtx,tx,ty,w.color);_drawHandle2d(ovCtx,hx,hy,w.color);}
      }
      ovCtx.restore();
    }
    ovCtx.restore();
  }

  function _drawHandle2d(ctx,x,y,color){
    ctx.save();ctx.fillStyle='#fff';ctx.strokeStyle=color||'#00e5ff';ctx.lineWidth=1.5;
    ctx.beginPath();ctx.arc(x,y,5,0,Math.PI*2);ctx.fill();ctx.stroke();ctx.restore();
  }

  function drawMarkers2d(p, hoverState) {
    const st=p.state; if(!st) return;
    const {pw,ph,mkCtx} = p;
    const imgW=p.imgW||Math.max(1,pw-PAD_L-PAD_R), imgH=p.imgH||Math.max(1,ph-PAD_T-PAD_B);
    mkCtx.clearRect(0,0,imgW,imgH);
    const sets=st.markers||[];
    if(!sets.length) return;
    const scale=_imgScale2d(st,imgW,imgH);
    const vr = _imgVisibleRect2d(st, imgW, imgH);
    const hsi = hoverState ? hoverState.si : -1;

    for(let si=0;si<sets.length;si++){
      const ms=sets[si];
      const isHov = si===hsi;
      const color = ms.color      || '#ff0000';
      const fc    = ms.fill_color || null;
      const fa    = ms.fill_alpha != null ? ms.fill_alpha : 0.3;
      const lw    = ms.linewidth  != null ? ms.linewidth  : 1.5;
      // Hover colours: only applied when explicitly set — no default fallback.
      // When hovered the whole group switches colour; linewidth bumped by 1.
      const ec  = isHov && ms.hover_color     ? ms.hover_color     : color;
      const fch = isHov && ms.hover_facecolor ? ms.hover_facecolor : fc;
      const dlw = isHov && (ms.hover_color || ms.hover_facecolor) ? lw+1 : lw;
      const type = ms.type || 'circles';
      // Per-marker edge/face colours: `color` and `fill_color` may be arrays
      // parallel to the markers (matplotlib's edgecolors=[...] / c=[...]).
      // Shorter arrays cycle, as matplotlib's colour cycle does.
      const _ecArr = Array.isArray(ec)  ? ec  : null;
      const _fcArr = Array.isArray(fch) ? fch : null;
      const _ecAt = (i) => _ecArr ? _ecArr[i % _ecArr.length] : ec;
      const _fcAt = (i) => _fcArr ? _fcArr[i % _fcArr.length] : fch;

      // Coordinate transform dispatch: "data" (default), "axes", "display".
      // For non-data transforms sizes are in pixels, not scaled by zoom.
      const tfm = ms.transform || 'data';
      const clipSet = tfm !== 'display' || ms.clip_display !== false;
      let _tc;
      if(tfm==='axes'){
        const fr=_imgFitRect(st.image_width,st.image_height,imgW,imgH);
        _tc=(fx,fy)=>[fr.x+fx*fr.w, fr.y+(1-fy)*fr.h];
      } else if(tfm==='display'){
        _tc=(ix,iy)=>[ix,iy];
      } else {
        _tc=(ix,iy)=>_imgToCanvas2d(ix,iy,st,imgW,imgH);
      }
      const scl = tfm==='data' ? scale : 1;
      // Sizes have their own space, independent of the position transform:
      // 'data' (default) grows with zoom the way a shape drawn on the data
      // does; 'px' pins them to screen pixels. A marker standing in for a
      // *point* wants px — matplotlib sizes scatter markers in display
      // points for exactly that reason.
      const sscl = ms.size_units==='px' ? 1 : scl;

      mkCtx.save();
      if(clipSet){
        mkCtx.beginPath(); mkCtx.rect(vr.x, vr.y, vr.w, vr.h); mkCtx.clip();
      }
      // Group-level style; per-marker arrays override inside each loop below.
      mkCtx.strokeStyle=_ecAt(0); mkCtx.fillStyle=_ecAt(0); mkCtx.lineWidth=dlw;

      if(type==='circles'){
        for(let i=0;i<ms.offsets.length;i++){
          const [cx,cy]=_tc(ms.offsets[i][0],ms.offsets[i][1]);
          const r=Math.max(1,(ms.sizes[i]!=null?ms.sizes[i]:ms.sizes[0]||5)*sscl);
          mkCtx.beginPath();mkCtx.arc(cx,cy,r,0,Math.PI*2);
          const _fc=_fcAt(i);
          if(_fc){mkCtx.save();mkCtx.globalAlpha=fa;mkCtx.fillStyle=_fc;mkCtx.fill();mkCtx.restore();}
          if(_ecArr) mkCtx.strokeStyle=_ecAt(i);
          mkCtx.stroke();
        }
      } else if(type==='arrows'){
        const HL=8;
        for(let i=0;i<ms.offsets.length;i++){
          const [x1,y1]=_tc(ms.offsets[i][0],ms.offsets[i][1]);
          const u=(ms.U[i]||0)*scl, v=(ms.V[i]||0)*scl;
          const x2=x1+u,y2=y1+v,ang=Math.atan2(y2-y1,x2-x1);
          if(_ecArr){mkCtx.strokeStyle=_ecAt(i);mkCtx.fillStyle=_ecAt(i);}
          mkCtx.beginPath();mkCtx.moveTo(x1,y1);mkCtx.lineTo(x2,y2);mkCtx.stroke();
          mkCtx.beginPath();mkCtx.moveTo(x2,y2);
          mkCtx.lineTo(x2-HL*Math.cos(ang-Math.PI/6),y2-HL*Math.sin(ang-Math.PI/6));
          mkCtx.lineTo(x2-HL*Math.cos(ang+Math.PI/6),y2-HL*Math.sin(ang+Math.PI/6));
          mkCtx.closePath();mkCtx.fill();
        }
      } else if(type==='ellipses'){
        for(let i=0;i<ms.offsets.length;i++){
          const [cx,cy]=_tc(ms.offsets[i][0],ms.offsets[i][1]);
          const rw=Math.max(1,(ms.widths[i]||ms.widths[0]||10)*sscl/2);
          const rh=Math.max(1,(ms.heights[i]||ms.heights[0]||10)*sscl/2);
          const ang=((ms.angles[i]||ms.angles[0]||0)*Math.PI)/180;
          mkCtx.beginPath();mkCtx.ellipse(cx,cy,rw,rh,ang,0,Math.PI*2);
          const _fc=_fcAt(i);
          if(_fc){mkCtx.save();mkCtx.globalAlpha=fa;mkCtx.fillStyle=_fc;mkCtx.fill();mkCtx.restore();}
          if(_ecArr) mkCtx.strokeStyle=_ecAt(i);
          mkCtx.stroke();
        }
      } else if(type==='lines'){
        const segs=ms.segments||[];
        for(let i=0;i<segs.length;i++){
          const seg=segs[i];
          const [x1,y1]=_tc(seg[0][0],seg[0][1]);
          const [x2,y2]=_tc(seg[1][0],seg[1][1]);
          if(_ecArr) mkCtx.strokeStyle=_ecAt(i);
          mkCtx.beginPath();mkCtx.moveTo(x1,y1);mkCtx.lineTo(x2,y2);mkCtx.stroke();
        }
      } else if(type==='rectangles'||type==='squares'){
        const heights=type==='squares'?ms.widths:ms.heights;
        for(let i=0;i<ms.offsets.length;i++){
          const [cx,cy]=_tc(ms.offsets[i][0],ms.offsets[i][1]);
          const rw=(ms.widths[i]||ms.widths[0]||20)*sscl;
          const rh=((heights[i]||heights[0]||20))*sscl;
          const ang=((ms.angles&&(ms.angles[i]||ms.angles[0])||0)*Math.PI)/180;
          mkCtx.save();mkCtx.translate(cx,cy);mkCtx.rotate(ang);
          const _fc=_fcAt(i);
          if(_fc){mkCtx.save();mkCtx.globalAlpha=fa;mkCtx.fillStyle=_fc;mkCtx.fillRect(-rw/2,-rh/2,rw,rh);mkCtx.restore();}
          if(_ecArr) mkCtx.strokeStyle=_ecAt(i);
          mkCtx.strokeRect(-rw/2,-rh/2,rw,rh);
          mkCtx.restore();
        }
      } else if(type==='polygons'){
        for(let i=0;i<(ms.vertices_list||[]).length;i++){
          const verts=ms.vertices_list[i];
          if(!verts||verts.length<2) continue;
          const [px0,py0]=_tc(verts[0][0],verts[0][1]);
          mkCtx.beginPath();mkCtx.moveTo(px0,py0);
          for(let k=1;k<verts.length;k++){const[px,py]=_tc(verts[k][0],verts[k][1]);mkCtx.lineTo(px,py);}
          mkCtx.closePath();
          const _fc=_fcAt(i);
          if(_fc){mkCtx.save();mkCtx.globalAlpha=fa;mkCtx.fillStyle=_fc;mkCtx.fill();mkCtx.restore();}
          if(_ecArr) mkCtx.strokeStyle=_ecAt(i);
          mkCtx.stroke();
        }
      } else if(type==='texts'){
        const fs=ms.fontsize||12;
        mkCtx.font=`${fs}px sans-serif`;mkCtx.textAlign='left';mkCtx.textBaseline='top';
        for(let i=0;i<ms.offsets.length;i++){
          const [cx,cy]=_tc(ms.offsets[i][0],ms.offsets[i][1]);
          if(_ecArr) mkCtx.fillStyle=_ecAt(i);
          mkCtx.fillText(String(ms.texts[i]||''),cx,cy);
        }
      }
      mkCtx.restore();
    }
  }

  // ── 3D drawing ───────────────────────────────────────────────────────────

  function _rot3(az, el) {
    // Turntable camera (matplotlib azim/elev semantics): azimuth spins the
    // scene about the DATA z-axis, elevation tilts it toward the viewer.
    // Screen axes after rotation: x'→right, y'→depth into screen, z'→up.
    // Unlike the previous Ry·Rx form (which pinned the data x-axis into the
    // screen plane), this view direction reaches ANY point on the sphere —
    // required for rotate-to-face interactions (e.g. the IPF explorer).
    // The camera faces unit vector v when  el = asin(vz),  az = atan2(vx, -vy).
    const azR = az * Math.PI / 180, elR = el * Math.PI / 180;
    const ca = Math.cos(azR), sa = Math.sin(azR);
    const ce = Math.cos(elR), se = Math.sin(elR);
    // R = Tilt_x(el) * Spin_z(az)
    return [
      [ ca,     sa,     0 ],
      [-ce*sa,  ce*ca, -se],
      [-se*sa,  se*ca,  ce],
    ];
  }

  function _applyRot(R, v) {
    return [
      R[0][0]*v[0] + R[0][1]*v[1] + R[0][2]*v[2],
      R[1][0]*v[0] + R[1][1]*v[1] + R[1][2]*v[2],
      R[2][0]*v[0] + R[2][1]*v[1] + R[2][2]*v[2],
    ];
  }

  function _project3(rv, cx, cy, scale) {
    // Weak perspective: x→right, z→up on screen
    return [cx + rv[0] * scale, cy - rv[2] * scale];
  }

  function _colourFromLut(lut, t) {
    // t in [0,1] → CSS colour from 256-entry [[r,g,b],...] lut
    const i = Math.max(0, Math.min(255, Math.round(t * 255)));
    const c = lut[i];
    if (!c) return '#888';
    return `rgb(${c[0]},${c[1]},${c[2]})`;
  }

  // ── 3D surface textures (Plot3D.set_texture) ─────────────────────────────
  // st.texture_url is a data: URL and st.texture_uv_b64 the per-vertex (u, v)
  // pairs; both ride the geometry channel.  Image decode is asynchronous, so
  // the frame that first sees a texture draws the colormapped surface and
  // schedules a redraw once the bitmap is ready — the same progressive
  // pattern the WebGPU init uses.  Returns the ready cache entry or null.
  //
  // Every triangle is genuinely texture-mapped (clip + affine drawImage).
  // A flat "sample one texel per small triangle" shortcut was tried and
  // dropped: it is ~3× cheaper per triangle, but flat shading makes
  // neighbours differ in colour, and the deliberate seam overlap below then
  // widens each of those steps into a visible herringbone across the mesh.
  // Textures therefore want a COARSE grid — the image carries the detail, so
  // ~2k triangles (orbiting at ~7 ms/frame) looks better than ~32k flat ones.
  function _texEnsure(p, url) {
    const cache = (p._3dTex ||= {});
    if (cache.url === url) return cache.ready ? cache : null;
    cache.url = url; cache.ready = false; cache.img = null;
    if (!url) return null;
    const img = new Image();
    img.onload = () => {
      if (!p._3dTex || p._3dTex.url !== url || !panels.has(p.id)) return;
      cache.img = img;
      cache.tw = img.naturalWidth  || img.width;
      cache.th = img.naturalHeight || img.height;
      cache.ready = cache.tw > 0 && cache.th > 0;
      if (cache.ready) _redrawPanel(p);
    };
    img.onerror = () => {
      if (p._3dTex && p._3dTex.url === url) cache.ready = false;
      console.warn('[anyplotlib] 3-D surface texture failed to decode');
    };
    img.src = url;
    return null;
  }

  // Light direction in VIEW space — (right, into-screen, up) — mostly from
  // the camera with an upper-left bias, which reads as a lit sphere rather
  // than a crescent.  Dotted against a camera-facing normal, so shading is
  // independent of the surface's triangle winding.
  const _TEX_LIGHT = (() => {
    const v = [-0.35, -0.85, 0.40];
    const m = Math.hypot(v[0], v[1], v[2]);
    return [v[0]/m, v[1]/m, v[2]/m];
  })();

  // Outward edge offset, in CSS px, applied to every textured triangle so
  // neighbours overlap instead of leaving antialiased hairlines between them.
  const _TEX_EXPAND = 0.75;
  // Cap on how far a vertex may travel: the exact miter length runs away as a
  // corner sharpens, and the near-degenerate slivers a sphere shows at its
  // limb would otherwise spray far outside the surface.
  const _TEX_MITER_MAX = 4.0;

  // Scale factor for a miter offset: `t·(nA+nB)/(1+nA·nB)`, length-clamped.
  // `sx`/`sy` are nA+nB and `den` is 1+nA·nB.
  function _miter(sx, sy, den) {
    const k = _TEX_EXPAND / Math.max(1e-4, den);
    const len = Math.hypot(sx, sy) * k;
    return len > _TEX_MITER_MAX ? k * (_TEX_MITER_MAX / len) : k;
  }

  // ═══════════════════════════════════════════════════════════════════════
  // WebGPU geometry renderer (progressive enhancement — Phase 1 prototype).
  //
  // Strictly additive: only instanced POINTS move to the GPU, and only when
  // (a) navigator.gpu exists, (b) an adapter+device resolve, and (c) the
  // panel opts in (gpu_mode 'always', or 'auto' above GPU_POINT_THRESHOLD).
  // Every failure — no navigator.gpu, null adapter, device loss — leaves
  // p._gpu === 'unavailable' and the Canvas2D path renders exactly as before.
  //
  // Decorations (axes, labels, sphere, planes, highlight) are NEVER on the
  // GPU; draw3d draws them over a transparent plotCanvas when GPU is active.
  // ═══════════════════════════════════════════════════════════════════════
  const GPU_POINT_THRESHOLD = 20000;
  const GPU_VOXEL_THRESHOLD = 1000;   // cubes cost ~6× a point on canvas, and
                                      // re-slicing (set_data on drag) redraws
                                      // them every frame, so switch to the GPU
                                      // early — a few thousand cubes already
                                      // stutter on Canvas2D.
  // A 2-D scalar image goes to the GPU (shader-LUT colormap on a texture) above
  // this many pixels — below it the Canvas2D atob+LUT loop is already instant.
  // ~1 megapixel: a 1024² image and up (a large in-situ movie frame is 16-64 Mpx).
  const GPU_IMAGE_THRESHOLD = 1 << 20;
  // A textured surface is worth the GPU almost immediately: each Canvas2D
  // triangle costs a clip + affine drawImage (~6 µs), so a few thousand
  // already misses 60 fps, while the GPU draws hundreds of thousands in one
  // indexed pass.  Below this a surface renders identically on canvas and
  // skips the device-init round trip.
  const GPU_SURFACE_THRESHOLD = 2000;
  let _gpuDevicePromise = null;   // module singleton: Promise<GPUDevice|null>

  function _gpuDevice() {
    if (_gpuDevicePromise) return _gpuDevicePromise;
    _gpuDevicePromise = (async () => {
      try {
        if (!navigator.gpu) return null;
        const adapter = await navigator.gpu.requestAdapter();
        if (!adapter) return null;
        const device = await adapter.requestDevice();
        device.lost.then((info) => {
          // Permanent per-session fallback: any GPU panel reverts to canvas.
          _gpuDevicePromise = Promise.resolve(null);
          for (const p of panels.values()) {
            if (p.kind === '3d' && p._gpu === 'active') {
              p._gpu = 'unavailable';
              if (p.gpuCanvas) p.gpuCanvas.style.display = 'none';
              if (p.plotCanvas) p.plotCanvas.style.background = theme.bgPlot;
              _gpuDisposePanel(p);
              _redrawPanel(p);
            } else if (p.kind === '2d' && p._gpu === 'active') {
              // 2-D image panel: revert to the Canvas2D blit path + free GPU
              // resources, and echo the fallback so plot.gpu_active goes False.
              p._gpu = 'unavailable';
              if (p.gpuCanvas) p.gpuCanvas.style.display = 'none';
              if (p.plotCanvas) p.plotCanvas.style.background = theme.bgCanvas;
              _gpuDisposeImagePanel(p);
              _reportGpu(p);
              _redrawPanel(p);
            }
          }
          console.warn('[anyplotlib] WebGPU device lost — fell back to canvas:',
                       info && info.message);
        });
        return device;
      } catch (e) {
        console.warn('[anyplotlib] WebGPU init failed — using canvas:', e);
        return null;
      }
    })();
    return _gpuDevicePromise;
  }

  // Report GPU activation back to Python via an event (so plot.gpu_active
  // reflects reality).  Fire-and-forget; ignored if no one listens.
  function _reportGpu(p) {
    try {
      _emitEvent(p.id, 'gpu_status', null, { gpu_active: p._gpu === 'active' });
    } catch (_) {}
  }

  // Should this 3-D panel try the GPU path for its current state?
  // `texReady` says a textured surface's image has finished decoding — a
  // surface can only go to the GPU once there is something to sample.
  function _gpuWanted(st, texReady) {
    if (typeof navigator === 'undefined' || !navigator.gpu) return false;
    const mode = st.gpu_mode || 'auto';
    if (mode === 'off') return false;
    const geom = st.geom_type;
    if (geom === 'surface') {
      // Only TEXTURED surfaces have a GPU path; a colormapped one still draws
      // its sorted, outlined triangles on Canvas2D.  alpha < 1 also stays on
      // canvas: the overlapping-triangle composite that makes a translucent
      // skin look right has no cheap depth-buffer equivalent.
      if (!st.texture_url || !texReady) return false;
      if ((st.texture_alpha == null ? 1 : st.texture_alpha) < 1) return false;
      if (mode === 'always') return true;
      return (st.faces_count || 0) > GPU_SURFACE_THRESHOLD;
    }
    if (geom !== 'scatter' && geom !== 'voxels') return false;
    if (mode === 'always') return true;
    const thr = geom === 'voxels' ? GPU_VOXEL_THRESHOLD : GPU_POINT_THRESHOLD;
    return (st.vertices_count || 0) > thr;
  }

  // Should this 2-D image panel take the WebGPU texture path? Scalar (LUT) images
  // only — RGB(A) images stay on Canvas2D (they need no colormap and are rare/
  // small). Gated by megapixels above GPU_IMAGE_THRESHOLD unless gpu_mode forces.
  function _gpuWanted2d(st) {
    if (typeof navigator === 'undefined' || !navigator.gpu) return false;
    const mode = st.gpu_mode || 'auto';
    if (mode === 'off') return false;
    if (st.is_rgb) return false;                 // no LUT → nothing to accelerate
    // Pixels present as base64 (image_b64) OR binary bytes (image_b64_bytes).
    if ((!st.image_b64 && !st.image_b64_bytes)
        || !st.image_width || !st.image_height) return false;
    // ZOOM/PAN is now honoured by the shader (the quad's clip rect + uv sub-region
    // mirror _blit2d, so the GPU image stays registered with the overlays and
    // UPSAMPLES real texels on zoom-in), so we no longer fall back on zoom. See
    // _imageDrawUniform.
    if (mode === 'always') return true;
    return (st.image_width * st.image_height) >= GPU_IMAGE_THRESHOLD;
  }

  const _GPU_POINT_WGSL = `
struct Uniforms {
  mvp      : mat4x4<f32>,   // clip-space transform (orthographic)
  viewport : vec2<f32>,     // panel pixels
  ptSize   : f32,
  _pad     : f32,
};
@group(0) @binding(0) var<uniform> U : Uniforms;

struct VsOut {
  @builtin(position) pos : vec4<f32>,
  @location(0) color     : vec4<f32>,
  @location(1) quad      : vec2<f32>,
};

// Unit quad (two triangles) expanded per instance into a screen-space square.
const QUAD = array<vec2<f32>, 6>(
  vec2(-1.0,-1.0), vec2(1.0,-1.0), vec2(-1.0,1.0),
  vec2(-1.0, 1.0), vec2(1.0,-1.0), vec2( 1.0,1.0));

@vertex
fn vs(@location(0) center : vec3<f32>,
      @location(1) color  : vec4<f32>,
      @builtin(vertex_index) vi : u32) -> VsOut {
  var out : VsOut;
  let clip = U.mvp * vec4<f32>(center, 1.0);
  let q    = QUAD[vi];
  // Offset in NDC by point size (pixels → NDC via viewport).  Orthographic,
  // so clip.w == 1; divide-by-w is implicit and the offset is in NDC units.
  let off  = vec2<f32>(q.x * U.ptSize * 2.0 / U.viewport.x,
                       q.y * U.ptSize * 2.0 / U.viewport.y);
  out.pos   = vec4<f32>(clip.x + off.x, clip.y + off.y, clip.z, 1.0);
  out.color = color;
  out.quad  = q;
  return out;
}

@fragment
fn fs(in : VsOut) -> @location(0) vec4<f32> {
  if (dot(in.quad, in.quad) > 1.0) { discard; }   // round points
  return in.color;
}
`;

  // Voxel cubes: 36 vertices (12 tris) for a unit cube centred at origin,
  // instanced per voxel.  Per-face shading + depth buffer (no sorting).
  // Slice emphasis (voxels on a PlaneWidget) is computed in the vertex shader
  // from up to 4 plane uniforms → dragging a plane is a uniform write, no
  // geometry re-upload.  Opaque mode (Phase 2); translucency is Phase 3.
  const _GPU_VOXEL_WGSL = `
struct Uniforms {
  mvp        : mat4x4<f32>,
  half       : f32,          // half voxel edge, data units
  baseAlpha  : f32,
  sliceAlpha : f32,
  nPlanes    : f32,
  planeAxis  : vec4<f32>,    // axis index 0/1/2 per plane (-1 = unused)
  planePos   : vec4<f32>,    // plane position, data units
  shade      : vec4<f32>,    // x,y,z face shade + pad
};
@group(0) @binding(0) var<uniform> U : Uniforms;

struct VsOut {
  @builtin(position) pos : vec4<f32>,
  @location(0) color     : vec4<f32>,
  @location(1) alpha     : f32,
};

// 36 cube corners (±1) and matching face axis (0=x,1=y,2=z) per triangle.
const CUBE = array<vec3<f32>, 36>(
  // +x
  vec3(1.,-1.,-1.), vec3(1.,1.,-1.), vec3(1.,1.,1.), vec3(1.,-1.,-1.), vec3(1.,1.,1.), vec3(1.,-1.,1.),
  // -x
  vec3(-1.,-1.,-1.), vec3(-1.,1.,1.), vec3(-1.,1.,-1.), vec3(-1.,-1.,-1.), vec3(-1.,-1.,1.), vec3(-1.,1.,1.),
  // +y
  vec3(-1.,1.,-1.), vec3(1.,1.,1.), vec3(1.,1.,-1.), vec3(-1.,1.,-1.), vec3(-1.,1.,1.), vec3(1.,1.,1.),
  // -y
  vec3(-1.,-1.,-1.), vec3(1.,-1.,-1.), vec3(1.,-1.,1.), vec3(-1.,-1.,-1.), vec3(1.,-1.,1.), vec3(-1.,-1.,1.),
  // +z
  vec3(-1.,-1.,1.), vec3(1.,-1.,1.), vec3(1.,1.,1.), vec3(-1.,-1.,1.), vec3(1.,1.,1.), vec3(-1.,1.,1.),
  // -z
  vec3(-1.,-1.,-1.), vec3(1.,1.,-1.), vec3(1.,-1.,-1.), vec3(-1.,-1.,-1.), vec3(-1.,1.,-1.), vec3(1.,1.,-1.));
const FACE_AXIS = array<u32, 12>(0u,0u, 0u,0u, 1u,1u, 1u,1u, 2u,2u, 2u,2u);

@vertex
fn vs(@location(0) center : vec3<f32>,
      @location(1) color  : vec4<f32>,
      @builtin(vertex_index) vi : u32) -> VsOut {
  var out : VsOut;
  let corner = CUBE[vi] * U.half;
  out.pos = U.mvp * vec4<f32>(center + corner, 1.0);
  // Per-face shading
  let fa = FACE_AXIS[vi / 3u];
  var sh = U.shade.x;
  if (fa == 1u) { sh = U.shade.y; }
  if (fa == 2u) { sh = U.shade.z; }
  out.color = vec4<f32>(color.rgb * sh, color.a);
  // Slice emphasis: opaque if the voxel centre lies on any plane.
  var emph = false;
  let np = i32(U.nPlanes);
  for (var i = 0; i < np; i = i + 1) {
    let ax = U.planeAxis[i];
    var cv = center.x;
    if (ax > 1.5) { cv = center.z; } else if (ax > 0.5) { cv = center.y; }
    if (abs(cv - U.planePos[i]) <= U.half * 1.1) { emph = true; }
  }
  out.alpha = select(U.baseAlpha, U.sliceAlpha, emph);
  return out;
}

@fragment
fn fs(in : VsOut) -> @location(0) vec4<f32> {
  return vec4<f32>(in.color.rgb, in.alpha);
}
`;

  // ── 2-D large-image WebGPU path ────────────────────────────────────────────
  // A fullscreen textured quad samples the normalized uint8 image (an R8 texture,
  // the same bytes the Canvas2D path decodes) and maps each pixel through the
  // 256-entry colormap LUT (a 256×1 RGBA texture). This replaces the 64-million-
  // iteration JS atob+LUT loop with one GPU draw.
  //
  // CRITICAL: the LUT is built by _buildLut32, which ALREADY bakes the display
  // window (clim) AND the scale_mode (linear/log/symlog) into a direct
  // "pixel value → final colour" map: lut[raw] = final colour. The Canvas2D path
  // uses it as a plain lookup (out32[i] = lut[bytes[i]]). So the shader must be an
  // IDENTITY lookup — index the LUT by raw/255 and NOTHING else. (A previous
  // version re-applied dmin/dmax in the shader on top of the already-windowed LUT,
  // double-applying the contrast — correct only at full-range clim, wrong for any
  // narrowed window or log/symlog. Do NOT reintroduce a clim uniform here.)
  //
  // The quad is fullscreen with NO zoom/pan: the GPU path is used only when the
  // view is unzoomed/uncentred (see _gpuWanted2d); a zoomed/panned view falls
  // back to Canvas2D so the base image stays registered with the axes/overlays.
  // ── Textured surface (Plot3D.set_texture on the GPU) ─────────────────────
  // Indexed triangles with per-vertex UVs and normals, depth-tested.  Three
  // things the Canvas2D path has to fake come for free here:
  //   • occlusion — the depth buffer replaces the per-frame painter's sort
  //     AND makes backface culling unnecessary (an open surface stays correct
  //     when viewed from behind, which `cull_backfaces` cannot manage);
  //   • seams — neighbouring triangles share vertices exactly, so there is no
  //     antialiased hairline to paper over with the miter expansion;
  //   • shading — Lambert per PIXEL against an interpolated vertex normal,
  //     instead of one flat value per triangle.
  // `rot` is the camera rotation R.  `norm()` scales all three axes by the
  // same 2/maxR, so a data-space normal only needs rotating to reach view
  // space (right, into-screen, up) — where the light lives.
  // mat4x4 (64 B) + five vec4 (80 B).  Keep in step with the struct below and
  // with the float offsets written in _gpuDrawSurface.
  const _GPU_SURFACE_UBO = 144;

  const _GPU_SURFACE_WGSL = `
struct U {
  mvp   : mat4x4<f32>,
  rot0  : vec4<f32>,
  rot1  : vec4<f32>,
  rot2  : vec4<f32>,
  light : vec4<f32>,   // xyz = light direction (view space), w = shade flag
  misc  : vec4<f32>,   // x = surface alpha
};
@group(0) @binding(0) var<uniform> u : U;
@group(0) @binding(1) var samp : sampler;
@group(0) @binding(2) var tex  : texture_2d<f32>;

struct VsOut {
  @builtin(position) pos : vec4<f32>,
  @location(0)       uv  : vec2<f32>,
  @location(1)       nrm : vec3<f32>,
};

@vertex
fn vs(@location(0) p  : vec3<f32>,
      @location(1) uv : vec2<f32>,
      @location(2) n  : vec3<f32>) -> VsOut {
  var o : VsOut;
  o.pos = u.mvp * vec4<f32>(p, 1.0);
  o.uv  = uv;
  o.nrm = vec3<f32>(dot(u.rot0.xyz, n), dot(u.rot1.xyz, n), dot(u.rot2.xyz, n));
  return o;
}

@fragment
fn fs(in : VsOut) -> @location(0) vec4<f32> {
  var c = textureSample(tex, samp, in.uv);
  if (u.light.w > 0.5) {
    let n = normalize(in.nrm);
    // Orient toward the camera (which sits at -y) so shading never depends on
    // the grid's triangle winding — matching the Canvas2D path.
    let o = select(1.0, -1.0, n.y > 0.0);
    let lam = max(0.0, o * dot(n, u.light.xyz));
    c = vec4<f32>(c.rgb * (0.35 + 0.65 * lam), c.a);
  }
  return vec4<f32>(c.rgb, c.a * u.misc.x);
}
`;

  // ── Mipmap generation ─────────────────────────────────────────────────────
  // WebGPU has no built-in mipmapper, and without one a 1440x720 sky texture
  // minified onto a 300 px sphere aliases into sparkling noise — visibly WORSE
  // than the Canvas2D path, which gets mip-like filtering free from
  // drawImage + imageSmoothingQuality. So downsample level by level with a
  // fullscreen-triangle blit. The pipeline is per (device, format) and cached.
  const _GPU_MIP_WGSL = `
@group(0) @binding(0) var samp : sampler;
@group(0) @binding(1) var src  : texture_2d<f32>;
struct VsOut { @builtin(position) pos : vec4<f32>, @location(0) uv : vec2<f32> };
@vertex
fn vs(@builtin(vertex_index) vi : u32) -> VsOut {
  var xy = array<vec2<f32>, 3>(
    vec2<f32>(-1.0, -1.0), vec2<f32>(3.0, -1.0), vec2<f32>(-1.0, 3.0));
  var o : VsOut;
  o.pos = vec4<f32>(xy[vi], 0.0, 1.0);
  o.uv  = vec2<f32>((xy[vi].x + 1.0) * 0.5, (1.0 - xy[vi].y) * 0.5);
  return o;
}
@fragment
fn fs(in : VsOut) -> @location(0) vec4<f32> { return textureSample(src, samp, in.uv); }
`;

  let _gpuMipCache = null;   // { device, pipeline, sampler }

  function _gpuMipTools(device, format) {
    if (_gpuMipCache && _gpuMipCache.device === device
        && _gpuMipCache.format === format) return _gpuMipCache;
    const module = device.createShaderModule({ code: _GPU_MIP_WGSL });
    _gpuMipCache = {
      device, format,
      pipeline: device.createRenderPipeline({
        layout: 'auto',
        vertex:   { module, entryPoint: 'vs' },
        fragment: { module, entryPoint: 'fs', targets: [{ format }] },
        primitive: { topology: 'triangle-list' },
      }),
      sampler: device.createSampler({ magFilter: 'linear', minFilter: 'linear' }),
    };
    return _gpuMipCache;
  }

  function _gpuGenerateMips(device, texture, format, levels) {
    if (levels < 2) return;
    const { pipeline, sampler } = _gpuMipTools(device, format);
    const enc = device.createCommandEncoder();
    for (let lvl = 1; lvl < levels; lvl++) {
      const bind = device.createBindGroup({
        layout: pipeline.getBindGroupLayout(0),
        entries: [
          { binding: 0, resource: sampler },
          { binding: 1, resource: texture.createView({
              baseMipLevel: lvl - 1, mipLevelCount: 1 }) },
        ],
      });
      const pass = enc.beginRenderPass({
        colorAttachments: [{
          view: texture.createView({ baseMipLevel: lvl, mipLevelCount: 1 }),
          loadOp: 'clear', storeOp: 'store',
          clearValue: { r: 0, g: 0, b: 0, a: 0 } }],
      });
      pass.setPipeline(pipeline);
      pass.setBindGroup(0, bind);
      pass.draw(3);
      pass.end();
    }
    device.queue.submit([enc.finish()]);
  }

  const _GPU_IMAGE_WGSL = `
// rect   = the on-screen quad in CLIP space (x0,y0,x1,y1). For zoom<=1 this is the
//          fit-rect shrunk by zoom (centred); for zoom>=1 it's the full fit-rect.
// uvrect = the texture sub-region to sample (u0,v0,u1,v1), in 0..1. For zoom>=1
//          this is the zoomed-in window of the image (a small region stretched over
//          the fit-rect, nearest sampling UPSAMPLES real texels); for zoom<=1 it's
//          the whole texture (0,0,1,1). Together they reproduce _blit2d's zoom/pan
//          exactly, so the GPU image stays registered with the axes/overlays at any
//          zoom. Outside the rect the clear colour shows as the letterbox bars.
struct U { rect : vec4<f32>, uvrect : vec4<f32>, };
@group(0) @binding(0) var<uniform> u : U;
@group(0) @binding(1) var img  : texture_2d<f32>;
@group(0) @binding(2) var lut  : texture_2d<f32>;
@group(0) @binding(3) var samp : sampler;

struct VsOut {
  @builtin(position) pos : vec4<f32>,
  @location(0) uv        : vec2<f32>,
};

// Unit quad in 0..1; mapped into the clip-space rect + the uv sub-region below.
const Q = array<vec2<f32>, 6>(
  vec2(0.0,0.0), vec2(1.0,0.0), vec2(0.0,1.0),
  vec2(0.0,1.0), vec2(1.0,0.0), vec2(1.0,1.0));

@vertex
fn vs(@builtin(vertex_index) vi : u32) -> VsOut {
  var out : VsOut;
  let q = Q[vi];                              // 0..1 across the drawn quad
  let x = mix(u.rect.x, u.rect.z, q.x);       // lerp into clip-space rect
  let y = mix(u.rect.y, u.rect.w, q.y);
  out.pos = vec4<f32>(x, y, 0.0, 1.0);
  let uu = mix(u.uvrect.x, u.uvrect.z, q.x);
  // q.y=0 is the SCREEN BOTTOM (rect.y is the lower clip edge), which shows
  // the LAST row of the visible window (v1); q.y=1 (screen top) shows the
  // first (v0) — so v interpolates from v1 down to v0 WITHIN the window
  // (imshow: texture row 0 = image top). Do NOT flip with a global (1 - v)
  // after interpolating [v0,v1]: that samples the MIRRORED window
  // [1-v1, 1-v0] — identical only when v0+v1 == 1 (full view / vertically
  // centred), so it survived centred-zoom tests but inverted the pan-y
  // direction and detached the image from markers/overlays on any
  // vertically off-centre view (base AND detail passes).
  let vv = mix(u.uvrect.w, u.uvrect.y, q.y);
  out.uv  = vec2<f32>(uu, vv);
  return out;
}

@fragment
fn fs(in : VsOut) -> @location(0) vec4<f32> {
  // R8 unorm (0..1) = the frame value already normalized to the 0..255 index the
  // LUT is keyed on. Direct identity lookup — the LUT holds the final colour
  // (clim + scale_mode baked in). Nearest sampling on img (no interpolation of
  // raw values); the LUT is sampled at the texel centre.
  let raw = textureSampleLevel(img, samp, in.uv, 0.0).r;   // 0..1 == index/255
  return textureSampleLevel(lut, samp, vec2<f32>(raw, 0.5), 0.0);
}
`;

  function _gpuInitImagePanel(p, device) {
    const fmt = navigator.gpu.getPreferredCanvasFormat();
    const ctx = p.gpuCanvas.getContext('webgpu');
    ctx.configure({ device, format: fmt, alphaMode: 'opaque' });
    const module = device.createShaderModule({ code: _GPU_IMAGE_WGSL });
    const pipeline = device.createRenderPipeline({
      layout: 'auto',
      vertex:   { module, entryPoint: 'vs' },
      fragment: { module, entryPoint: 'fs', targets: [{ format: fmt }] },
      primitive:{ topology: 'triangle-list' },
    });
    // NEAREST on both textures matches the Canvas2D path's imageSmoothingEnabled=
    // false (no interpolation of raw values or between LUT colour entries), so the
    // GPU output is a pixel-faithful match of the reference.
    const samp = device.createSampler({
      magFilter: 'nearest', minFilter: 'nearest', mipmapFilter: 'nearest' });
    // Uniform holds the clip-space quad rect + the texture uv sub-region (two
    // vec4 = 32 B) so the quad matches the fit-rect AND zoom/pan of the Canvas2D
    // path + overlays.
    const uniformBuf = device.createBuffer({
      size: 32, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST });
    // Second uniform for the DETAIL overlay pass (its own screen rect + uv), so the
    // crisp tile can be stitched OVER the upsampled overview base in one frame
    // (base fills the margin, tile fills the padded FOV — no zoom-out flash).
    const uniformBuf2 = device.createBuffer({
      size: 32, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST });
    p._gpuImg = { device, ctx, fmt, pipeline, samp, uniformBuf, uniformBuf2,
                  tex: null, texW: 0, texH: 0, lutTex: null, lutKey: null,
                  bytesKey: null, bindGroup: null,
                  // Detail texture slot (kept resident alongside the base).
                  dtex: null, dtexW: 0, dtexH: 0, dbytesKey: null, dbindGroup: null };
  }

  // Raw single-channel pixel bytes for the current image state. Prefers the
  // BINARY bytes `image_b64_bytes` (a Uint8Array spliced into the state from the
  // geomCache by the binary transport — no atob) over `image_b64` (base64, needs
  // decoding). Returns {bytes, key} where `key` is a cheap identity for the
  // "unchanged → skip re-upload" check.
  function _imageBytes(st) {
    const raw = st.image_b64_bytes;
    if (raw && (raw instanceof Uint8Array || raw.byteLength !== undefined)) {
      const u8 = raw instanceof Uint8Array ? raw : new Uint8Array(raw);
      // Cache identity, in preference order:
      //  1. the content token in st.image_b64 ("\x00bin:<adler>", kept in the
      //     slimmed geom by _route_change),
      //  2. the buffer's ARRIVAL sequence (stamped when the binary frame was
      //     spliced in — every received frame is new content),
      //  3. a sampled fingerprint as a last resort. NB sampling is WEAK: it
      //     reads only 4 bytes, so frames differing anywhere else collide and
      //     the "unchanged → skip re-upload" check freezes the display — this
      //     branch must stay a fallback, never the primary key.
      let key = st.image_b64;
      if (!key && u8.__aplSeq !== undefined) key = `binseq:${u8.__aplSeq}`;
      if (!key) {
        const n = u8.length;
        const s0 = u8[0] || 0, s1 = u8[(n >> 2) | 0] || 0;
        const s2 = u8[(n >> 1) | 0] || 0, s3 = u8[n - 1] || 0;
        key = `bin:${n}:${s0},${s1},${s2},${s3}`;
      }
      return { bytes: u8, key };
    }
    const b64 = st.image_b64 || '';
    if (!b64) return { bytes: null, key: '' };
    try {
      const bin = atob(b64);
      const u8 = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
      return { bytes: u8, key: b64 };
    } catch (_) { return { bytes: null, key: '' }; }
  }

  // Detail-tile bytes (binary `detail_b64_bytes` or base64 `detail_b64`), keyed so a
  // new tile re-uploads. Prefix the key with 'detail:' so it never collides with a
  // base-image key of the same length (they share the one GPU texture slot).
  function _detailBytes(st) {
    const raw = st.detail_b64_bytes;
    if (raw && (raw instanceof Uint8Array || raw.byteLength !== undefined)) {
      const u8 = raw instanceof Uint8Array ? raw : new Uint8Array(raw);
      const reg = st.detail_region || [];
      // Key on detail_seq (a monotonic counter bumped by Python's set_detail on EVERY
      // push), NOT just length+region. A live movie scrub while zoomed in re-samples
      // the SAME region every frame → identical length + region, so a length/region
      // key would match every frame and the GPU/Canvas dedup would SKIP the re-upload
      // — the display freezes on the first frame ("won't update when zoomed in").
      // detail_seq guarantees a distinct key per pushed tile.
      const seq = st.detail_seq || 0;
      return { bytes: u8, key: `detail:${seq}:${u8.length}:${reg.join(',')}` };
    }
    const b64 = st.detail_b64 || '';
    if (!b64) return { bytes: null, key: '' };
    try {
      const bin = atob(b64);
      const u8 = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
      return { bytes: u8, key: `detail:${b64}` };
    } catch (_) { return { bytes: null, key: '' }; }
  }

  // ── Hover readout (position + pixel value) ────────────────────────────────
  // _imageBytes / _detailBytes atob the WHOLE frame on the base64 transport, and
  // the readout runs per mousemove — so cache the decode by the byte identity.
  // The binary transport hands over a view (no decode) and needs no cache.
  function _readoutBytes2d(p, st) {
    if (st.image_b64_bytes) return _imageBytes(st);
    if (!st.image_b64) return { bytes: null, key: '' };
    if (p._roImg && p._roImg.key === st.image_b64) return p._roImg;
    return (p._roImg = _imageBytes(st));
  }
  function _readoutDetailBytes2d(p, st) {
    if (st.detail_b64_bytes) return _detailBytes(st);
    if (!st.detail_b64) return { bytes: null, key: '' };
    if (p._roDet && p._roDet.key === `detail:${st.detail_b64}`) return p._roDet;
    return (p._roDet = _detailBytes(st));
  }

  // uint8 code → data value over the quantisation band [lo, hi]. `step` is the
  // width of one level (0 ⇒ the value is EXACT); null when there is no usable band.
  //
  // `isInt` (Python's raw_is_int / detail_is_int) says the quantised array held
  // integers. Python's _normalize_image TRUNCATES, so code c covers the half-open
  // interval [lo + c*step, lo + (c+1)*step). When step <= 1 that interval is
  // narrower than 1 and therefore contains at most ONE integer — which must be the
  // source value, so the quantisation is fully invertible and the readout is exact
  // (uint8 frames, masks, label maps, small-range counts). The interval midpoint is
  // within step/2 <= 0.5 of that integer; the epsilon breaks the step == 1 tie
  // downwards (midpoint n + 0.5 must round to n, not n + 1).
  function _codeToValue(lo, hi, code, isInt) {
    if (lo == null || hi == null || !isFinite(lo) || !isFinite(hi)) return null;
    if (!(hi > lo)) return { value: lo, step: 0 };
    const step = (hi - lo) / 255;
    if (isInt && step <= 1) {
      return { value: Math.round(lo + (code + 0.5) * step - 1e-9), step: 0 };
    }
    return { value: lo + code * step, step };
  }

  // The data value under the cursor, reconstructed from the SAME uint8 codes the
  // renderer draws: Python quantises the frame over [raw_min, raw_max]
  // (_normalize_image in _utils.py), so code c means raw_min + c/255*(raw_max -
  // raw_min). Only 256 levels cross the wire, so this is exact when the codes are
  // invertible (see _codeToValue) and a step of range/255 otherwise — for that case
  // _armValueProbe asks Python for the true value and _readoutInfo2d prefers the
  // answer. This is the always-available estimate underneath that.
  //
  // Prefers the detail tile wherever it covers the pixel: in tile mode the base
  // texture is a DOWNSAMPLED overview whose codes are block averages, while the
  // tile carries true native pixels for the visible region. Image LAYERS
  // (_drawLayers2d) are never probed — the base image is the primary data.
  //
  // Returns {value, step} for a scalar image, {rgba:[r,g,b,a]} for a true-colour
  // one, or null when the bytes / the band are unavailable.
  function _pixelValue2d(p, st, ix, iy) {
    const iw = st.image_width, ih = st.image_height;
    if (!(iw > 0) || !(ih > 0)) return null;
    if (!(ix >= 0 && iy >= 0 && ix < iw && iy < ih)) return null;
    // Logical px → base-texture texel (the same kx/ky scale _blit2d draws with,
    // so the readout names the texel the cursor is actually over).
    const bw = st.base_width || iw, bh = st.base_height || ih;
    const bx = Math.min(bw - 1, Math.max(0, Math.floor(ix / iw * bw)));
    const by = Math.min(bh - 1, Math.max(0, Math.floor(iy / ih * bh)));

    if (st.is_rgb) {
      const b = _readoutBytes2d(p, st).bytes;
      if (!b) return null;
      const o = (by * bw + bx) * 4;
      if (o + 4 > b.length) return null;
      return { rgba: [b[o], b[o + 1], b[o + 2], b[o + 3]] };
    }

    // Only above zoom 1, where the tile is what the blit samples (_detailUV /
    // _detailOverlayRect both bail at zoom <= 1) — so the readout always names
    // the source of the pixel actually on screen.
    const reg = st.detail_region || [];
    const dw = st.detail_width | 0, dh = st.detail_height | 0;
    if ((st.zoom || 1) > 1 && reg.length === 4 && dw > 0 && dh > 0 &&
        ix >= reg[0] && ix < reg[1] && iy >= reg[2] && iy < reg[3]) {
      const d = _readoutDetailBytes2d(p, st).bytes;
      if (d && d.length >= dw * dh) {
        const tx = Math.min(dw - 1, Math.floor((ix - reg[0]) / (reg[1] - reg[0]) * dw));
        const ty = Math.min(dh - 1, Math.floor((iy - reg[2]) / (reg[3] - reg[2]) * dh));
        // The tile carries the band it was quantised over (tile mode reuses the
        // fixed raw band; a manual set_detail matches the display window).
        const v = _codeToValue(
          st.detail_min != null ? st.detail_min : st.raw_min,
          st.detail_max != null ? st.detail_max : st.raw_max,
          d[ty * dw + tx],
          st.detail_min != null ? st.detail_is_int : st.raw_is_int);
        if (v) return v;
      }
    }

    const b = _readoutBytes2d(p, st).bytes;
    if (!b) return null;
    const o = by * bw + bx;
    if (o >= b.length) return null;
    return _codeToValue(st.raw_min, st.raw_max, b[o], st.raw_is_int);
  }

  // Pixel-value format: keeps 3 significant digits where fmtVal's 2 would hide
  // real signal (58 400 counts must not read "5.8e+4"), and stays compact — the
  // status bar is one nowrap line over the image.
  function fmtPixVal(v) {
    if (v == null || !isFinite(v)) return String(v);
    const a = Math.abs(v);
    if (a === 0) return '0';
    if (a >= 1e5 || a < 1e-3) return v.toExponential(2);
    if (a >= 100) return v.toFixed(0);
    return stripZeros(v.toPrecision(3));
  }

  // An EXACT value (a Python probe answer, or a losslessly invertible code) — up to
  // 6 significant digits, past which float32 source data stops being meaningful.
  // Never abbreviates an integer: an exactly-known 1234567 must not read "1.23e+6".
  function fmtExactVal(v) {
    if (v == null || !isFinite(v)) return String(v);
    if (Number.isInteger(v)) return String(v);
    const a = Math.abs(v);
    if (a >= 1e6 || a < 1e-4) return v.toExponential(5);
    return stripZeros(v.toPrecision(6));
  }

  // The exact value Python answered for one specific pixel (see the value_probe
  // event / Plot2D.set_value_probe), or null when there is no answer or it is for a
  // DIFFERENT pixel — i.e. the cursor moved on before the round trip landed.
  function _probeValueFor(st, px, py) {
    if (st.probe_value == null) return null;
    if (st.probe_x !== px || st.probe_y !== py) return null;
    return st.probe_value;
  }

  // Structured hover readout for the pixel under (ix, iy): what the status bar
  // renders AND the payload handed to an embedding host (see _notifyReadout).
  // Returns null when the cursor is off-image.
  function _readoutInfo2d(p, st, ix, iy) {
    const iw = st.image_width, ih = st.image_height;
    if (!(ix >= 0 && iy >= 0 && ix < iw && iy < ih)) return null;
    const xArr = st.x_axis || [], yArr = st.y_axis || [];
    const showPhys = xArr.length >= 2 || yArr.length >= 2;
    // For both imshow (centre arrays) and pcolormesh (edge arrays), ix/iw maps the
    // pixel fraction into the axis array via binary search.
    const physX = showPhys && xArr.length >= 2 ? _axisFracToVal(xArr, ix / iw) : ix;
    const physY = showPhys && yArr.length >= 2 ? _axisFracToVal(yArr, iy / ih) : iy;
    const units = st.units || 'px';
    const px = Math.floor(ix), py = Math.floor(iy);
    const pv = _pixelValue2d(p, st, ix, iy);
    const probe = _probeValueFor(st, px, py);

    let value = null, exact = false, rgba = null, vTxt = '';
    if (pv && pv.rgba) {
      rgba = pv.rgba; exact = true;                    // uint8 channels — no quantising
      vTxt = `  rgb:${rgba[0]},${rgba[1]},${rgba[2]}` +
             (rgba[3] < 255 ? ',' + rgba[3] : '');
    } else if (probe != null) {
      value = probe; exact = true;                     // Python answered for this pixel
      vTxt = `  v:${fmtExactVal(value)}`;
    } else if (pv) {
      value = pv.value; exact = pv.step === 0;         // step 0 ⇒ invertible codes
      vTxt = `  v:${exact ? fmtExactVal(value) : fmtPixVal(value)}`;
    }
    const text = (showPhys
      ? `x:${fmtVal(physX)} y:${fmtVal(physY)}${units ? ' ' + units : ''}  [${px}, ${py}]`
      : `x:${px}  y:${py}`) + vTxt;
    return { panel_id: p.id, img_x: ix, img_y: iy, col: px, row: py,
             xdata: physX, ydata: physY, units, value, exact, rgba, text };
  }

  // Hand the readout to an embedding host so it can render the position/value in its
  // OWN chrome — e.g. a status line in the corner of an Electron window, where it
  // covers nothing — instead of (or as well as) the overlay pill: mount()'s
  // opts.onReadout(info) plus an `apl:readout` CustomEvent bubbling off the figure
  // root. `info` is null when the cursor leaves the image so the host can clear.
  // Fires regardless of readout_visible — that is what makes "hide the built-in bar
  // and draw it myself" work. Deduped by text so a host is not spammed at 60 Hz.
  function _notifyReadout(p, info) {
    const next = info ? info.text : '';
    if (next === (p._readoutTxt || '')) return;
    p._readoutTxt = next;
    if (typeof onReadout === 'function') { try { onReadout(info); } catch (_) {} }
    try {
      el.dispatchEvent(new CustomEvent('apl:readout',
        { detail: info, bubbles: true }));
    } catch (_) {}
  }

  // Recompute the readout from the panel's last known cursor position: write the
  // status bar (unless readout_visible is false) and notify the host. Called on every
  // mousemove AND on every panel-state change — a probe answer landing under a
  // stationary cursor must refresh the text. Returns the info (null ⇒ off-image).
  function _updateStatus2d(p) {
    const st = p.state;
    if (!st || !p.statusBar) return null;
    const imgW = p.imgW || Math.max(1, p.pw - PAD_L - PAD_R);
    const imgH = p.imgH || Math.max(1, p.ph - PAD_T - PAD_B);
    const [ix, iy] = _canvasToImg2d(p.mouseX, p.mouseY, st, imgW, imgH);
    const info = _readoutInfo2d(p, st, ix, iy);
    p.statusBar.textContent = info ? info.text : '';
    // Hidden by Python (readout_visible) or by the viewer's `v` toggle.
    p.statusBar.style.display =
      (info && st.readout_visible !== false && !p.readoutHidden) ? 'block' : 'none';
    _notifyReadout(p, info);
    return info;
  }

  // Exact-value probe (on by default; st.probe_ms <= 0 disables it): once the cursor
  // DWELLS on a pixel, ask Python for the true value there — the codes in the browser
  // are 8-bit, Python has the array. One message per dwell, never per move, and never
  // twice for the same pixel. The answer arrives as probe_x/probe_y/probe_value and
  // _updateStatus2d swaps it in. When there is no kernel (static HTML, embedded page
  // with no bridge) or it is busy, nothing arrives and the quantised value just stays.
  function _armValueProbe(p, ix, iy) {
    const st = p.state;
    clearTimeout(p._probeT); p._probeT = 0;
    if (!st) return;
    const ms = st.probe_ms || 0;
    if (ms <= 0 || st.is_rgb) return;          // RGB channels are already exact
    if (!(ix >= 0 && iy >= 0 && ix < st.image_width && iy < st.image_height)) return;
    const px = Math.floor(ix), py = Math.floor(iy);
    if (st.probe_x === px && st.probe_y === py) return;   // already answered
    const key = `${px},${py}`;
    if (p._probeSent === key) return;                     // already asked, no answer yet
    p._probeT = setTimeout(() => {
      p._probeT = 0;
      p._probeSent = key;
      _emitEvent(p.id, 'value_probe', null,
        { img_x: px, img_y: py, x: p.mouseX, y: p.mouseY });
    }, ms);
  }

  // Write single-channel R8 bytes into a device texture, (re)creating it if the size
  // changed. Returns the (possibly new) texture, or null if bytes are missing/short.
  function _gpuWriteR8(device, tex, texWH, iw, ih, bytes) {
    if (!bytes) return null;
    if (bytes.length < iw * ih) return null;
    if (!tex || texWH.w !== iw || texWH.h !== ih) {
      if (tex) tex.destroy();
      tex = device.createTexture({
        size: [iw, ih, 1], format: 'r8unorm',
        usage: GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.COPY_DST |
               GPUTextureUsage.RENDER_ATTACHMENT });
      texWH.w = iw; texWH.h = ih;
    }
    // bytesPerRow must be a multiple of 256 for writeTexture; R8 = 1 B/px, so pad
    // each row up to the next 256 boundary.
    const bpr = Math.ceil(iw / 256) * 256;
    let src = bytes;
    if (bpr !== iw) {
      src = new Uint8Array(bpr * ih);
      for (let r = 0; r < ih; r++) src.set(bytes.subarray(r * iw, r * iw + iw), r * bpr);
    }
    device.queue.writeTexture(
      { texture: tex }, src, { bytesPerRow: bpr, rowsPerImage: ih }, [iw, ih, 1]);
    return tex;
  }

  // Ensure the shared LUT texture is current for st. Returns false only if it can't
  // be built. Sets g.lutTex; invalidates both bind groups when the LUT changes.
  function _gpuEnsureLut(g, st) {
    const device = g.device;
    const lutKey = _lutKey(st);
    if (lutKey === g.lutKey && g.lutTex) return true;
    const lut = _buildLut32(st);             // Uint32Array(256), 0xAABBGGRR
    const rgba = new Uint8Array(256 * 4);
    for (let i = 0; i < 256; i++) {
      const v = lut[i];
      rgba[i*4]   = v & 0xff;
      rgba[i*4+1] = (v >> 8) & 0xff;
      rgba[i*4+2] = (v >> 16) & 0xff;
      rgba[i*4+3] = 255;
    }
    if (!g.lutTex) {
      g.lutTex = device.createTexture({
        size: [256, 1, 1], format: 'rgba8unorm',
        usage: GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.COPY_DST });
    }
    device.queue.writeTexture(
      { texture: g.lutTex }, rgba, { bytesPerRow: 256 * 4, rowsPerImage: 1 },
      [256, 1, 1]);
    g.lutKey = lutKey;
    g.bindGroup = null; g.dbindGroup = null;   // LUT changed → both groups rebuild
    return true;
  }

  // Upload the BASE (overview/full) image bytes + the LUT. Returns false if the base
  // bytes couldn't be decoded (caller falls back to Canvas2D). The detail tile is
  // uploaded separately (_gpuUploadDetail) into its own slot for the overlay pass —
  // base and detail are STITCHED in one frame, not swapped, so a zoom-out shows the
  // crisp padded tile over an upsampled-overview margin (no flash).
  function _gpuUploadImage(p, st) {
    const g = p._gpuImg, device = g.device;
    // The BASE texture is an OVERVIEW in tile mode: its real texel dims are
    // base_width/height (0 → full image_width/height). The shader samples UV as a
    // fraction 0..1 of the texture, so a smaller overview still maps over the full
    // logical extent — lower-res until the detail tile covers the view.
    const iw = st.base_width || st.image_width;
    const ih = st.base_height || st.image_height;
    const img = _imageBytes(st);
    if (img.key !== g.bytesKey || !g.tex || g.texW !== iw || g.texH !== ih) {
      const texWH = { w: g.texW, h: g.texH };
      const tex = _gpuWriteR8(device, g.tex, texWH, iw, ih, img.bytes);
      if (!tex) return false;
      g.tex = tex; g.texW = texWH.w; g.texH = texWH.h;
      g.bytesKey = img.key;
      g.bindGroup = null;   // texture changed → rebuild bind group
    }
    if (!_gpuEnsureLut(g, st)) return false;
    if (!g.bindGroup) {
      g.bindGroup = device.createBindGroup({
        layout: g.pipeline.getBindGroupLayout(0),
        entries: [
          { binding: 0, resource: { buffer: g.uniformBuf } },
          { binding: 1, resource: g.tex.createView() },
          { binding: 2, resource: g.lutTex.createView() },
          { binding: 3, resource: g.samp },
        ],
      });
    }
    return true;
  }

  // Upload the DETAIL tile into its own slot (g.dtex) + build g.dbindGroup bound to
  // uniformBuf2. Returns true if a detail tile is resident & ready to draw, false if
  // there's none (or its bytes couldn't be decoded → skip the overlay pass). Assumes
  // _gpuUploadImage already ran this frame (LUT is current).
  function _gpuUploadDetail(p, st) {
    const g = p._gpuImg, device = g.device;
    const reg = st.detail_region;
    if (!_hasDetail(st) || !reg || reg.length !== 4
        || !st.detail_width || !st.detail_height) return false;
    const iw = st.detail_width, ih = st.detail_height;
    const img = _detailBytes(st);
    if (img.key !== g.dbytesKey || !g.dtex || g.dtexW !== iw || g.dtexH !== ih) {
      const texWH = { w: g.dtexW, h: g.dtexH };
      const tex = _gpuWriteR8(device, g.dtex, texWH, iw, ih, img.bytes);
      if (!tex) return false;
      g.dtex = tex; g.dtexW = texWH.w; g.dtexH = texWH.h;
      g.dbytesKey = img.key;
      g.dbindGroup = null;
    }
    if (!g.dtex) return false;
    if (!g.dbindGroup) {
      g.dbindGroup = device.createBindGroup({
        layout: g.pipeline.getBindGroupLayout(0),
        entries: [
          { binding: 0, resource: { buffer: g.uniformBuf2 } },
          { binding: 1, resource: g.dtex.createView() },
          { binding: 2, resource: g.lutTex.createView() },
          { binding: 3, resource: g.samp },
        ],
      });
    }
    return true;
  }

  // Compute the GPU uniform: the on-screen quad in CLIP space + the texture uv
  // sub-region to sample, honouring zoom/center EXACTLY like the Canvas2D _blit2d
  // (so the GPU image stays registered with the axes/overlays at any zoom, and a
  // zoom-in UPSAMPLES real texels via nearest sampling). Returns 8 floats:
  // [rx0,ry0,rx1,ry1, u0,v0,u1,v1]. imgW/imgH = the gpuCanvas area in CSS px.
  // The visible image-pixel window [srcX, srcX+visW]×[srcY, srcY+visH] for the
  // current zoom/center, in BASE image pixels (zoom>=1). Mirrors _imageDrawUniform.
  function _visibleWindow(st) {
    const iw = st.image_width, ih = st.image_height;
    const zoom = st.zoom || 1.0;
    if (zoom < 1.0) return { srcX: 0, srcY: 0, visW: iw, visH: ih };
    const cx = (st.center_x == null ? 0.5 : st.center_x);
    const cy = (st.center_y == null ? 0.5 : st.center_y);
    const visW = iw / zoom, visH = ih / zoom;
    const srcX = Math.max(0, Math.min(iw - visW, cx * iw - visW / 2));
    const srcY = Math.max(0, Math.min(ih - visH, cy * ih - visH / 2));
    return { srcX, srcY, visW, visH };
  }

  // Is the detail tile active AND does it fully cover the current visible window?
  // If so, return the tile-relative UV of that window (so the shader samples the
  // hi-res tile); otherwise null (sample the base texture). Requires the whole
  // visible window inside detail_region so a zoom-in shows only crisp tile texels.
  // True when a detail tile is present, regardless of transport: base64 path leaves
  // the string in st.detail_b64; the BINARY path strips detail_b64 out of the geom
  // and ships bytes on the companion trait (spliced into st.detail_b64_bytes). Gating
  // on detail_b64 alone made the binary path NEVER show the detail tile — only the
  // blurry overview — because the string is absent under binary transport.
  function _hasDetail(st) {
    if (st.detail_b64) return true;
    const b = st.detail_b64_bytes;
    return !!(b && (b instanceof Uint8Array || b.byteLength !== undefined) && b.length);
  }

  function _detailUV(st) {
    const reg = st.detail_region;
    if (!_hasDetail(st) || !reg || reg.length !== 4) return null;
    const [tx0, tx1, ty0, ty1] = reg;
    const tw = tx1 - tx0, th = ty1 - ty0;
    if (!(tw > 0) || !(th > 0)) return null;
    const w = _visibleWindow(st);
    if (w.srcX < tx0 - 0.5 || w.srcX + w.visW > tx1 + 0.5 ||
        w.srcY < ty0 - 0.5 || w.srcY + w.visH > ty1 + 0.5) return null;
    return {
      u0: (w.srcX - tx0) / tw, u1: (w.srcX + w.visW - tx0) / tw,
      v0: (w.srcY - ty0) / th, v1: (w.srcY + w.visH - ty0) / th,
    };
  }

  // The screen rect (within the fit-rect fx,fy,fw,fh) where the detail tile's
  // logical region maps at the current zoom/center — for compositing the still-
  // valid crisp tile OVER the base when it no longer FULLY covers the view (a
  // zoom-out/pan that outgrew the region). Returns null when: no tile; the tile
  // already fully covers (the _detailUV branch draws it full-screen instead); or
  // the region is entirely off-screen (nothing to overlay). This is what removes
  // the zoom-out flash — the centre stays crisp until the wider tile lands.
  function _detailOverlayRect(st, fx, fy, fw, fh) {
    const reg = st.detail_region;
    if (!_hasDetail(st) || !reg || reg.length !== 4) return null;
    if (_detailUV(st)) return null;                 // fully covered → drawn elsewhere
    const zoom = st.zoom || 1.0;
    // At/below zoom 1 the whole image is visible and the overview base is
    // authoritative — don't float a stale crisp patch over it. The overlay is a
    // zoom-IN / transition aid (it prevents the zoom-OUT flash WHILE still
    // magnified); the live loop clears the tile below VIEW_ZOOM_MIN anyway, so this
    // only additionally guards a manually-set tile at zoom<=1.
    if (zoom <= 1.0) return null;
    const [tx0, tx1, ty0, ty1] = reg;
    if (!(tx1 > tx0) || !(ty1 > ty0)) return null;
    const iw = st.image_width, ih = st.image_height;
    // Logical→screen mapping identical to the zoom>=1 base blit (windowed), so the
    // overlaid tile registers exactly over the base.
    const cx = (st.center_x == null ? 0.5 : st.center_x);
    const cy = (st.center_y == null ? 0.5 : st.center_y);
    const visW = iw / zoom, visH = ih / zoom;
    const srcX = Math.max(0, Math.min(iw - visW, cx * iw - visW / 2));
    const srcY = Math.max(0, Math.min(ih - visH, cy * ih - visH / 2));
    const mapX = (lx) => fx + ((lx - srcX) / visW) * fw;
    const mapY = (ly) => fy + ((ly - srcY) / visH) * fh;
    const dx = mapX(tx0), dx1 = mapX(tx1);
    const dy = mapY(ty0), dy1 = mapY(ty1);
    const dw = dx1 - dx, dh = dy1 - dy;
    if (!(dw > 0.5) || !(dh > 0.5)) return null;
    // Fully outside the fit-rect → nothing to show.
    if (dx1 <= fx || dx >= fx + fw || dy1 <= fy || dy >= fy + fh) return null;
    return { dx, dy, dw, dh };
  }

  // Pack a screen dest rect (px, y-down) + uv sub-region (0..1) into the 8-float
  // clip-space uniform the shader expects. Shared by the base + detail passes.
  function _drawUniform(dx, dy, dw, dh, u0, v0, u1, v1, imgW, imgH) {
    const rx0 = (dx / imgW) * 2 - 1;
    const rx1 = ((dx + dw) / imgW) * 2 - 1;
    const ry0 = 1 - ((dy + dh) / imgH) * 2;   // bottom edge (lower clip y)
    const ry1 = 1 - (dy / imgH) * 2;          // top edge (upper clip y)
    return new Float32Array([rx0, ry0, rx1, ry1, u0, v0, u1, v1]);
  }

  // Uniform for the BASE pass: the overview/full frame over the fit-rect honouring
  // zoom/pan (NOT the detail — that's a separate overlay pass now, so the base
  // always fills the whole view and the crisp tile stitches on top).
  function _imageDrawUniform(st, imgW, imgH) {
    const fr = _imgFitRect(st.image_width, st.image_height, imgW, imgH);
    const iw = st.image_width, ih = st.image_height;
    const zoom = st.zoom || 1.0;
    const cx = (st.center_x == null ? 0.5 : st.center_x);
    const cy = (st.center_y == null ? 0.5 : st.center_y);
    let dx = fr.x, dy = fr.y, dw = fr.w, dh = fr.h;   // dest rect in px
    let u0 = 0, v0 = 0, u1 = 1, v1 = 1;               // full texture
    if (zoom >= 1.0) {
      // Zoomed in: sample a window of the image over the full fit-rect.
      const visW = iw / zoom, visH = ih / zoom;
      const srcX = Math.max(0, Math.min(iw - visW, cx * iw - visW / 2));
      const srcY = Math.max(0, Math.min(ih - visH, cy * ih - visH / 2));
      u0 = srcX / iw; u1 = (srcX + visW) / iw;
      v0 = srcY / ih; v1 = (srcY + visH) / ih;
    } else {
      // Zoomed out: shrink the dest rect proportionally, keep centred.
      dw = fr.w * zoom; dh = fr.h * zoom;
      dx = fr.x + (fr.w - dw) / 2; dy = fr.y + (fr.h - dh) / 2;
    }
    return _drawUniform(dx, dy, dw, dh, u0, v0, u1, v1, imgW, imgH);
  }

  // Uniform for the DETAIL overlay pass. Two cases:
  //  • fully covers (_detailUV): draw the tile over the WHOLE fit-rect, sampling the
  //    tile-relative UV of the visible window (crisp zoom-in) — hides the base.
  //  • partial (_detailOverlayRect): draw the tile at its own screen rect over the
  //    base (crisp centre + overview margin on a zoom-out, no flash).
  // Returns null when there's no detail tile to overlay.
  function _detailDrawUniform(st, imgW, imgH) {
    const fr = _imgFitRect(st.image_width, st.image_height, imgW, imgH);
    const vr = _imgVisibleRect2d(st, imgW, imgH);
    const det = _detailUV(st);
    if (det) {
      return _drawUniform(vr.x, vr.y, vr.w, vr.h,
                          det.u0, det.v0, det.u1, det.v1, imgW, imgH);
    }
    const ov = _detailOverlayRect(st, fr.x, fr.y, fr.w, fr.h);
    if (ov) {
      const cl = _clipRectUv(ov.dx, ov.dy, ov.dw, ov.dh,
        0, 0, 1, 1, vr.x, vr.y, vr.w, vr.h);
      if (!cl) return null;
      return _drawUniform(cl.dx, cl.dy, cl.dw, cl.dh,
        cl.u0, cl.v0, cl.u1, cl.v1, imgW, imgH);
    }
    return null;
  }

  // Draw the image on the GPU canvas. Returns false on any failure so the caller
  // reverts to Canvas2D for this frame. No clim uniform: the LUT already bakes in
  // the display window + scale_mode (see _GPU_IMAGE_WGSL) — the shader is a plain
  // identity lookup.
  function _gpuDraw2dImage(p, st, imgW, imgH) {
    const g = p._gpuImg;
    try {
      if (!_gpuUploadImage(p, st)) { _tiledbg('gpu', 'base upload FAILED → canvas fallback'); return false; }
      const device = g.device;
      // BASE pass: the overview/full frame over the fit-rect, honouring zoom/pan, so
      // it lines up with the Canvas2D blit + overlays. Always drawn — the crisp tile
      // stitches on top, and the base shows through any margin the tile doesn't cover.
      device.queue.writeBuffer(g.uniformBuf, 0, _imageDrawUniform(st, imgW, imgH));
      // DETAIL pass (optional): the hi-res tile over its screen rect (full fit-rect
      // when it covers the view; its own padded-FOV rect on a zoom-out). Prepared
      // BEFORE the encoder so a decode failure just skips the overlay (base still
      // draws) rather than aborting the whole frame to the Canvas2D fallback.
      let drawDetail = false;
      const du = _detailDrawUniform(st, imgW, imgH);
      const _detUpload = du ? _gpuUploadDetail(p, st) : false;
      if (du && _detUpload) {
        device.queue.writeBuffer(g.uniformBuf2, 0, du);
        drawDetail = true;
      }
      if (globalThis.__apl_tiledbg) {
        const reg = st.detail_region || [];
        const uv = _detailUV(st);
        _tiledbg('gpu', `DRAW zoom=${(st.zoom||1).toFixed(2)} ` +
          `center=(${(st.center_x||0.5).toFixed(3)},${(st.center_y||0.5).toFixed(3)}) ` +
          `base[${st.base_width}x${st.base_height}] image[${st.image_width}x${st.image_height}] ` +
          `detail_region=[${reg.join(',')}] detailUV=${uv?'COVERS(full)':'partial/none'} ` +
          `drawDetail=${drawDetail} detUpload=${_detUpload} ` +
          `display=(${st.display_min},${st.display_max})`);
      }
      // Clear to the canvas background so the letterbox bars match the Canvas2D
      // path (which leaves the plotCanvas bg showing outside the fit-rect).
      const bg = _clearRgba(theme.bgCanvas);
      const enc = device.createCommandEncoder();
      const view = g.ctx.getCurrentTexture().createView();
      const pass = enc.beginRenderPass({
        colorAttachments: [{ view, loadOp: 'clear', storeOp: 'store',
          clearValue: bg }] });
      pass.setPipeline(g.pipeline);
      pass.setBindGroup(0, g.bindGroup);
      pass.draw(6);
      if (drawDetail) {
        // Second pass on the SAME target, loadOp:'load' to keep the base underneath.
        pass.end();
        const pass2 = enc.beginRenderPass({
          colorAttachments: [{ view, loadOp: 'load', storeOp: 'store' }] });
        pass2.setPipeline(g.pipeline);
        pass2.setBindGroup(0, g.dbindGroup);
        pass2.draw(6);
        pass2.end();
      } else {
        pass.end();
      }
      device.queue.submit([enc.finish()]);
      return true;
    } catch (e) {
      console.warn('[anyplotlib] GPU image draw failed — canvas fallback:', e);
      return false;
    }
  }

  // '#rrggbb' → {r,g,b,a} floats 0..1 for a WebGPU clearValue.
  function _clearRgba(hex) {
    const h = (hex || '#000000').replace('#', '');
    const n = parseInt(h.length === 3
      ? h.split('').map(c => c + c).join('') : h, 16);
    return { r: ((n >> 16) & 255) / 255, g: ((n >> 8) & 255) / 255,
             b: (n & 255) / 255, a: 1 };
  }

  // Test hook: render an active 2-D image panel into an OFFSCREEN RGBA texture
  // (not the live swapchain, which reads black under automation) and copy it back
  // to CPU. Returns {w,h,px:[[r,g,b],...]} on an NxN sample grid so a test can
  // verify the shader-LUT actually produced the expected colormapped output.
  async function _gpuReadbackImage(panelId, N) {
    N = N || 24;
    const p = panels.get(panelId);
    if (!p || p._gpu !== 'active' || !p._gpuImg) return null;
    const g = p._gpuImg, device = g.device, st = p.state;
    if (!_gpuUploadImage(p, st)) return null;
    // Fill the whole NxN readback target (rect = full clip space) sampling the
    // FULL texture (uv 0..1) so the readback reads the entire image regardless of
    // aspect or the live zoom — the shader is a plain LUT identity lookup (clim
    // baked into LUT), so this reads the true colormapped output.
    device.queue.writeBuffer(g.uniformBuf, 0,
      new Float32Array([-1, -1, 1, 1, 0, 0, 1, 1]));
    // Offscreen target at NxN (a coarse but faithful downscale via the sampler).
    const tex = device.createTexture({
      size: [N, N, 1], format: g.fmt,
      usage: GPUTextureUsage.RENDER_ATTACHMENT | GPUTextureUsage.COPY_SRC });
    const enc = device.createCommandEncoder();
    const pass = enc.beginRenderPass({
      colorAttachments: [{ view: tex.createView(), loadOp: 'clear',
        storeOp: 'store', clearValue: { r: 0, g: 0, b: 0, a: 1 } }] });
    pass.setPipeline(g.pipeline); pass.setBindGroup(0, g.bindGroup); pass.draw(6); pass.end();
    const bpr = Math.ceil(N * 4 / 256) * 256;
    const buf = device.createBuffer({
      size: bpr * N, usage: GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ });
    enc.copyTextureToBuffer({ texture: tex }, { buffer: buf, bytesPerRow: bpr }, [N, N, 1]);
    device.queue.submit([enc.finish()]);
    await buf.mapAsync(GPUMapMode.READ);
    const data = new Uint8Array(buf.getMappedRange()).slice();
    buf.unmap(); buf.destroy(); tex.destroy();
    const isBgra = g.fmt.startsWith('bgra');
    const px = [];
    for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) {
      const o = r * bpr + c * 4;
      px.push(isBgra ? [data[o+2], data[o+1], data[o]]
                     : [data[o], data[o+1], data[o+2]]);
    }
    return { w: N, h: N, px };
  }
  try { globalThis.__apl_gpuReadback = _gpuReadbackImage; } catch (_) {}

  // Test hook: set zoom/center on a 2-D image panel and redraw, so an automated
  // test can verify the GPU path stays active + upsamples when zoomed (mirrors the
  // wheel handler, without a synthetic wheel event).
  try {
    globalThis.__apl_setZoom = function (panelId, zoom, cx, cy) {
      const p = panels.get(panelId);
      if (!p || !p.state) return false;
      p.state.zoom = zoom;
      if (cx != null) p.state.center_x = cx;
      if (cy != null) p.state.center_y = cy;
      const _t0 = performance.now();
      try { draw2d(p); } catch (_) {}
      const _tDraw = performance.now() - _t0;
      // Compare the wheel handler's post-draw serialise: the OLD cost
      // (JSON.stringify of the whole geom-polluted state) vs the NEW cost
      // (_viewStateJson, geom stripped). On the binary path the old cost is a
      // Uint8Array → {"0":..} stringify (millions of keys); the new one is tiny.
      const _t1 = performance.now();
      let _slen = 0;
      try { _slen = JSON.stringify(p.state).length; } catch (_) { _slen = -1; }
      const _tStringify = performance.now() - _t1;
      const _t2 = performance.now();
      let _vlen = 0;
      try { _vlen = _viewStateJson(p).length; } catch (_) { _vlen = -1; }
      const _tView = performance.now() - _t2;
      globalThis.__apl_zoom_dbg = { draw: _tDraw,
        stringify: _tStringify, len: _slen,           // OLD (full state)
        viewStringify: _tView, viewLen: _vlen,        // NEW (geom stripped)
        hasBytes: !!(p.state && p.state.image_b64_bytes),
        b64len: (p.state && p.state.image_b64 && p.state.image_b64.length) || 0 };
      return _tDraw;   // draw2d ms (a zoom-only redraw)
    };
    // Test hook: return the EXACT string the interaction handlers now write to
    // the light `panel_<id>_json` trait (geometry stripped). Lets a test assert
    // the heavy geom keys never leak into the per-tick view write.
    globalThis.__apl_viewStateJson = function (panelId) {
      const p = panels.get(panelId);
      if (!p) return null;
      try { return _viewStateJson(p); } catch (_) { return null; }
    };
    // Test hook: the image-px → canvas-px transform for a 2-D panel at its
    // CURRENT zoom/center (the same _imgToCanvas2d the markers/widgets use),
    // so a test can aim the mouse at a widget/feature under any view.
    globalThis.__apl_imgToCanvas = function (panelId, ix, iy) {
      const p = panels.get(panelId);
      if (!p || !p.state || p.kind !== '2d') return null;
      const imgW = p.imgW || Math.max(1, p.pw - PAD_L - PAD_R);
      const imgH = p.imgH || Math.max(1, p.ph - PAD_T - PAD_B);
      try { return _imgToCanvas2d(ix, iy, p.state, imgW, imgH); }
      catch (_) { return null; }
    };
    // Test hook: pixel-freshness diagnostic for a 2-D panel — which bytes does
    // the state hold vs which bitmap/texture is cached? Distinguishes "stale
    // bytes arrived" from "fresh bytes, stale render cache".
    globalThis.__apl_panelDiag = function (panelId) {
      const p = panels.get(panelId);
      if (!p || !p.state || p.kind !== '2d') return null;
      const st = p.state;
      const img = _imageBytes(st);
      const fp = (u8) => {
        if (!u8) return null;
        const n = u8.length;
        let s = 0;
        for (let i = 0; i < n; i += Math.max(1, n >> 6)) s = (s * 31 + u8[i]) >>> 0;
        return `${n}:${s}`;
      };
      return {
        token: String(st.image_b64 || '').slice(0, 24),
        hasBytes: !!st.image_b64_bytes,
        bytesFp: fp(img.bytes),
        base: [st.base_width, st.base_height],
        logical: [st.image_width, st.image_height],
        detail_region: st.detail_region || [],
        detail_seq: st.detail_seq || 0,
        geomRev: st._geom_rev,
        blitKey: p.blitCache && String(p.blitCache.bytesKey || '').slice(0, 24),
        blitWH: p.blitCache && [p.blitCache.w, p.blitCache.h],
        gpuBytesKey: p._gpuImg && String(p._gpuImg.bytesKey || '').slice(0, 24),
        gpu: p._gpu,
      };
    };
    // Test hook: the hover status-bar text for a panel (position + pixel value),
    // plus whether it is currently shown — the bar is a plain div with no stable
    // selector, so a test reads it through here after a mouse move.
    globalThis.__apl_statusText = function (panelId) {
      const p = panels.get(panelId);
      if (!p || !p.statusBar) return null;
      return { text: p.statusBar.textContent,
               shown: p.statusBar.style.display !== 'none' };
    };
    // Tile debug: __apl_tileDebug(true) then pan/zoom, then __apl_tileDump() to read
    // the ring buffer of detail-tile decisions (detailUV vs FALLBACK->base) + the
    // window/region/uv so we can see exactly where a pan snaps or inverts.
    globalThis.__apl_tileDebug = function (on) { globalThis.__APL_TILE_DEBUG = !!on;
      if (on) globalThis.__apl_tileDbg = []; return globalThis.__APL_TILE_DEBUG; };
    globalThis.__apl_tileDump = function () { return globalThis.__apl_tileDbg || []; };
  } catch (_) {}

  function _gpuInitPanel(p, device, geom) {
    const fmt = navigator.gpu.getPreferredCanvasFormat();
    const ctx = p.gpuCanvas.getContext('webgpu');
    // Opaque canvas: voxel alpha-blending happens inside the render pass over
    // the opaque background clear, so the canvas itself stays opaque.
    ctx.configure({ device, format: fmt, alphaMode: 'opaque' });
    if (geom === 'surface') { _gpuInitSurfacePanel(p, device, ctx, fmt); return; }
    const isVox = geom === 'voxels';
    const module = device.createShaderModule({
      code: isVox ? _GPU_VOXEL_WGSL : _GPU_POINT_WGSL });
    // Voxels with baseAlpha < 1 blend (back-to-front not guaranteed, but the
    // depth buffer + low alpha reads acceptably for a translucent volume;
    // opaque voxels use depth only).
    const blend = {
      color: { srcFactor: 'src-alpha', dstFactor: 'one-minus-src-alpha' },
      alpha: { srcFactor: 'one', dstFactor: 'one-minus-src-alpha' },
    };
    const pipeline = device.createRenderPipeline({
      layout: 'auto',
      vertex: {
        module, entryPoint: 'vs',
        buffers: [
          { arrayStride: 12, stepMode: 'instance',
            attributes: [{ shaderLocation: 0, offset: 0, format: 'float32x3' }] },
          { arrayStride: 4, stepMode: 'instance',
            attributes: [{ shaderLocation: 1, offset: 0, format: 'unorm8x4' }] },
        ],
      },
      fragment: { module, entryPoint: 'fs',
                  targets: [{ format: fmt, blend: isVox ? blend : undefined }] },
      primitive: { topology: 'triangle-list',
                   cullMode: isVox ? 'back' : 'none' },
      depthStencil: { format: 'depth24plus',
                      // Translucent voxels: test depth but don't write it, so
                      // blending isn't order-killed; opaque points write depth.
                      depthWriteEnabled: !isVox, depthCompare: 'less' },
    });
    const uniformBuf = device.createBuffer({
      size: isVox ? 160 : 96,
      usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST });
    const bindGroup = device.createBindGroup({
      layout: pipeline.getBindGroupLayout(0),
      entries: [{ binding: 0, resource: { buffer: uniformBuf } }],
    });
    p._gpuObj = { device, ctx, fmt, pipeline, uniformBuf, bindGroup, geom,
                  posBuf: null, colBuf: null, depthTex: null,
                  count: 0, geomKey: null };
  }

  // ── Textured surface: pipeline, buffers, texture ─────────────────────────
  function _gpuInitSurfacePanel(p, device, ctx, fmt) {
    const module = device.createShaderModule({ code: _GPU_SURFACE_WGSL });
    const pipeline = device.createRenderPipeline({
      layout: 'auto',
      vertex: {
        module, entryPoint: 'vs',
        buffers: [
          { arrayStride: 12,   // position
            attributes: [{ shaderLocation: 0, offset: 0, format: 'float32x3' }] },
          { arrayStride: 8,    // uv
            attributes: [{ shaderLocation: 1, offset: 0, format: 'float32x2' }] },
          { arrayStride: 12,   // normal
            attributes: [{ shaderLocation: 2, offset: 0, format: 'float32x3' }] },
        ],
      },
      fragment: { module, entryPoint: 'fs', targets: [{ format: fmt, blend: {
        // Only matters for a texture carrying its own per-texel alpha; an
        // opaque one blends as a plain overwrite, so draw order is irrelevant.
        color: { srcFactor: 'src-alpha', dstFactor: 'one-minus-src-alpha' },
        alpha: { srcFactor: 'one', dstFactor: 'one-minus-src-alpha' },
      } }] },
      // No culling: the depth buffer resolves occlusion exactly, so an open
      // surface stays visible from behind (which `cull_backfaces` cannot do)
      // and a closed one hides its own far side for free.
      primitive: { topology: 'triangle-list', cullMode: 'none' },
      depthStencil: { format: 'depth24plus',
                      depthWriteEnabled: true, depthCompare: 'less' },
    });
    const uniformBuf = device.createBuffer({
      size: _GPU_SURFACE_UBO,
      usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST });
    const sampler = device.createSampler({
      magFilter: 'linear', minFilter: 'linear', mipmapFilter: 'linear',
      // U wraps so a sphere's 0h/24h seam interpolates across; V clamps so the
      // poles do not bleed round to the opposite hemisphere.
      addressModeU: 'repeat', addressModeV: 'clamp-to-edge',
    });
    p._gpuObj = { device, ctx, fmt, pipeline, uniformBuf, sampler,
                  geom: 'surface', bindGroup: null,
                  posBuf: null, uvBuf: null, nrmBuf: null, idxBuf: null,
                  texture: null, texKey: null, depthTex: null,
                  count: 0, geomKey: null };
  }

  function _gpuUploadSurface(p, tex) {
    const g = p._gpuObj, st = p.state, device = g.device;
    const key = (st.vertices_b64 || '') + '|' + (st.faces_b64 || '')
              + '|' + (st.texture_uv_b64 || '');
    if (g.geomKey !== key) {
      g.geomKey = key;
      for (const b of ['posBuf', 'uvBuf', 'nrmBuf', 'idxBuf']) {
        if (g[b]) { g[b].destroy(); g[b] = null; }
      }
      const verts = p._3dVerts || [], uv = p._3dUV;
      const idx = p._3dFacesFlat;
      const n = verts.length;
      if (!n || !uv || !idx || !idx.length) { g.count = 0; return; }

      const pos = new Float32Array(n * 3);
      for (let i = 0; i < n; i++) {
        pos[i*3] = verts[i][0]; pos[i*3+1] = verts[i][1]; pos[i*3+2] = verts[i][2];
      }
      // Smooth vertex normals: accumulate each face's normal onto its three
      // corners.  The absolute sign does not matter (the shader orients toward
      // the camera), only that neighbouring faces agree — which a grid
      // triangulation guarantees.  This is what buys per-pixel shading.
      const nrm = new Float32Array(n * 3);
      for (let f = 0; f + 2 < idx.length; f += 3) {
        const a = idx[f], b = idx[f+1], c = idx[f+2];
        const ax = pos[a*3], ay = pos[a*3+1], az = pos[a*3+2];
        const e1x = pos[b*3] - ax, e1y = pos[b*3+1] - ay, e1z = pos[b*3+2] - az;
        const e2x = pos[c*3] - ax, e2y = pos[c*3+1] - ay, e2z = pos[c*3+2] - az;
        const fx = e1y*e2z - e1z*e2y;
        const fy = e1z*e2x - e1x*e2z;
        const fz = e1x*e2y - e1y*e2x;
        for (const v of [a, b, c]) {
          nrm[v*3] += fx; nrm[v*3+1] += fy; nrm[v*3+2] += fz;
        }
      }
      for (let i = 0; i < n; i++) {
        const x = nrm[i*3], y = nrm[i*3+1], z = nrm[i*3+2];
        const L = Math.hypot(x, y, z);
        if (L > 0) { nrm[i*3] = x/L; nrm[i*3+1] = y/L; nrm[i*3+2] = z/L; }
        else { nrm[i*3+2] = 1; }
      }
      // UVs may be shorter than the vertex count only if state is mid-update;
      // the caller already gates on length, so copy straight through.
      const uvs = new Float32Array(uv.buffer, uv.byteOffset, n * 2);

      const mk = (data, usage) => {
        const buf = device.createBuffer({
          size: Math.max(16, data.byteLength), usage: usage | GPUBufferUsage.COPY_DST });
        device.queue.writeBuffer(buf, 0, data);
        return buf;
      };
      g.posBuf = mk(pos, GPUBufferUsage.VERTEX);
      g.uvBuf  = mk(uvs, GPUBufferUsage.VERTEX);
      g.nrmBuf = mk(nrm, GPUBufferUsage.VERTEX);
      // Indices are non-negative, so the int32 bit patterns are already uint32.
      g.idxBuf = mk(new Uint32Array(idx.buffer, idx.byteOffset, idx.length),
                    GPUBufferUsage.INDEX);
      g.count = idx.length;
    }

    // Texture: uploaded from the decoded <img>, with a full mip chain.
    if (g.texKey !== tex.url) {
      const lim = device.limits.maxTextureDimension2D || 8192;
      if (tex.tw > lim || tex.th > lim) {
        throw new Error(`texture ${tex.tw}x${tex.th} exceeds the device limit ${lim}`);
      }
      if (g.texture) g.texture.destroy();
      const levels = 1 + Math.floor(Math.log2(Math.max(tex.tw, tex.th)));
      g.texture = device.createTexture({
        size: [tex.tw, tex.th], format: 'rgba8unorm', mipLevelCount: levels,
        usage: GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.COPY_DST
             | GPUTextureUsage.RENDER_ATTACHMENT });
      device.queue.copyExternalImageToTexture(
        { source: tex.img }, { texture: g.texture }, [tex.tw, tex.th]);
      _gpuGenerateMips(device, g.texture, 'rgba8unorm', levels);
      g.texKey = tex.url;
      g.bindGroup = device.createBindGroup({
        layout: g.pipeline.getBindGroupLayout(0),
        entries: [
          { binding: 0, resource: { buffer: g.uniformBuf } },
          { binding: 1, resource: g.sampler },
          { binding: 2, resource: g.texture.createView() },
        ],
      });
    }
  }

  function _gpuDrawSurface(p, R, scale, cx, cy) {
    const g = p._gpuObj;
    if (!g || !g.count || !g.bindGroup) return;
    const st = p.state, device = g.device;
    const { W, H, dpr } = _gpuEnsureSize(p);
    const gm = p._gpuGeom;
    const mvp = _gpuMatrix(R, scale * dpr, cx * dpr, cy * dpr, W, H,
                           gm.bnds, gm.maxR, gm.xr, gm.yr, gm.zr);
    // Uniform layout, in floats: mvp 0..15 | rot0 16..19 | rot1 20..23 |
    // rot2 24..27 | light.xyz + shade flag 28..31 | misc.x = alpha 32..35.
    // 36 floats = 144 bytes (mat4 + five vec4), matching _GPU_SURFACE_UBO.
    const u = new Float32Array(36);
    u.set(mvp, 0);
    u[16] = R[0][0]; u[17] = R[0][1]; u[18] = R[0][2];
    u[20] = R[1][0]; u[21] = R[1][1]; u[22] = R[1][2];
    u[24] = R[2][0]; u[25] = R[2][1]; u[26] = R[2][2];
    u[28] = _TEX_LIGHT[0]; u[29] = _TEX_LIGHT[1]; u[30] = _TEX_LIGHT[2];
    u[31] = st.texture_shade ? 1 : 0;
    u[32] = st.texture_alpha == null ? 1 : st.texture_alpha;
    device.queue.writeBuffer(g.uniformBuf, 0, u);

    const enc = device.createCommandEncoder();
    const pass = _gpuBeginPass(g, enc);
    pass.setPipeline(g.pipeline);
    pass.setBindGroup(0, g.bindGroup);
    pass.setVertexBuffer(0, g.posBuf);
    pass.setVertexBuffer(1, g.uvBuf);
    pass.setVertexBuffer(2, g.nrmBuf);
    pass.setIndexBuffer(g.idxBuf, 'uint32');
    pass.drawIndexed(g.count);
    pass.end();
    device.queue.submit([enc.finish()]);
  }

  function _gpuUploadGeometry(p) {
    const g = p._gpuObj, st = p.state, device = g.device;
    // Key on BOTH geometry and colours: the orthoslice explorer recolours
    // voxels via set_point_colors with the vertex set unchanged, so caching
    // on vertices_b64 alone would reuse a stale colour buffer.
    const key = (st.vertices_b64 || '') + '|' + (st.point_colors_b64 || '');
    if (g.geomKey === key && g.posBuf) return;
    g.geomKey = key;
    if (g.posBuf) g.posBuf.destroy();
    if (g.colBuf) g.colBuf.destroy();

    const verts = p._3dVerts || [];   // [[x,y,z],...] decoded by draw3d
    const n = verts.length;
    g.count = n;
    const pos = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) {
      pos[i*3] = verts[i][0]; pos[i*3+1] = verts[i][1]; pos[i*3+2] = verts[i][2];
    }
    g.posBuf = device.createBuffer({
      size: Math.max(16, pos.byteLength),
      usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST });
    device.queue.writeBuffer(g.posBuf, 0, pos);

    // Colours: per-point RGBA u8, or replicate the single colour.
    const col = new Uint8Array(n * 4);
    const pc = p._3dPCols;
    if (pc) {
      for (let i = 0; i < n; i++) {
        col[i*4] = pc[i*3]; col[i*4+1] = pc[i*3+1];
        col[i*4+2] = pc[i*3+2]; col[i*4+3] = 255;
      }
    } else {
      const c = st.color || '#4fc3f7';
      const r = parseInt(c.slice(1,3),16), gg = parseInt(c.slice(3,5),16),
            b = parseInt(c.slice(5,7),16);
      for (let i = 0; i < n; i++) {
        col[i*4]=r; col[i*4+1]=gg; col[i*4+2]=b; col[i*4+3]=255;
      }
    }
    g.colBuf = device.createBuffer({
      size: Math.max(16, col.byteLength),
      usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST });
    device.queue.writeBuffer(g.colBuf, 0, col);
  }

  // Orthographic clip-space matrix matching the canvas projection EXACTLY.
  // Canvas does:  n = k*v - o  (k=2/maxR; o_i = k*bmin_i + extent_i/maxR),
  //   sx = cx + scale*(r0·n) ;  sy = cy - scale*(r2·n) ;  depth from (r1·n)
  // We want clip = M·[v;1] (WGSL is M × column-vector) producing:
  //   clip.x = NDC.x = 2*sx/pw - 1
  //   clip.y = NDC.y = 1 - 2*sy/ph   (NDC y is up; screen y is down)
  //   clip.z in [0,1], clip.w = 1
  //
  // Substituting n = k*v - o, each clip component is affine in v:
  //   clip.x = (2*scale*k/pw)*(r0·v) + [ -(2*scale/pw)*(r0·o) + (2*cx/pw - 1) ]
  //   clip.y = -(2*scale*k/ph)*(r2·v) + [  (2*scale/ph)*(r2·o) + (1 - 2*cy/ph) ]
  //   clip.z = +DK*k*(r1·v) + [ -DK*(r1·o) + 0.5 ]   →  0.5 + DK*depth
  //
  // DEPTH SIGN: r1·n is depth INTO the screen, so clip.z must INCREASE with it
  // for `depthCompare: 'less'` against a 1.0 clear to keep the nearest
  // fragment.  This row used to be negated, which inverted every depth-tested
  // GPU draw — a scatter cloud painted its far points over its near ones, and
  // a textured surface rendered inside-out (you saw the far hemisphere).  It
  // went unnoticed because voxels, the other GPU consumer, disable depth
  // writes entirely.
  //
  // Build the 4 ROWS, then transpose into WGSL's column-major storage.
  //
  // DEPTH SCALE: `norm()` puts the geometry in a box that reaches [-1,1] on its
  // longest axis, so |r1·n| can reach √3 at a corner (r1 is a unit row).  WebGPU
  // clips fragments outside z ∈ [0,1] — there is no depth clamp without the
  // `depth-clip-control` feature — so DK must satisfy DK*√3 ≤ 0.5, i.e.
  // DK ≤ 0.2887.  This was 0.35, which put the corners of a CUBE-shaped dataset
  // outside the range: at the default camera (az -60, el 30) r1 = [.75,.433,-.5]
  // and ‖r1‖₁ = 1.683, so clip.z peaked at 1.089 and the near corner of a dense
  // scatter cloud was silently clipped away.  A sphere (|n| = 1) never noticed.
  // depth24plus has ample precision left at this scale.
  const _GPU_DEPTH_K = 0.28;
  function _gpuMatrix(R, scale, cx, cy, pw, ph, bnds, maxR, xr, yr, zr) {
    const r0 = R[0], r1 = R[1], r2 = R[2];
    const k = 2 / maxR;
    const ox = k*bnds.xmin + xr/maxR;
    const oy = k*bnds.ymin + yr/maxR;
    const oz = k*bnds.zmin + zr/maxR;
    const r0o = r0[0]*ox + r0[1]*oy + r0[2]*oz;
    const r1o = r1[0]*ox + r1[1]*oy + r1[2]*oz;
    const r2o = r2[0]*ox + r2[1]*oy + r2[2]*oz;
    const sx = 2*scale*k/pw,  sy = 2*scale*k/ph;
    // Rows of M (M·[vx,vy,vz,1]ᵀ).  For Y: canvas does sy = cy - scale*(r2·n)
    // (screen y down), and NDC.y = 1 - 2*sy/ph flips again — the two
    // negations CANCEL, so rowY's coefficients are +sy*r2, not -sy*r2.
    const rowX = [ sx*r0[0],  sx*r0[1],  sx*r0[2],  -(2*scale/pw)*r0o + (2*cx/pw - 1) ];
    const rowY = [ sy*r2[0],  sy*r2[1],  sy*r2[2],  -(2*scale/ph)*r2o + (1 - 2*cy/ph) ];
    const DK = _GPU_DEPTH_K;
    const rowZ = [ DK*k*r1[0],  DK*k*r1[1],  DK*k*r1[2], -DK*r1o + 0.5 ];
    const rowW = [0, 0, 0, 1];
    // Column-major: column j = [rowX[j], rowY[j], rowZ[j], rowW[j]]
    return new Float32Array([
      rowX[0], rowY[0], rowZ[0], rowW[0],
      rowX[1], rowY[1], rowZ[1], rowW[1],
      rowX[2], rowY[2], rowZ[2], rowW[2],
      rowX[3], rowY[3], rowZ[3], rowW[3],
    ]);
  }

  function _gpuDrawPoints(p, R, scale, cx, cy) {
    const g = p._gpuObj;
    if (!g || !g.count) return;
    const device = g.device, dpr = window.devicePixelRatio || 1;
    const W = Math.max(1, Math.round(p.pw * dpr));
    const H = Math.max(1, Math.round(p.ph * dpr));
    if (p.gpuCanvas.width !== W || p.gpuCanvas.height !== H || !g.depthTex) {
      p.gpuCanvas.width = W; p.gpuCanvas.height = H;
      if (g.depthTex) g.depthTex.destroy();
      g.depthTex = device.createTexture({
        size: [W, H], format: 'depth24plus',
        usage: GPUTextureUsage.RENDER_ATTACHMENT });
    }
    // Uniforms (matrix uses dpr-scaled pixels so points size in CSS px)
    const gm = p._gpuGeom;
    const mvp = _gpuMatrix(R, scale * dpr, cx * dpr, cy * dpr, W, H,
                           gm.bnds, gm.maxR, gm.xr, gm.yr, gm.zr);
    const u = new Float32Array(24);
    u.set(mvp, 0);
    u[16] = W; u[17] = H; u[18] = (p.state.point_size || 4) * dpr;
    device.queue.writeBuffer(g.uniformBuf, 0, u);

    const enc = device.createCommandEncoder();
    const bg = theme.bgPlot;
    const cr = parseInt(bg.slice(1,3),16)/255 || 0.1;
    const cg = parseInt(bg.slice(3,5),16)/255 || 0.1;
    const cb = parseInt(bg.slice(5,7),16)/255 || 0.12;
    const pass = enc.beginRenderPass({
      colorAttachments: [{
        view: g.ctx.getCurrentTexture().createView(),
        clearValue: { r: cr, g: cg, b: cb, a: 1 },
        loadOp: 'clear', storeOp: 'store' }],
      depthStencilAttachment: {
        view: g.depthTex.createView(),
        depthClearValue: 1.0, depthLoadOp: 'clear', depthStoreOp: 'store' },
    });
    pass.setPipeline(g.pipeline);
    pass.setBindGroup(0, g.bindGroup);
    pass.setVertexBuffer(0, g.posBuf);
    pass.setVertexBuffer(1, g.colBuf);
    pass.draw(6, g.count);
    pass.end();
    device.queue.submit([enc.finish()]);
  }

  // Ensure the gpuCanvas + depth texture are sized to the panel (dpr-scaled).
  function _gpuEnsureSize(p) {
    const g = p._gpuObj, device = g.device, dpr = window.devicePixelRatio || 1;
    const W = Math.max(1, Math.round(p.pw * dpr));
    const H = Math.max(1, Math.round(p.ph * dpr));
    if (p.gpuCanvas.width !== W || p.gpuCanvas.height !== H || !g.depthTex) {
      p.gpuCanvas.width = W; p.gpuCanvas.height = H;
      if (g.depthTex) g.depthTex.destroy();
      g.depthTex = device.createTexture({
        size: [W, H], format: 'depth24plus',
        usage: GPUTextureUsage.RENDER_ATTACHMENT });
    }
    return { W, H, dpr };
  }

  function _gpuBeginPass(g, enc) {
    const bg = theme.bgPlot;
    const cr = parseInt(bg.slice(1,3),16)/255 || 0.1;
    const cg = parseInt(bg.slice(3,5),16)/255 || 0.1;
    const cb = parseInt(bg.slice(5,7),16)/255 || 0.12;
    return enc.beginRenderPass({
      colorAttachments: [{
        view: g.ctx.getCurrentTexture().createView(),
        clearValue: { r: cr, g: cg, b: cb, a: 1 },
        loadOp: 'clear', storeOp: 'store' }],
      depthStencilAttachment: {
        view: g.depthTex.createView(),
        depthClearValue: 1.0, depthLoadOp: 'clear', depthStoreOp: 'store' },
    });
  }

  function _gpuDrawVoxels(p, R, scale, cx, cy) {
    const g = p._gpuObj;
    if (!g || !g.count) return;
    const st = p.state, device = g.device;
    const { W, H, dpr } = _gpuEnsureSize(p);
    const gm = p._gpuGeom;
    const mvp = _gpuMatrix(R, scale * dpr, cx * dpr, cy * dpr, W, H,
                           gm.bnds, gm.maxR, gm.xr, gm.yr, gm.zr);
    // Uniform layout (std140-ish): mat4(0..63), half/baseA/sliceA/nPlanes
    // (64..79), planeAxis vec4(80..95), planePos vec4(96..111),
    // shade vec4(112..127).  Buffer is 160 to satisfy 16-byte rounding.
    const u = new Float32Array(40);
    u.set(mvp, 0);
    u[16] = (st.voxel_size || 1) / 2;
    u[17] = st.voxel_alpha != null ? st.voxel_alpha : 0.3;
    u[18] = st.voxel_slice_alpha != null ? st.voxel_slice_alpha : 0.95;
    const AXI = { x: 0, y: 1, z: 2 };
    const planes = (st.overlay_widgets || [])
      .filter(w => w.type === 'plane' && w.visible !== false).slice(0, 4);
    u[19] = planes.length;
    for (let i = 0; i < planes.length; i++) {
      u[20 + i] = AXI[planes[i].axis] ?? 2;   // planeAxis vec4 @ float 20
      u[24 + i] = planes[i].position || 0;     // planePos  vec4 @ float 24
    }
    u[28] = 0.82; u[29] = 0.68; u[30] = 1.0;   // shade x/y/z (match canvas)
    device.queue.writeBuffer(g.uniformBuf, 0, u);

    const enc = device.createCommandEncoder();
    const pass = _gpuBeginPass(g, enc);
    pass.setPipeline(g.pipeline);
    pass.setBindGroup(0, g.bindGroup);
    pass.setVertexBuffer(0, g.posBuf);
    pass.setVertexBuffer(1, g.colBuf);
    pass.draw(36, g.count);
    pass.end();
    device.queue.submit([enc.finish()]);
  }

  function _gpuDisposePanel(p) {
    const g = p._gpuObj;
    if (!g) return;
    try {
      g.posBuf && g.posBuf.destroy();
      g.colBuf && g.colBuf.destroy();
      g.depthTex && g.depthTex.destroy();
      g.uniformBuf && g.uniformBuf.destroy();
      // Textured-surface resources (the mip-chained texture can be tens of MB).
      g.uvBuf && g.uvBuf.destroy();
      g.nrmBuf && g.nrmBuf.destroy();
      g.idxBuf && g.idxBuf.destroy();
      g.texture && g.texture.destroy();
    } catch (_) {}
    p._gpuObj = null;
  }

  // Free the 2-D image GPU resources (R8 image texture can be tens of MB). Call on
  // panel removal / figure dispose / device loss so repeatedly opening + closing
  // large-image panels (an in-situ movie viewer) doesn't leak GPU memory.
  function _gpuDisposeImagePanel(p) {
    const g = p._gpuImg;
    if (!g) return;
    try {
      g.tex && g.tex.destroy();
      g.dtex && g.dtex.destroy();
      g.lutTex && g.lutTex.destroy();
      g.uniformBuf && g.uniformBuf.destroy();
      g.uniformBuf2 && g.uniformBuf2.destroy();
    } catch (_) {}
    p._gpuImg = null;
  }

  function draw3d(p, _retry) {
    const st = p.state; if (!st) return;
    if (!_retry) p._gpuFellBack = false;   // per-render re-entry guard reset
    _recordFrame(p);
    const { pw, ph, plotCtx: ctx } = p;

    ctx.clearRect(0, 0, pw, ph);
    ctx.fillStyle = theme.bgPlot;
    ctx.fillRect(0, 0, pw, ph);

    // ── decode + cache b64 geometry (only when state changes) ──────────────
    const vKey = st.vertices_b64 || '';
    const fKey = st.faces_b64    || '';
    const zKey = st.z_values_b64 || '';
    if (p._3dVertsKey !== vKey) {
      p._3dVertsKey = vKey;
      p._voxGen = (p._voxGen || 0) + 1;   // invalidates voxel projection cache
      if (vKey) {
        const vf = _decodeF32(vKey);
        const nv = vf.length / 3;
        const arr = new Array(nv);
        for (let i = 0; i < nv; i++) arr[i] = [vf[i*3], vf[i*3+1], vf[i*3+2]];
        p._3dVerts = arr;
      } else { p._3dVerts = st.vertices || []; }
    }
    if (p._3dFacesKey !== fKey) {
      p._3dFacesKey = fKey;
      if (fKey) {
        const ff = _decodeI32(fKey);
        const nf = ff.length / 3;
        const arr = new Array(nf);
        for (let i = 0; i < nf; i++) arr[i] = [ff[i*3], ff[i*3+1], ff[i*3+2]];
        p._3dFaces = arr;
        p._3dFacesFlat = ff;      // straight to a GPU index buffer
      } else { p._3dFaces = st.faces || []; p._3dFacesFlat = null; }
    }
    if (p._3dZKey !== zKey) {
      p._3dZKey = zKey;
      p._3dZVals = zKey ? _decodeF32(zKey) : (st.z_values || []);
    }
    const uvKey = st.texture_uv_b64 || '';
    if (p._3dUVKey !== uvKey) {
      p._3dUVKey = uvKey;
      p._3dUV = uvKey ? _decodeF32(uvKey) : null;
    }
    const verts = p._3dVerts  || [];
    const faces = p._3dFaces  || [];
    const zVals = p._3dZVals  || [];

    const lut      = st.colormap_data || [];
    const geom     = st.geom_type   || 'surface';
    const bnds     = st.data_bounds || {};
    const az       = st.azimuth     || 0;
    const el       = st.elevation   || 30;
    const zoom     = st.zoom        || 1.0;
    const color    = st.color       || '#4fc3f7';
    const ptSize   = st.point_size  || 4;
    const lw       = st.linewidth   || 1.5;

    // Normalise vertices to [-1,1]³
    const xr = (bnds.xmax - bnds.xmin) || 1;
    const yr = (bnds.ymax - bnds.ymin) || 1;
    const zr = (bnds.zmax - bnds.zmin) || 1;
    const maxR = Math.max(xr, yr, zr);
    function norm(v) {
      return [
        2 * (v[0] - bnds.xmin) / maxR - xr / maxR,
        2 * (v[1] - bnds.ymin) / maxR - yr / maxR,
        2 * (v[2] - bnds.zmin) / maxR - zr / maxR,
      ];
    }

    const R = _rot3(az, el);
    const cx = pw / 2, cy = ph / 2;
    const scale = zoom * Math.min(pw, ph) * 0.32;

    // Resolve a surface texture BEFORE the GPU decision — a surface only wants
    // the GPU once its image has decoded, and _texEnsure is what starts that
    // (returning null and scheduling a redraw until the bitmap is ready).
    const surfTex = (geom === 'surface' && p._3dUV
                     && p._3dUV.length >= verts.length * 2)
      ? _texEnsure(p, st.texture_url || '') : null;

    // ── WebGPU geometry path (instanced points + voxels, textured surfaces) ─
    // Decide once whether this panel renders geometry on the GPU.  On the
    // first frame that wants it, kick off async device init; until it
    // resolves (or if it fails) the canvas path below runs unchanged.
    // A geom-type change tears down and re-inits the pipeline.
    let gpuActive = false;
    const gpuGeomChanged = p._gpuObj && p._gpuObj.geom !== geom;
    if (gpuGeomChanged) { _gpuDisposePanel(p); p._gpu = undefined; }
    // Test/diagnostic hook, mirroring __apl_gpu2d: what did the GPU decision
    // depend on this frame?  Cheap, and the only way to tell "no adapter" from
    // "texture not decoded yet" from "panel had zero size" after the fact.
    try { (globalThis.__apl_gpu3d ||= {})[p.id] = {
      geom, gpu: p._gpu, wanted: _gpuWanted(st, !!surfTex),
      texUrl: !!st.texture_url, texReady: !!surfTex,
      faces: st.faces_count || 0, mode: st.gpu_mode, pw, ph,
      hasNavGpu: typeof navigator !== 'undefined' && !!navigator.gpu }; } catch (_) {}
    if (p.kind === '3d' && _gpuWanted(st, !!surfTex)) {
      // Zero-drawable-size guard: SpyDE (and any host) mounts a 3-D panel HIDDEN
      // (display:none) and reveals it later, so the FIRST draw3d can run with
      // pw/ph == 0 (a zero-size layout) and the gpuCanvas collapsed to 0 client
      // px.  _gpuInitPanel configures the WebGPU swapchain and every draw pass
      // calls getCurrentTexture() against that canvas — on a zero-drawable-size
      // surface this is undefined behaviour: some drivers throw (→ the mid-draw
      // catch latches p._gpu='unavailable', TERMINAL) and others configure a
      // dead 0×0 context that silently draws nothing.  Either way the panel is
      // then stuck on Canvas2D forever because the `_gpu === undefined` guard
      // never re-runs.  So DON'T init at zero size: leave _gpu === undefined and
      // let the canvas path render (a hidden panel isn't visible anyway).  When
      // the panel is revealed/resized, the layout/fig-size change fires a
      // redrawAll() → this draw3d re-runs at the real size → init re-attempts.
      // Gate on pw/ph (the LOGICAL panel size that drives the gpuCanvas backing
      // store in _gpuDrawPoints/_gpuEnsureSize and every getCurrentTexture()).
      // NB: don't test the gpuCanvas' own client size — it starts display:none
      // until GPU activates, so clientWidth is 0 even for a fully-visible panel;
      // that would wrongly block the normal case.  A panel revealed by a pure
      // display toggle (pw/ph already non-zero, only client size was 0) is
      // handled by the ResizeObserver reveal branch, which redraws it.
      const hasDrawableSize = (pw || 0) > 0 && (ph || 0) > 0;
      if (p._gpu === undefined && hasDrawableSize) {
        p._gpu = 'pending';
        const initGeom = geom;
        _gpuDevice().then((device) => {
          if (!device || !panels.has(p.id)) { p._gpu = 'unavailable'; return; }
          try { _gpuInitPanel(p, device, initGeom); p._gpu = 'active'; }
          catch (e) { console.warn('[anyplotlib] GPU panel init failed:', e);
                      p._gpu = 'unavailable'; }
          _reportGpu(p);
          _redrawPanel(p);
        });
      }
      gpuActive = (p._gpu === 'active' && !!p._gpuObj);
    } else if (p._gpu === 'active') {
      // State no longer wants GPU — revert to canvas.
      p._gpu = undefined; gpuActive = false;
      if (p.gpuCanvas) p.gpuCanvas.style.display = 'none';
      p.plotCanvas.style.background = theme.bgPlot;   // restore opaque bg
      _gpuDisposePanel(p);
    }

    if (gpuActive) {
      // Decode per-instance colours (the canvas block that normally does this
      // is skipped in GPU mode).
      const pcKey = st.point_colors_b64 || '';
      if (p._3dPColKey !== pcKey) {
        p._3dPColKey = pcKey;
        if (pcKey) {
          const bin = atob(pcKey);
          const buf = new Uint8Array(bin.length);
          for (let i = 0; i < bin.length; i++) buf[i] = bin.charCodeAt(i);
          p._3dPCols = buf;
        } else { p._3dPCols = null; }
      }
      // Stash geometry params the GPU matrix needs, upload, draw.
      p._gpuGeom = { bnds, maxR, xr, yr, zr };
      p.gpuCanvas.style.display = 'block';
      p.gpuCanvas.style.width  = pw + 'px';
      p.gpuCanvas.style.height = ph + 'px';
      // plotCanvas becomes a transparent decoration overlay: clear its BITMAP
      // *and* drop its opaque CSS background — otherwise the element keeps
      // painting theme.bgPlot over the gpuCanvas beneath it (z-index 1 vs 0),
      // hiding every GPU-drawn voxel while canvas-drawn planes/highlight still
      // show.  (This is what made large voxel volumes look "empty" with only
      // the plane widgets + highlight visible.)
      p.plotCanvas.style.background = 'transparent';
      ctx.clearRect(0, 0, pw, ph);
      try {
        if (geom === 'surface') {
          _gpuUploadSurface(p, surfTex);
          _gpuDrawSurface(p, R, scale, cx, cy);
        } else {
          _gpuUploadGeometry(p);
          if (geom === 'voxels') _gpuDrawVoxels(p, R, scale, cx, cy);
          else                   _gpuDrawPoints(p, R, scale, cx, cy);
        }
      } catch (e) {
        console.warn('[anyplotlib] GPU draw failed — falling back:', e);
        p._gpu = 'unavailable'; gpuActive = false;
        if (p.gpuCanvas) p.gpuCanvas.style.display = 'none';
        p.plotCanvas.style.background = theme.bgPlot;   // restore opaque bg
        _gpuDisposePanel(p);
        // The current frame already cleared plotCanvas and took GPU-only
        // branches (proj == null etc.), so the axes/decorations for THIS frame
        // are half-built.  Rather than limp through, re-render the whole panel
        // once from the top on the canvas path — self-healing without needing
        // a user resize.  (Safari's experimental WebGPU can throw mid-draw or
        // lose the device after working for a while; this recovers cleanly.)
        if (!p._gpuFellBack) {
          p._gpuFellBack = true;
          ctx.fillStyle = theme.bgPlot; ctx.fillRect(0, 0, pw, ph);
          draw3d(p, true);   // re-render once on the canvas path
          return;
        }
        ctx.fillStyle = theme.bgPlot; ctx.fillRect(0, 0, pw, ph);
      }
    }
    p._gpuActiveNow = gpuActive;

    // Pre-project all vertices (voxels use a faster typed-array path inline;
    // skipped entirely when the GPU is drawing the geometry).
    const proj = (geom === 'voxels' || gpuActive) ? null : verts.map(v => {
      const nv = norm(v);
      const rv = _applyRot(R, nv);
      return { s: _project3(rv, cx, cy, scale), d: rv[1] }; // d = depth (into screen)
    });

    // Z-value normalisation for colormap
    const zMin = bnds.zmin, zMax = bnds.zmax, zRange = (zMax - zMin) || 1;

    // ── Reference sphere (set_sphere): shaded silhouette + wireframe ──────
    // Drawn before the geometry so data sits on top; far-side scatter points
    // are dimmed below for a correct depth read.
    const sp = st.sphere;
    const sphereOn = !!(sp && sp.radius > 0);
    if (sphereOn) {
      const cN   = norm([0, 0, 0]);
      const cRot = _applyRot(R, cN);
      const [spx, spy] = _project3(cRot, cx, cy, scale);
      const spr  = (2 * sp.radius / maxR) * scale;
      const col  = sp.color || '#9e9e9e';
      ctx.save();
      // Shaded silhouette disk (light from upper-left)
      const grad = ctx.createRadialGradient(
        spx - spr * 0.35, spy - spr * 0.35, spr * 0.1, spx, spy, spr);
      grad.addColorStop(0, theme.dark ? '#cfd8dc' : '#ffffff');
      grad.addColorStop(1, col);
      ctx.globalAlpha = sp.alpha != null ? sp.alpha : 0.15;
      ctx.fillStyle = grad;
      ctx.beginPath(); ctx.arc(spx, spy, spr, 0, Math.PI * 2); ctx.fill();
      // Silhouette ring
      ctx.globalAlpha = Math.min(1, (sp.alpha != null ? sp.alpha : 0.15) * 3);
      ctx.strokeStyle = col; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.arc(spx, spy, spr, 0, Math.PI * 2); ctx.stroke();
      // Latitude/longitude wireframe, depth-dimmed per segment
      if (sp.wireframe !== false) {
        ctx.lineWidth = 0.7;
        const SEG = 72, r3 = sp.radius;
        const circles = [];
        for (let lat = -60; lat <= 60; lat += 30) {        // parallels
          const cl = Math.cos(lat * Math.PI / 180) * r3;
          const zl = Math.sin(lat * Math.PI / 180) * r3;
          circles.push(t => [cl * Math.cos(t), cl * Math.sin(t), zl]);
        }
        for (let lon = 0; lon < 180; lon += 30) {          // meridians
          const cl = Math.cos(lon * Math.PI / 180), sl = Math.sin(lon * Math.PI / 180);
          circles.push(t => {
            const x3 = Math.cos(t) * r3;
            return [Math.sin(t) * r3 * cl, Math.sin(t) * r3 * sl, x3];
          });
        }
        for (const f of circles) {
          let prev = null;
          for (let i = 0; i <= SEG; i++) {
            const t  = (i / SEG) * Math.PI * 2;
            const rv = _applyRot(R, norm(f(t)));
            const s  = _project3(rv, cx, cy, scale);
            if (prev) {
              ctx.globalAlpha = (rv[1] + prev[2]) / 2 > 0 ? 0.06 : 0.22;
              ctx.strokeStyle = col;
              ctx.beginPath(); ctx.moveTo(prev[0], prev[1]); ctx.lineTo(s[0], s[1]); ctx.stroke();
            }
            prev = [s[0], s[1], rv[1]];
          }
        }
      }
      ctx.restore();
    }

    if (geom === 'surface' && faces.length > 0 && !gpuActive) {
      // An image texture replaces the Z colormap when one is attached AND
      // decoded; until the bitmap loads (or if it fails) the colormap path
      // below renders unchanged.  Already resolved above, because the GPU
      // decision depends on it.
      const uv  = p._3dUV;
      const tex = surfTex;

      // Compute per-face mean depth and mean z for colour
      const faceData = faces.map(f => {
        const d = (proj[f[0]].d + proj[f[1]].d + proj[f[2]].d) / 3;
        const zMean = (zVals[f[0]] + zVals[f[1]] + zVals[f[2]]) / 3;
        return { f, d, zMean };
      });
      // Painter's algorithm: draw back-to-front
      faceData.sort((a, b) => b.d - a.d);

      if (tex) {
        const texA  = st.texture_alpha == null ? 1 : st.texture_alpha;
        const shade = !!st.texture_shade;
        const cull  = !!st.texture_cull;
        const tw = tex.tw, th = tex.th;

        // A translucent surface has to be built opaque on a scratch canvas and
        // composited ONCE, because the triangles deliberately overlap (see the
        // seam note below): drawing them at globalAlpha < 1 straight onto the
        // panel would double-composite every overlap and etch the mesh into
        // the surface as a scaly grid.
        let dctx = ctx, off = null;
        if (texA < 1) {
          off = (p._3dTexOff ||= new OffscreenCanvas(1, 1));
          if (off.width !== ctx.canvas.width || off.height !== ctx.canvas.height) {
            off.width  = ctx.canvas.width;
            off.height = ctx.canvas.height;
          }
          dctx = off.getContext('2d');
          dctx.setTransform(1, 0, 0, 1, 0, 0);
          dctx.clearRect(0, 0, off.width, off.height);
          dctx.setTransform(ctx.getTransform());   // inherit the DPR scale
        }
        const passA = off ? 1 : texA;              // alpha applied at composite

        dctx.save();
        dctx.imageSmoothingEnabled = true;
        dctx.imageSmoothingQuality = 'high';
        for (const { f } of faceData) {
          const i0 = f[0], i1 = f[1], i2 = f[2];
          const [x0, y0] = proj[i0].s;
          const [x1, y1] = proj[i1].s;
          const [x2, y2] = proj[i2].s;

          // View-space edge vectors, recovered from the screen position and
          // depth (all three components carry the same `scale` factor, which
          // cancels out of a normal direction).  The mesh centre is the
          // origin here: `norm` maps the data-bounds midpoint to (0,0,0).
          const ax3 = x0 - cx, ay3 = proj[i0].d * scale, az3 = cy - y0;
          const e1x = (x1 - cx) - ax3, e1y = proj[i1].d * scale - ay3, e1z = (cy - y1) - az3;
          const e2x = (x2 - cx) - ax3, e2y = proj[i2].d * scale - ay3, e2z = (cy - y2) - az3;
          let nx = e1y * e2z - e1z * e2y;
          let ny = e1z * e2x - e1x * e2z;
          let nz = e1x * e2y - e1y * e2x;
          const nLen = Math.hypot(nx, ny, nz);
          if (!(nLen > 0)) continue;            // degenerate (pole) triangle
          nx /= nLen; ny /= nLen; nz /= nLen;

          if (cull) {
            // Orient the normal outward per face using the vector from the
            // mesh centre to the face centroid — no dependence on the
            // triangulation's winding, and exact for any star-shaped closed
            // surface (sphere, ellipsoid, blob).  Skip it when it points
            // away from the camera, which sits at -y.
            const gx3 = ax3 + (e1x + e2x) / 3;
            const gy3 = ay3 + (e1y + e2y) / 3;
            const gz3 = az3 + (e1z + e2z) / 3;
            const s = (nx * gx3 + ny * gy3 + nz * gz3) >= 0 ? 1 : -1;
            if (s * ny > 0) continue;
          }

          // Lambert against a camera-facing normal (flip when it points into
          // the screen).  Orienting by the camera rather than by triangle
          // winding makes the shading independent of how the grid was
          // generated, while still keeping the light's upper-left bias that
          // an unsigned |n·L| would wash out.
          let bright = 1;
          if (shade) {
            const o = ny > 0 ? -1 : 1;
            const lam = o * (nx * _TEX_LIGHT[0] + ny * _TEX_LIGHT[1]
                             + nz * _TEX_LIGHT[2]);
            bright = 0.35 + 0.65 * (lam > 0 ? lam : 0);
          }

          // Grow the triangle before clipping.  Adjacent triangles each cover
          // about half the pixels along their shared edge, and source-over of
          // two half-covered fills leaves a hairline of background showing —
          // a mesh etched over the whole surface.  Overlapping them paints
          // those pixels fully; the overlap is harmless because the nearer
          // triangle simply wins and everything inside is drawn opaque.
          //
          // The growth must offset the three EDGES, not push the vertices
          // away from the centroid: for the sliver triangles a quad-split
          // grid produces near a sphere's limb, the centroid lies almost on
          // the long edges, so a vertex nudge moves them barely at all.
          // Each vertex therefore travels along its miter direction,
          // t·(nA + nB)/(1 + nA·nB) for unit outward edge normals — clamped
          // at a very sharp corner, where the exact miter runs away.
          const gx = (x0 + x1 + x2) / 3, gy = (y0 + y1 + y2) / 3;
          let n0x = y1 - y0, n0y = x0 - x1;    // outward normals, edge i → i+1
          let n1x = y2 - y1, n1y = x1 - x2;
          let n2x = y0 - y2, n2y = x2 - x0;
          const l0 = Math.hypot(n0x, n0y) || 1, l1 = Math.hypot(n1x, n1y) || 1,
                l2 = Math.hypot(n2x, n2y) || 1;
          n0x /= l0; n0y /= l0; n1x /= l1; n1y /= l1; n2x /= l2; n2y /= l2;
          if (n0x * ((x0 + x1) / 2 - gx) + n0y * ((y0 + y1) / 2 - gy) < 0) {
            n0x = -n0x; n0y = -n0y; n1x = -n1x; n1y = -n1y; n2x = -n2x; n2y = -n2y;
          }
          const m01 = _miter(n0x + n1x, n0y + n1y, 1 + n0x*n1x + n0y*n1y);
          const m12 = _miter(n1x + n2x, n1y + n2y, 1 + n1x*n2x + n1y*n2y);
          const m20 = _miter(n2x + n0x, n2y + n0y, 1 + n2x*n0x + n2y*n0y);
          const ex0 = x0 + (n2x + n0x) * m20, ey0 = y0 + (n2y + n0y) * m20;
          const ex1 = x1 + (n0x + n1x) * m01, ey1 = y1 + (n0y + n1y) * m01;
          const ex2 = x2 + (n1x + n2x) * m12, ey2 = y2 + (n1y + n2y) * m12;

          // Texture coordinates in texel units.  A degenerate UV triangle has
          // no affine map onto the screen; skip it (it covers no texels).
          const u0 = uv[i0*2] * tw, v0 = uv[i0*2+1] * th;
          const u1 = uv[i1*2] * tw, v1 = uv[i1*2+1] * th;
          const u2 = uv[i2*2] * tw, v2 = uv[i2*2+1] * th;
          const den = (u1 - u0) * (v2 - v0) - (u2 - u0) * (v1 - v0);
          if (Math.abs(den) < 1e-9) continue;

          // Affine map taking (u, v) texel space onto the screen triangle.
          const a = ((x1-x0)*(v2-v0) - (x2-x0)*(v1-v0)) / den;
          const b = ((y1-y0)*(v2-v0) - (y2-y0)*(v1-v0)) / den;
          const c = ((x2-x0)*(u1-u0) - (x1-x0)*(u2-u0)) / den;
          const d = ((y2-y0)*(u1-u0) - (y1-y0)*(u2-u0)) / den;

          dctx.save();
          dctx.beginPath();
          dctx.moveTo(ex0, ey0); dctx.lineTo(ex1, ey1); dctx.lineTo(ex2, ey2);
          dctx.closePath();
          dctx.clip();
          if (shade) {
            // Diffuse falloff as an opaque black base the texture is drawn
            // over at `bright` — modulating this way keeps the seam overlap
            // free of the double-darkened grid a translucent second pass
            // would leave.
            dctx.globalAlpha = passA;
            dctx.fillStyle = '#000';
            dctx.fill();
          }
          dctx.globalAlpha = passA * bright;
          // transform(), not setTransform(): the panel's device-pixel-ratio
          // scale is already on the context and must survive.
          dctx.transform(a, b, c, d, x0 - a*u0 - c*v0, y0 - b*u0 - d*v0);
          dctx.drawImage(tex.img, 0, 0);
          dctx.restore();
        }
        dctx.restore();

        if (off) {
          ctx.save();
          ctx.setTransform(1, 0, 0, 1, 0, 0);   // off is already device-sized
          ctx.globalAlpha = texA;
          ctx.drawImage(off, 0, 0);
          ctx.restore();
        }

      } else {
        for (const { f, zMean } of faceData) {
          const t  = (zMean - zMin) / zRange;
          const fc = _colourFromLut(lut, t);
          const [ax2, ay2] = proj[f[0]].s;
          const [bx,  by ] = proj[f[1]].s;
          const [ccx2,ccy2] = proj[f[2]].s;
          ctx.beginPath();
          ctx.moveTo(ax2, ay2); ctx.lineTo(bx, by); ctx.lineTo(ccx2, ccy2);
          ctx.closePath();
          ctx.fillStyle = fc;
          ctx.fill();
          ctx.strokeStyle = 'rgba(0,0,0,0.12)';
          ctx.lineWidth = 0.4;
          ctx.stroke();
        }
      }

    } else if (geom === 'scatter' && !gpuActive) {
      // Optional per-point colours: b64-encoded uint8 RGB triplets
      const pcKey = st.point_colors_b64 || '';
      if (p._3dPColKey !== pcKey) {
        p._3dPColKey = pcKey;
        p._3dPColUniq = null;
        if (pcKey) {
          const bin = atob(pcKey);
          const buf = new Uint8Array(bin.length);
          for (let i = 0; i < bin.length; i++) buf[i] = bin.charCodeAt(i);
          p._3dPCols = buf;
        } else { p._3dPCols = null; }
      }
      const pCols = p._3dPCols;
      // Sort back-to-front so nearer points draw on top
      const order = proj.map((p2, i) => ({ i, d: p2.d })).sort((a, b) => b.d - a.d);
      ctx.save();
      for (const { i } of order) {
        const [sx, sy] = proj[i].s;
        // Dim far-side points when a reference sphere is shown (depth cue)
        ctx.globalAlpha = (sphereOn && proj[i].d > 0) ? 0.25 : 1.0;
        ctx.beginPath();
        ctx.arc(sx, sy, ptSize, 0, Math.PI * 2);
        ctx.fillStyle = pCols
          ? `rgb(${pCols[i*3]},${pCols[i*3+1]},${pCols[i*3+2]})`
          : color;
        ctx.fill();
      }
      ctx.restore();

    } else if (geom === 'voxels' && !gpuActive) {
      // Shaded translucent cubes at the vertex centres.  Voxels lying on a
      // plane widget's slice render at voxel_slice_alpha (more opaque).
      const pcKey = st.point_colors_b64 || '';
      if (p._3dPColKey !== pcKey) {
        p._3dPColKey = pcKey;
        p._3dPColUniq = null;
        if (pcKey) {
          const bin = atob(pcKey);
          const buf = new Uint8Array(bin.length);
          for (let i = 0; i < bin.length; i++) buf[i] = bin.charCodeAt(i);
          p._3dPCols = buf;
        } else { p._3dPCols = null; }
      }
      const pCols  = p._3dPCols;
      const vsz    = st.voxel_size || 1;
      const h      = vsz / 2;
      const baseA  = st.voxel_alpha != null ? st.voxel_alpha : 0.3;
      const sliceA = st.voxel_slice_alpha != null ? st.voxel_slice_alpha : 0.95;
      const planes = (st.overlay_widgets || []).filter(
        w => w.type === 'plane' && w.visible !== false);
      const AXI = { x: 0, y: 1, z: 2 };

      // Orthographic projection + affine normalisation ⇒ the screen offset
      // of a fixed data-space offset is constant, so cube-corner offsets and
      // face visibility are computed ONCE per frame (one projection/voxel).
      const s2 = 2 / maxR;
      const corners = [];
      for (let ci = 0; ci < 8; ci++) {
        const o  = [ci & 1 ? h : -h, ci & 2 ? h : -h, ci & 4 ? h : -h];
        const rv = _applyRot(R, [o[0] * s2, o[1] * s2, o[2] * s2]);
        corners.push([rv[0] * scale, -rv[2] * scale]);
      }
      // Corner bit encoding: bit0 → +x, bit1 → +y, bit2 → +z
      const FACES = [
        { a: 0, n: [ 1, 0, 0], idx: [1, 3, 7, 5] },
        { a: 0, n: [-1, 0, 0], idx: [0, 2, 6, 4] },
        { a: 1, n: [0,  1, 0], idx: [2, 3, 7, 6] },
        { a: 1, n: [0, -1, 0], idx: [0, 1, 5, 4] },
        { a: 2, n: [0, 0,  1], idx: [4, 5, 7, 6] },
        { a: 2, n: [0, 0, -1], idx: [0, 1, 3, 2] },
      ];
      const SHADE = [0.82, 0.68, 1.0];   // x / y / z faces — top brightest
      const visF = [];
      for (const f of FACES) {
        if (_applyRot(R, f.n)[1] < 0) visF.push({ idx: f.idx, shade: SHADE[f.a] });
      }

      // Volumes typically have few label colours (grains, phases), so render
      // each (colour, emphasis) cube ONCE into a sprite and blit per voxel —
      // drawImage is ~10× cheaper than three path fills.  Degenerate
      // many-colour data falls back to direct path drawing.
      if (p._3dPColUniq == null) {
        if (!pCols) { p._3dPColUniq = 1; }
        else {
          const seen = new Set();
          for (let i = 0; i < pCols.length; i += 3) {
            seen.add((pCols[i] << 16) | (pCols[i + 1] << 8) | pCols[i + 2]);
            if (seen.size > 256) break;
          }
          p._3dPColUniq = seen.size;
        }
      }
      const useSprites = p._3dPColUniq <= 256 &&
                         typeof OffscreenCanvas !== 'undefined';

      // Typed-array projection with inlined matrix math: no per-vertex
      // allocations.  Cached per (geometry, view, panel size): redraws that
      // don't move the camera — e.g. plane-widget drags — skip projection
      // and depth-sort entirely and only re-blit.
      const nV = verts.length;
      const projKey = `${p._voxGen || 0}|${az}|${el}|${zoom}|${pw}x${ph}|${vsz}`;
      if (p._voxProjKey !== projKey || p._voxProjN !== nV) {
        p._voxProjKey = projKey;
        p._voxProjN = nV;
        const SXn = new Float32Array(nV);
        const SYn = new Float32Array(nV);
        const DPn = new Float32Array(nV);
        const k2 = 2 / maxR;
        const bx0 = bnds.xmin, by0 = bnds.ymin, bz0 = bnds.zmin;
        const ox2 = xr / maxR, oy2 = yr / maxR, oz2 = zr / maxR;
        const r00 = R[0][0], r01 = R[0][1], r02 = R[0][2];
        const r10 = R[1][0], r11 = R[1][1], r12 = R[1][2];
        const r20 = R[2][0], r21 = R[2][1], r22 = R[2][2];
        for (let i = 0; i < nV; i++) {
          const v  = verts[i];
          const nx = (v[0] - bx0) * k2 - ox2;
          const ny = (v[1] - by0) * k2 - oy2;
          const nz = (v[2] - bz0) * k2 - oz2;
          SXn[i] = cx + (r00 * nx + r01 * ny + r02 * nz) * scale;
          DPn[i] = r10 * nx + r11 * ny + r12 * nz;
          SYn[i] = cy - (r20 * nx + r21 * ny + r22 * nz) * scale;
        }
        p._voxSX = SXn; p._voxSY = SYn; p._voxDP = DPn;
        p._voxOrder = Array.from({ length: nV }, (_, i) => i)
          .sort((a, b) => DPn[b] - DPn[a]);
      }
      const SXa = p._voxSX, SYa = p._voxSY;
      const order = p._voxOrder;
      ctx.save();

      if (useSprites) {
        // Sprite extent = cube bounding box at the current rotation/zoom
        let mnX = 1e9, mnY = 1e9, mxX = -1e9, mxY = -1e9;
        for (const c of corners) {
          if (c[0] < mnX) mnX = c[0]; if (c[0] > mxX) mxX = c[0];
          if (c[1] < mnY) mnY = c[1]; if (c[1] > mxY) mxY = c[1];
        }
        const sw = Math.max(2, Math.ceil(mxX - mnX) + 2);
        const sh = Math.max(2, Math.ceil(mxY - mnY) + 2);
        const ox = -mnX + 1, oy = -mnY + 1;
        const sprKey = `${az}|${el}|${zoom}|${vsz}|${pw}x${ph}`;
        if (p._voxSprKey !== sprKey) {
          p._voxSprKey = sprKey;
          p._voxSprites = new Map();
        }
        const sprites = p._voxSprites;
        const getSprite = (r0, g0, b0, stroked) => {
          const k = ((r0 << 16) | (g0 << 8) | b0) * 2 + (stroked ? 1 : 0);
          let s = sprites.get(k);
          if (s) return s;
          s = new OffscreenCanvas(sw, sh);
          const sc = s.getContext('2d');
          sc.lineWidth = 0.5;
          sc.strokeStyle = 'rgba(0,0,0,0.35)';
          for (const f of visF) {
            sc.fillStyle =
              `rgb(${(r0 * f.shade) | 0},${(g0 * f.shade) | 0},${(b0 * f.shade) | 0})`;
            sc.beginPath();
            sc.moveTo(ox + corners[f.idx[0]][0], oy + corners[f.idx[0]][1]);
            for (let k2 = 1; k2 < 4; k2++) {
              sc.lineTo(ox + corners[f.idx[k2]][0], oy + corners[f.idx[k2]][1]);
            }
            sc.closePath();
            sc.fill();
            if (stroked) sc.stroke();   // crisp edges on the selected slice
          }
          sprites.set(k, s);
          return s;
        };
        for (let oi = 0; oi < nV; oi++) {
          const i = order[oi];
          const v = verts[i];
          let emph = false;
          for (const pl of planes) {
            if (Math.abs(v[AXI[pl.axis] ?? 2] - (pl.position || 0)) <= vsz * 0.55) {
              emph = true; break;
            }
          }
          ctx.globalAlpha = emph ? sliceA : baseA;
          const r0 = pCols ? pCols[i * 3]     : 79;
          const g0 = pCols ? pCols[i * 3 + 1] : 195;
          const b0 = pCols ? pCols[i * 3 + 2] : 247;
          // Integer-snapped blit: subpixel drawImage triggers resampling,
          // which dominates frame time in software rasterisers.
          ctx.drawImage(getSprite(r0, g0, b0, emph),
                        (SXa[i] - ox + 0.5) | 0, (SYa[i] - oy + 0.5) | 0);
        }
      } else {
        // Direct path drawing (many unique colours / no OffscreenCanvas)
        ctx.lineWidth = 0.5;
        ctx.strokeStyle = 'rgba(0,0,0,0.35)';
        for (let oi = 0; oi < nV; oi++) {
          const i = order[oi];
          const vx2 = SXa[i], vy2 = SYa[i];
          const v = verts[i];
          let emph = false;
          for (const pl of planes) {
            if (Math.abs(v[AXI[pl.axis] ?? 2] - (pl.position || 0)) <= vsz * 0.55) {
              emph = true; break;
            }
          }
          ctx.globalAlpha = emph ? sliceA : baseA;
          const r0 = pCols ? pCols[i * 3]     : 79;
          const g0 = pCols ? pCols[i * 3 + 1] : 195;
          const b0 = pCols ? pCols[i * 3 + 2] : 247;
          for (const f of visF) {
            ctx.fillStyle =
              `rgb(${(r0 * f.shade) | 0},${(g0 * f.shade) | 0},${(b0 * f.shade) | 0})`;
            ctx.beginPath();
            ctx.moveTo(vx2 + corners[f.idx[0]][0], vy2 + corners[f.idx[0]][1]);
            for (let k = 1; k < 4; k++) {
              ctx.lineTo(vx2 + corners[f.idx[k]][0], vy2 + corners[f.idx[k]][1]);
            }
            ctx.closePath();
            ctx.fill();
            if (emph) ctx.stroke();
          }
        }
      }
      ctx.restore();

    } else if (geom === 'line') {
      ctx.beginPath();
      ctx.strokeStyle = color;
      ctx.lineWidth   = lw;
      ctx.lineJoin    = 'round';
      for (let i = 0; i < proj.length; i++) {
        const [sx, sy] = proj[i].s;
        if (i === 0) ctx.moveTo(sx, sy); else ctx.lineTo(sx, sy);
      }
      ctx.stroke();
      // Draw point markers at each vertex
      ctx.fillStyle = color;
      for (const { s } of proj) {
        ctx.beginPath(); ctx.arc(s[0], s[1], lw + 1, 0, Math.PI * 2); ctx.fill();
      }
    }

    // ── Plane widgets: translucent draggable slice selectors ──────────────
    // Drawn over the geometry; screen-space quads + the axis screen
    // direction are cached on the panel for mousedown hit-testing and drag.
    p._3dPlanes = [];
    const planeWs = (st.overlay_widgets || []).filter(
      w => w.type === 'plane' && w.visible !== false);
    if (planeWs.length) {
      const AXI = { x: 0, y: 1, z: 2 };
      const lo = [bnds.xmin, bnds.ymin, bnds.zmin];
      const hi = [bnds.xmax, bnds.ymax, bnds.zmax];
      ctx.save();
      for (const w of planeWs) {
        const a   = AXI[w.axis] ?? 2;
        const u   = (a + 1) % 3, vA = (a + 2) % 3;
        const pos = Math.max(lo[a], Math.min(hi[a], w.position || 0));
        const mk  = (uu, vv) => {
          const c = [0, 0, 0]; c[a] = pos; c[u] = uu; c[vA] = vv; return c;
        };
        const cs  = [mk(lo[u], lo[vA]), mk(hi[u], lo[vA]),
                     mk(hi[u], hi[vA]), mk(lo[u], hi[vA])];
        const scr = cs.map(c => _project3(_applyRot(R, norm(c)), cx, cy, scale));
        // Screen direction of +1 data unit along the plane's axis (for drag)
        const c0 = [0, 0, 0];
        c0[a] = pos; c0[u] = (lo[u] + hi[u]) / 2; c0[vA] = (lo[vA] + hi[vA]) / 2;
        const c1 = c0.slice(); c1[a] = pos + 1;
        const s0 = _project3(_applyRot(R, norm(c0)), cx, cy, scale);
        const s1 = _project3(_applyRot(R, norm(c1)), cx, cy, scale);
        const col = w.color || '#00e5ff';
        const al  = w.alpha != null ? w.alpha : 0.12;
        ctx.globalAlpha = al;
        ctx.fillStyle = col;
        ctx.beginPath();
        ctx.moveTo(scr[0][0], scr[0][1]);
        for (let k = 1; k < 4; k++) ctx.lineTo(scr[k][0], scr[k][1]);
        ctx.closePath(); ctx.fill();
        ctx.globalAlpha = Math.min(1, al * 5);
        ctx.lineWidth = 1.5; ctx.strokeStyle = col; ctx.stroke();
        p._3dPlanes.push({ id: w.id, corners: scr,
                           dir: [s1[0] - s0[0], s1[1] - s0[1]],
                           lo: lo[a], hi: hi[a] });
      }
      ctx.restore();
    }

    // ── Draw axes ────────────────────────────────────────────────────────────
    // set_axis_off() hides the axis lines, labels, and ticks — worth having on
    // a 3-D panel whose geometry IS the subject (a textured globe reads badly
    // with three dashed lines drawn through it).
    if (st.axis_visible !== false) {
      const axisVerts = [
        [-1,0,0],[1,0,0],[0,-1,0],[0,1,0],[0,0,-1],[0,0,1]
      ];
      const ap = axisVerts.map(v => _project3(_applyRot(R, v), cx, cy, scale));

      const axDefs = [
        { i0:0, i1:1, label: st.x_label||'x', col:'#e06c75', size: st.x_label_size||11 },
        { i0:2, i1:3, label: st.y_label||'y', col:'#98c379', size: st.y_label_size||11 },
        { i0:4, i1:5, label: st.z_label||'z', col:'#61afef', size: st.z_label_size||11 },
      ];
      for (const { i0, i1, label, col, size } of axDefs) {
        ctx.beginPath();
        ctx.moveTo(ap[i0][0], ap[i0][1]);
        ctx.lineTo(ap[i1][0], ap[i1][1]);
        ctx.strokeStyle = col;
        ctx.lineWidth   = 1.5;
        ctx.setLineDash([4, 3]);
        ctx.stroke();
        ctx.setLineDash([]);
        // Positive-end label
        ctx.fillStyle   = col;
        ctx.textBaseline = 'middle';
        _drawTex(ctx, label, ap[i1][0], ap[i1][1], size,
                 { align: 'center', weight: 'bold' });
      }

      // ── Tick marks on each axis (5 evenly spaced) ─────────────────────────
      ctx.font = '9px sans-serif';
      ctx.fillStyle = theme.tickText;
      const NTICK = 5;
      const axisData = [
        { lo: bnds.xmin, hi: bnds.xmax, baseN: [0,0,0], dir: [1/maxR*2,0,0] },
        { lo: bnds.ymin, hi: bnds.ymax, baseN: [0,0,0], dir: [0,1/maxR*2,0] },
        { lo: bnds.zmin, hi: bnds.zmax, baseN: [0,0,0], dir: [0,0,1/maxR*2] },
      ];
      const axisColours = ['#e06c75','#98c379','#61afef'];
      for (let ai = 0; ai < 3; ai++) {
        const { lo, hi } = axisData[ai];
        const range = hi - lo || 1;
        const step  = findNice(range / NTICK);
        ctx.fillStyle   = axisColours[ai];
        ctx.strokeStyle = axisColours[ai];
        ctx.lineWidth   = 0.8;
        for (let tv = Math.ceil(lo / step) * step; tv <= hi + step * 0.01; tv += step) {
          const t = (tv - lo) / range; // 0..1
          // Normalised position on the axis
          let nv;
          if (ai === 0) nv = [2*t*xr/maxR - xr/maxR, -yr/maxR, -zr/maxR];
          else if(ai===1) nv = [-xr/maxR, 2*t*yr/maxR - yr/maxR, -zr/maxR];
          else            nv = [-xr/maxR, -yr/maxR, 2*t*zr/maxR - zr/maxR];
          const [tx, ty] = _project3(_applyRot(R, nv), cx, cy, scale);
          // Small tick cross
          ctx.beginPath();
          ctx.arc(tx, ty, 1.5, 0, Math.PI * 2);
          ctx.fill();
          // Label (only every other tick to avoid crowding)
          ctx.textAlign = 'left';
          ctx.textBaseline = 'bottom';
          ctx.fillText(fmtVal(tv), tx + 3, ty - 1);
        }
      }
    }

    // ── Highlight point (drawn last, always on top) ───────────────────────
    // st.highlight = {x, y, z, color, size} in data coordinates.  A filled
    // dot with a contrasting ring; semi-transparent when on the far side of
    // the data (depth cue).
    const hl = st.highlight;
    if (hl && hl.x != null) {
      const rv = _applyRot(R, norm([hl.x, hl.y, hl.z]));
      const [hx, hy] = _project3(rv, cx, cy, scale);
      const far = rv[1] > 0;
      const sz  = hl.size || 7;
      ctx.save();
      ctx.globalAlpha = far ? 0.45 : 1.0;
      ctx.beginPath();
      ctx.arc(hx, hy, sz, 0, Math.PI * 2);
      ctx.fillStyle = hl.color || '#ff1744';
      ctx.fill();
      ctx.lineWidth = 2;
      ctx.strokeStyle = theme.dark ? '#ffffff' : '#1a1a1a';
      ctx.stroke();
      // Outer ring for visibility against same-coloured points
      ctx.beginPath();
      ctx.arc(hx, hy, sz + 3.5, 0, Math.PI * 2);
      ctx.lineWidth = 1.2;
      ctx.strokeStyle = hl.color || '#ff1744';
      ctx.stroke();
      ctx.restore();
    }
  }

  // ── event emission helper (module-scope: accessible to all attach fns) ──
  // eventType: any pointer_* or key_* event type string
  function _emitEvent(panelId, eventType, widgetId, extraData) {
    const payload = Object.assign(
      { source: 'js', panel_id: panelId, event_type: eventType,
        widget_id: widgetId || null },
      extraData || {}
    );
    model.set('event_json', JSON.stringify(payload));
    model.save_changes();
  }

  // Debounced 'view_changed' event: fires to Python after zoom/pan SETTLES (~90 ms
  // idle) with the current view rect, so a viewport-LOD consumer can fetch a hi-res
  // detail tile for exactly the visible region (see Plot2D.set_detail). Debounced so
  // a fast wheel/drag doesn't flood Python — only the final resting view is sent.
  const _viewChangeTimers = {};
  function _emitViewChanged(p, immediate) {
    const st = p.state; if (!st) return;
    // An export transiently rewrites zoom/center (source:'full'/'native') and
    // redraws; draw2d's one-shot initial emit must not report that as a real
    // view change, or a tiled plot would fetch a detail tile for a view the
    // user never navigated to.
    if (_exporting) return;
    const send = () => {
      _viewChangeTimers[p.id] = null;
      const s = p.state; if (!s) return;
      const dpr = window.devicePixelRatio || 1;
      _emitEvent(p.id, 'view_changed', null, {
        zoom: s.zoom, center_x: s.center_x, center_y: s.center_y,
        image_width: s.image_width, image_height: s.image_height,
        // Panel device px → the tile consumer sizes the tile to what fits on screen.
        display_width: Math.round((p.imgW || 0) * dpr),
        display_height: Math.round((p.imgH || 0) * dpr),
      });
    };
    if (_viewChangeTimers[p.id]) clearTimeout(_viewChangeTimers[p.id]);
    if (immediate) { send(); return; }
    _viewChangeTimers[p.id] = setTimeout(send, 90);
  }

  function _modifiers(e) {
    const mods = [];
    if (e.ctrlKey)  mods.push("ctrl");
    if (e.shiftKey) mods.push("shift");
    if (e.altKey)   mods.push("alt");
    if (e.metaKey)  mods.push("meta");
    return mods;
  }

  function _pointerFields(e) {
    return {
      time_stamp: performance.now() / 1000,
      modifiers:  _modifiers(e),
      button:     null,
      buttons:    e.buttons ?? 0,
    };
  }

  function _attachEvents3d(p) {
    const { overlayCanvas } = p;
    let dragStart = null;
    let planeDrag = null;   // active plane-widget drag, or null
    const _scheduleCommit = _makeCommitter(() => model.save_changes());
    const settled = _makeSettledScheduler(p);

    // Write our (already-applied) interaction state without triggering the
    // panel listener echo — see the _selfWrite guard in _createPanelDOM.
    function _writeState() {
      p._selfWrite = true;
      try { model.set(`panel_${p.id}_json`, _viewStateJson(p)); }
      finally { p._selfWrite = false; }
    }

    // Point-in-quad test against the screen-space planes cached by draw3d.
    function _hitPlane(mx, my) {
      const list = p._3dPlanes || [];
      for (let i = list.length - 1; i >= 0; i--) {
        const c = list[i].corners;
        let inside = false;
        for (let k = 0, j = 3; k < 4; j = k++) {
          if (((c[k][1] > my) !== (c[j][1] > my)) &&
              (mx < (c[j][0] - c[k][0]) * (my - c[k][1]) /
                    (c[j][1] - c[k][1]) + c[k][0])) {
            inside = !inside;
          }
        }
        if (inside) return list[i];
      }
      return null;
    }

    overlayCanvas.addEventListener('mousedown', (e) => {
      if (e.button !== 0) return;
      const {mx:_d3mx, my:_d3my} = _clientPos(e, overlayCanvas, p.pw, p.ph);
      // Plane-widget drag takes precedence over orbiting.
      // Cache only the widget ID — p.state is replaced on every model echo,
      // so object references into overlay_widgets go stale mid-drag.
      const hit = _hitPlane(_d3mx, _d3my);
      if (hit) {
        const ws = (p.state.overlay_widgets || []).find(w => w.id === hit.id);
        if (ws) {
          planeDrag = { id: hit.id, dir: hit.dir, lo: hit.lo, hi: hit.hi,
                        mx: _d3mx, my: _d3my, start: ws.position || 0 };
          overlayCanvas.style.cursor = 'move';
          return;
        }
      }
      dragStart = { mx: _d3mx, my: _d3my,
                    az: p.state.azimuth, el: p.state.elevation };
      overlayCanvas.style.cursor = 'grabbing';
      // Do NOT call e.preventDefault() — suppresses click → dblclick cascade.
    });
    document.addEventListener('mousemove', (e) => {
      if (planeDrag) {
        const {mx, my} = _clientPos(e, overlayCanvas, p.pw, p.ph);
        const d   = planeDrag.dir;
        const len2 = d[0] * d[0] + d[1] * d[1] || 1;
        const delta = ((mx - planeDrag.mx) * d[0] + (my - planeDrag.my) * d[1]) / len2;
        // Re-resolve the widget in the CURRENT state (replaced on model echo)
        const ws = (p.state.overlay_widgets || []).find(w => w.id === planeDrag.id);
        if (ws) {
          ws.position = Math.max(planeDrag.lo,
            Math.min(planeDrag.hi, planeDrag.start + delta));
          draw3d(p);
          // Write fresh state BEFORE emitting so the listener echo re-parses
          // the updated widgets (mirrors the orbit-drag pattern).
          _writeState();
          _emitEvent(p.id, 'pointer_move', planeDrag.id,
            { axis: ws.axis, position: ws.position, ..._pointerFields(e) });
        }
        e.preventDefault();
        return;
      }
      if (!dragStart) return;
      const {mx:_d3mx2, my:_d3my2} = _clientPos(e, overlayCanvas, p.pw, p.ph);
      const dx = _d3mx2 - dragStart.mx;
      const dy = _d3my2 - dragStart.my;
      // DIRECT MANIPULATION: the surface under the cursor follows the cursor,
      // the way a globe does.  Both signs are inverted relative to the camera
      // angles because azimuth/elevation move the CAMERA: a feature's screen x
      // is `cx + scale*cos(az - θ)`, so raising azimuth sweeps the surface
      // LEFT, and raising elevation lifts the camera to show more of the top.
      // Adding dx (and subtracting dy) therefore made a rightward drag push
      // the surface left — it felt like grabbing the far side of the sphere.
      p.state.azimuth   = dragStart.az - dx * 0.5;
      p.state.elevation = Math.max(-89, Math.min(89, dragStart.el + dy * 0.5));
      draw3d(p);
      _writeState();
      _emitEvent(p.id, 'pointer_move', null,
        { azimuth: p.state.azimuth, elevation: p.state.elevation, zoom: p.state.zoom,
          ..._pointerFields(e) });
      e.preventDefault();
    });
    document.addEventListener('mouseup', (e) => {
      settled.clear();
      if (planeDrag) {
        const wid = planeDrag.id;
        planeDrag = null;
        overlayCanvas.style.cursor = 'grab';
        _writeState();
        const ws = (p.state.overlay_widgets || []).find(w => w.id === wid);
        _emitEvent(p.id, 'pointer_up', wid,
          { axis: ws ? ws.axis : null, position: ws ? ws.position : null,
            ..._pointerFields(e), button: e.button });
        _scheduleCommit();
        return;
      }
      if (!dragStart) return;
      dragStart = null;
      overlayCanvas.style.cursor = 'grab';
      _writeState();
      _emitEvent(p.id, 'pointer_up', null,
        { azimuth: p.state.azimuth, elevation: p.state.elevation, zoom: p.state.zoom,
          ..._pointerFields(e), button: e.button });
      _scheduleCommit();
    });

    overlayCanvas.addEventListener('wheel', (e) => {
      e.preventDefault();
      p.state.zoom = Math.max(0.1, Math.min(10, p.state.zoom * (e.deltaY > 0 ? 0.9 : 1.1)));
      draw3d(p);
      _writeState();
      _emitEvent(p.id, 'wheel', null, {
        time_stamp: performance.now() / 1000,
        modifiers: _modifiers(e),
        x: p.mouseX ?? 0, y: p.mouseY ?? 0,
        dx: e.deltaX, dy: e.deltaY,
      });
      _emitEvent(p.id, 'pointer_move', null,
        { azimuth: p.state.azimuth, elevation: p.state.elevation, zoom: p.state.zoom,
          ..._pointerFields(e) });
      _scheduleCommit();
    }, { passive: false });

    overlayCanvas.addEventListener('mousemove', (e) => {
      const {mx, my} = _clientPos(e, overlayCanvas, p.pw, p.ph);
      p.mouseX = mx;
      p.mouseY = my;
      settled.arm(mx, my, e);
    });

    // Keyboard shortcuts
    // Built-in: r=reset view. All keys are forwarded to Python unconditionally.
    overlayCanvas.addEventListener('keydown', (e) => {
      const st = p.state; if (!st) return;
      _emitEvent(p.id, 'key_down', null, {
        time_stamp: performance.now() / 1000,
        modifiers: _modifiers(e),
        key: e.key,
        last_widget_id: p.lastWidgetId || null,
        x: p.mouseX ?? 0, y: p.mouseY ?? 0,
      });
      // Modified keys belong to the host (Ctrl+C copy, Cmd+S save); the key_down
      // emit above already forwarded them to Python.
      if (e.ctrlKey || e.metaKey || e.altKey) return;
      if (e.key.toLowerCase() === 'r') {
        p.state.azimuth = -60; p.state.elevation = 30; p.state.zoom = 1;
        draw3d(p);
        _writeState();
        model.save_changes();
        e.stopPropagation(); e.preventDefault();
      }
    });
    overlayCanvas.tabIndex = 0;
    overlayCanvas.style.outline = 'none';
    overlayCanvas.style.cursor  = 'grab';
    overlayCanvas.addEventListener('mouseenter', (e) => {
      overlayCanvas.focus();
      _emitEvent(p.id, 'pointer_enter', null, {..._pointerFields(e), x: e.offsetX, y: e.offsetY});
    });
    overlayCanvas.addEventListener('mouseleave', (e) => {
      settled.clear();
      _emitEvent(p.id, 'pointer_leave', null, {..._pointerFields(e), x: e.offsetX, y: e.offsetY});
    });
    overlayCanvas.addEventListener('keyup', (e) => {
      _emitEvent(p.id, 'key_up', null, {
        time_stamp: performance.now() / 1000,
        modifiers: _modifiers(e),
        key: e.key,
        x: p.mouseX ?? 0, y: p.mouseY ?? 0,
      });
    });
    overlayCanvas.addEventListener('dblclick', (e) => {
      const {mx, my} = _clientPos(e, overlayCanvas, p.pw, p.ph);
      _emitEvent(p.id, 'double_click', null, {..._pointerFields(e), button: e.button, x: mx, y: my});
    });
  }

  // ── 1D drawing ───────────────────────────────────────────────────────────

  // Panel rect for a 1-D / coordinate (PlotXY) axis. When state.aspect==='equal'
  // we apply matplotlib's apply_aspect(): shrink + centre the box so one data
  // unit spans equal pixels on x and y (an IPF triangle etc. must not stretch).
  // Baked in here so EVERY consumer (draw1d / markers / overlay / hit-test) uses
  // the identical box — matplotlib's transData derives from the adjusted axes box.
  // Extra right-hand gutter reserved for a secondary (twinx) y-axis so its
  // tick labels and rotated units clear the panel edge.
  // Right gutter for a twinx axis: tick numbers (fmtVal caps them at ~6 chars,
  // e.g. "1.0e+6") plus the rotated units label.  ~58px clears both.
  const PAD_R_TWIN=58;
  function _plotRect1d(p){
    const pw=p.pw, ph=p.ph, st=p.state;
    const padR=(st && st.right_axis) ? PAD_R_TWIN : PAD_R;
    const r={x:PAD_L,y:PAD_T,w:Math.max(1,pw-PAD_L-padR),h:Math.max(1,ph-PAD_T-PAD_B)};
    if(!st || st.aspect!=='equal') return r;
    const xArr=p._1dXArr || (st.x_axis_b64 ? _decodeF64(st.x_axis_b64) : (st.x_axis||[]));
    const x0=st.view_x0||0, x1=st.view_x1||1;
    let xspan=1;
    if(xArr && xArr.length>=2) xspan=Math.abs(_axisFracToVal(xArr,x1)-_axisFracToVal(xArr,x0))||1;
    let dMin=st.data_min, dMax=st.data_max;
    if(st.y_range && st.y_range.length===2){ dMin=st.y_range[0]; dMax=st.y_range[1]; }
    const yspan=Math.abs((dMax!=null?dMax:1)-(dMin!=null?dMin:0))||1;
    const s=Math.min(r.w/xspan, r.h/yspan);
    const nw=s*xspan, nh=s*yspan;
    return {x:r.x+(r.w-nw)/2, y:r.y+(r.h-nh)/2, w:nw, h:nh};
  }

  // _xToFrac1d / _fracToX1d are identical to _axisValToFrac / _axisFracToVal
  // (defined at the top of this file) — callers use those shared functions.
  function _fracToPx1d(frac,x0,x1,r){return r.x+((frac-x0)/((x1-x0)||1))*r.w;}
  function _valToPy1d(val,dMin,dMax,r){return r.y+r.h-((val-dMin)/((dMax-dMin)||1))*r.h;}

  function draw1d(p) {
    const st=p.state; if(!st) return;
    _recordFrame(p);
    const {pw,ph,plotCtx:ctx} = p;
    const r=_plotRect1d(p);

    // ── decode + cache b64 arrays (keyed by b64 string; free on re-render) ──
    const xKey = st.x_axis_b64 || '';
    const dKey = st.data_b64   || '';
    if (p._1dXKey !== xKey) {
      p._1dXKey  = xKey;
      p._1dXArr  = xKey ? _decodeF64(xKey) : (st.x_axis || []);
    }
    if (p._1dDKey !== dKey) {
      p._1dDKey  = dKey;
      p._1dDArr  = dKey ? _decodeF64(dKey)  : (st.data   || []);
    }
    const xArr = p._1dXArr;   // Float64Array (or plain array fallback)
    const yData = p._1dDArr;  // Float64Array (or plain array fallback)

    const x0=st.view_x0||0, x1=st.view_x1||1;
    let dMin=st.data_min, dMax=st.data_max;
    if (st.y_range && st.y_range.length === 2) { dMin = st.y_range[0]; dMax = st.y_range[1]; }
    // Cache the linear y bounds so the dblclick handler inverts event y → data y
    // using exactly what was drawn (for a PlotXY coordinate axis the y range is
    // y_range, not the hidden zero-curve's data_min/max).
    p._1dDMin=dMin; p._1dDMax=dMax;
    const units=st.units||'', yUnits=st.y_units||'';

    const isLog = st.yscale === 'log';
    const _logEps = 1e-300;
    const effDMin = isLog ? Math.log10(Math.max(_logEps, dMin)) : dMin;
    const effDMax = isLog ? Math.log10(Math.max(_logEps, dMax)) : dMax;
    function _toPlotY(v) {
      return _valToPy1d(isLog ? Math.log10(Math.max(_logEps, v)) : v, effDMin, effDMax, r);
    }

    // ── secondary (right-hand) y-axis scale ──
    // A twinx line maps against right_y_range (explicit) or the auto range
    // derived from the right-axis overlays.  Always linear.
    const hasRightAxis = st.right_axis === true;
    let rMin = 0, rMax = 1;
    if (hasRightAxis) {
      if (st.right_y_range && st.right_y_range.length === 2) {
        rMin = st.right_y_range[0]; rMax = st.right_y_range[1];
      } else {
        rMin = st.right_data_min != null ? st.right_data_min : 0;
        rMax = st.right_data_max != null ? st.right_data_max : 1;
      }
    }
    function _toRightY(v) { return _valToPy1d(v, rMin, rMax, r); }

    ctx.clearRect(0,0,pw,ph);
    ctx.fillStyle=theme.bg; ctx.fillRect(0,0,pw,ph);
    ctx.fillStyle=theme.bgPlot; ctx.fillRect(r.x,r.y,r.w,r.h);

    // Grid
    ctx.strokeStyle=theme.gridStroke; ctx.lineWidth=1;
    if(xArr.length>=2){
      const xVMin=_axisFracToVal(xArr,x0), xVMax=_axisFracToVal(xArr,x1);
      const xStep=findNice((xVMax-xVMin)/Math.max(2,Math.floor(r.w/70)));
      for(let v=Math.ceil(xVMin/xStep)*xStep;v<=xVMax+xStep*0.01;v+=xStep){
        const px=_fracToPx1d(_axisValToFrac(xArr,v),x0,x1,r);
        if(px<r.x||px>r.x+r.w) continue;
        ctx.beginPath();ctx.moveTo(px,r.y);ctx.lineTo(px,r.y+r.h);ctx.stroke();
      }
    }
    const yRange=(effDMax-effDMin)||1;
    const yStep=findNice(yRange/Math.max(2,Math.floor(r.h/40)));
    if(isLog){
      const lo=Math.floor(effDMin), hi=Math.ceil(effDMax);
      for(let e=lo;e<=hi;e++){
        const py=_toPlotY(Math.pow(10,e));
        if(py<r.y||py>r.y+r.h) continue;
        ctx.beginPath();ctx.moveTo(r.x,py);ctx.lineTo(r.x+r.w,py);ctx.stroke();
      }
    } else {
      for(let v=Math.ceil(dMin/yStep)*yStep;v<=dMax+yStep*0.01;v+=yStep){
        const py=_valToPy1d(v,dMin,dMax,r);
        if(py<r.y||py>r.y+r.h) continue;
        ctx.beginPath();ctx.moveTo(r.x,py);ctx.lineTo(r.x+r.w,py);ctx.stroke();
      }
    }

    // Spans
    for(const sp of (st.spans||[])){
      ctx.fillStyle=sp.color||(theme.dark?'rgba(255,255,100,0.15)':'rgba(200,160,0,0.15)');
      if(sp.axis==='x'){
        const px0=_fracToPx1d(_axisValToFrac(xArr,sp.v0),x0,x1,r);
        const px1b=_fracToPx1d(_axisValToFrac(xArr,sp.v1),x0,x1,r);
        ctx.fillRect(px0,r.y,px1b-px0,r.h);
      } else {
        const py0=_toPlotY(sp.v1), py1=_toPlotY(sp.v0);
        ctx.fillRect(r.x,py0,r.w,py1-py0);
      }
    }

    // Clip
    ctx.save(); ctx.beginPath(); ctx.rect(r.x,r.y,r.w,r.h); ctx.clip();

    // Linestyle → canvas dash pattern
    const _LINESTYLE_DASH = {
      'solid':   [],
      'dashed':  [6, 3],
      'dotted':  [2, 3],
      'dashdot': [6, 3, 2, 3],
    };

    // Draw a single marker symbol centred at (px, py) with half-size ms.
    // The caller is responsible for beginPath() before and fill()/stroke() after.
    function _drawMarkerSymbol(mctx, marker, px, py, ms) {
      switch (marker) {
        case 'o':
          mctx.arc(px, py, ms, 0, Math.PI * 2);
          break;
        case 's':
          mctx.rect(px - ms, py - ms, ms * 2, ms * 2);
          break;
        case '^':
          mctx.moveTo(px, py - ms);
          mctx.lineTo(px + ms, py + ms);
          mctx.lineTo(px - ms, py + ms);
          mctx.closePath();
          break;
        case 'v':
          mctx.moveTo(px, py + ms);
          mctx.lineTo(px + ms, py - ms);
          mctx.lineTo(px - ms, py - ms);
          mctx.closePath();
          break;
        case 'D':
          mctx.moveTo(px, py - ms);
          mctx.lineTo(px + ms, py);
          mctx.lineTo(px, py + ms);
          mctx.lineTo(px - ms, py);
          mctx.closePath();
          break;
        case '+':
          mctx.moveTo(px - ms, py); mctx.lineTo(px + ms, py);
          mctx.moveTo(px, py - ms); mctx.lineTo(px, py + ms);
          break;
        case 'x':
          mctx.moveTo(px - ms, py - ms); mctx.lineTo(px + ms, py + ms);
          mctx.moveTo(px + ms, py - ms); mctx.lineTo(px - ms, py + ms);
          break;
        default:
          mctx.arc(px, py, ms, 0, Math.PI * 2);
      }
    }

    // Stroke-only markers (no meaningful fill area)
    const _MARKER_STROKE_ONLY = new Set(['+', 'x']);

    function _drawLine(yData, lineXArr, color, lw, linestyle, alpha, marker, markersize, yMap) {
      if (!yData || !yData.length) return;
      const _yMap = yMap || _toPlotY;   // left scale by default; right lines pass _toRightY
      const n = yData.length;
      const isStepMid = linestyle === 'step-mid';
      const dash = isStepMid ? [] : (_LINESTYLE_DASH[linestyle || 'solid'] || []);
      const eff_alpha = (alpha != null && alpha < 1.0) ? alpha : 1.0;
      const ms = Math.max(1, markersize || 4);
      const doMarker = marker && marker !== 'none';
      // linestyle 'none' (or a zero width) means "markers only" — matplotlib's
      // scatter idiom.  Skip the connecting stroke but keep drawing markers.
      const doLine = linestyle !== 'none' && lw > 0;

      // Pre-compute pixel positions
      const allPx = new Array(n), allPy = new Array(n);
      for (let i = 0; i < n; i++) {
        const xFrac = lineXArr.length >= 2
          ? (lineXArr[i] - lineXArr[0]) / ((lineXArr[lineXArr.length - 1] - lineXArr[0]) || 1)
          : i / ((n - 1) || 1);
        allPx[i] = _fracToPx1d(xFrac, x0, x1, r);
        allPy[i] = _yMap(yData[i]);
      }

      ctx.save();
      if (eff_alpha < 1.0) ctx.globalAlpha = eff_alpha;

      if (doLine) {
        ctx.setLineDash(dash);
        ctx.beginPath();
        ctx.strokeStyle = color; ctx.lineWidth = lw; ctx.lineJoin = 'round';

        if (isStepMid && n >= 2) {
          ctx.moveTo(allPx[0], allPy[0]);
          for (let i = 0; i < n - 1; i++) {
            const midX = (allPx[i] + allPx[i + 1]) / 2;
            ctx.lineTo(midX, allPy[i]);
            ctx.lineTo(midX, allPy[i + 1]);
          }
          ctx.lineTo(allPx[n - 1], allPy[n - 1]);
        } else {
          for (let i = 0; i < n; i++) {
            if (i === 0) ctx.moveTo(allPx[i], allPy[i]);
            else ctx.lineTo(allPx[i], allPy[i]);
          }
        }
        ctx.stroke();
        ctx.setLineDash([]);
      }

      const pts = doMarker ? allPx.map((px, i) => [px, allPy[i]]) : null;

      // Per-point marker symbols
      if (doMarker && pts && pts.length) {
        ctx.strokeStyle = color;
        ctx.fillStyle   = color;
        ctx.lineWidth   = Math.max(1, lw * 0.8);
        const strokeOnly = _MARKER_STROKE_ONLY.has(marker);
        for (const [px, py] of pts) {
          ctx.beginPath();
          _drawMarkerSymbol(ctx, marker, px, py, ms);
          if (!strokeOnly) ctx.fill();
          ctx.stroke();
        }
      }

      ctx.restore();
    }

    // ?? not || on linewidth: an explicit 0 means "no stroke" and must not
    // fall back to the 1.5 default (see _drawLine's doLine).
    _drawLine(yData, xArr,
      st.line_color || '#4fc3f7', st.line_linewidth ?? 1.5,
      st.line_linestyle || 'solid',
      st.line_alpha != null ? st.line_alpha : 1.0,
      st.line_marker || 'none', st.line_markersize || 4);
    for (const ex of (st.extra_lines || [])) {
      const exY = ex.data_b64   ? _decodeF64(ex.data_b64)   : (ex.data   || []);
      const exX = ex.x_axis_b64 ? _decodeF64(ex.x_axis_b64) : (ex.x_axis ? ex.x_axis : xArr);
      const exMap = ex.axis === 'right' ? _toRightY : _toPlotY;
      _drawLine(exY, exX,
        ex.color || (theme.dark ? '#fff' : '#333'), ex.linewidth ?? 1.5,
        ex.linestyle || 'solid',
        ex.alpha != null ? ex.alpha : 1.0,
        ex.marker || 'none', ex.markersize || 4, exMap);
    }
    // ── hovered-line highlight: redraw on top with brightened colour + thicker stroke ──
    const _hovId = p._lineHoverId;
    if (_hovId !== undefined && _hovId !== '__none__') {
      if (_hovId === null) {
        _drawLine(yData, xArr,
          _brightenColor(st.line_color||'#4fc3f7'), (st.line_linewidth??1.5)+1,
          st.line_linestyle||'solid', st.line_alpha!=null?st.line_alpha:1.0,
          st.line_marker||'none', st.line_markersize||4);
      } else {
        for (const ex of (st.extra_lines||[])) {
          if (ex.id === _hovId) {
            const exY = ex.data_b64 ? _decodeF64(ex.data_b64) : (ex.data||[]);
            const exX = ex.x_axis_b64 ? _decodeF64(ex.x_axis_b64) : (ex.x_axis?ex.x_axis:xArr);
            const exMap = ex.axis === 'right' ? _toRightY : _toPlotY;
            _drawLine(exY, exX,
              _brightenColor(ex.color||(theme.dark?'#fff':'#333')), (ex.linewidth??1.5)+1,
              ex.linestyle||'solid', ex.alpha!=null?ex.alpha:1.0,
              ex.marker||'none', ex.markersize||4, exMap);
            break;
          }
        }
      }
    }
    ctx.restore();

    const axisVis1d=st.axis_visible!==false;
    const xTicksVis1d=st.x_ticks_visible!==false;
    const yTicksVis1d=st.y_ticks_visible!==false;

    // Axes
    ctx.strokeStyle=theme.axisStroke; ctx.lineWidth=1;
    ctx.beginPath();ctx.moveTo(r.x,r.y+r.h);ctx.lineTo(r.x+r.w,r.y+r.h);ctx.stroke();
    ctx.beginPath();ctx.moveTo(r.x,r.y);ctx.lineTo(r.x,r.y+r.h);ctx.stroke();

    if(axisVis1d&&xTicksVis1d){
      ctx.fillStyle=theme.tickText; ctx.font=(st.tick_size||10)+'px monospace';
      if(xArr.length>=2){
        const xVMin=_axisFracToVal(xArr,x0), xVMax=_axisFracToVal(xArr,x1);
        const xStep=findNice((xVMax-xVMin)/Math.max(2,Math.floor(r.w/70)));
        ctx.textAlign='center'; ctx.textBaseline='top';
        for(let v=Math.ceil(xVMin/xStep)*xStep;v<=xVMax+xStep*0.01;v+=xStep){
          const px=_fracToPx1d(_axisValToFrac(xArr,v),x0,x1,r);
          if(px<r.x||px>r.x+r.w) continue;
          ctx.strokeStyle=theme.axisStroke;ctx.beginPath();ctx.moveTo(px,r.y+r.h);ctx.lineTo(px,r.y+r.h+5);ctx.stroke();
          const xtTxt=fmtVal(v);
          const xtHw=ctx.measureText(xtTxt).width/2;
          ctx.fillStyle=theme.tickText;
          ctx.fillText(xtTxt, Math.min(Math.max(px,xtHw), pw-xtHw), r.y+r.h+7);
        }
        if(units&&units!=='px'){ctx.textBaseline='top';ctx.fillStyle=theme.unitText;_drawTex(ctx,units,r.x+r.w,r.y+r.h+24,st.x_label_size||9,{align:'right',family:'monospace'});}
      }
    }
    if(axisVis1d&&yTicksVis1d){
      ctx.font=(st.tick_size||10)+'px monospace';ctx.textAlign='right';ctx.textBaseline='middle';
      const tickRX=r.x-8;
      // Widest tick string, in both branches: the y label is placed relative
      // to it below, so it has to be measured whatever the scale.
      let maxTW=0;
      if(isLog){
        const lo=Math.floor(effDMin), hi=Math.ceil(effDMax);
        for(let e=lo;e<=hi;e++){
          // Plain-text measure of "10^{e}" over-estimates the TeX-rendered
          // width (the exponent is drawn smaller). Over-estimating is the
          // safe direction: it pushes the label further from the ticks.
          const tw=ctx.measureText('10'+e).width;
          if(tw>maxTW)maxTW=tw;
        }
        for(let e=lo;e<=hi;e++){
          const v=Math.pow(10,e);
          const py=_toPlotY(v);
          if(py<r.y||py>r.y+r.h) continue;
          ctx.strokeStyle=theme.axisStroke;ctx.beginPath();ctx.moveTo(r.x,py);ctx.lineTo(r.x-5,py);ctx.stroke();
          ctx.fillStyle=theme.tickText;_drawTex(ctx,'$10^{'+e+'}$',tickRX,py,st.tick_size||10,{align:'right',family:'monospace'});
        }
      } else {
        for(let v=Math.ceil(dMin/yStep)*yStep;v<=dMax+yStep*0.01;v+=yStep){const tw=ctx.measureText(fmtVal(v)).width;if(tw>maxTW)maxTW=tw;}
        for(let v=Math.ceil(dMin/yStep)*yStep;v<=dMax+yStep*0.01;v+=yStep){
          const py=_valToPy1d(v,dMin,dMax,r);
          if(py<r.y||py>r.y+r.h) continue;
          ctx.strokeStyle=theme.axisStroke;ctx.beginPath();ctx.moveTo(r.x,py);ctx.lineTo(r.x-5,py);ctx.stroke();
          ctx.fillStyle=theme.tickText;ctx.fillText(fmtVal(v),tickRX,py);
        }
      }
      if(yUnits){
        ctx.save();
        // Centre the rotated label in the left gutter (x = 0..r.x).
        //
        // The x used to be a fixed PAD_L*0.28 on the assumption that it
        // cleared the tick numbers whatever their width. It does not: wide
        // strings ("-5.6e-17" at the default tick size) reach back past it
        // and the label is drawn through them. So take the fixed position as
        // a *preference* and shift left when the ticks actually need the
        // room, clamped so the label stays on the canvas — half the rotated
        // glyph height is the least it can sit at.
        const ylpx1d = st.y_label_size||9;
        const halfGlyph = Math.ceil(ylpx1d*0.62)+1;
        const clearOfTicks = tickRX - maxTW - halfGlyph - 2;
        const lcx = Math.max(
          halfGlyph,
          Math.min(Math.round(PAD_L * 0.28), clearOfTicks)
        );
        ctx.translate(lcx, r.y+r.h/2); ctx.rotate(-Math.PI/2);
        ctx.textBaseline='middle';
        ctx.fillStyle=theme.unitText;
        _drawTex(ctx, yUnits, 0, 0, ylpx1d, {align:'center',family:'monospace'});
        ctx.restore();
      }
    }

    // ── secondary (right-hand) y-axis: spine, ticks, label ──
    if(hasRightAxis&&axisVis1d&&yTicksVis1d){
      const rColor=st.right_axis_color||theme.tickText;
      const rx=r.x+r.w;
      // Axis spine on the right edge of the plot rect.
      ctx.strokeStyle=rColor; ctx.lineWidth=1;
      ctx.beginPath();ctx.moveTo(rx,r.y);ctx.lineTo(rx,r.y+r.h);ctx.stroke();
      ctx.font=(st.tick_size||10)+'px monospace';ctx.textAlign='left';ctx.textBaseline='middle';
      // Iterate the ordered range so ticks render regardless of whether the
      // caller pinned set_right_ylim(lo,hi) or an inverted (hi,lo); _valToPy1d
      // still maps against the raw rMin/rMax so a deliberate flip is preserved.
      const rLo=Math.min(rMin,rMax), rHi=Math.max(rMin,rMax);
      const rRange=(rHi-rLo)||1;
      const rStep=findNice(rRange/Math.max(2,Math.floor(r.h/40)));
      let rMaxTW=0;
      for(let v=Math.ceil(rLo/rStep)*rStep;v<=rHi+rStep*0.01;v+=rStep){
        const tw=ctx.measureText(fmtVal(v)).width;if(tw>rMaxTW)rMaxTW=tw;
      }
      for(let v=Math.ceil(rLo/rStep)*rStep;v<=rHi+rStep*0.01;v+=rStep){
        const py=_valToPy1d(v,rMin,rMax,r);
        if(py<r.y||py>r.y+r.h) continue;
        ctx.strokeStyle=rColor;ctx.beginPath();ctx.moveTo(rx,py);ctx.lineTo(rx+5,py);ctx.stroke();
        ctx.fillStyle=rColor;ctx.fillText(fmtVal(v),rx+8,py);
      }
      const rUnits=st.right_y_units||'';
      if(rUnits){
        ctx.save();
        const rylpx=st.y_label_size||9;
        // Place the rotated units label just past the widest tick number, but
        // never past the panel edge — clamp keeps it on-canvas even when the
        // fixed right gutter is too narrow for very wide tick strings.
        const rcx=Math.min(pw-Math.ceil(rylpx*0.62)-1, rx+8+rMaxTW+Math.ceil(rylpx*0.9));
        ctx.translate(rcx, r.y+r.h/2); ctx.rotate(-Math.PI/2);
        ctx.textBaseline='middle';
        ctx.fillStyle=rColor;
        _drawTex(ctx, rUnits, 0, 0, rylpx, {align:'center',family:'monospace'});
        ctx.restore();
      }
    }

    // Legend
    const labels=[];
    if(st.line_label) labels.push({
      color: st.line_color||'#4fc3f7', text: st.line_label,
      linestyle: st.line_linestyle||'solid',
      marker: st.line_marker||'none', ms: st.line_markersize||4,
    });
    for(const ex of (st.extra_lines||[])) if(ex.label) labels.push({
      color: ex.color||(theme.dark?'#fff':'#333'), text: ex.label,
      linestyle: ex.linestyle||'solid',
      marker: ex.marker||'none', ms: ex.markersize||4,
    });
    p._legendRect = null; // consumed by the 1D double-click legend hit-test
    if(labels.length){
      const legFs = st.legend_fontsize||10;
      const legScale = legFs/10;
      const rowH = Math.round(legFs*1.6);
      const swatchX0 = r.x+Math.round(8*legScale), swatchX1 = r.x+Math.round(24*legScale);
      const markerX = r.x+Math.round(16*legScale), textX = r.x+Math.round(28*legScale);
      ctx.font=legFs+'px monospace'; let ly=r.y+6;
      let legendMaxTextW = 0;
      const legendTop = ly;
      for(const lb of labels){
        const ldash=_LINESTYLE_DASH[lb.linestyle||'solid']||[];
        // linestyle 'none' is a markers-only series: the swatch shows just the
        // marker, with no connecting rule (matches how the series is drawn).
        if(lb.linestyle!=='none'){
          ctx.strokeStyle=lb.color; ctx.lineWidth=2;
          ctx.setLineDash(ldash);
          ctx.beginPath(); ctx.moveTo(swatchX0,ly+5); ctx.lineTo(swatchX1,ly+5); ctx.stroke();
          ctx.setLineDash([]);
        }
        if(lb.marker && lb.marker!=='none'){
          ctx.strokeStyle=lb.color; ctx.fillStyle=lb.color; ctx.lineWidth=1.5;
          ctx.beginPath(); _drawMarkerSymbol(ctx,lb.marker,markerX,ly+5,Math.min(lb.ms||4,4)); ctx.fill(); ctx.stroke();
        }
        ctx.fillStyle=theme.tickText;ctx.textAlign='left';ctx.textBaseline='top';ctx.fillText(lb.text,textX,ly);
        legendMaxTextW = Math.max(legendMaxTextW, ctx.measureText(lb.text).width);
        ly+=rowH;
      }
      // Cache the legend's on-canvas bounding box for the 1D double-click
      // legend hit-test (see the dblclick handler in _attachEvents1d).
      p._legendRect = {x: r.x, y: legendTop, w: (textX-r.x)+legendMaxTextW, h: ly-legendTop};
    }

    const title1d=st.title||'';
    if(title1d){
      ctx.fillStyle=theme.tickText;
      ctx.textBaseline='middle';
      // 1D titles live in the fixed PAD_T strip; clamp the drawn size so
      // ascenders/descenders never clip (the 2D title strip grows instead).
      _drawTex(ctx, title1d, r.x+r.w/2, PAD_T/2, _titlePx(st),
               {align:'center', weight:'bold'});
    }

    drawOverlay1d(p);
    drawMarkers1d(p);
  }

  function drawOverlay1d(p) {
    const st=p.state; if(!st) return;
    const {pw,ph,ovCtx} = p;
    const r=_plotRect1d(p);
    const xArr = p._1dXArr || (st.x_axis_b64 ? _decodeF64(st.x_axis_b64) : (st.x_axis||[]));
    const x0=st.view_x0||0, x1=st.view_x1||1;
    const dMin=st.data_min, dMax=st.data_max;
    ovCtx.clearRect(0,0,pw,ph);
    const widgets=st.overlay_widgets||[];
    if(!widgets.length) return;

    for(const w of widgets){
      if(w.visible === false) continue;
      const color=w.color||'#00e5ff';
      ovCtx.save();ovCtx.strokeStyle=color;ovCtx.lineWidth=(w.linewidth!=null?w.linewidth:2);
      if(w.type==='vline'){
        const px=_fracToPx1d(_axisValToFrac(xArr,w.x),x0,x1,r);
        ovCtx.setLineDash([5,3]);ovCtx.beginPath();ovCtx.moveTo(px,r.y);ovCtx.lineTo(px,r.y+r.h);ovCtx.stroke();ovCtx.setLineDash([]);
        _ovHandle1d(ovCtx,px,r.y+7,color);
      } else if(w.type==='hline'){
        const py=_valToPy1d(w.y,dMin,dMax,r);
        ovCtx.setLineDash([5,3]);ovCtx.beginPath();ovCtx.moveTo(r.x,py);ovCtx.lineTo(r.x+r.w,py);ovCtx.stroke();ovCtx.setLineDash([]);
        _ovHandle1d(ovCtx,r.x+r.w-7,py,color);
      } else if(w.type==='range' && w.orientation==='vertical'){
        // Vertical range: the two edges are VALUES on the y axis and the band
        // spans the full plot width.  x0/x1 stay the field names — they are
        // the extents along the selection axis, the same way matplotlib's
        // SpanSelector treats `extents` regardless of its `direction`.
        const vpy0=_valToPy1d(w.x0,dMin,dMax,r);
        const vpy1=_valToPy1d(w.x1,dMin,dMax,r);
        const vtop=Math.min(vpy0,vpy1), vbot=Math.max(vpy0,vpy1);
        ovCtx.save();ovCtx.globalAlpha=0.15;ovCtx.fillStyle=color;ovCtx.fillRect(r.x,vtop,r.w,vbot-vtop);ovCtx.restore();
        ovCtx.setLineDash([5,3]);
        ovCtx.beginPath();ovCtx.moveTo(r.x,vpy0);ovCtx.lineTo(r.x+r.w,vpy0);ovCtx.stroke();
        ovCtx.beginPath();ovCtx.moveTo(r.x,vpy1);ovCtx.lineTo(r.x+r.w,vpy1);ovCtx.stroke();
        ovCtx.setLineDash([]);
        _ovHandle1d(ovCtx,r.x+r.w-7,vpy0,color);_ovHandle1d(ovCtx,r.x+r.w-7,vpy1,color);
      } else if(w.type==='range'){
        const px0=_fracToPx1d(_axisValToFrac(xArr,w.x0),x0,x1,r);
        const px1b=_fracToPx1d(_axisValToFrac(xArr,w.x1),x0,x1,r);
        if(w.style==='fwhm'){
          // FWHM style: o-------o  two handles joined by a dashed horizontal line
          const pyHalf=_valToPy1d(w.y||0,dMin,dMax,r);
          ovCtx.setLineDash([5,4]);
          ovCtx.beginPath();ovCtx.moveTo(px0,pyHalf);ovCtx.lineTo(px1b,pyHalf);ovCtx.stroke();
          ovCtx.setLineDash([]);
          _ovHandle1d(ovCtx,px0,pyHalf,color);
          _ovHandle1d(ovCtx,px1b,pyHalf,color);
        } else {
          // band style (default)
          const left=Math.min(px0,px1b), right=Math.max(px0,px1b);
          ovCtx.save();ovCtx.globalAlpha=0.15;ovCtx.fillStyle=color;ovCtx.fillRect(left,r.y,right-left,r.h);ovCtx.restore();
          ovCtx.setLineDash([5,3]);
          ovCtx.beginPath();ovCtx.moveTo(px0,r.y);ovCtx.lineTo(px0,r.y+r.h);ovCtx.stroke();
          ovCtx.beginPath();ovCtx.moveTo(px1b,r.y);ovCtx.lineTo(px1b,r.y+r.h);ovCtx.stroke();
          ovCtx.setLineDash([]);
          _ovHandle1d(ovCtx,px0,r.y+7,color);_ovHandle1d(ovCtx,px1b,r.y+7,color);
        }
      } else if(w.type==='point'){
        const px=_fracToPx1d(_axisValToFrac(xArr,w.x),x0,x1,r);
        const py=_valToPy1d(w.y,dMin,dMax,r);
        // Dashed crosshair guide lines (skipped when show_crosshair is false)
        if(w.show_crosshair!==false){
          ovCtx.save();ovCtx.beginPath();ovCtx.rect(r.x,r.y,r.w,r.h);ovCtx.clip();
          ovCtx.setLineDash([4,3]);
          ovCtx.beginPath();ovCtx.moveTo(px,r.y);ovCtx.lineTo(px,r.y+r.h);ovCtx.stroke();
          ovCtx.beginPath();ovCtx.moveTo(r.x,py);ovCtx.lineTo(r.x+r.w,py);ovCtx.stroke();
          ovCtx.setLineDash([]);
          ovCtx.restore();
        }
        // Draw the draggable handle (larger than _ovHandle1d for easy grab)
        ovCtx.save();ovCtx.fillStyle=color;ovCtx.strokeStyle='rgba(0,0,0,0.5)';ovCtx.lineWidth=1.5;
        ovCtx.beginPath();ovCtx.arc(px,py,7,0,Math.PI*2);ovCtx.fill();ovCtx.stroke();
        ovCtx.restore();
      }
      ovCtx.restore();
    }
  }

  function _ovHandle1d(ctx,x,y,color){
    ctx.save();ctx.fillStyle=color;ctx.strokeStyle='rgba(0,0,0,0.45)';ctx.lineWidth=1.5;
    ctx.beginPath();ctx.arc(x,y,5,0,Math.PI*2);ctx.fill();ctx.stroke();ctx.restore();
  }

  function drawMarkers1d(p, hoverState) {
    const st=p.state; if(!st) return;
    const {pw,ph,mkCtx} = p;
    const r=_plotRect1d(p);
    // Use cached decoded arrays from draw1d; fall back to inline decode if needed.
    const xArr = p._1dXArr || (st.x_axis_b64 ? _decodeF64(st.x_axis_b64) : (st.x_axis||[]));
    const yData = p._1dDArr || (st.data_b64 ? _decodeF64(st.data_b64) : (st.data||[]));
    const x0=st.view_x0||0, x1=st.view_x1||1;
    let dMin=st.data_min, dMax=st.data_max;
    if (st.y_range && st.y_range.length === 2) { dMin = st.y_range[0]; dMax = st.y_range[1]; }
    mkCtx.clearRect(0,0,pw,ph);
    const sets=st.markers||[];
    if(!sets.length) return;
    const hsi = hoverState ? hoverState.si : -1;

    mkCtx.save();mkCtx.beginPath();mkCtx.rect(r.x,r.y,r.w,r.h);mkCtx.clip();

    function _offToCanvas(off){
      const xFrac=xArr.length>=2?_axisValToFrac(xArr,off[0]):(off[0]/((xArr.length-1)||1));
      const px=_fracToPx1d(xFrac,x0,x1,r);
      let py;
      if(off.length>=2&&off[1]!=null){py=_valToPy1d(off[1],dMin,dMax,r);}
      else if(yData.length>1){const idx=Math.max(0,Math.min(yData.length-1,Math.round(xFrac*(yData.length-1))));py=_valToPy1d(yData[idx],dMin,dMax,r);}
      else{py=_valToPy1d(0,dMin,dMax,r);}
      return[px,py];
    }
    function _xPx(v){return _fracToPx1d(xArr.length>=2?_axisValToFrac(xArr,v):0,x0,x1,r);}
    function _yPx(v){return _valToPy1d(v,dMin,dMax,r);}

    for(let si=0;si<sets.length;si++){
      const ms=sets[si];
      const isHov=si===hsi;
      const color=ms.color||'#ff0000', lw=ms.linewidth!=null?ms.linewidth:1.5;
      const type=ms.type||'points';
      const fc=ms.fill_color||null, fa=ms.fill_alpha!=null?ms.fill_alpha:0.3;
      // Hover colours: only applied when explicitly set — no default fallback.
      const ec  = isHov && ms.hover_color     ? ms.hover_color     : color;
      const fch = isHov && ms.hover_facecolor ? ms.hover_facecolor : fc;
      const dlw = isHov && (ms.hover_color || ms.hover_facecolor) ? lw+1 : lw;
      // Per-marker edge/face colours — see the matching block in _drawMarkers2d.
      const _ecArr = Array.isArray(ec)  ? ec  : null;
      const _fcArr = Array.isArray(fch) ? fch : null;
      const _ecAt = (i) => _ecArr ? _ecArr[i % _ecArr.length] : ec;
      const _fcAt = (i) => _fcArr ? _fcArr[i % _fcArr.length] : fch;

      // Coordinate transform: "axes" and "display" map 2-D offsets to panel
      // space independently of data values; vlines/hlines stay in data coords.
      const tfm = ms.transform || 'data';
      let _tc2d;
      if(tfm==='axes'){
        _tc2d=(fx,fy)=>[r.x+fx*r.w, r.y+(1-fy)*r.h];
      } else if(tfm==='display'){
        _tc2d=(ix,iy)=>[ix,iy];
      } else {
        _tc2d=(off0,off1)=>_offToCanvas([off0,off1]);
      }

      mkCtx.save();mkCtx.strokeStyle=_ecAt(0);mkCtx.fillStyle=_ecAt(0);mkCtx.lineWidth=dlw;

      // Optional clip path (matplotlib set_clip_path): a data-coord polygon the
      // group is clipped to — e.g. a pcolormesh mesh clipped to a curved
      // fundamental-sector boundary so edge cells don't stick out. Scoped to this
      // set's save()/restore().
      if(ms.clip_path && ms.clip_path.length>=3){
        const _cp0= tfm==='data' ? _offToCanvas(ms.clip_path[0]) : _tc2d(ms.clip_path[0][0],ms.clip_path[0][1]);
        mkCtx.beginPath();mkCtx.moveTo(_cp0[0],_cp0[1]);
        for(let k=1;k<ms.clip_path.length;k++){
          const _cp= tfm==='data' ? _offToCanvas(ms.clip_path[k]) : _tc2d(ms.clip_path[k][0],ms.clip_path[k][1]);
          mkCtx.lineTo(_cp[0],_cp[1]);
        }
        mkCtx.closePath();mkCtx.clip();
      }

      if(type==='points'){
        for(let i=0;i<ms.offsets.length;i++){
          const [px,py]= tfm==='data' ? _offToCanvas(ms.offsets[i]) : _tc2d(ms.offsets[i][0],ms.offsets[i][1]!=null?ms.offsets[i][1]:0);
          const sz=Math.max(1,ms.sizes[i]!=null?ms.sizes[i]:ms.sizes[0]||5);
          mkCtx.beginPath();mkCtx.arc(px,py,sz,0,Math.PI*2);
          const _fc=_fcAt(i);
          if(_fc){mkCtx.save();mkCtx.globalAlpha=fa;mkCtx.fillStyle=_fc;mkCtx.fill();mkCtx.restore();}
          if(_ecArr) mkCtx.strokeStyle=_ecAt(i);
          mkCtx.stroke();
        }
      } else if(type==='vlines'){
        for(let i=0;i<ms.offsets.length;i++){
          const px=_xPx(ms.offsets[i][0]);
          if(_ecArr) mkCtx.strokeStyle=_ecAt(i);
          mkCtx.beginPath();mkCtx.moveTo(px,r.y);mkCtx.lineTo(px,r.y+r.h);mkCtx.stroke();
        }
      } else if(type==='hlines'){
        for(let i=0;i<ms.offsets.length;i++){
          const py=_yPx(ms.offsets[i][0]);
          if(_ecArr) mkCtx.strokeStyle=_ecAt(i);
          mkCtx.beginPath();mkCtx.moveTo(r.x,py);mkCtx.lineTo(r.x+r.w,py);mkCtx.stroke();
        }
      } else if(type==='lines'){
        const segs=ms.segments||[];
        for(let i=0;i<segs.length;i++){
          const seg=segs[i];
          const [x1c,y1c]= tfm==='data' ? _offToCanvas(seg[0]) : _tc2d(seg[0][0],seg[0][1]);
          const [x2c,y2c]= tfm==='data' ? _offToCanvas(seg[1]) : _tc2d(seg[1][0],seg[1][1]);
          if(_ecArr) mkCtx.strokeStyle=_ecAt(i);
          mkCtx.beginPath();mkCtx.moveTo(x1c,y1c);mkCtx.lineTo(x2c,y2c);mkCtx.stroke();
        }
      } else if(type==='ellipses'){
        for(let i=0;i<ms.offsets.length;i++){
          const off=ms.offsets[i];
          const [cx,cy]= tfm==='data' ? _offToCanvas(off) : _tc2d(off[0],off[1]!=null?off[1]:0);
          const wd=ms.widths[i]!=null?ms.widths[i]:(ms.widths[0]||10);
          const hd=ms.heights[i]!=null?ms.heights[i]:(ms.heights[0]||10);
          const rw=Math.max(1, tfm==='data' ? Math.abs(_xPx(off[0]+wd/2)-_xPx(off[0]-wd/2))/2 : wd/2);
          const rh=Math.max(1, tfm==='data' ? Math.abs(_yPx((off[1]||0)-hd/2)-_yPx((off[1]||0)+hd/2))/2 : hd/2);
          const ang=((ms.angles&&(ms.angles[i]!=null?ms.angles[i]:ms.angles[0])||0)*Math.PI)/180;
          mkCtx.beginPath();mkCtx.ellipse(cx,cy,rw,rh,ang,0,Math.PI*2);
          const _fc=_fcAt(i);
          if(_fc){mkCtx.save();mkCtx.globalAlpha=fa;mkCtx.fillStyle=_fc;mkCtx.fill();mkCtx.restore();}
          if(_ecArr) mkCtx.strokeStyle=_ecAt(i);
          mkCtx.stroke();
        }
      } else if(type==='rectangles'||type==='squares'){
        const heights=type==='squares'?ms.widths:ms.heights;
        for(let i=0;i<ms.offsets.length;i++){
          const off=ms.offsets[i];
          const [cx,cy]= tfm==='data' ? _offToCanvas(off) : _tc2d(off[0],off[1]!=null?off[1]:0);
          const wd=ms.widths[i]!=null?ms.widths[i]:(ms.widths[0]||10);
          const hd=heights[i]!=null?heights[i]:(heights[0]||10);
          const rw=Math.max(1, tfm==='data' ? Math.abs(_xPx(off[0]+wd/2)-_xPx(off[0]-wd/2)) : wd);
          const rh=Math.max(1, tfm==='data' ? Math.abs(_yPx((off[1]||0)-hd/2)-_yPx((off[1]||0)+hd/2)) : hd);
          const ang=((ms.angles&&(ms.angles[i]!=null?ms.angles[i]:ms.angles[0])||0)*Math.PI)/180;
          mkCtx.save();mkCtx.translate(cx,cy);mkCtx.rotate(ang);
          const _fc=_fcAt(i);
          if(_fc){mkCtx.save();mkCtx.globalAlpha=fa;mkCtx.fillStyle=_fc;mkCtx.fillRect(-rw/2,-rh/2,rw,rh);mkCtx.restore();}
          if(_ecArr) mkCtx.strokeStyle=_ecAt(i);
          mkCtx.strokeRect(-rw/2,-rh/2,rw,rh);
          mkCtx.restore();
        }
      } else if(type==='polygons'){
        for(let i=0;i<(ms.vertices_list||[]).length;i++){
          const verts=ms.vertices_list[i];
          if(!verts||verts.length<2) continue;
          const [px0,py0]= tfm==='data' ? _offToCanvas(verts[0]) : _tc2d(verts[0][0],verts[0][1]);
          mkCtx.beginPath();mkCtx.moveTo(px0,py0);
          for(let k=1;k<verts.length;k++){
            const[px,py]= tfm==='data' ? _offToCanvas(verts[k]) : _tc2d(verts[k][0],verts[k][1]);
            mkCtx.lineTo(px,py);
          }
          mkCtx.closePath();
          const _fc=_fcAt(i);
          if(_fc){mkCtx.save();mkCtx.globalAlpha=fa;mkCtx.fillStyle=_fc;mkCtx.fill();mkCtx.restore();}
          if(_ecArr) mkCtx.strokeStyle=_ecAt(i);
          mkCtx.stroke();
        }
      } else if(type==='raster'){
        // A single RGBA image stretched across data-coord `extent`. Heavy bytes
        // ride the geom channel (st.raster_geom[id]); fall back to inline. The
        // decoded OffscreenCanvas is cached on the set so view-only redraws blit
        // without re-decoding. The clip block above already scoped any sector.
        const rg = (st.raster_geom && st.raster_geom[ms.id]) || ms;
        const b64 = rg.image_b64 || '';
        const iw = rg.image_width|0, ih = rg.image_height|0;
        if(b64 && iw>0 && ih>0){
          if(ms._rasterKey!==b64 || !ms._rasterBmp){
            try{
              const bin=atob(b64);
              const bytes=new Uint8ClampedArray(bin.length);
              for(let i=0;i<bin.length;i++) bytes[i]=bin.charCodeAt(i);
              const imgData=new ImageData(bytes, iw, ih);
              const oc=new OffscreenCanvas(iw,ih);
              oc.getContext('2d').putImageData(imgData,0,0);
              ms._rasterBmp=oc; ms._rasterKey=b64;
            }catch(_){ ms._rasterBmp=null; }
          }
          const ext=ms.extent||[0,1,0,1];
          const [ax2,ay2]= tfm==='data' ? _offToCanvas([ext[0],ext[2]]) : _tc2d(ext[0],ext[2]);
          const [bx2,by2]= tfm==='data' ? _offToCanvas([ext[1],ext[3]]) : _tc2d(ext[1],ext[3]);
          if(ms._rasterBmp){
            mkCtx.save();
            // Nearest-neighbour by default (crisp cells); smoothing bilinearly
            // interpolates for a smooth heat field (ms.smooth === true).
            mkCtx.imageSmoothingEnabled = ms.smooth === true;
            if(ms.smooth === true) mkCtx.imageSmoothingQuality = 'high';
            mkCtx.drawImage(ms._rasterBmp, 0,0,iw,ih,
              Math.min(ax2,bx2), Math.min(ay2,by2),
              Math.abs(bx2-ax2), Math.abs(by2-ay2));
            mkCtx.restore();
          }
        }
      } else if(type==='arrows'){
        const HL=8;
        for(let i=0;i<ms.offsets.length;i++){
          const off=ms.offsets[i];
          const [x1a,y1a]= tfm==='data' ? _offToCanvas(off) : _tc2d(off[0],off[1]!=null?off[1]:0);
          const u=ms.U[i]||0, v=ms.V[i]||0;
          const x2a= tfm==='data' ? _xPx(off[0]+u) : x1a+u;
          const y2a= tfm==='data' ? _yPx((off[1]||0)+v) : y1a+v;
          const ang=Math.atan2(y2a-y1a,x2a-x1a);
          mkCtx.beginPath();mkCtx.moveTo(x1a,y1a);mkCtx.lineTo(x2a,y2a);mkCtx.stroke();
          mkCtx.beginPath();mkCtx.moveTo(x2a,y2a);
          mkCtx.lineTo(x2a-HL*Math.cos(ang-Math.PI/6),y2a-HL*Math.sin(ang-Math.PI/6));
          mkCtx.lineTo(x2a-HL*Math.cos(ang+Math.PI/6),y2a-HL*Math.sin(ang+Math.PI/6));
          mkCtx.closePath();mkCtx.fill();
        }
      } else if(type==='texts'){
        const fs=ms.fontsize||12;
        mkCtx.font=`${fs}px sans-serif`;mkCtx.textAlign='left';mkCtx.textBaseline='top';
        for(let i=0;i<ms.offsets.length;i++){
          const [px,py]= tfm==='data' ? _offToCanvas(ms.offsets[i]) : _tc2d(ms.offsets[i][0],ms.offsets[i][1]!=null?ms.offsets[i][1]:0);
          mkCtx.fillText(String((ms.texts&&ms.texts[i])||''),px,py);
        }
      }
      mkCtx.restore();
    }
    mkCtx.restore();
  }

  // Returns {lineId, canvasPx, canvasPy, x, y} for the line closest to (mx,my),
  // or null if nothing is within HIT px.
  // lineId: null = primary line, string = extra-line id.
  function _lineHitTest1d(mx, my, p) {
    const st = p.state; if (!st) return null;
    const r = _plotRect1d(p);
    if (mx < r.x || mx > r.x+r.w || my < r.y || my > r.y+r.h) return null;
    const xArr = p._1dXArr || (st.x_axis_b64 ? _decodeF64(st.x_axis_b64) : (st.x_axis||[]));
    const x0 = st.view_x0||0, x1 = st.view_x1||1;
    const dMin = st.data_min, dMax = st.data_max;
    const HIT = 6;

    function _nearestOnLine(yData, lineXArr, lineId) {
      if (!yData || yData.length < 2) return null;
      const n = yData.length;
      const span = lineXArr.length >= 2 ? (lineXArr[lineXArr.length-1] - lineXArr[0]) || 1 : (n-1)||1;
      let bestDist = HIT + 1, bx = null, by = null;
      for (let i = 0; i < n - 1; i++) {
        const f0 = lineXArr.length >= 2 ? (lineXArr[i]   - lineXArr[0]) / span : i   / ((n-1)||1);
        const f1 = lineXArr.length >= 2 ? (lineXArr[i+1] - lineXArr[0]) / span : (i+1) / ((n-1)||1);
        const px0 = _fracToPx1d(f0, x0, x1, r), py0 = _valToPy1d(yData[i],   dMin, dMax, r);
        const px1 = _fracToPx1d(f1, x0, x1, r), py1 = _valToPy1d(yData[i+1], dMin, dMax, r);
        const dx = px1-px0, dy = py1-py0, lenSq = dx*dx+dy*dy;
        const t  = lenSq > 0 ? Math.max(0, Math.min(1, ((mx-px0)*dx+(my-py0)*dy)/lenSq)) : 0;
        const nx = px0+t*dx, ny = py0+t*dy;
        const d  = Math.hypot(mx-nx, my-ny);
        if (d < bestDist) { bestDist = d; bx = nx; by = ny; }
      }
      if (bx === null) return null;
      // Convert canvas best-point back to data coords
      const frac = _canvasXToFrac1d(bx, x0, x1, r);
      const physX = lineXArr.length >= 2 ? _axisFracToVal(lineXArr, frac) : frac;
      const physY = dMin + (r.y + r.h - by) / (r.h||1) * (dMax - dMin);
      return { lineId, canvasPx: bx, canvasPy: by, x: physX, y: physY };
    }

    // Check extra lines first (drawn on top), then primary
    for (let i = (st.extra_lines||[]).length - 1; i >= 0; i--) {
      const ex = st.extra_lines[i];
      const exY = ex.data_b64   ? _decodeF64(ex.data_b64)   : (ex.data   || []);
      const exX = ex.x_axis_b64 ? _decodeF64(ex.x_axis_b64) : (ex.x_axis ? ex.x_axis : xArr);
      const hit = _nearestOnLine(exY, exX, ex.id);
      if (hit) return hit;
    }
    const primY = p._1dDArr || (st.data_b64 ? _decodeF64(st.data_b64) : (st.data||[]));
    return _nearestOnLine(primY, xArr, null);
  }

  // ── marker hit-test helpers ────────────────────────────────────────────────
  const MARKER_HIT = 8;

  // Returns {si, i, collectionLabel, markerLabel} or null.
  // si/i identify the set/marker for hover; labels are for tooltips (null if unset).
  function _markerHitTest2d(mx, my, st, pw, ph) {
    const sets = st.markers || [];
    const scale = _imgScale2d(st, pw, ph);
    const vr = _imgVisibleRect2d(st, pw, ph);
    for (let si = sets.length-1; si >= 0; si--) {
      const ms = sets[si];
      const type = ms.type || 'circles';
      const tfm = ms.transform || 'data';
      const clipSet = tfm !== 'display' || ms.clip_display !== false;
      if (clipSet && (mx < vr.x || mx > vr.x + vr.w || my < vr.y || my > vr.y + vr.h)) {
        continue;
      }
      const collLabel = ms.label != null ? String(ms.label) : null;
      const perLabels = Array.isArray(ms.labels) ? ms.labels : null;
      let _tc;
      if(tfm==='axes'){
        const fr=_imgFitRect(st.image_width,st.image_height,pw,ph);
        _tc=(fx,fy)=>[fr.x+fx*fr.w, fr.y+(1-fy)*fr.h];
      } else if(tfm==='display'){
        _tc=(ix,iy)=>[ix,iy];
      } else {
        _tc=(ix,iy)=>_imgToCanvas2d(ix,iy,st,pw,ph);
      }
      const scl = tfm==='data' ? scale : 1;
      // Match the draw loop's size space (see drawMarkers2d).
      const sscl = ms.size_units==='px' ? 1 : scl;
      if (type === 'circles') {
        for (let i=0;i<(ms.offsets||[]).length;i++) {
          const [cx,cy]=_tc(ms.offsets[i][0],ms.offsets[i][1]);
          const r=Math.max(1,(ms.sizes[i]!=null?ms.sizes[i]:ms.sizes[0]||5)*sscl);
          if(Math.sqrt((mx-cx)**2+(my-cy)**2)<=r+MARKER_HIT)
            return{si,i,collectionLabel:collLabel,markerLabel:perLabels?String(perLabels[i]??''):null};
        }
      } else if (type === 'ellipses') {
        for (let i=0;i<(ms.offsets||[]).length;i++) {
          const [cx,cy]=_tc(ms.offsets[i][0],ms.offsets[i][1]);
          const rw=(ms.widths[i]||ms.widths[0]||10)*sscl/2+MARKER_HIT;
          const rh=(ms.heights[i]||ms.heights[0]||10)*sscl/2+MARKER_HIT;
          const dx=(mx-cx)/Math.max(1,rw), dy=(my-cy)/Math.max(1,rh);
          if(dx*dx+dy*dy<=1.0)
            return{si,i,collectionLabel:collLabel,markerLabel:perLabels?String(perLabels[i]??''):null};
        }
      } else if (type === 'rectangles' || type === 'squares') {
        const heights = type==='squares' ? ms.widths : ms.heights;
        for (let i=0;i<(ms.offsets||[]).length;i++) {
          const [cx,cy]=_tc(ms.offsets[i][0],ms.offsets[i][1]);
          const hw=(ms.widths[i]||ms.widths[0]||20)*sscl/2+MARKER_HIT;
          const hh=((heights[i]||heights[0]||20))*sscl/2+MARKER_HIT;
          if(Math.abs(mx-cx)<=hw&&Math.abs(my-cy)<=hh)
            return{si,i,collectionLabel:collLabel,markerLabel:perLabels?String(perLabels[i]??''):null};
        }
      } else if (type === 'arrows') {
        for (let i=0;i<(ms.offsets||[]).length;i++) {
          const [x1,y1]=_tc(ms.offsets[i][0],ms.offsets[i][1]);
          const mx2=x1+(ms.U[i]||0)*scl/2, my2=y1+(ms.V[i]||0)*scl/2;
          if(Math.sqrt((mx-mx2)**2+(my-my2)**2)<=MARKER_HIT*2)
            return{si,i,collectionLabel:collLabel,markerLabel:perLabels?String(perLabels[i]??''):null};
        }
      } else if (type === 'lines') {
        for (let i=0;i<(ms.segments||[]).length;i++) {
          const seg=ms.segments[i];
          const [x1,y1]=_tc(seg[0][0],seg[0][1]);
          const [x2,y2]=_tc(seg[1][0],seg[1][1]);
          const dx=x2-x1,dy=y2-y1,len2=dx*dx+dy*dy;
          const t=len2>0?Math.max(0,Math.min(1,((mx-x1)*dx+(my-y1)*dy)/len2)):0;
          if(Math.sqrt((mx-(x1+t*dx))**2+(my-(y1+t*dy))**2)<=MARKER_HIT)
            return{si,i,collectionLabel:collLabel,markerLabel:perLabels?String(perLabels[i]??''):null};
        }
      } else if (type === 'polygons') {
        for (let i=0;i<(ms.vertices_list||[]).length;i++) {
          const verts=ms.vertices_list[i]; if(!verts||!verts.length) continue;
          const [cx,cy]=_tc(verts[0][0],verts[0][1]);
          if(Math.sqrt((mx-cx)**2+(my-cy)**2)<=MARKER_HIT*1.5)
            return{si,i,collectionLabel:collLabel,markerLabel:perLabels?String(perLabels[i]??''):null};
        }
      } else if (type === 'texts') {
        for (let i=0;i<(ms.offsets||[]).length;i++) {
          const [cx,cy]=_tc(ms.offsets[i][0],ms.offsets[i][1]);
          if(Math.sqrt((mx-cx)**2+(my-cy)**2)<=MARKER_HIT*1.5)
            return{si,i,collectionLabel:collLabel,markerLabel:perLabels?String(perLabels[i]??''):null};
        }
      }
    }
    return null;
  }

  function _markerHitTest1d(mx, my, p) {
    const st=p.state; if(!st) return null;
    const r=_plotRect1d(p);
    // Use cached decoded array from draw1d; fall back to inline decode if needed.
    const xArr = p._1dXArr || (st.x_axis_b64 ? _decodeF64(st.x_axis_b64) : (st.x_axis||[]));
    const x0=st.view_x0||0, x1=st.view_x1||1;
    const dMin=st.data_min, dMax=st.data_max;
    const sets=st.markers||[];
    for(let si=sets.length-1;si>=0;si--){
      const ms=sets[si];
      const collLabel=ms.label!=null?String(ms.label):null;
      const perLabels=Array.isArray(ms.labels)?ms.labels:null;
      if(ms.type==='points'){
        for(let i=0;i<(ms.offsets||[]).length;i++){
          const frac=xArr.length>=2?_axisValToFrac(xArr,ms.offsets[i][0]):0;
          const px=_fracToPx1d(frac,x0,x1,r);
          const sz=Math.max(1,ms.sizes[i]!=null?ms.sizes[i]:ms.sizes[0]||5);
          if(Math.sqrt((mx-px)**2+(my-r.y-r.h/2)**2)<=sz+MARKER_HIT)
            return{si,i,collectionLabel:collLabel,markerLabel:perLabels?String(perLabels[i]??''):null};
        }
      } else if(ms.type==='vlines'){
        for(let i=0;i<(ms.offsets||[]).length;i++){
          const px=_fracToPx1d(xArr.length>=2?_axisValToFrac(xArr,ms.offsets[i][0]):0,x0,x1,r);
          if(Math.abs(mx-px)<=MARKER_HIT&&my>=r.y&&my<=r.y+r.h)
            return{si,i,collectionLabel:collLabel,markerLabel:perLabels?String(perLabels[i]??''):null};
        }
      } else if(ms.type==='hlines'){
        for(let i=0;i<(ms.offsets||[]).length;i++){
          const py=_valToPy1d(ms.offsets[i][0],dMin,dMax,r);
          if(Math.abs(my-py)<=MARKER_HIT&&mx>=r.x&&mx<=r.x+r.w)
            return{si,i,collectionLabel:collLabel,markerLabel:perLabels?String(perLabels[i]??''):null};
        }
      } else if(ms.type==='lines'){
        for(let i=0;i<(ms.segments||[]).length;i++){
          const seg=ms.segments[i];
          const xf1=xArr.length>=2?_axisValToFrac(xArr,seg[0][0]):0;
          const xf2=xArr.length>=2?_axisValToFrac(xArr,seg[1][0]):0;
          const x1c=_fracToPx1d(xf1,x0,x1,r),y1c=_valToPy1d(seg[0][1],dMin,dMax,r);
          const x2c=_fracToPx1d(xf2,x0,x1,r),y2c=_valToPy1d(seg[1][1],dMin,dMax,r);
          const dx=x2c-x1c,dy=y2c-y1c,len2=dx*dx+dy*dy;
          const t=len2>0?Math.max(0,Math.min(1,((mx-x1c)*dx+(my-y1c)*dy)/len2)):0;
          if(Math.sqrt((mx-(x1c+t*dx))**2+(my-(y1c+t*dy))**2)<=MARKER_HIT)
            return{si,i,collectionLabel:collLabel,markerLabel:perLabels?String(perLabels[i]??''):null};
        }
      }
    }
    return null;
  }

  // ── touch input bridge ────────────────────────────────────────────────────
  // Touch devices (iPad / iPhone) emit touch* events, not mouse* — but every
  // panel handler is written against mouse events.  Rather than rewrite ~20
  // handlers per kind, we translate touch gestures into the synthetic mouse /
  // wheel events those handlers already understand, attached once per panel:
  //
  //   1 finger  drag   → mousedown / mousemove / mouseup  (pan, orbit, drag a
  //                       widget / ROI / marker / plane — whatever's under it)
  //   2 fingers pinch  → wheel (zoom), centred on the gesture midpoint
  //   double-tap       → dblclick → the panel's double_click event (picking /
  //                       app callbacks), exactly as a mouse double-click
  //
  // A synthetic event carries exactly the fields the handlers read:
  // clientX/Y, button, buttons, the modifier flags (always false for touch),
  // and a no-op preventDefault.  document-level mousemove/up listeners in the
  // handlers receive the synthetic move/up too, so drags that start on the
  // canvas and continue off it work just like a mouse.
  // Dispatch a real MouseEvent so it reaches every listener (including the
  // document-level mousemove/mouseup the handlers use for off-canvas drags).
  // Native MouseEvent carries clientX/Y, button, buttons and false modifiers —
  // exactly what _clientPos / _pointerFields / _modifiers read.
  function _dispatchMouse(target, type, clientX, clientY) {
    target.dispatchEvent(new MouseEvent(type, {
      clientX, clientY, button: 0,
      buttons: type === 'mouseup' ? 0 : 1,
      bubbles: true, cancelable: true, view: window,
    }));
  }

  // Dispatch a real WheelEvent (pinch → zoom).  dir = -1 zoom in, +1 zoom out
  // (matches the handlers' deltaY sign convention).
  function _dispatchWheel(target, clientX, clientY, dir) {
    target.dispatchEvent(new WheelEvent('wheel', {
      clientX, clientY, deltaY: dir * 100, deltaX: 0,
      bubbles: true, cancelable: true, view: window,
    }));
  }

  function _attachTouch(p) {
    const oc = p.overlayCanvas;
    if (!oc || oc._touchBridged) return;
    oc._touchBridged = true;

    let mode = null;            // null | 'drag' | 'pinch'
    let pinchStartDist = 0;
    let lastTapTime = 0, lastTapX = 0, lastTapY = 0;

    const dist = (t0, t1) =>
      Math.hypot(t0.clientX - t1.clientX, t0.clientY - t1.clientY);
    const mid = (t0, t1) => ({
      x: (t0.clientX + t1.clientX) / 2, y: (t0.clientY + t1.clientY) / 2 });

    oc.addEventListener('touchstart', (e) => {
      if (e.touches.length === 1) {
        mode = 'drag';
        const t = e.touches[0];
        _dispatchMouse(oc, 'mousedown', t.clientX, t.clientY);
        e.preventDefault();
      } else if (e.touches.length === 2) {
        // Switching into a pinch — end any single-finger drag cleanly first.
        if (mode === 'drag') {
          const t = e.touches[0];
          _dispatchMouse(document, 'mouseup', t.clientX, t.clientY);
        }
        mode = 'pinch';
        pinchStartDist = dist(e.touches[0], e.touches[1]);
        e.preventDefault();
      }
    }, { passive: false });

    oc.addEventListener('touchmove', (e) => {
      if (mode === 'drag' && e.touches.length >= 1) {
        const t = e.touches[0];
        _dispatchMouse(document, 'mousemove', t.clientX, t.clientY);
        e.preventDefault();
      } else if (mode === 'pinch' && e.touches.length >= 2) {
        const d = dist(e.touches[0], e.touches[1]);
        const m = mid(e.touches[0], e.touches[1]);
        // Quantise into wheel steps; spread (d>start) zooms IN (deltaY<0).
        const ratio = d / (pinchStartDist || d);
        if (Math.abs(ratio - 1) > 0.02) {
          // Update mouse position so wheel-zoom anchors at the pinch centre.
          const { mx, my } = _clientPos({ clientX: m.x, clientY: m.y },
                                        oc, p.pw, p.ph);
          p.mouseX = mx; p.mouseY = my;
          _dispatchWheel(oc, m.x, m.y, ratio > 1 ? -1 : 1);
          pinchStartDist = d;   // incremental — each move is one small step
        }
        e.preventDefault();
      }
    }, { passive: false });

    const endTouch = (e) => {
      if (mode === 'drag') {
        const t = (e.changedTouches && e.changedTouches[0]) || { clientX: 0, clientY: 0 };
        _dispatchMouse(document, 'mouseup', t.clientX, t.clientY);
        // Double-tap detection (only for a tap, not a drag-release): a quick
        // second tap near the first fires dblclick → reset view.
        const now = performance.now();
        if (now - lastTapTime < 300 &&
            Math.hypot(t.clientX - lastTapX, t.clientY - lastTapY) < 30) {
          _dispatchMouse(oc, 'dblclick', t.clientX, t.clientY);
          lastTapTime = 0;
        } else {
          lastTapTime = now; lastTapX = t.clientX; lastTapY = t.clientY;
        }
      }
      // If fingers remain (pinch→1 finger), restart a drag from the survivor.
      if (e.touches && e.touches.length === 1) {
        mode = 'drag';
        const t = e.touches[0];
        _dispatchMouse(oc, 'mousedown', t.clientX, t.clientY);
      } else if (!e.touches || e.touches.length === 0) {
        mode = null;
      }
      if (e.cancelable) e.preventDefault();
    };
    oc.addEventListener('touchend', endTouch, { passive: false });
    oc.addEventListener('touchcancel', endTouch, { passive: false });
  }

  // ── panel-level event handlers ───────────────────────────────────────────
  function _attachPanelEvents(p) {
    if (p.kind === '2d')  _attachEvents2d(p);
    else if (p.kind === '3d')  _attachEvents3d(p);
    else if (p.kind === 'bar') _attachEventsBar(p);
    else                       _attachEvents1d(p);
    _attachTouch(p);   // touch bridge — translates gestures to mouse/wheel

    // Hover flag for `hover_only` keys. Attached HERE rather than inside each
    // per-kind handler because it is the one panel behaviour that is identical
    // for all four, and it must not depend on a kind remembering to wire it.
    // Redraws only the key canvas, never the data — this fires on every
    // pointer entry, so it has to stay cheap.
    if (p.overlayCanvas) {
      p.overlayCanvas.addEventListener('mouseenter', () => {
        if (p._hover) return;
        p._hover = true;
        if ((p.state?.keys || []).some(k => k && k.hover_only)) drawKeys(p);
      });
      p.overlayCanvas.addEventListener('mouseleave', () => {
        if (!p._hover) return;
        p._hover = false;
        if ((p.state?.keys || []).some(k => k && k.hover_only)) drawKeys(p);
      });
    }
  }

  function _canvasToImg2d(px, py, st, pw, ph) {
    const { x, y, w, h } = _imgFitRect(st.image_width, st.image_height, pw, ph);
    const zoom = st.zoom, cx = st.center_x, cy = st.center_y;
    const iw = st.image_width, ih = st.image_height;
    if (zoom < 1.0) {
      // Zoom-out path: inverse of the centred-shrink in _blit2d.
      const dstW = w * zoom, dstH = h * zoom;
      const dstX = x + (w - dstW) / 2, dstY = y + (h - dstH) / 2;
      return [(px - dstX) / dstW * iw, (py - dstY) / dstH * ih];
    }
    const visW = iw / zoom, visH = ih / zoom;
    const srcX = Math.max(0, Math.min(iw - visW, cx * iw - visW / 2));
    const srcY = Math.max(0, Math.min(ih - visH, cy * ih - visH / 2));
    return [srcX + (px - x) / w * visW, srcY + (py - y) / h * visH];
  }

  function _attachEvents2d(p) {
    const { overlayCanvas } = p;
    let localOnly = false;
    const _scheduleCommit = _makeCommitter(() => {
      localOnly = true; model.save_changes(); setTimeout(() => { localOnly = false; }, 200);
    });
    const settled = _makeSettledScheduler(p);

    // Wheel zoom — anchored on the image point under the cursor
    overlayCanvas.addEventListener('wheel',(e)=>{
      e.preventDefault();
      const st=p.state; if(!st) return;
      const imgW=p.imgW||Math.max(1,p.pw-PAD_L-PAD_R), imgH=p.imgH||Math.max(1,p.ph-PAD_T-PAD_B);
      const newZ=Math.max(0.75,Math.min(100,st.zoom*(e.deltaY>0?0.9:1.1)));
      if(!st.tile_enabled){
        // NON-tiled image: anchor the zoom on the cursor (the image point under the
        // cursor stays put) — there's no detail-tile fetch to disagree with it.
        const {mx,my}=_clientPos(e,overlayCanvas,imgW,imgH);
        const [anchorX,anchorY]=_canvasToImg2d(mx,my,st,imgW,imgH);
        st.zoom=newZ;
        const iw=st.image_width, ih=st.image_height;
        const fr=_imgFitRect(iw,ih,imgW,imgH);
        const newVisW=iw/newZ, newVisH=ih/newZ;
        const newSrcX=anchorX-(mx-fr.x)/fr.w*newVisW;
        const newSrcY=anchorY-(my-fr.y)/fr.h*newVisH;
        st.center_x=Math.max(0,Math.min(1,(newSrcX+newVisW/2)/iw));
        st.center_y=Math.max(0,Math.min(1,(newSrcY+newVisH/2)/ih));
      } else {
        // TILE mode: zoom about the CURRENT CENTER, not the cursor. Cursor-anchored
        // zoom looked right DURING the wheel (base blit re-anchored to the cursor),
        // but when the debounced detail-tile fetch landed it re-derived the visible
        // window from center_x/center_y — a different anchor — so the image visibly
        // JUMPED. Center-zoom makes the base blit + detail tile agree at every zoom.
        st.zoom=newZ;
      }
      draw2d(p);
      _propagateZoom2d(p);
      model.set(`panel_${p.id}_json`, _viewStateJson(p));
      _emitViewChanged(p);   // debounced → fetch a hi-res detail tile on zoom settle
      _scheduleCommit();
    },{passive:false});

    // Pan + widget drag
    let panStart={};
    overlayCanvas.addEventListener('mousedown',(e)=>{
      if(e.button!==0) return;
      const st=p.state; if(!st) return;
      overlayCanvas.focus();
      const imgW=p.imgW||Math.max(1,p.pw-PAD_L-PAD_R), imgH=p.imgH||Math.max(1,p.ph-PAD_T-PAD_B);
      const {mx,my}=_clientPos(e,overlayCanvas,imgW,imgH);
      // Modifiers go in so an ARMED brush can claim a Shift-drag (and only a
      // Shift-drag) before pan/click ever see it — see _ovHitTest2d's first pass.
      const hit=_ovHitTest2d(mx, my, p, {shift:e.shiftKey});
      if(hit){
        p.ovDrag2d=hit;
        p.lastWidgetId=(st.overlay_widgets||[])[hit.idx]?.id||null;
        // Stash the ID as well as the index: a model echo can replace p.state
        // (and reorder overlay_widgets) mid-drag, after which `hit.idx` points
        // at the wrong widget. mouseup resolves by ID and falls back to index.
        hit.wid=p.lastWidgetId;
        if(hit.mode==='paint'||hit.mode==='erase'){
          // Open the stroke HERE, not on the first move: a Shift-click with no
          // motion must still paint (or erase) a single dot.
          const _bw=(st.overlay_widgets||[])[hit.idx];
          if(_bw){
            const _L=_brushLiveBegin(p,_bw);
            const [_bix,_biy]=_canvasToImg2d(mx,my,st,imgW,imgH);
            _brushPaintAt(_L,st,_bix,_biy,hit);
          }
          drawOverlay2d(p);
          overlayCanvas.style.cursor='crosshair';
          e.preventDefault(); return;
        }
        overlayCanvas.style.cursor='move';
        e.preventDefault(); return;
      }
      // Store pan start in canvas-pixel coords so the drag delta is also
      // in canvas-pixel space and matches fr.w/fr.h (both canvas-pixel).
      panStart={mx,my,cx:st.center_x,cy:st.center_y};
      // Track potential click: distance + time guards distinguish click from pan.
      p.clickCandidate={mx,my,t:Date.now(),shiftKey:e.shiftKey};
      p.isPanning=true; overlayCanvas.style.cursor='grabbing';
      // Do NOT call e.preventDefault() here: Chrome suppresses the click event
      // when mousedown is cancelled, which in turn prevents dblclick from firing.
      // Panning's preventDefault lives in the mousemove handler (prevents scroll).
    });
    document.addEventListener('mousemove',(e)=>{
      if(p.ovDrag2d){
        _doDrag2d(e,p);
        // A `silent` drag (brush stroke) emits nothing until release. Spreading
        // a growing stroke list into an event_json every tick is exactly the
        // O(n²) the local-accumulate design exists to avoid; the mouseup handler
        // below ships the finished stroke once.
        if(!p.ovDrag2d.silent){
          const _dw=(p.state.overlay_widgets||[])[p.ovDrag2d.idx]||{};
          _emitEvent(p.id,'pointer_move',_dw.id||null,{..._dw,..._pointerFields(e)});
        }
        return;
      }
      if(!p.isPanning) return;
      const st=p.state; if(!st) return;
      const imgW=p.imgW||Math.max(1,p.pw-PAD_L-PAD_R), imgH=p.imgH||Math.max(1,p.ph-PAD_T-PAD_B);
      const fr=_imgFitRect(st.image_width,st.image_height,imgW,imgH);
      const z=st.zoom;
      const {mx:cmx,my:cmy}=_clientPos(e,overlayCanvas,imgW,imgH);
      // Invalidate click candidate once the cursor has clearly moved (>4 px).
      if(p.clickCandidate){const _dx=cmx-p.clickCandidate.mx,_dy=cmy-p.clickCandidate.my;if(_dx*_dx+_dy*_dy>16)p.clickCandidate=null;}
      localOnly=true;
      st.center_x=Math.max(0,Math.min(1,panStart.cx-(cmx-panStart.mx)/fr.w/z));
      st.center_y=Math.max(0,Math.min(1,panStart.cy-(cmy-panStart.my)/fr.h/z));
      draw2d(p);
      _propagateZoom2d(p);
      model.set(`panel_${p.id}_json`, _viewStateJson(p));
      _scheduleCommit(); e.preventDefault();
    });
    document.addEventListener('mouseup',(e)=>{
      settled.clear();
      if(p.ovDrag2d){
        // A brush stroke lived in the panel scratch for the whole drag (see
        // _brushLiveBegin) — fold it into p.state FIRST, so the generic push +
        // emit below is what ships the finished stroke to Python, exactly once.
        if(p._brushLive) _brushCommit(p);
        // Resolve by ID the way _brushCommit does — an echo may have replaced
        // p.state during the drag, and emitting the widget that happens to sit
        // at the drag's original INDEX would ship the wrong payload (for a
        // brush, another widget's dict in place of the finished stroke).
        const _wid=p.ovDrag2d.wid, _idx=p.ovDrag2d.idx;
        const _ws=p.state.overlay_widgets||[];
        const _dw=(_wid?_ws.find(x=>x&&x.id===_wid):null)||_ws[_idx]||{};
        const _did=_dw.id||null;
        p.ovDrag2d=null; overlayCanvas.style.cursor='default';
        model.set(`panel_${p.id}_json`, _viewStateJson(p));
        _emitEvent(p.id,'pointer_up',_did,{..._dw,..._pointerFields(e),button:e.button});
        return;
      }
      if(!p.isPanning) return;
      p.isPanning=false; overlayCanvas.style.cursor='default';
      const st=p.state; if(!st) return;
      const imgW=p.imgW||Math.max(1,p.pw-PAD_L-PAD_R), imgH=p.imgH||Math.max(1,p.ph-PAD_T-PAD_B);
      const fr=_imgFitRect(st.image_width,st.image_height,imgW,imgH);
      const {mx:cmx,my:cmy}=_clientPos(e,overlayCanvas,imgW,imgH);
      // ── Click detection: short-duration + small-movement mousedown/up ────────
      // Criteria: candidate still alive (not cleared by mousemove) AND ≤300 ms.
      // We also re-check final distance as a safety net for document-level moves
      // that didn't fire our mousemove guard (e.g. rapid trackpad flicks).
      if(p.clickCandidate){
        const _cc=p.clickCandidate; p.clickCandidate=null;
        const _dx=cmx-_cc.mx, _dy=cmy-_cc.my;
        const _dist2=_dx*_dx+_dy*_dy;
        const _dt=Date.now()-_cc.t;
        if(_dist2<=25&&_dt<=350){
          // Genuine click — skip pan-settle, emit pointer_down with image coords.
          const [imgX,imgY]=_canvasToImg2d(_cc.mx,_cc.my,st,imgW,imgH);
          const xArr=st.x_axis||[], yArr=st.y_axis||[];
          const _iw=st.image_width||1, _ih=st.image_height||1;
          const physX=xArr.length>=2?_axisFracToVal(xArr,imgX/_iw):imgX;
          const physY=yArr.length>=2?_axisFracToVal(yArr,imgY/_ih):imgY;
          _emitEvent(p.id,'pointer_down',null,{
            img_x:imgX, img_y:imgY,
            xdata:physX, ydata:physY,
            x:_cc.mx, y:_cc.my,
            ..._pointerFields(e),
            button:e.button,
          });
          // _emitEvent already calls model.save_changes() — no duplicate needed.
          return;
        }
      }
      // ── Normal pan settle ───────────────────────────────────────────────────
      st.center_x=Math.max(0,Math.min(1,panStart.cx-(cmx-panStart.mx)/fr.w/st.zoom));
      st.center_y=Math.max(0,Math.min(1,panStart.cy-(cmy-panStart.my)/fr.h/st.zoom));
      model.set(`panel_${p.id}_json`, _viewStateJson(p));
      _emitEvent(p.id,'pointer_up',null,{center_x:st.center_x,center_y:st.center_y,zoom:st.zoom,..._pointerFields(e),button:e.button});
      _emitViewChanged(p);   // pan settled → refresh the detail tile for the new view
      model.save_changes();
    });

    // Status bar + tooltip + widget hover cursor
    overlayCanvas.addEventListener('mousemove',(e)=>{
      const imgW=p.imgW||Math.max(1,p.pw-PAD_L-PAD_R), imgH=p.imgH||Math.max(1,p.ph-PAD_T-PAD_B);
      const {mx,my}=_clientPos(e,overlayCanvas,imgW,imgH);
      p.mouseX=mx; p.mouseY=my;
      if(p.ovDrag2d) return; // handled by document mousemove
      const st=p.state; if(!st) return;

      // Update cursor based on widget hit. Modifiers go in so holding Shift over
      // an armed brush previews the paint cursor (and so the brush does not
      // claim the cursor when it is NOT armed by the modifier).
      const whit=_ovHitTest2d(mx, my, p, {shift:e.shiftKey});
      if(whit){
        const m=whit.mode;
        overlayCanvas.style.cursor = m==='move' ? 'move'
          : (m==='paint'||m==='erase')          ? 'crosshair'
          : (m==='resize_br'||m==='resize_tl') ? 'nwse-resize'
          : (m==='resize_bl'||m==='resize_tr') ? 'nesw-resize'
          : (m==='resize_r'||m==='resize_ir')  ? 'ew-resize'
          : (m==='resize_head'||m==='resize_tail') ? 'crosshair'
          : m.startsWith('vertex_')            ? 'crosshair'
          : 'move';
      } else if(!p.isPanning){
        overlayCanvas.style.cursor='default';
      }

      const [ix,iy]=_canvasToImg2d(mx,my,st,imgW,imgH);
      // Position + pixel value → the status bar and/or the embedding host, then arm
      // the dwell probe that upgrades the value to full precision.
      p._hoverIn = true;
      const info = _updateStatus2d(p);
      _armValueProbe(p, ix, iy);
      if(info){
        const mhit=_markerHitTest2d(mx,my,st,imgW,imgH);
        const newSi=mhit?mhit.si:-1;
        if(newSi!==p._hoverSi){
          p._hoverSi=newSi; p._hoverI=mhit?mhit.i:-1;
          drawMarkers2d(p, mhit?{si:newSi}:null);
        }
        if(mhit&&(mhit.collectionLabel||mhit.markerLabel)){const parts=[];if(mhit.collectionLabel)parts.push(mhit.collectionLabel);if(mhit.markerLabel)parts.push(mhit.markerLabel);_showTooltip(parts.join('\n'),e.clientX,e.clientY);settled.clear();return;}
        tooltip.style.display='none';
      } else { tooltip.style.display='none';
        if(p._hoverSi!==-1){p._hoverSi=-1;p._hoverI=-1;drawMarkers2d(p,null);}
      }
      settled.arm(mx, my, e, () => {
        const st2 = p.state; if (!st2) return {};
        const imgW2 = p.imgW || Math.max(1, p.pw - PAD_L - PAD_R);
        const imgH2 = p.imgH || Math.max(1, p.ph - PAD_T - PAD_B);
        const [sImgX, sImgY] = _canvasToImg2d(p.mouseX, p.mouseY, st2, imgW2, imgH2);
        const sXArr = st2.x_axis || [], sYArr = st2.y_axis || [];
        const _siw = st2.image_width || 1, _sih = st2.image_height || 1;
        return {
          img_x:  sImgX, img_y:  sImgY,
          xdata:  sXArr.length >= 2 ? _axisFracToVal(sXArr, sImgX / _siw) : sImgX,
          ydata:  sYArr.length >= 2 ? _axisFracToVal(sYArr, sImgY / _sih) : sImgY,
        };
      });
    });
    overlayCanvas.addEventListener('mouseleave',(e)=>{
      settled.clear();
      clearTimeout(p._probeT); p._probeT=0;
      _emitEvent(p.id,'pointer_leave',null,{..._pointerFields(e),x:e.offsetX,y:e.offsetY});
      p._hoverIn=false;
      p.statusBar.style.display='none';tooltip.style.display='none';
      _notifyReadout(p, null);       // host clears its own readout too
      if(p._hoverSi!==-1){p._hoverSi=-1;p._hoverI=-1;drawMarkers2d(p,null);}
    });
    overlayCanvas.addEventListener('dblclick',(e)=>{
      const st=p.state; if(!st) return;
      const imgW=p.imgW||Math.max(1,p.pw-PAD_L-PAD_R), imgH=p.imgH||Math.max(1,p.ph-PAD_T-PAD_B);
      const {mx,my}=_clientPos(e,overlayCanvas,imgW,imgH);
      const [imgX,imgY]=_canvasToImg2d(mx,my,st,imgW,imgH);
      const xArr=st.x_axis||[], yArr=st.y_axis||[];
      const _iw=st.image_width||1, _ih=st.image_height||1;
      const physX=xArr.length>=2?_axisFracToVal(xArr,imgX/_iw):imgX;
      const physY=yArr.length>=2?_axisFracToVal(yArr,imgY/_ih):imgY;
      _emitEvent(p.id,'double_click',null,{..._pointerFields(e),button:e.button,x:mx,y:my,img_x:imgX,img_y:imgY,xdata:physX,ydata:physY});
    });

    // ── Tagged chrome double-clicks ──────────────────────────────────────────
    // The axis gutters, colorbar strip and title band are SEPARATE canvases
    // from the plot-area overlay above.  Double-clicking one emits a
    // `double_click` with a `target` field so a host can tell WHICH text
    // element was hit (axis label vs ticks vs title vs colorbar label).  The
    // zone splits mirror the metrics the draw code (_drawAxes2d) uses:
    //   • x gutter (xAxisCanvas, height PAD_B): the x_label is drawn along the
    //     BOTTOM (baseline ah-2) at `x_label_size` px, so the bottom band of
    //     height ceil(x_label_size)+3 is 'x_label'; everything above is
    //     'x_ticks'.  No label → whole gutter is 'x_ticks'.
    //   • y gutter (yAxisCanvas, width PAD_L): the y_label is drawn rotated in
    //     the LEFT strip; its horizontal reach is the same
    //     max(round(PAD_L*0.15), ceil(y_label_size*0.62)+1) translate plus the
    //     glyph half-height, so the left band of width ceil(y_label_size)+3 is
    //     'y_label'; the rest is 'y_ticks'.  No label → whole gutter 'y_ticks'.
    //   • colorbar (cbCanvas) → 'colorbar_label' everywhere on the strip.
    //   • title band (titleCanvas, height _padT) → 'title'; emits nothing
    //     outside the drawn band (there is none — the canvas IS the band).
    // Do NOT preventDefault (keeps the native click→dblclick cascade intact,
    // matching the plot-area handler).
    if (p.xAxisCanvas) {
      p.xAxisCanvas.addEventListener('dblclick', (e) => {
        const st = p.state; if (!st) return;
        const labelH = st.x_label ? Math.ceil(st.x_label_size || 11) + 3 : 0;
        const ah = p.xAxisCanvas.clientHeight || PAD_B;
        const target = (labelH && e.offsetY >= ah - labelH) ? 'x_label' : 'x_ticks';
        _emitEvent(p.id, 'double_click', null,
          { ..._pointerFields(e), button: e.button, x: e.offsetX, y: e.offsetY, target });
      });
    }
    if (p.yAxisCanvas) {
      p.yAxisCanvas.addEventListener('dblclick', (e) => {
        const st = p.state; if (!st) return;
        const labelW = st.y_label ? Math.ceil(st.y_label_size || 11) + 3 : 0;
        const target = (labelW && e.offsetX <= labelW) ? 'y_label' : 'y_ticks';
        _emitEvent(p.id, 'double_click', null,
          { ..._pointerFields(e), button: e.button, x: e.offsetX, y: e.offsetY, target });
      });
    }
    if (p.cbCanvas) {
      // cbCanvas is pointer-events:none by default (it's a passive strip) —
      // enable so it can receive the double-click.
      p.cbCanvas.style.pointerEvents = 'auto';
      p.cbCanvas.addEventListener('dblclick', (e) => {
        if (!p.state) return;
        _emitEvent(p.id, 'double_click', null,
          { ..._pointerFields(e), button: e.button, x: e.offsetX, y: e.offsetY,
            target: 'colorbar_label' });
      });
    }
    if (p.titleCanvas) {
      // titleCanvas is pointer-events:none by default — enable for the dblclick.
      p.titleCanvas.style.pointerEvents = 'auto';
      p.titleCanvas.addEventListener('dblclick', (e) => {
        if (!p.state) return;
        _emitEvent(p.id, 'double_click', null,
          { ..._pointerFields(e), button: e.button, x: e.offsetX, y: e.offsetY,
            target: 'title' });
      });
    }

    overlayCanvas.addEventListener('wheel',(e)=>{
      _emitEvent(p.id,'wheel',null,{
        time_stamp:performance.now()/1000,
        modifiers:_modifiers(e),
        x:p.mouseX??0, y:p.mouseY??0,
        dx:e.deltaX, dy:e.deltaY,
      });
    },{passive:true});

    // Keyboard shortcuts
    // Built-ins: r=reset zoom, c=colorbar toggle, l=log scale, s=symlog scale,
    // v=hover-readout toggle. All keys are forwarded to Python unconditionally.
    overlayCanvas.addEventListener('keydown',(e)=>{
      const st=p.state; if(!st) return;
      const imgW=p.imgW||Math.max(1,p.pw-PAD_L-PAD_R), imgH=p.imgH||Math.max(1,p.ph-PAD_T-PAD_B);
      const [imgX,imgY]=_canvasToImg2d(p.mouseX,p.mouseY,st,imgW,imgH);
      const xArr=st.x_axis||[], yArr=st.y_axis||[];
      const iw=st.image_width||1, ih=st.image_height||1;
      const physX=xArr.length>=2?_axisFracToVal(xArr,imgX/iw):imgX;
      const physY=yArr.length>=2?_axisFracToVal(yArr,imgY/ih):imgY;
      _emitEvent(p.id,'key_down',null,{
        time_stamp:performance.now()/1000,
        modifiers:_modifiers(e),
        key:e.key,
        last_widget_id:p.lastWidgetId||null,
        x:p.mouseX ?? 0, y:p.mouseY ?? 0,
        img_x:imgX, img_y:imgY,
        xdata:physX, ydata:physY,
      });
      // Modified keys belong to the host (Ctrl+C copy, Cmd+S save); the key_down
      // emit above already forwarded them to Python.
      if (e.ctrlKey || e.metaKey || e.altKey) return;
      const key=e.key.toLowerCase();
      if(key==='r'){
        st.zoom=1; st.center_x=0.5; st.center_y=0.5;
        draw2d(p); model.set(`panel_${p.id}_json`,_viewStateJson(p)); model.save_changes();
        e.stopPropagation(); e.preventDefault();
      } else if(key==='c'){
        st.show_colorbar=!st.show_colorbar;
        draw2d(p);
        model.set(`panel_${p.id}_json`,_viewStateJson(p)); model.save_changes();
        e.stopPropagation(); e.preventDefault();
      } else if(key==='l'){
        st.scale_mode=st.scale_mode==='log'?'linear':'log';
        draw2d(p); model.set(`panel_${p.id}_json`,_viewStateJson(p)); model.save_changes();
        e.stopPropagation(); e.preventDefault();
      } else if(key==='s'){
        st.scale_mode=st.scale_mode==='symlog'?'linear':'symlog';
        draw2d(p); model.set(`panel_${p.id}_json`,_viewStateJson(p)); model.save_changes();
        e.stopPropagation(); e.preventDefault();
      } else if(key==='v'){
        // Local show/hide of the on-image readout. Held on the PANEL rather than in
        // the state: a Python push (a movie scrub pushes every frame) must not undo
        // the viewer's toggle, and hover chrome has no business in the exported
        // state. set_readout_visible(False) from Python still hides it; pressing v
        // again re-shows it. The payload keeps flowing to an embedding host either
        // way (see _notifyReadout), so this only governs the pill.
        p.readoutHidden = !p.readoutHidden;
        _updateStatus2d(p);
        e.stopPropagation(); e.preventDefault();
      }
    });
    overlayCanvas.addEventListener('keyup',(e)=>{
      _emitEvent(p.id,'key_up',null,{
        time_stamp:performance.now()/1000,
        modifiers:_modifiers(e),
        key:e.key,
        x:p.mouseX??0, y:p.mouseY??0,
      });
    });
    overlayCanvas.addEventListener('mouseenter',(e)=>{
      overlayCanvas.focus();
      _emitEvent(p.id,'pointer_enter',null,{..._pointerFields(e),x:e.offsetX,y:e.offsetY});
    });
  }

  function _attachEvents1d(p) {
    const { overlayCanvas } = p;
    let localOnly = false;
    const _scheduleCommit = _makeCommitter(() => {
      localOnly = true; model.save_changes(); setTimeout(() => { localOnly = false; }, 200);
    });
    const settled = _makeSettledScheduler(p);

    // Wheel zoom
    overlayCanvas.addEventListener('wheel',(e)=>{
      e.preventDefault();
      const st=p.state; if(!st) return;
      const r=_plotRect1d(p);
      const {mx}=_clientPos(e,overlayCanvas,p.pw,p.ph);
      const frac=_canvasXToFrac1d(mx,st.view_x0,st.view_x1,r);
      const x0=st.view_x0, x1=st.view_x1, span=x1-x0;
      const factor=e.deltaY>0?1.15:0.87;
      let ns=Math.min(1,span*factor);
      let nx0=frac-(frac-x0)*(ns/span), nx1=nx0+ns;
      if(nx0<0){nx0=0;nx1=ns;}if(nx1>1){nx1=1;nx0=1-ns;}
      st.view_x0=nx0;st.view_x1=nx1;
      draw1d(p);
      _propagateView1d(p);
      model.set(`panel_${p.id}_json`,_viewStateJson(p));
      _scheduleCommit();
    },{passive:false});

    // Pan
    let panStart={};
    overlayCanvas.addEventListener('mousedown',(e)=>{
      if(e.button!==0) return;
      const st=p.state; if(!st) return;
      // Store raw client coords for the drag-vs-click threshold (visual pixels
      // are fine for that comparison — both endpoints use the same space).
      p._mousedownX=e.clientX; p._mousedownY=e.clientY;
      const {mx:_emx,my:_emy}=_clientPos(e,overlayCanvas,p.pw,p.ph);
      const hit=_ovHitTest1d(_emx, _emy, p);
      if(hit){p.ovDrag=hit;p.lastWidgetId=(p.state.overlay_widgets||[])[hit.idx]?.id||null;overlayCanvas.style.cursor=(hit.mode==='edge0'||hit.mode==='edge1')?'ew-resize':'move';e.preventDefault();return;}
      // Store pan start in canvas-px so pan delta in mousemove is canvas-px.
      panStart={mx:_emx,x0:st.view_x0,x1:st.view_x1};
      p.isPanning=true;overlayCanvas.style.cursor='grabbing';
      // Do NOT call e.preventDefault() — see 2D note: suppresses click → dblclick.
    });
    document.addEventListener('mousemove',(e)=>{
      if(p.ovDrag){
        _doDrag1d(e,p);
        const _dw=(p.state.overlay_widgets||[])[p.ovDrag.idx]||{};
        _emitEvent(p.id,'pointer_move',_dw.id||null,{..._dw,..._pointerFields(e)});
        return;
      }
      if(!p.isPanning) return;
      const st=p.state; if(!st) return;
      const r=_plotRect1d(p);
      const {mx:cmx}=_clientPos(e,overlayCanvas,p.pw,p.ph);
      const dx=(cmx-panStart.mx)/(r.w||1);
      const span=panStart.x1-panStart.x0;
      let nx0=panStart.x0-dx*span, nx1=panStart.x1-dx*span;
      if(nx0<0){nx0=0;nx1=span;}if(nx1>1){nx1=1;nx0=1-span;}
      st.view_x0=nx0;st.view_x1=nx1;
      draw1d(p);_propagateView1d(p);
      model.set(`panel_${p.id}_json`,_viewStateJson(p));_scheduleCommit();e.preventDefault();
    });
    document.addEventListener('mouseup',(e)=>{
      settled.clear();
      const wasWidgetDragging=!!p.ovDrag;   // capture BEFORE clearing
      const wasDragging=wasWidgetDragging||!!p.isPanning;
      if(p.ovDrag){
        const _idx=p.ovDrag.idx;
        const _dw=(p.state.overlay_widgets||[])[_idx]||{};
        const _did=_dw.id||null;
        p.ovDrag=null; overlayCanvas.style.cursor='crosshair';
        model.set(`panel_${p.id}_json`,_viewStateJson(p));
        _emitEvent(p.id,'pointer_up',_did,{..._dw,..._pointerFields(e),button:e.button});
      }
      if(p.isPanning){
        p.isPanning=false; overlayCanvas.style.cursor='crosshair';
        const st=p.state;
        if(st) _emitEvent(p.id,'pointer_up',null,{view_x0:st.view_x0,view_x1:st.view_x1,..._pointerFields(e),button:e.button});
      }
      // Click: fire when no widget was being dragged and mouse barely moved.
      // NOTE: p.isPanning is always set true on mousedown (pan start), so we
      // deliberately only block on wasWidgetDragging here — the distance
      // threshold below already excludes real pan gestures.
      //
      // A click always emits exactly one pointer_down carrying the clicked
      // position in data coords, mirroring 2-D panels. When the click also
      // landed on a line, line_id (and the snapped on-line x/y) come along —
      // that is the pre-existing line-click contract, kept intact.
      if(!wasWidgetDragging && p._mousedownX!=null){
        const mdx=e.clientX-p._mousedownX, mdy=e.clientY-p._mousedownY;
        if(Math.hypot(mdx,mdy)<5){
          const {mx,my}=_clientPos(e,overlayCanvas,p.pw,p.ph);
          const st=p.state;
          const r=_plotRect1d(p);
          const inPlot = st && mx>=r.x && mx<=r.x+r.w && my>=r.y && my<=r.y+r.h;
          if(inPlot){
            const lhit=_lineHitTest1d(mx,my,p);
            const xArr=p._1dXArr||(st.x_axis_b64?_decodeF64(st.x_axis_b64):(st.x_axis||[]));
            const frac=_canvasXToFrac1d(mx,st.view_x0||0,st.view_x1||1,r);
            const physX=xArr.length>=2?_axisFracToVal(xArr,frac):frac;
            const dMin=st.data_min, dMax=st.data_max;
            const physY=dMin+(r.y+r.h-my)/(r.h||1)*(dMax-dMin);
            _emitEvent(p.id,'pointer_down',null,{
              ...(lhit?{line_id:lhit.lineId}:{}),
              // On-line coords when a line was hit, else the raw click point.
              x:lhit?lhit.x:physX, y:lhit?lhit.y:physY,
              xdata:physX, ydata:physY,
              ..._pointerFields(e),
              button:e.button,
            });
          }
        }
      }
      p._mousedownX=null;
    });

    // Keyboard shortcuts
    // Built-in: r=reset view. All keys are forwarded to Python unconditionally.
    overlayCanvas.addEventListener('keydown',(e)=>{
      const st=p.state; if(!st) return;
      const r=_plotRect1d(p);
      const xArr = p._1dXArr || (st.x_axis_b64 ? _decodeF64(st.x_axis_b64) : (st.x_axis||[]));
      const frac=_canvasXToFrac1d(p.mouseX,st.view_x0,st.view_x1,r);
      const physX=xArr.length>=2?_axisFracToVal(xArr,frac):frac;
      _emitEvent(p.id,'key_down',null,{
        time_stamp:performance.now()/1000,
        modifiers:_modifiers(e),
        key:e.key,
        last_widget_id:p.lastWidgetId||null,
        x:p.mouseX ?? 0, y:p.mouseY ?? 0,
        xdata:physX,
      });
      // Modified keys belong to the host (Ctrl+C copy, Cmd+S save); the key_down
      // emit above already forwarded them to Python.
      if (e.ctrlKey || e.metaKey || e.altKey) return;
      if(e.key.toLowerCase()==='r'){st.view_x0=0;st.view_x1=1;draw1d(p);model.set(`panel_${p.id}_json`,_viewStateJson(p));model.save_changes();e.stopPropagation();e.preventDefault();}
    });
    overlayCanvas.addEventListener('keyup',(e)=>{
      _emitEvent(p.id,'key_up',null,{
        time_stamp:performance.now()/1000,
        modifiers:_modifiers(e),
        key:e.key,
        x:p.mouseX??0, y:p.mouseY??0,
      });
    });
    overlayCanvas.tabIndex=0;overlayCanvas.style.outline='none';
    overlayCanvas.addEventListener('mouseenter',(e)=>{
      overlayCanvas.focus();
      _emitEvent(p.id,'pointer_enter',null,{..._pointerFields(e),x:e.offsetX,y:e.offsetY});
    });
    overlayCanvas.addEventListener('mousemove',(e)=>{
      const st=p.state;if(!st)return;
      const {mx,my}=_clientPos(e,overlayCanvas,p.pw,p.ph);
      p.mouseX=mx; p.mouseY=my;
      const r=_plotRect1d(p);
      if(mx<r.x||mx>r.x+r.w||my<r.y||my>r.y+r.h){
        p.statusBar.style.display='none';tooltip.style.display='none';
        if(p._hoverSi!==-1){p._hoverSi=-1;p._hoverI=-1;drawMarkers1d(p,null);}
        settled.clear();
        return;
      }
      const xArr = p._1dXArr || (st.x_axis_b64 ? _decodeF64(st.x_axis_b64) : (st.x_axis||[]));
      const frac=_canvasXToFrac1d(mx,st.view_x0,st.view_x1,r);
      const phys=xArr.length>=2?_axisFracToVal(xArr,frac):frac;
      p.statusBar.textContent=`x:${fmtVal(phys)}`;p.statusBar.style.display='block';
      const mhit=_markerHitTest1d(mx,my,p);
      const newSi=mhit?mhit.si:-1;
      if(newSi!==p._hoverSi){
        p._hoverSi=newSi; p._hoverI=mhit?mhit.i:-1;
        drawMarkers1d(p, mhit?{si:newSi}:null);
      }
      if(mhit&&(mhit.collectionLabel||mhit.markerLabel)){const parts=[];if(mhit.collectionLabel)parts.push(mhit.collectionLabel);if(mhit.markerLabel)parts.push(mhit.markerLabel);_showTooltip(parts.join('\n'),e.clientX,e.clientY);return;}
      tooltip.style.display='none';
      // Line hover — only when no widget is being dragged
      if(!p.ovDrag){
        const lhit=_lineHitTest1d(mx,my,p);
        const newLid=lhit?lhit.lineId:'__none__';
        if(newLid!==p._lineHoverId){
          p._lineHoverId=newLid;
          draw1d(p);  // redraw so hovered line is brightened
          drawOverlay1d(p);
          overlayCanvas.style.cursor=lhit?'pointer':'crosshair';
          if(lhit){
            p.ovCtx.save();p.ovCtx.fillStyle='rgba(255,255,255,0.9)';
            p.ovCtx.strokeStyle='rgba(0,0,0,0.5)';p.ovCtx.lineWidth=1.5;
            p.ovCtx.beginPath();p.ovCtx.arc(lhit.canvasPx,lhit.canvasPy,4,0,Math.PI*2);
            p.ovCtx.fill();p.ovCtx.stroke();p.ovCtx.restore();
          }
        }
        if(lhit) _emitEvent(p.id,'pointer_move',null,{line_id:lhit.lineId,x:lhit.x,y:lhit.y,..._pointerFields(e)});
      }
      settled.arm(mx, my, e);
    });
    overlayCanvas.addEventListener('mouseleave',(e)=>{
      settled.clear();
      _emitEvent(p.id,'pointer_leave',null,{..._pointerFields(e),x:e.offsetX,y:e.offsetY});
      p.statusBar.style.display='none';tooltip.style.display='none';
      if(p._hoverSi!==-1){p._hoverSi=-1;p._hoverI=-1;drawMarkers1d(p,null);}
      if(p._lineHoverId!=='__none__'){p._lineHoverId='__none__';draw1d(p);drawOverlay1d(p);overlayCanvas.style.cursor='crosshair';}
    });
    overlayCanvas.addEventListener('dblclick',(e)=>{
      const {mx,my}=_clientPos(e,overlayCanvas,p.pw,p.ph);
      const st=p.state;
      let xdata=null, ydata=null;
      if(st){
        const r=_plotRect1d(p);
        const xArr=p._1dXArr||(st.x_axis_b64?_decodeF64(st.x_axis_b64):(st.x_axis||[]));
        const frac=_canvasXToFrac1d(mx,st.view_x0,st.view_x1,r);
        xdata=xArr.length>=2?_axisFracToVal(xArr,frac):frac;
        // ydata: invert the linear y transform. Prefer the bounds draw1d cached
        // (exactly what was rendered) — for a coordinate axis (PlotXY) data_min
        // may be the zero-curve's range, so y_range / the cache is authoritative.
        let dMin=(p._1dDMin!=null?p._1dDMin:st.data_min), dMax=(p._1dDMax!=null?p._1dDMax:st.data_max);
        if(dMin==null && st.y_range && st.y_range.length===2){ dMin=st.y_range[0]; dMax=st.y_range[1]; }
        if(dMin!=null && dMax!=null) ydata=dMin+((r.y+r.h-my)/(r.h||1))*(dMax-dMin);

        // ── Tagged chrome hit-tests (priority order) ─────────────────────────
        // The 1D panel is a SINGLE canvas: the plot rect `r` plus the title
        // strip (top), the x gutter (below r) and the y gutter (left of r).
        // Test the chrome zones first; if the cursor is over one, emit a
        // `double_click` with the matching `target` and stop.  Metrics mirror
        // the 1D draw code:
        //   • legend  → inside the cached p._legendRect (canvas px).
        //   • title   → title present AND my < r.y (the fixed PAD_T top strip
        //               the 1D title is drawn in at baseline PAD_T/2).
        //   • x gutter (my > r.y+r.h): bottom band of height
        //     ceil(x_label_size)+3 → 'x_label'; rest → 'x_ticks'.
        //   • y gutter (mx < r.x): left band of width ceil(y_label_size)+3 →
        //     'y_label'; rest → 'y_ticks'.
        let target=null;
        const lr=p._legendRect;
        if(lr && mx>=lr.x && mx<=lr.x+lr.w && my>=lr.y && my<=lr.y+lr.h){
          target='legend';
        } else if(st.title && my < r.y){
          target='title';
        } else if(my > r.y+r.h){
          const labelH=Math.ceil(st.x_label_size||11)+3;
          target=(my >= p.ph-labelH) ? 'x_label' : 'x_ticks';
        } else if(mx < r.x){
          const labelW=Math.ceil(st.y_label_size||11)+3;
          target=(mx <= labelW) ? 'y_label' : 'y_ticks';
        }
        if(target){
          _emitEvent(p.id,'double_click',null,{..._pointerFields(e),button:e.button,x:mx,y:my,xdata,ydata,target});
          return;
        }
      }
      _emitEvent(p.id,'double_click',null,{..._pointerFields(e),button:e.button,x:mx,y:my,xdata,ydata});
    });
    overlayCanvas.addEventListener('wheel',(e)=>{
      _emitEvent(p.id,'wheel',null,{
        time_stamp:performance.now()/1000,
        modifiers:_modifiers(e),
        x:p.mouseX??0, y:p.mouseY??0,
        dx:e.deltaX, dy:e.deltaY,
      });
    },{passive:true});
  }

  // ── 2D overlay widget hit-test & drag ────────────────────────────────────
  // Returns {idx, mode, snapW, ...} describing which widget and handle was hit.
  // mode values:
  //   'move'       – drag the whole widget body
  //   'resize_r'   – circle/annular outer-radius handle (right)
  //   'resize_ir'  – annular inner-radius handle
  //   'resize_br'  – rectangle bottom-right corner
  //   'resize_bl'  – rectangle bottom-left corner
  //   'resize_tr'  – rectangle top-right corner
  //   'resize_tl'  – rectangle top-left corner
  //   'vertex_N'   – polygon vertex N
  //   'paint'      – armed brush, Shift+drag lays down a stroke
  //   'erase'      – armed brush in erase mode
  //
  // `mods` (optional) carries the mousedown/hover modifier state, currently
  // only `{shift}`. Callers that pass nothing can never get a brush hit.
  function _ovHitTest2d(mx, my, p, mods) {
    const st = p.state; if (!st) return null;
    const imgW = p.imgW||Math.max(1, p.pw - PAD_L - PAD_R);
    const imgH = p.imgH||Math.max(1, p.ph - PAD_T - PAD_B);
    const widgets = st.overlay_widgets || [];
    const scale   = _imgScale2d(st, imgW, imgH);
    const HR = 9; // handle grab radius (px)

    // ── First pass: an ARMED brush under a Shift-drag wins outright ──────────
    // A brush's body is "anywhere in the image", so it must NOT be a hit in the
    // ordinary sense — that would kill panning and click-to-select. Instead it
    // takes the drag only when the caller reports Shift held, and then it takes
    // it absolutely: painting is modal, and a scribble across the image must not
    // be stolen half way by whatever widget happens to sit under the cursor
    // (which is what a z-order-dependent hit in the main loop below would do).
    // Nothing claims a brush hit without the modifier, so a BARE drag still pans
    // and still drags every other widget. Mirrors the "first pass" precedent in
    // _ovHitTest1d, where point widgets outrank the range band they sit in.
    // `silent` tells the drag loop this gesture emits nothing until release.
    //
    // The START must be inside the image. `_brushPaintAt` drops out-of-image
    // points, so a gesture begun in the axis margin would claim the drag and
    // then paint nothing — a dead zone that also swallowed the pan. Leaving the
    // image MID-stroke is still fine (it just breaks the stroke).
    if (mods && mods.shift && _inImage2d(mx, my, st, imgW, imgH)) {
      for (let i = widgets.length - 1; i >= 0; i--) {
        const w = widgets[i];
        if (w.type !== 'brush') continue;
        if (w.visible === false || w.active === false) continue;
        return { idx:i, mode: w.erase ? 'erase' : 'paint', silent:true, _gap:true,
                 snapW:{...w}, startMX:mx, startMY:my };
      }
    }

    // iterate top-to-bottom (last drawn = topmost)
    for (let i = widgets.length - 1; i >= 0; i--) {
      const w = widgets[i];
      if(w.visible === false) continue;
      if (w.type === 'circle') {
        const [ccx, ccy] = _imgToCanvas2d(w.cx, w.cy, st, imgW, imgH);
        const cr = w.r * scale;
        // outer radius handle
        if (Math.hypot(mx - (ccx + cr), my - ccy) <= HR)
          return { idx:i, mode:'resize_r', snapW:{...w}, startMX:mx, startMY:my };
        // body (inside ring ± tolerance). `lock_center` refuses the grab
        // outright rather than letting the drag run and correcting afterwards:
        // a centre snapped back on release still tracks the cursor for the
        // whole drag, which reads as a broken lock. Refusing here also leaves
        // the hover cursor at 'default' and lets the drag fall through to the
        // plot's own pan, so the ring is simply not a handle any more.
        if (w.lock_center) continue;
        if (Math.abs(Math.hypot(mx-ccx, my-ccy) - cr) <= Math.max(HR, cr*0.18) ||
            Math.hypot(mx-ccx, my-ccy) <= HR)
          return { idx:i, mode:'move', snapW:{...w}, startMX:mx, startMY:my };

      } else if (w.type === 'annular') {
        const [ccx, ccy] = _imgToCanvas2d(w.cx, w.cy, st, imgW, imgH);
        const ro = w.r_outer * scale, ri = w.r_inner * scale;
        // inner-radius handle (above centre, inside inner ring)
        if (Math.hypot(mx - (ccx + ri), my - (ccy - ri * 0.3)) <= HR)
          return { idx:i, mode:'resize_ir', snapW:{...w}, startMX:mx, startMY:my };
        // outer-radius handle
        if (Math.hypot(mx - (ccx + ro), my - ccy) <= HR)
          return { idx:i, mode:'resize_r', snapW:{...w}, startMX:mx, startMY:my };
        // body (annular band)
        const d = Math.hypot(mx - ccx, my - ccy);
        if (d >= ri - HR && d <= ro + HR)
          return { idx:i, mode:'move', snapW:{...w}, startMX:mx, startMY:my };

      } else if (w.type === 'rectangle') {
        const [rx, ry] = _imgToCanvas2d(w.x, w.y, st, imgW, imgH);
        const rw = w.w * scale, rh = w.h * scale;
        if (Math.hypot(mx-(rx+rw), my-(ry+rh)) <= HR) return { idx:i, mode:'resize_br', snapW:{...w}, startMX:mx, startMY:my };
        if (Math.hypot(mx-rx,      my-(ry+rh)) <= HR) return { idx:i, mode:'resize_bl', snapW:{...w}, startMX:mx, startMY:my };
        if (Math.hypot(mx-(rx+rw), my-ry)      <= HR) return { idx:i, mode:'resize_tr', snapW:{...w}, startMX:mx, startMY:my };
        if (Math.hypot(mx-rx,      my-ry)      <= HR) return { idx:i, mode:'resize_tl', snapW:{...w}, startMX:mx, startMY:my };
        if (mx >= rx-HR && mx <= rx+rw+HR && my >= ry-HR && my <= ry+rh+HR)
          return { idx:i, mode:'move', snapW:{...w}, startMX:mx, startMY:my };

      } else if (w.type === 'crosshair') {
        const [ccx, ccy] = _imgToCanvas2d(w.cx, w.cy, st, imgW, imgH);
        // Centre hotspot moves both axes at once.
        if (Math.hypot(mx-ccx, my-ccy) <= HR + 4)
          return { idx:i, mode:'move', snapW:{...w}, startMX:mx, startMY:my };
        // Anywhere along either rule is also a grab target: for a line-style
        // pointer the lines ARE the widget, and requiring the user to find a
        // one-pixel intersection made it feel broken.  Grabbing a rule
        // constrains the drag to that rule's own axis.
        if (Math.abs(mx-ccx) <= HR)
          return { idx:i, mode:'move_x', snapW:{...w}, startMX:mx, startMY:my };
        if (Math.abs(my-ccy) <= HR)
          return { idx:i, mode:'move_y', snapW:{...w}, startMX:mx, startMY:my };

      } else if (w.type === 'vline') {
        const [vx] = _imgToCanvas2d(w.x, 0, st, imgW, imgH);
        if (Math.abs(mx - vx) <= HR)
          return { idx:i, mode:'move', snapW:{...w}, startMX:mx, startMY:my };

      } else if (w.type === 'hline') {
        const [, hy] = _imgToCanvas2d(0, w.y, st, imgW, imgH);
        if (Math.abs(my - hy) <= HR)
          return { idx:i, mode:'move', snapW:{...w}, startMX:mx, startMY:my };

      } else if (w.type === 'line') {
        const [ax, ay] = _imgToCanvas2d(w.x1, w.y1, st, imgW, imgH);
        const [bx, by] = _imgToCanvas2d(w.x2, w.y2, st, imgW, imgH);
        if (Math.hypot(mx-ax, my-ay) <= HR)
          return { idx:i, mode:'move_p1', snapW:{...w}, startMX:mx, startMY:my };
        if (Math.hypot(mx-bx, my-by) <= HR)
          return { idx:i, mode:'move_p2', snapW:{...w}, startMX:mx, startMY:my };
        if (_distToSegment2d(mx, my, ax, ay, bx, by) <= HR)
          return { idx:i, mode:'move', snapW:{...w}, startMX:mx, startMY:my };

      } else if (w.type === 'polygon') {
        const verts = w.vertices || [];
        for (let k = 0; k < verts.length; k++) {
          const [px, py] = _imgToCanvas2d(verts[k][0], verts[k][1], st, imgW, imgH);
          if (Math.hypot(mx-px, my-py) <= HR)
            return { idx:i, mode:`vertex_${k}`, snapW:{...w, vertices: verts.map(v=>[...v])}, startMX:mx, startMY:my };
        }
        // hit inside polygon → move whole polygon
        if (_pointInPolygon2d(mx, my, verts, st, imgW, imgH))
          return { idx:i, mode:'move', snapW:{...w, vertices: verts.map(v=>[...v])}, startMX:mx, startMY:my };

      } else if (w.type === 'label') {
        const [lx, ly] = _imgToCanvas2d(w.x, w.y, st, imgW, imgH);
        if (Math.hypot(mx-lx, my-ly) <= HR + 6)
          return { idx:i, mode:'move', snapW:{...w}, startMX:mx, startMY:my };

      } else if (w.type === 'arrow') {
        const [tx, ty] = _imgToCanvas2d(w.x, w.y, st, imgW, imgH);
        const [hx, hy] = _imgToCanvas2d(w.x + w.u, w.y + w.v, st, imgW, imgH);
        // head handle → re-aim the arrow (head moves, tail fixed)
        if (Math.hypot(mx-hx, my-hy) <= HR)
          return { idx:i, mode:'resize_head', snapW:{...w}, startMX:mx, startMY:my };
        // tail handle → reshape (tail moves, HEAD stays anchored)
        if (Math.hypot(mx-tx, my-ty) <= HR)
          return { idx:i, mode:'resize_tail', snapW:{...w}, startMX:mx, startMY:my };
        // near the shaft → move whole arrow
        if (_distToSegment2d(mx, my, tx, ty, hx, hy) <= HR)
          return { idx:i, mode:'move', snapW:{...w}, startMX:mx, startMY:my };
      }
    }
    return null;
  }

  // Perpendicular distance from point (px,py) to the segment (ax,ay)-(bx,by).
  function _distToSegment2d(px, py, ax, ay, bx, by) {
    const dx = bx - ax, dy = by - ay;
    const len2 = dx*dx + dy*dy;
    if (len2 === 0) return Math.hypot(px-ax, py-ay);
    let t = ((px-ax)*dx + (py-ay)*dy) / len2;
    t = Math.max(0, Math.min(1, t));
    return Math.hypot(px - (ax + t*dx), py - (ay + t*dy));
  }

  function _pointInPolygon2d(mx, my, verts, st, imgW, imgH) {
    let inside = false;
    const cverts = verts.map(v => _imgToCanvas2d(v[0], v[1], st, imgW, imgH));
    for (let i = 0, j = cverts.length-1; i < cverts.length; j = i++) {
      const [xi,yi] = cverts[i], [xj,yj] = cverts[j];
      if (((yi>my)!==(yj>my)) && (mx < (xj-xi)*(my-yi)/(yj-yi)+xi)) inside = !inside;
    }
    return inside;
  }

  // ── brush stroke accumulation ─────────────────────────────────────────────
  // The stroke being drawn lives in a per-panel SCRATCH (`p._brushLive`), not in
  // `p.state.overlay_widgets`, and reaches the model only on mouseup. Both halves
  // of that are load-bearing:
  //
  //  * PERF — widget drags here are unthrottled. Every document mousemove ends
  //    `_doDrag2d` with a full `_viewStateJson` serialise + `save_changes()`, and
  //    the caller then spreads the whole widget dict into an `event_json`. A
  //    stroke growing by a point per tick would re-serialise, re-transmit and
  //    re-diff the ENTIRE stroke list on every tick — O(n²) over one stroke,
  //    which makes painting unusable.
  //  * CORRECTNESS — precisely because we do NOT write the panel trait during the
  //    stroke, the trait stays STALE for its whole duration. Any unrelated
  //    `save_changes()` (the `pointer_leave` emit as the cursor crosses the panel
  //    edge — routine when painting near an edge — a key event, a Python-side
  //    push) re-fires `change:panel_<id>_json`, which replaces `p.state`
  //    wholesale from that stale value. A stroke accumulated in `p.state` is
  //    silently wiped by it mid-drag. The scratch survives, and `drawOverlay2d`
  //    prefers it, so the stroke also survives the redraw that echo triggers.
  //
  // Same shape as the inset drag: `_doInsetDrag` mutates live, `_endInsetDrag`
  // emits once (see `inset_geometry_change` in figure/_figure.py).

  // Snapshot the widget's committed strokes into the scratch. Each stroke array
  // is copied so appends never touch p.state's own arrays (the point pairs are
  // shared but only ever read).
  function _brushLiveBegin(p, w) {
    p._brushLive = {
      wid: w.id,
      radius: (w.radius != null ? w.radius : 8),
      class_id: w.class_id | 0,
      strokes: (w.strokes || []).map(s => s.slice()),
      classes: (w.stroke_classes || []).slice(),
    };
    return p._brushLive;
  }

  // Fold the scratch back into p.state. Resolves the widget by ID, not by the
  // drag's index, because an echo may have replaced p.state (and its widget
  // objects) at any point during the stroke.
  function _brushCommit(p) {
    const L = p._brushLive; p._brushLive = null;
    if (!L || !p.state) return;
    const w = (p.state.overlay_widgets || []).find(x => x && x.id === L.wid);
    if (w) { w.strokes = L.strokes; w.stroke_classes = L.classes; }
  }

  function _brushBegin(L, ix, iy) {
    L.strokes.push([[ix, iy]]);
    L.classes.push(L.class_id);
  }

  function _brushAppend(L, ix, iy) {
    if (!L.strokes.length) { _brushBegin(L, ix, iy); return; }
    const cur  = L.strokes[L.strokes.length - 1];
    const last = cur[cur.length - 1];
    // Resample. A mousemove can fire many times per image pixel when zoomed in,
    // and every point ends up on the wire on release — so drop points closer
    // than a quarter of the brush radius. The round joins hide the coarser
    // polyline; nothing visible is lost.
    const step = Math.max(0.5, L.radius * 0.25);
    if (last && Math.hypot(ix - last[0], iy - last[1]) < step) return;
    cur.push([ix, iy]);
  }

  // Erase = drop every stroke point within `radius` image px of (ix,iy), then
  // keep each surviving RUN of consecutive points as its own stroke. Filtering
  // a stroke in place instead would rejoin its two ends with one long straight
  // segment straight across the gap the user just erased.
  function _brushErase(L, ix, iy) {
    const r2 = L.radius * L.radius;
    const src = L.strokes, cls = L.classes;
    const outS = [], outC = [];
    for (let s = 0; s < src.length; s++) {
      const pts = src[s] || [], ci = cls[s] | 0;
      let run = [];
      for (let k = 0; k < pts.length; k++) {
        const dx = pts[k][0] - ix, dy = pts[k][1] - iy;
        if (dx*dx + dy*dy <= r2) {
          if (run.length) { outS.push(run); outC.push(ci); }
          run = [];
        } else run.push(pts[k]);
      }
      if (run.length) { outS.push(run); outC.push(ci); }
    }
    L.strokes = outS; L.classes = outC;
  }

  // Is CANVAS point (mx,my) over the image itself (not the axis margin)? Same
  // bounds rule `_brushPaintAt` applies, so the hit-test can refuse to start a
  // stroke exactly where painting would drop every point.
  function _inImage2d(mx, my, st, imgW, imgH) {
    const [ix, iy] = _canvasToImg2d(mx, my, st, imgW, imgH);
    return ix >= 0 && ix < st.image_width && iy >= 0 && iy < st.image_height;
  }

  // Extend (or start) the brush's stroke at image point (ix,iy). Shared by
  // mousedown (so a Shift-CLICK with no motion still paints one dot) and the
  // drag loop. Points OUTSIDE the image are dropped and re-entry starts a NEW
  // stroke: a label coordinate outside the array is useless to a consumer (and
  // a negative index silently wraps), while bridging the gap would draw a
  // straight segment across ground the user never painted. `d._gap` is the
  // per-drag "next in-bounds point starts a stroke" flag — the hit-test seeds
  // it true, which is what makes mousedown open a fresh stroke.
  function _brushPaintAt(L, st, ix, iy, d) {
    if (!(ix >= 0 && ix < st.image_width && iy >= 0 && iy < st.image_height)) {
      d._gap = true; return;
    }
    if (d.mode === 'erase') { _brushErase(L, ix, iy); return; }
    if (d._gap) { _brushBegin(L, ix, iy); d._gap = false; return; }
    _brushAppend(L, ix, iy);
  }

  function _doDrag2d(e, p) {
    const st = p.state; if (!st) return;
    const imgW = p.imgW||Math.max(1, p.pw - PAD_L - PAD_R);
    const imgH = p.imgH||Math.max(1, p.ph - PAD_T - PAD_B);
    const {mx, my} = _clientPos(e, p.overlayCanvas, imgW, imgH);
    const d     = p.ovDrag2d;
    const s     = d.snapW;
    const w     = st.overlay_widgets[d.idx];
    const scale = _imgScale2d(st, imgW, imgH);

    // Convert current mouse to image coords
    const [imgMX, imgMY] = _canvasToImg2d(mx, my, st, imgW, imgH);
    // delta in image pixels from drag-start
    const [imgSX, imgSY] = _canvasToImg2d(d.startMX, d.startMY, st, imgW, imgH);
    const dix = imgMX - imgSX, diy = imgMY - imgSY;

    // ── Brush: paint/erase into the panel scratch, publish NOTHING ───────────
    // Redraws the overlay locally and returns BEFORE the `_viewStateJson` +
    // `save_changes()` tail below; the mouseup handler commits the scratch and
    // ships the finished stroke once. See `_brushLiveBegin` for why.
    // Gated on the drag MODE rather than the widget type: an echo can have
    // swapped `p.state` (and therefore `w`) out from under us mid-stroke.
    if (d.mode === 'paint' || d.mode === 'erase') {
      if (p._brushLive) _brushPaintAt(p._brushLive, st, imgMX, imgMY, d);
      drawOverlay2d(p);
      e.preventDefault();
      return;
    }

    if (w.type === 'circle') {
      // A drag already in flight when `lock_center` is turned on must not keep
      // translating the widget: the hit-test gate only runs at grab time.
      if (d.mode === 'move' && !w.lock_center) {
        w.cx = s.cx + dix; w.cy = s.cy + diy;
      } else if (d.mode === 'resize_r') {
        // distance from centre in image-px
        const [ccx, ccy] = _imgToCanvas2d(s.cx, s.cy, st, imgW, imgH);
        w.r = Math.max(1, Math.hypot(mx-ccx, my-ccy) / scale);
      }
    } else if (w.type === 'annular') {
      if (d.mode === 'move') {
        w.cx = s.cx + dix; w.cy = s.cy + diy;
      } else if (d.mode === 'resize_r') {
        const [ccx, ccy] = _imgToCanvas2d(s.cx, s.cy, st, imgW, imgH);
        const newR = Math.max(s.r_inner + 1, Math.hypot(mx-ccx, my-ccy) / scale);
        w.r_outer = newR;
      } else if (d.mode === 'resize_ir') {
        const [ccx, ccy] = _imgToCanvas2d(s.cx, s.cy, st, imgW, imgH);
        const newR = Math.max(1, Math.min(s.r_outer - 1, Math.hypot(mx-ccx, my-ccy) / scale));
        w.r_inner = newR;
      }
    } else if (w.type === 'rectangle') {
      // max_w / max_h cap the rectangle DURING the drag, so it physically stops
      // growing rather than being silently clamped afterwards. Each branch pins
      // the size and leaves the OPPOSITE corner where it is, so the anchor never
      // shifts and the rectangle cannot jump out from under the cursor.
      const capW = (v) => (w.max_w == null ? v : Math.min(v, w.max_w));
      const capH = (v) => (w.max_h == null ? v : Math.min(v, w.max_h));
      if (d.mode === 'move') {
        w.x = s.x + dix; w.y = s.y + diy;
      } else if (d.mode === 'resize_br') {
        w.w = capW(Math.max(1, s.w + dix)); w.h = capH(Math.max(1, s.h + diy));
      } else if (d.mode === 'resize_bl') {
        const newW = capW(Math.max(1, s.w - dix));
        w.x = s.x + (s.w - newW); w.w = newW;
        w.h = capH(Math.max(1, s.h + diy));
      } else if (d.mode === 'resize_tr') {
        w.w = capW(Math.max(1, s.w + dix));
        const newH = capH(Math.max(1, s.h - diy));
        w.y = s.y + (s.h - newH); w.h = newH;
      } else if (d.mode === 'resize_tl') {
        const newW = capW(Math.max(1, s.w - dix));
        w.x = s.x + (s.w - newW); w.w = newW;
        const newH = capH(Math.max(1, s.h - diy));
        w.y = s.y + (s.h - newH); w.h = newH;
      }
    } else if (w.type === 'crosshair') {
      // Grabbing a single rule constrains the drag to that rule's own axis;
      // grabbing the centre moves both (see _ovHitTest2d).
      if (d.mode === 'move_x')      { w.cx = s.cx + dix; }
      else if (d.mode === 'move_y') { w.cy = s.cy + diy; }
      else                          { w.cx = s.cx + dix; w.cy = s.cy + diy; }
    } else if (w.type === 'vline') {
      w.x = s.x + dix;
    } else if (w.type === 'hline') {
      w.y = s.y + diy;
    } else if (w.type === 'line') {
      if (d.mode === 'move') {
        w.x1 = s.x1 + dix; w.y1 = s.y1 + diy;
        w.x2 = s.x2 + dix; w.y2 = s.y2 + diy;
      } else if (d.mode === 'move_p1') {
        w.x1 = imgMX; w.y1 = imgMY;
      } else if (d.mode === 'move_p2') {
        w.x2 = imgMX; w.y2 = imgMY;
      }
    } else if (w.type === 'polygon') {
      if (d.mode === 'move') {
        w.vertices = s.vertices.map(v => [v[0]+dix, v[1]+diy]);
      } else if (d.mode.startsWith('vertex_')) {
        const k = parseInt(d.mode.slice(7));
        w.vertices = s.vertices.map((v,j) => j===k ? [imgMX, imgMY] : [...v]);
      }
    } else if (w.type === 'label') {
      w.x = s.x + dix; w.y = s.y + diy;
    } else if (w.type === 'arrow') {
      if (d.mode === 'move') {
        w.x = s.x + dix; w.y = s.y + diy;
      } else if (d.mode === 'resize_head') {
        // head follows the cursor → u,v = imgMouse − tail (tail fixed)
        w.u = imgMX - s.x; w.v = imgMY - s.y;
      } else if (d.mode === 'resize_tail') {
        // tail follows the cursor, HEAD stays anchored: the fixed head is
        // (s.x + s.u, s.y + s.v).  x,y = tail; u,v = head − tail so the head
        // point is invariant under the drag.
        w.x = s.x + dix; w.y = s.y + diy;
        w.u = s.u - dix; w.v = s.v - diy;
      }
    }

    drawOverlay2d(p);
    model.set(`panel_${p.id}_json`, _viewStateJson(p));
    model.save_changes();
    e.preventDefault();
  }

  function _canvasXToFrac1d(px,x0,x1,r){return x0+((px-r.x)/(r.w||1))*(x1-x0);}

  function _ovHitTest1d(mx,my,p){
    const st=p.state;if(!st)return null;
    const r=_plotRect1d(p);
    const xArr = p._1dXArr || (st.x_axis_b64 ? _decodeF64(st.x_axis_b64) : (st.x_axis||[]));
    const x0=st.view_x0||0,x1=st.view_x1||1;
    const widgets=st.overlay_widgets||[];
    const HR=7;
    // First pass: point widgets have highest drag priority so that a point
    // handle sitting inside a range band is always reachable.
    for(let i=widgets.length-1;i>=0;i--){
      const w=widgets[i];
      if(w.visible===false) continue;
      if(w.type==='point'){
        const px=_fracToPx1d(_axisValToFrac(xArr,w.x),x0,x1,r);
        const py=_valToPy1d(w.y,st.data_min,st.data_max,r);
        if(Math.hypot(mx-px,my-py)<=HR+4)
          return{idx:i,mode:'move',wtype:'point',startMX:mx,startMY:my,snapW:{...w}};
      }
    }
    // Second pass: everything else
    for(let i=widgets.length-1;i>=0;i--){
      const w=widgets[i];
      if(w.visible===false) continue;
      if(w.type==='vline'){
        const px=_fracToPx1d(_axisValToFrac(xArr,w.x),x0,x1,r);
        if(Math.sqrt((mx-px)**2+(my-(r.y+7))**2)<=HR||Math.abs(mx-px)<=5)
          return{idx:i,mode:'move',wtype:'vline',startMX:mx,snapW:{...w}};
      } else if(w.type==='hline'){
        const py=_valToPy1d(w.y,st.data_min,st.data_max,r);
        if(Math.abs(my-py)<=5) return{idx:i,mode:'move',wtype:'hline',startMY:my,snapW:{...w}};
      } else if(w.type==='range' && w.orientation==='vertical'){
        const vpy0=_valToPy1d(w.x0,st.data_min,st.data_max,r);
        const vpy1=_valToPy1d(w.x1,st.data_min,st.data_max,r);
        const vtop=Math.min(vpy0,vpy1), vbot=Math.max(vpy0,vpy1);
        // Same one-third rule as the horizontal band: a thin band must keep a
        // grabbable middle rather than being all edge.
        const vgrab=Math.min(HR+5,(vbot-vtop)/3);
        if(Math.abs(my-vpy0)<=vgrab) return{idx:i,mode:'edge0',wtype:'range',startMY:my,snapW:{...w}};
        if(Math.abs(my-vpy1)<=vgrab) return{idx:i,mode:'edge1',wtype:'range',startMY:my,snapW:{...w}};
        if(my>=vtop&&my<=vbot&&mx>=r.x&&mx<=r.x+r.w) return{idx:i,mode:'move',wtype:'range',startMY:my,snapW:{...w}};
      } else if(w.type==='range'){
        const px0=_fracToPx1d(_axisValToFrac(xArr,w.x0),x0,x1,r);
        const px1b=_fracToPx1d(_axisValToFrac(xArr,w.x1),x0,x1,r);
        if(w.style==='fwhm'){
          // FWHM style: hit-test the two circular handles
          const pyHalf=_valToPy1d(w.y||0,st.data_min,st.data_max,r);
          if(Math.hypot(mx-px0,my-pyHalf)<=HR+5)
            return{idx:i,mode:'edge0',wtype:'range',startMX:mx,snapW:{...w}};
          if(Math.hypot(mx-px1b,my-pyHalf)<=HR+5)
            return{idx:i,mode:'edge1',wtype:'range',startMX:mx,snapW:{...w}};
        } else {
          // Band style. The edge grab zones are ±(HR+5)=12 px each, so on a
          // NARROW band (< ~24 px on screen — routine when the span is capped, or
          // just zoomed out) the two zones meet and swallow the body: the user
          // aims at the middle to translate the band and gets an edge resize
          // instead. Give each edge at most a THIRD of the band, so the middle
          // third always belongs to 'move' no matter how narrow the band gets.
          const left=Math.min(px0,px1b),right=Math.max(px0,px1b);
          const grab=Math.min(HR+5,(right-left)/3);
          if(Math.abs(mx-px0)<=grab) return{idx:i,mode:'edge0',wtype:'range',startMX:mx,snapW:{...w}};
          if(Math.abs(mx-px1b)<=grab) return{idx:i,mode:'edge1',wtype:'range',startMX:mx,snapW:{...w}};
          if(mx>=left&&mx<=right&&my>=r.y&&my<=r.y+r.h) return{idx:i,mode:'move',wtype:'range',startMX:mx,snapW:{...w}};
        }
      }
    }
    return null;
  }

  // Snap a value to the nearest entry of a widget's snap_values, if it has any.
  // Mirrors matplotlib SpanSelector.snap_values: the drag follows the cursor
  // but lands only on allowed positions.
  function _snapVal(v, snapValues){
    if(!Array.isArray(snapValues) || !snapValues.length) return v;
    let best=snapValues[0], bestD=Math.abs(v-best);
    for(let i=1;i<snapValues.length;i++){
      const dd=Math.abs(v-snapValues[i]);
      if(dd<bestD){bestD=dd;best=snapValues[i];}
    }
    return best;
  }

  function _doDrag1d(e,p){
    const st=p.state;if(!st)return;
    const r=_plotRect1d(p);
    const {mx,my:py}=_clientPos(e,p.overlayCanvas,p.pw,p.ph);
    const xArr = p._1dXArr || (st.x_axis_b64 ? _decodeF64(st.x_axis_b64) : (st.x_axis||[]));
    const x0=st.view_x0||0,x1=st.view_x1||1;
    const widgets=st.overlay_widgets;
    const d=p.ovDrag, s=d.snapW, w=widgets[d.idx];
    const snap=(v)=>_snapVal(v,w.snap_values);
    const xUnit=snap(xArr.length>=2?_axisFracToVal(xArr,_canvasXToFrac1d(mx,x0,x1,r)):_canvasXToFrac1d(mx,x0,x1,r));
    const yUnit=snap(st.data_max-((py-r.y)/(r.h||1))*(st.data_max-st.data_min));
    if(w.type==='vline'){w.x=xUnit;}
    else if(w.type==='hline'){w.y=yUnit;}
    else if(w.type==='range' && w.orientation==='vertical'){
      // Same cap semantics as the horizontal band, on the value axis.
      const vcap = (w.max_extent == null ? null : Math.abs(w.max_extent));
      if(d.mode==='edge0'){
        w.x0 = (vcap!=null && Math.abs(w.x1-yUnit) > vcap)
          ? w.x1 + (yUnit < w.x1 ? -vcap : vcap) : yUnit;
      } else if(d.mode==='edge1'){
        w.x1 = (vcap!=null && Math.abs(yUnit-w.x0) > vcap)
          ? w.x0 + (yUnit < w.x0 ? -vcap : vcap) : yUnit;
      } else {
        const dv=(st.data_max-st.data_min)*((d.startMY-py)/(r.h||1));
        w.x0=snap(s.x0+dv);w.x1=snap(s.x1+dv);
      }
    }
    else if(w.type==='range'){
      // max_extent caps the span DURING the drag. The edge NOT being dragged is
      // the anchor and never moves, so the span stops growing at the cap without
      // the range jumping. (Clamping afterwards by rewriting whichever endpoint
      // happens to be numerically smaller moves the edge the user is not holding
      // — that reads as phantom movement.) Dragging the whole band is unaffected:
      // a translation can't change the width.
      const cap = (w.max_extent == null ? null : Math.abs(w.max_extent));
      if(d.mode==='edge0'){
        w.x0 = (cap!=null && Math.abs(w.x1-xUnit) > cap)
          ? w.x1 + (xUnit < w.x1 ? -cap : cap) : xUnit;
      }
      else if(d.mode==='edge1'){
        w.x1 = (cap!=null && Math.abs(xUnit-w.x0) > cap)
          ? w.x0 + (xUnit < w.x0 ? -cap : cap) : xUnit;
      }
      else {
        const snapPx=_fracToPx1d(xArr.length>=2?_axisValToFrac(xArr,s.x0):0,x0,x1,r);
        const dxUnit=xArr.length>=2?_axisFracToVal(xArr,_canvasXToFrac1d(snapPx+(mx-d.startMX),x0,x1,r))-s.x0:(mx-d.startMX)/(r.w||1);
        w.x0=snap(s.x0+dxUnit);w.x1=snap(s.x1+dxUnit);
      }
    } else if(w.type==='point'){
      // Clamp to plot rectangle
      const clampX=Math.max(r.x,Math.min(r.x+r.w,mx));
      const clampY=Math.max(r.y,Math.min(r.y+r.h,py));
      w.x=snap(xArr.length>=2?_axisFracToVal(xArr,_canvasXToFrac1d(clampX,x0,x1,r)):_canvasXToFrac1d(clampX,x0,x1,r));
      w.y=st.data_max-((clampY-r.y)/(r.h||1))*(st.data_max-st.data_min);
    }
    drawOverlay1d(p);
    model.set(`panel_${p.id}_json`,_viewStateJson(p));model.save_changes();
    e.preventDefault();
  }

  // ── shared-axis propagation ───────────────────────────────────────────────
  function _getShareGroups() {
    try { return JSON.parse(model.get('layout_json')).share_groups||{}; } catch(_){ return {}; }
  }

  function _propagateZoom2d(srcPanel) {
    const sg=_getShareGroups();
    const srcId=srcPanel.id, st=srcPanel.state;
    for(const [axis,groups] of Object.entries(sg)){
      for(const group of groups){
        if(!group.includes(srcId)) continue;
        for(const pid of group){
          if(pid===srcId) continue;
          const tp=panels.get(pid); if(!tp||!tp.state) continue;
          if(axis==='x'||axis==='both'){tp.state.zoom=st.zoom;tp.state.center_x=st.center_x;}
          if(axis==='y'||axis==='both'){tp.state.center_y=st.center_y;}
          _redrawPanel(tp);
          model.set(`panel_${pid}_json`,_viewStateJson(tp));
        }
      }
    }
  }

  function _propagateView1d(srcPanel) {
    const sg=_getShareGroups();
    const srcId=srcPanel.id, st=srcPanel.state;
    for(const [axis,groups] of Object.entries(sg)){
      if(axis!=='x'&&axis!=='both') continue;
      for(const group of groups){
        if(!group.includes(srcId)) continue;
        for(const pid of group){
          if(pid===srcId) continue;
          const tp=panels.get(pid); if(!tp||!tp.state) continue;
          tp.state.view_x0=st.view_x0; tp.state.view_x1=st.view_x1;
          _redrawPanel(tp);
          model.set(`panel_${pid}_json`,_viewStateJson(tp));
        }
      }
    }
  }

  // ── figure-level resize ───────────────────────────────────────────────────
  let isResizing = false;
  let resizeStart = {};
  let _cachedLayout = null;   // layout parsed once at mousedown — avoids per-frame JSON.parse
  let _rafPending = false;    // rAF throttle flag
  let _pendingNfw = 0, _pendingNfh = 0;

  resizeHandle.addEventListener('mousedown', (e) => {
    isResizing = true;
    _suppressLayoutUpdate = true;
    const fw = model.get('fig_width'), fh = model.get('fig_height');
    // Capture the current CSS scale so drag deltas (in visual/page pixels) can
    // be converted back to native figure pixels.  offsetWidth is pre-transform.
    const _oRect = outerDiv.getBoundingClientRect();
    const _sfFig = (_oRect.width > 0) ? outerDiv.offsetWidth / _oRect.width : 1;
    resizeStart = { mx: e.clientX, my: e.clientY, fw, fh, sfFig: _sfFig };
    // Cache the layout once so mousemove never needs to parse JSON
    try { _cachedLayout = JSON.parse(model.get('layout_json')); } catch(_) { _cachedLayout = null; }
    sizeLabel.style.display = 'block';
    e.preventDefault();
  });

  // Low-level resize: only moves DOM geometry, no pixel drawing.
  // This is cheap enough to call every rAF (~16 ms).
  function _applyFigResizeDOM(nfw, nfh) {
    const layout = _cachedLayout;
    if (!layout) return;
    const { nrows, ncols, width_ratios, height_ratios, panel_specs } = layout;
    const wsum = width_ratios.reduce((a,b)=>a+b,0);
    const hsum = height_ratios.reduce((a,b)=>a+b,0);

    const col_px = width_ratios.map(w => nfw * w / wsum);
    const row_px = height_ratios.map(h => nfh * h / hsum);


    // Resize canvases (CSS size only — no pixel content redrawn)
    const colPx = new Array(ncols).fill(0);
    const rowPx = new Array(nrows).fill(0);
    for (const spec of panel_specs) {
      const p = panels.get(spec.id); if (!p) continue;
      let cw=0, ch=0;
      for(let c=spec.col_start;c<spec.col_stop;c++) cw+=col_px[c];
      for(let r=spec.row_start;r<spec.row_stop;r++) ch+=row_px[r];
      cw = Math.max(64, Math.round(cw));
      ch = Math.max(64, Math.round(ch));
      p.pw = cw; p.ph = ch;

      // Resize only CSS dimensions — don't touch canvas.width/height yet
      // (that clears the pixel buffer and forces a redraw)
      _resizePanelCSS(spec.id, cw, ch);

      const perC=Math.round(cw/(spec.col_stop-spec.col_start));
      const perR=Math.round(ch/(spec.row_stop-spec.row_start));
      for(let c=spec.col_start;c<spec.col_stop;c++) colPx[c]=Math.max(colPx[c],perC);
      for(let r=spec.row_start;r<spec.row_stop;r++) rowPx[r]=Math.max(rowPx[r],perR);
    }

    gridDiv.style.gridTemplateColumns = colPx.map(px=>px+'px').join(' ');
    gridDiv.style.gridTemplateRows    = rowPx.map(px=>px+'px').join(' ');
    gridDiv.style.width  = '';
    gridDiv.style.height = '';

    // CSS-only reposition of insets (no canvas redraw during live drag)
    insetsContainer.style.width  = nfw + 'px';
    insetsContainer.style.height = nfh + 'px';
    const insetSpecs = layout.inset_specs || [];
    for (const spec of insetSpecs) {
      const pi = panels.get(spec.id);
      if (!pi || !pi.isInset) continue;
      const pw = Math.max(64, Math.round(nfw * spec.w_frac));
      const ph = Math.max(64, Math.round(nfh * spec.h_frac));
      pi.pw = pw; pi.ph = ph;
      // Reuse _applyAllInsetStates logic inline (CSS only) by temporarily
      // patching spec dimensions and calling the function with a fake layout.
      spec.panel_width  = pw;
      spec.panel_height = ph;
    }
    if (insetSpecs.length) {
      _applyAllInsetStates({ ...layout, fig_width: nfw, fig_height: nfh });
    }
  }

  // CSS-only resize: move/size elements without clearing canvas buffers.
  // The canvas still renders its old content scaled by CSS — which looks
  // slightly blurry but is instantaneous. A full redraw follows on mouseup.
  function _resizePanelCSS(id, pw, ph) {
    const p = panels.get(id); if (!p) return;

    function _szCSS(c, w, h) {
      c.style.width  = w + 'px';
      c.style.height = h + 'px';
      // Do NOT set c.width / c.height — that would clear the canvas buffer
    }

    if (p.kind === '2d') {
      const st = p.state;
      const hasPhysAxis = st && (st.is_mesh || st.has_axes)
                       && st.x_axis && st.x_axis.length >= 2
                       && st.y_axis && st.y_axis.length >= 2;
      const availW = hasPhysAxis ? pw - PAD_L - PAD_R : pw;
      const cbW  = _cbWidth(st, availW);
      const padT = _padT(st);
      const imgX = hasPhysAxis ? PAD_L : 0;
      const imgY = hasPhysAxis ? padT : 0;
      const imgW = Math.max(1, availW - (cbW ? cbW + _cbGap(st) : 0));
      const imgH = hasPhysAxis ? Math.max(1, ph - padT - PAD_B) : ph;
      p._cbW = cbW; p._cbTickW = _cbTickW(st, availW);
      // Update stored dims so event handlers stay consistent during CSS resize
      p.imgX = imgX; p.imgY = imgY; p.imgW = imgW; p.imgH = imgH;

      if (p.plotWrap) { p.plotWrap.style.width=pw+'px'; p.plotWrap.style.height=ph+'px'; }

      _szCSS(p.plotCanvas,    imgW, imgH);
      _szCSS(p.overlayCanvas, imgW, imgH);
      _szCSS(p.markersCanvas, imgW, imgH);

      p.plotCanvas.style.left    = imgX+'px'; p.plotCanvas.style.top    = imgY+'px';
      p.overlayCanvas.style.left = imgX+'px'; p.overlayCanvas.style.top = imgY+'px';
      p.markersCanvas.style.left = imgX+'px'; p.markersCanvas.style.top = imgY+'px';

      if (p.statusBar) { p.statusBar.style.left=(imgX+4)+'px'; p.statusBar.style.bottom=(ph-imgY-imgH+4)+'px'; }
      if (p.scaleBar)  { p.scaleBar.style.right=(pw-imgX-imgW+12)+'px'; p.scaleBar.style.bottom=(ph-imgY-imgH+12)+'px'; }

      // Axis canvases: just reposition, size handled on full redraw
      if (p.yAxisCanvas && p.yAxisCanvas.style.display !== 'none') {
        p.yAxisCanvas.style.left = '0px'; p.yAxisCanvas.style.top = imgY+'px';
        _szCSS(p.yAxisCanvas, PAD_L, imgH);
      }
      if (p.xAxisCanvas && p.xAxisCanvas.style.display !== 'none') {
        p.xAxisCanvas.style.left = imgX+'px'; p.xAxisCanvas.style.top = (ph-PAD_B)+'px';
        _szCSS(p.xAxisCanvas, imgW, PAD_B);
      }
      if (p.cbCanvas && p.cbCanvas.style.display !== 'none') {
        const fit = _cbFitRect(st, imgW, imgH);
        p._cbH = fit.h;
        p.cbCanvas.style.left = (imgX + imgW + _cbGap(st)) + 'px'; p.cbCanvas.style.top = (imgY + fit.y) + 'px';
        _szCSS(p.cbCanvas, cbW || 16, fit.h);
      }
    } else if (p.kind === '3d') {
      _szCSS(p.plotCanvas,    pw, ph);
      _szCSS(p.overlayCanvas, pw, ph);
    } else {
      _szCSS(p.plotCanvas,    pw, ph);
      _szCSS(p.overlayCanvas, pw, ph);
      _szCSS(p.markersCanvas, pw, ph);
    }
  }

  // Full resize: update canvas pixel buffers and redraw content.
  function _applyFigResize(nfw, nfh) {
    _applyFigResizeDOM(nfw, nfh);
    for (const p of panels.values()) {
      _resizePanelDOM(p.id, p.pw, p.ph);
      _redrawPanel(p);
    }
    _drawFigureMarkers([nfw, nfh]);
  }

  document.addEventListener('mousemove', (e) => {
    if (!isResizing) return;
    const sf = resizeStart.sfFig || 1;
    _pendingNfw = Math.max(200, resizeStart.fw + (e.clientX - resizeStart.mx) * sf);
    _pendingNfh = Math.max(100, resizeStart.fh + (e.clientY - resizeStart.my) * sf);
    sizeLabel.textContent = `${Math.round(_pendingNfw)}×${Math.round(_pendingNfh)}`;

    // Throttle to one DOM update per animation frame
    if (!_rafPending) {
      _rafPending = true;
      requestAnimationFrame(() => {
        _rafPending = false;
        if (!isResizing) return;
        _applyFigResizeDOM(_pendingNfw, _pendingNfh);
        // Track the figure-marker overlay to the live drag size.
        _drawFigureMarkers([_pendingNfw, _pendingNfh]);
      });
    }
    e.preventDefault();
  });

  document.addEventListener('mouseup', (e) => {
    if (!isResizing) return;
    isResizing = false;
    _rafPending = false;
    sizeLabel.style.display = 'none';
    const sf = resizeStart.sfFig || 1;
    const nfw = Math.max(200, resizeStart.fw + (e.clientX - resizeStart.mx) * sf);
    const nfh = Math.max(100, resizeStart.fh + (e.clientY - resizeStart.my) * sf);

    // Full redraw at final size
    _applyFigResize(nfw, nfh);

    // Patch layout_json so the model listener won't revert sizes
    try {
      const layout = JSON.parse(model.get('layout_json'));
      layout.fig_width  = Math.round(nfw);
      layout.fig_height = Math.round(nfh);
      for (const spec of layout.panel_specs) {
        const p = panels.get(spec.id);
        if (p) { spec.panel_width = p.pw; spec.panel_height = p.ph; }
      }
      for (const spec of (layout.inset_specs || [])) {
        const pi = panels.get(spec.id);
        if (pi) { spec.panel_width = pi.pw; spec.panel_height = pi.ph; }
      }
      model.set('layout_json', JSON.stringify(layout));
    } catch(_) {}

    _suppressLayoutUpdate = false;
    model.set('fig_width',  Math.round(nfw));
    model.set('fig_height', Math.round(nfh));
    model.save_changes();
    e.preventDefault();
  });


  // ── bar chart ─────────────────────────────────────────────────────────────
  // Shared geometry helper used by both drawBar and _attachEventsBar.
  // Returns per-slot/bar pixel sizes, coordinate mappers, and group helpers.
  function _barGeom(st, r) {
    const values   = st.values   || [];
    const n        = values.length || 1;
    const groups   = st.groups   || 1;
    const orient   = st.orient   || 'v';
    const bwFrac   = st.bar_width !== undefined ? st.bar_width : 0.8;
    const baseline = st.baseline !== undefined  ? st.baseline  : 0;
    let dMin = st.data_min, dMax = st.data_max;
    if (st.y_range && st.y_range.length === 2) { dMin = st.y_range[0]; dMax = st.y_range[1]; }
    const logScale = !!st.log_scale;
    const LC       = 1e-10; // log clamp

    // Value at category i, group g — supports 2-D [[g0,g1,...], ...] and
    // legacy 1-D [v0, v1, ...].
    function getVal(i, g) {
      const row = values[i];
      if (Array.isArray(row)) return row[g] !== undefined ? row[g] : 0;
      return (g === 0) ? (row !== undefined ? +row : 0) : 0;
    }

    // Pixel coordinate along the VALUE axis.
    function _valToPy(v) {
      if (logScale) {
        const lv   = Math.log10(Math.max(LC, v));
        const lMin = Math.log10(Math.max(LC, dMin));
        const lMax = Math.log10(Math.max(LC, dMax));
        return r.y + r.h - ((lv - lMin) / ((lMax - lMin) || 1)) * r.h;
      }
      return r.y + r.h - ((v - dMin) / ((dMax - dMin) || 1)) * r.h;
    }
    function _valToX(v) {
      if (logScale) {
        const lv   = Math.log10(Math.max(LC, v));
        const lMin = Math.log10(Math.max(LC, dMin));
        const lMax = Math.log10(Math.max(LC, dMax));
        return r.x + ((lv - lMin) / ((lMax - lMin) || 1)) * r.w;
      }
      return r.x + ((v - dMin) / ((dMax - dMin) || 1)) * r.w;
    }

    if (orient === 'h') {
      const slotPx     = r.h / n;
      const barPx      = (slotPx * bwFrac) / groups;
      function xToPx(v) { return _valToX(v); }
      function yToPx(i) { return r.y + (i + 0.5) * slotPx; }
      function groupOffsetPx(g) { return (g - (groups - 1) / 2) * barPx; }
      const bv = logScale ? Math.max(LC, baseline) : baseline;
      const basePx = Math.max(r.x, Math.min(r.x + r.w, xToPx(bv)));
      return { n, groups, orient, slotPx, barPx, dMin, dMax, baseline,
               basePx, xToPx, yToPx, groupOffsetPx, logScale, getVal, LC };
    } else {
      const slotPx     = r.w / n;
      const barPx      = (slotPx * bwFrac) / groups;
      function xToPx(i) { return r.x + (i + 0.5) * slotPx; }
      function yToPx(v) { return _valToPy(v); }
      function groupOffsetPx(g) { return (g - (groups - 1) / 2) * barPx; }
      const bv = logScale ? Math.max(LC, baseline) : baseline;
      const basePx = Math.max(r.y, Math.min(r.y + r.h, yToPx(bv)));
      return { n, groups, orient, slotPx, barPx, dMin, dMax, baseline,
               basePx, xToPx, yToPx, groupOffsetPx, logScale, getVal, LC };
    }
  }

  function drawBar(p) {
    const st = p.state; if (!st) return;
    _recordFrame(p);
    const { pw, ph, plotCtx: ctx } = p;
    const r = _plotRect1d(p);

    ctx.clearRect(0, 0, pw, ph);
    ctx.fillStyle = theme.bg;     ctx.fillRect(0, 0, pw, ph);
    ctx.fillStyle = theme.bgPlot; ctx.fillRect(r.x, r.y, r.w, r.h);

    const values      = st.values      || [];
    const xCenters    = st.x_centers   || values.map((_, i) => i);
    const xLabels     = st.x_labels    || [];
    const barColor    = st.bar_color   || '#4fc3f7';
    const barColors   = st.bar_colors  || [];
    const groupColors = st.group_colors || [];
    const groupLabels = st.group_labels || [];
    const orient      = st.orient || 'v';
    let dMin = st.data_min, dMax = st.data_max;
    if (st.y_range && st.y_range.length === 2) { dMin = st.y_range[0]; dMax = st.y_range[1]; }
    const logScale    = !!st.log_scale;
    const axisVis     = st.axis_visible !== false;
    const xTicksVis   = st.x_ticks_visible !== false;
    const yTicksVis   = st.y_ticks_visible !== false;

    if (!values.length) return;

    const g = _barGeom(st, r);
    const LC = g.LC;

    // ── log tick helper ───────────────────────────────────────────────────
    function _fmtLogTick(v) {
      const exp = Math.round(Math.log10(v));
      if (Math.abs(v - Math.pow(10, exp)) < v * 1e-6) {
        if (exp === 0) return '1';
        if (exp === 1) return '10';
        return `$10^{${exp}}$`;   // rendered as a true superscript by _drawTex
      }
      return fmtVal(v);
    }

    // ── grid lines (along value axis) ─────────────────────────────────────
    ctx.strokeStyle = theme.gridStroke; ctx.lineWidth = 1;

    if (logScale) {
      const lMin = Math.log10(Math.max(LC, dMin));
      const lMax = Math.log10(Math.max(LC, dMax));
      // minor grid — 2,3,5 × decade, semi-transparent
      ctx.globalAlpha = 0.3;
      for (let exp = Math.floor(lMin); exp < Math.ceil(lMax); exp++) {
        for (const m of [2, 3, 5]) {
          const v = m * Math.pow(10, exp);
          if (v < dMin || v > dMax) continue;
          if (orient === 'h') {
            const px = g.xToPx(v);
            if (px < r.x || px > r.x + r.w) continue;
            ctx.beginPath(); ctx.moveTo(px, r.y); ctx.lineTo(px, r.y + r.h); ctx.stroke();
          } else {
            const py = g.yToPx(v);
            if (py < r.y || py > r.y + r.h) continue;
            ctx.beginPath(); ctx.moveTo(r.x, py); ctx.lineTo(r.x + r.w, py); ctx.stroke();
          }
        }
      }
      ctx.globalAlpha = 1.0;
      // major grid — decades, full opacity
      for (let exp = Math.floor(lMin); exp <= Math.ceil(lMax); exp++) {
        const v = Math.pow(10, exp);
        if (v < dMin || v > dMax) continue;
        if (orient === 'h') {
          const px = g.xToPx(v);
          if (px < r.x || px > r.x + r.w) continue;
          ctx.beginPath(); ctx.moveTo(px, r.y); ctx.lineTo(px, r.y + r.h); ctx.stroke();
        } else {
          const py = g.yToPx(v);
          if (py < r.y || py > r.y + r.h) continue;
          ctx.beginPath(); ctx.moveTo(r.x, py); ctx.lineTo(r.x + r.w, py); ctx.stroke();
        }
      }
    } else {
      const valRange = (dMax - dMin) || 1;
      const valStep  = findNice(valRange / Math.max(2, Math.floor((orient==='h' ? r.w : r.h) / 40)));
      if (orient === 'h') {
        for (let v = Math.ceil(dMin/valStep)*valStep; v <= dMax+valStep*0.01; v += valStep) {
          const px = g.xToPx(v);
          if (px < r.x || px > r.x + r.w) continue;
          ctx.beginPath(); ctx.moveTo(px, r.y); ctx.lineTo(px, r.y + r.h); ctx.stroke();
        }
      } else {
        for (let v = Math.ceil(dMin/valStep)*valStep; v <= dMax+valStep*0.01; v += valStep) {
          const py = g.yToPx(v);
          if (py < r.y || py > r.y + r.h) continue;
          ctx.beginPath(); ctx.moveTo(r.x, py); ctx.lineTo(r.x + r.w, py); ctx.stroke();
        }
      }
    }

    // ── bars ──────────────────────────────────────────────────────────────
    ctx.save(); ctx.beginPath(); ctx.rect(r.x, r.y, r.w, r.h); ctx.clip();

    for (let i = 0; i < g.n; i++) {
      for (let gi = 0; gi < g.groups; gi++) {
        const val   = g.getVal(i, gi);
        const color = groupColors[gi] || barColors[i] || barColor;
        const isHov = p._hovBar !== null &&
                      p._hovBar.slot === i && p._hovBar.group === gi;
        const dv    = logScale ? Math.max(LC, val) : val;

        if (orient === 'h') {
          const cy    = g.yToPx(i) + g.groupOffsetPx(gi);
          const valPx = g.xToPx(dv);
          const bLeft = Math.min(valPx, g.basePx);
          const bW    = Math.max(1, Math.abs(valPx - g.basePx));
          ctx.fillStyle = color;
          ctx.fillRect(bLeft, cy - g.barPx / 2, bW, g.barPx);
          if (isHov) {
            ctx.save(); ctx.fillStyle = 'rgba(255,255,255,0.22)';
            ctx.fillRect(bLeft, cy - g.barPx / 2, bW, g.barPx); ctx.restore();
          }
          ctx.strokeStyle = theme.dark ? 'rgba(0,0,0,0.25)' : 'rgba(0,0,0,0.09)';
          ctx.lineWidth = 0.5;
          ctx.strokeRect(bLeft, cy - g.barPx / 2, bW, g.barPx);
        } else {
          const cx    = g.xToPx(i) + g.groupOffsetPx(gi);
          const valPy = g.yToPx(dv);
          const bTop  = Math.min(valPy, g.basePx);
          const bH    = Math.max(1, Math.abs(valPy - g.basePx));
          ctx.fillStyle = color;
          ctx.fillRect(cx - g.barPx / 2, bTop, g.barPx, bH);
          if (isHov) {
            ctx.save(); ctx.fillStyle = 'rgba(255,255,255,0.22)';
            ctx.fillRect(cx - g.barPx / 2, bTop, g.barPx, bH); ctx.restore();
          }
          ctx.strokeStyle = theme.dark ? 'rgba(0,0,0,0.25)' : 'rgba(0,0,0,0.09)';
          ctx.lineWidth = 0.5;
          ctx.strokeRect(cx - g.barPx / 2, bTop, g.barPx, bH);
        }
      }
    }
    ctx.restore();

    // ── value annotations ─────────────────────────────────────────────────
    if (st.show_values) {
      ctx.font = '9px monospace'; ctx.fillStyle = theme.tickText;
      for (let i = 0; i < g.n; i++) {
        for (let gi = 0; gi < g.groups; gi++) {
          const val = g.getVal(i, gi);
          const dv  = logScale ? Math.max(LC, val) : val;
          if (orient === 'h') {
            const cy    = g.yToPx(i) + g.groupOffsetPx(gi);
            const valPx = g.xToPx(dv);
            const above = val >= g.baseline;
            ctx.textAlign    = above ? 'left' : 'right';
            ctx.textBaseline = 'middle';
            ctx.fillText(fmtVal(val), valPx + (above ? 3 : -3), cy);
          } else {
            const cx    = g.xToPx(i) + g.groupOffsetPx(gi);
            const valPy = g.yToPx(dv);
            const above = val >= g.baseline;
            ctx.textAlign    = 'center';
            ctx.textBaseline = above ? 'bottom' : 'top';
            ctx.fillText(fmtVal(val), cx, valPy + (above ? -2 : 2));
          }
        }
      }
    }

    // ── axis borders ──────────────────────────────────────────────────────
    if (axisVis) {
    ctx.strokeStyle = theme.axisStroke; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(r.x, r.y + r.h); ctx.lineTo(r.x + r.w, r.y + r.h); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(r.x, r.y);         ctx.lineTo(r.x, r.y + r.h);       ctx.stroke();

    // Explicit baseline (only for linear scale)
    if (!logScale) {
      if (orient === 'h') {
        if (g.basePx > r.x && g.basePx < r.x + r.w) {
          ctx.strokeStyle = theme.axisStroke; ctx.lineWidth = 1.5;
          ctx.beginPath(); ctx.moveTo(g.basePx, r.y); ctx.lineTo(g.basePx, r.y + r.h); ctx.stroke();
        }
      } else {
        if (g.basePx > r.y && g.basePx < r.y + r.h) {
          ctx.strokeStyle = theme.axisStroke; ctx.lineWidth = 1.5;
          ctx.beginPath(); ctx.moveTo(r.x, g.basePx); ctx.lineTo(r.x + r.w, g.basePx); ctx.stroke();
        }
      }
    } // end axisVis (baseline)
    } // end axisVis (borders)

    // ── tick labels ───────────────────────────────────────────────────────
    if (axisVis) {
      ctx.font = (st.tick_size||10) + 'px monospace'; ctx.fillStyle = theme.tickText;

      if (orient === 'h') {
        // Value axis → X ticks at bottom
        if (xTicksVis) {
          ctx.textAlign = 'center'; ctx.textBaseline = 'top';
          if (logScale) {
            const lMin = Math.log10(Math.max(LC, dMin));
            const lMax = Math.log10(Math.max(LC, dMax));
            for (let exp = Math.floor(lMin); exp <= Math.ceil(lMax); exp++) {
              const v = Math.pow(10, exp);
              if (v < dMin || v > dMax) continue;
              const px = g.xToPx(v);
              if (px < r.x || px > r.x + r.w) continue;
              ctx.strokeStyle = theme.axisStroke;
              ctx.beginPath(); ctx.moveTo(px, r.y + r.h); ctx.lineTo(px, r.y + r.h + 4); ctx.stroke();
              ctx.fillStyle = theme.tickText;
              _drawTex(ctx, _fmtLogTick(v), px, r.y + r.h + 7,
                       st.tick_size||10, {align:'center', family:'monospace'});
            }
          } else {
            const valRange = (dMax - dMin) || 1;
            const valStep  = findNice(valRange / Math.max(2, Math.floor(r.w / 40)));
            for (let v = Math.ceil(dMin/valStep)*valStep; v <= dMax+valStep*0.01; v += valStep) {
              const px = g.xToPx(v);
              if (px < r.x || px > r.x + r.w) continue;
              ctx.strokeStyle = theme.axisStroke;
              ctx.beginPath(); ctx.moveTo(px, r.y + r.h); ctx.lineTo(px, r.y + r.h + 4); ctx.stroke();
              ctx.fillStyle = theme.tickText;
              ctx.fillText(fmtVal(v), px, r.y + r.h + 7);
            }
          }
          if (st.y_units) {
            ctx.textAlign='right'; ctx.textBaseline='top'; ctx.font='9px monospace';
            ctx.fillStyle=theme.unitText;
            ctx.fillText(st.y_units, r.x + r.w, r.y + r.h + 24);
            ctx.font='10px monospace';
          }
        }
        // Category axis → Y labels on left
        if (yTicksVis) {
          ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
          const maxCatLabels = Math.max(1, Math.floor(r.h / 14));
          const catStep = Math.max(1, Math.ceil(g.n / maxCatLabels));
          for (let i = 0; i < g.n; i += catStep) {
            const cy    = g.yToPx(i);
            const label = xLabels[i] !== undefined ? String(xLabels[i]) : fmtVal(xCenters[i]);
            ctx.strokeStyle = theme.axisStroke;
            ctx.beginPath(); ctx.moveTo(r.x, cy); ctx.lineTo(r.x - 4, cy); ctx.stroke();
            ctx.fillStyle = theme.tickText;
            ctx.fillText(label, r.x - 7, cy);
          }
          if (st.units) {
            ctx.save();
            ctx.translate(Math.round(PAD_L * 0.28), r.y + r.h / 2); ctx.rotate(-Math.PI/2);
            ctx.textAlign='center'; ctx.textBaseline='middle';
            ctx.fillStyle=theme.unitText; ctx.font='9px monospace';
            ctx.fillText(st.units, 0, 0);
            ctx.restore();
          }
        }
      } else {
        // Category axis → X ticks at bottom
        if (xTicksVis) {
          ctx.textAlign = 'center'; ctx.textBaseline = 'top';
          const maxCatLabels = Math.max(1, Math.floor(r.w / 42));
          const catStep = Math.max(1, Math.ceil(g.n / maxCatLabels));
          for (let i = 0; i < g.n; i += catStep) {
            const cx    = g.xToPx(i);
            const label = xLabels[i] !== undefined ? String(xLabels[i]) : fmtVal(xCenters[i]);
            ctx.strokeStyle = theme.axisStroke;
            ctx.beginPath(); ctx.moveTo(cx, r.y + r.h); ctx.lineTo(cx, r.y + r.h + 4); ctx.stroke();
            ctx.fillStyle = theme.tickText;
            const catHw = ctx.measureText(label).width / 2;
            ctx.fillText(label, Math.min(Math.max(cx, catHw), p.pw - catHw), r.y + r.h + 7);
          }
          if (st.units && st.units !== 'px') {
            ctx.textAlign='right'; ctx.textBaseline='top'; ctx.font='9px monospace';
            ctx.fillStyle=theme.unitText;
            ctx.fillText(st.units, r.x + r.w, r.y + r.h + 24);
            ctx.font='10px monospace';
          }
        }
        // Value axis → Y ticks on left
        if (yTicksVis) {
          ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
          if (logScale) {
            const lMin = Math.log10(Math.max(LC, dMin));
            const lMax = Math.log10(Math.max(LC, dMax));
            for (let exp = Math.floor(lMin); exp <= Math.ceil(lMax); exp++) {
              const v = Math.pow(10, exp);
              if (v < dMin || v > dMax) continue;
              const py = g.yToPx(v);
              if (py < r.y || py > r.y + r.h) continue;
              ctx.strokeStyle = theme.axisStroke;
              ctx.beginPath(); ctx.moveTo(r.x, py); ctx.lineTo(r.x - 5, py); ctx.stroke();
              ctx.fillStyle = theme.tickText;
              _drawTex(ctx, _fmtLogTick(v), r.x - 8, py,
                       st.tick_size||10, {align:'right', family:'monospace'});
            }
          } else {
            const valRange = (dMax - dMin) || 1;
            const valStep  = findNice(valRange / Math.max(2, Math.floor(r.h / 40)));
            for (let v = Math.ceil(dMin/valStep)*valStep; v <= dMax+valStep*0.01; v += valStep) {
              const py = g.yToPx(v);
              if (py < r.y || py > r.y + r.h) continue;
              ctx.strokeStyle = theme.axisStroke;
              ctx.beginPath(); ctx.moveTo(r.x, py); ctx.lineTo(r.x - 5, py); ctx.stroke();
              ctx.fillStyle = theme.tickText;
              ctx.fillText(fmtVal(v), r.x - 8, py);
            }
          }
          if (st.y_units) {
            ctx.save();
            ctx.translate(Math.round(PAD_L * 0.28), r.y + r.h / 2); ctx.rotate(-Math.PI/2);
            ctx.textAlign='center'; ctx.textBaseline='middle';
            ctx.fillStyle=theme.unitText; ctx.font='9px monospace';
            ctx.fillText(st.y_units, 0, 0);
            ctx.restore();
          }
        }
      }
    } // end axisVis

    // ── group legend (only when group_labels are provided) ────────────────
    if (g.groups > 1 && groupLabels.length > 0) {
      ctx.font = '9px monospace';
      const swatchW = 12, swatchH = 10, pad = 4, rowH = 15;
      let legendMaxW = 0;
      for (let gi = 0; gi < Math.min(g.groups, groupLabels.length); gi++) {
        legendMaxW = Math.max(legendMaxW, ctx.measureText(String(groupLabels[gi])).width);
      }
      const legendW = swatchW + pad + legendMaxW + 6;
      const nRows   = Math.min(g.groups, groupLabels.length);
      const legendH = nRows * rowH + 4;
      const lx = r.x + r.w - legendW - 4;
      const ly = r.y + 4;
      ctx.fillStyle = theme.dark ? 'rgba(0,0,0,0.45)' : 'rgba(255,255,255,0.75)';
      ctx.fillRect(lx, ly, legendW, legendH);
      ctx.strokeStyle = theme.axisStroke; ctx.lineWidth = 0.5;
      ctx.strokeRect(lx, ly, legendW, legendH);
      for (let gi = 0; gi < nRows; gi++) {
        const label = String(groupLabels[gi]);
        const ey    = ly + 2 + gi * rowH;
        ctx.fillStyle = groupColors[gi] || barColor;
        ctx.fillRect(lx + 3, ey + (rowH - swatchH) / 2, swatchW, swatchH);
        ctx.fillStyle = theme.tickText;
        ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
        ctx.fillText(label, lx + 3 + swatchW + pad, ey + rowH / 2);
      }
    }

    // ── title ─────────────────────────────────────────────────────────────
    const titleBar = st.title || '';
    if (titleBar) {
      ctx.fillStyle = theme.tickText;
      ctx.textBaseline = 'middle';
      // Fixed PAD_T strip — clamp drawn size like 1D (2D strips grow instead).
      _drawTex(ctx, titleBar, r.x + r.w / 2, PAD_T / 2, _titlePx(st),
               { align: 'center', weight: 'bold' });
    }

    // ── axis labels ───────────────────────────────────────────────────────
    const xLabelBar = st.x_label || '';
    const yLabelBar = st.y_label || '';
    if (xLabelBar) {
      ctx.fillStyle = theme.tickText; ctx.textBaseline = 'top';
      _drawTex(ctx, xLabelBar, r.x + r.w / 2, r.y + r.h + 26,
               st.x_label_size || 10, { align: 'center' });
    }
    if (yLabelBar) {
      ctx.save();
      const ylpxBar = st.y_label_size || 10;
      ctx.translate(Math.max(Math.round(PAD_L * 0.1), Math.ceil(ylpxBar*0.62)+1),
                    r.y + r.h / 2);
      ctx.rotate(-Math.PI / 2);
      ctx.fillStyle = theme.tickText; ctx.textBaseline = 'middle';
      _drawTex(ctx, yLabelBar, 0, 0, ylpxBar, { align: 'center' });
      ctx.restore();
    }

    // Overlay widgets (vlines, hlines) drawn on overlay canvas
    drawOverlay1d(p);
  }

  function _attachEventsBar(p) {
    const { overlayCanvas } = p;

    // Returns {slot, group} for the bar at canvas (mx,my), or null if none.
    function _barHit(mx, my) {
      const st = p.state;
      if (!st || !st.values || !st.values.length) return null;
      const r  = _plotRect1d(p);
      if (mx < r.x || mx > r.x + r.w || my < r.y || my > r.y + r.h) return null;
      const g  = _barGeom(st, r);
      const LC = g.LC;
      for (let i = 0; i < g.n; i++) {
        for (let gi = 0; gi < g.groups; gi++) {
          const val = g.getVal(i, gi);
          const dv  = g.logScale ? Math.max(LC, val) : val;
          if (g.orient === 'h') {
            const cy    = g.yToPx(i) + g.groupOffsetPx(gi);
            const valPx = g.xToPx(dv);
            const left  = Math.min(valPx, g.basePx);
            const bW    = Math.max(1, Math.abs(valPx - g.basePx));
            if (Math.abs(my - cy) <= g.barPx / 2 && mx >= left && mx <= left + bW)
              return { slot: i, group: gi };
          } else {
            const cx    = g.xToPx(i) + g.groupOffsetPx(gi);
            const valPy = g.yToPx(dv);
            const top   = Math.min(valPy, g.basePx);
            const bH    = Math.max(1, Math.abs(valPy - g.basePx));
            if (Math.abs(mx - cx) <= g.barPx / 2 && my >= top && my <= top + bH)
              return { slot: i, group: gi };
          }
        }
      }
      return null;
    }

    // Widget drag support
    const _scheduleCommit = _makeCommitter(() => model.save_changes());
    const settled = _makeSettledScheduler(p);

    overlayCanvas.addEventListener('mousedown', (e) => {
      if (e.button !== 0) return;
      const {mx:_bmx, my:_bmy} = _clientPos(e, overlayCanvas, p.pw, p.ph);
      const hit = _ovHitTest1d(_bmx, _bmy, p);
      if (hit) {
        p.ovDrag = hit;
        p.lastWidgetId = (p.state.overlay_widgets || [])[hit.idx]?.id || null;
        overlayCanvas.style.cursor = 'ew-resize';
        e.preventDefault();
      }
    });

    document.addEventListener('mousemove', (e) => {
      if (!p.ovDrag) return;
      _doDrag1d(e, p);
      const _dw = (p.state.overlay_widgets || [])[p.ovDrag.idx] || {};
      _emitEvent(p.id, 'pointer_move', _dw.id || null, {..._dw, ..._pointerFields(e)});
    });

    document.addEventListener('mouseup', (e) => {
      settled.clear();
      if (!p.ovDrag) return;
      const _idx = p.ovDrag.idx;
      const _dw  = (p.state.overlay_widgets || [])[_idx] || {};
      const _did = _dw.id || null;
      p.ovDrag = null;
      overlayCanvas.style.cursor = 'default';
      model.set(`panel_${p.id}_json`, _viewStateJson(p));
      _emitEvent(p.id, 'pointer_up', _did, {..._dw, ..._pointerFields(e), button: e.button});
      _scheduleCommit();
    });

    overlayCanvas.addEventListener('mousemove', (e) => {
      const {mx, my} = _clientPos(e, overlayCanvas, p.pw, p.ph);
      p.mouseX = mx; p.mouseY = my;
      if (p.ovDrag) return;
      const st = p.state; if (!st) return;

      // Overlay widget cursor hint
      const whit = _ovHitTest1d(mx, my, p);
      if (whit) {
        overlayCanvas.style.cursor = 'ew-resize';
        tooltip.style.display = 'none';
        if (p._hovBar !== null) { p._hovBar = null; drawBar(p); }
        return;
      }

      const hit = _barHit(mx, my);
      const prev = p._hovBar;
      const same = hit !== null && prev !== null &&
                   prev.slot === hit.slot && prev.group === hit.group;
      if (!same) { p._hovBar = hit; drawBar(p); }

      if (hit !== null) {
        const { slot: idx, group: gi } = hit;
        const label = (st.x_labels||[])[idx] !== undefined
          ? String(st.x_labels[idx])
          : fmtVal((st.x_centers||[])[idx] ?? idx);
        const gLabel = (st.group_labels||[])[gi];
        const gm  = _barGeom(st, _plotRect1d(p));
        const val = gm.getVal(idx, gi);
        const tip = (st.groups > 1 && gLabel)
          ? `${gLabel} | ${label}: ${fmtVal(val)}`
          : `${label}: ${fmtVal(val)}`;
        _showTooltip(tip, e.clientX, e.clientY);
        overlayCanvas.style.cursor = 'pointer';
      } else {
        tooltip.style.display = 'none';
        overlayCanvas.style.cursor = 'default';
      }
      settled.arm(mx, my, e);
    });

    overlayCanvas.addEventListener('mouseleave', (e) => {
      settled.clear();
      _emitEvent(p.id, 'pointer_leave', null, {..._pointerFields(e), x: e.offsetX, y: e.offsetY});
      if (p._hovBar !== null) { p._hovBar = null; drawBar(p); }
      tooltip.style.display = 'none';
    });

    overlayCanvas.addEventListener('mousedown', (e) => {
      if (p.ovDrag) return;
      const st = p.state; if (!st) return;
      const {mx:_cmx, my:_cmy} = _clientPos(e, overlayCanvas, p.pw, p.ph);
      const hit = _barHit(_cmx, _cmy);
      const _baseFields = {..._pointerFields(e), button: e.button, x: _cmx, y: _cmy};
      if (hit === null) {
        _emitEvent(p.id, 'pointer_down', null, {
          bar_index:   null,
          group_index: null,
          value:       null,
          x_label:     null,
          ..._baseFields,
        });
        return;
      }
      const { slot: idx, group: gi } = hit;
      const gm  = _barGeom(st, _plotRect1d(p));
      const val = gm.getVal(idx, gi);
      _emitEvent(p.id, 'pointer_down', null, {
        bar_index:   idx,
        group_index: gi,
        value:       val,
        group_value: val,
        x_center:    (st.x_centers||[])[idx] ?? idx,
        x_label:     (st.x_labels||[])[idx] !== undefined
                       ? String(st.x_labels[idx]) : null,
        ..._baseFields,
      });
    });

    // Keyboard: all keys forwarded to Python unconditionally; no built-in bar shortcuts.
    overlayCanvas.addEventListener('keydown', (e) => {
      const st = p.state; if (!st) return;
      _emitEvent(p.id, 'key_down', null, {
        time_stamp: performance.now() / 1000,
        modifiers: _modifiers(e),
        key: e.key,
        last_widget_id: p.lastWidgetId || null,
        x: p.mouseX ?? 0, y: p.mouseY ?? 0,
      });
    });
    overlayCanvas.addEventListener('keyup', (e) => {
      _emitEvent(p.id, 'key_up', null, {
        time_stamp: performance.now() / 1000,
        modifiers: _modifiers(e),
        key: e.key,
        x: p.mouseX ?? 0, y: p.mouseY ?? 0,
      });
    });
    overlayCanvas.tabIndex = 0;
    overlayCanvas.style.outline = 'none';
    overlayCanvas.addEventListener('mouseenter', (e) => {
      overlayCanvas.focus();
      _emitEvent(p.id, 'pointer_enter', null, {..._pointerFields(e), x: e.offsetX, y: e.offsetY});
    });
    overlayCanvas.addEventListener('dblclick', (e) => {
      const {mx, my} = _clientPos(e, overlayCanvas, p.pw, p.ph);
      _emitEvent(p.id, 'double_click', null, {..._pointerFields(e), button: e.button, x: mx, y: my, xdata: null});
    });
    overlayCanvas.addEventListener('wheel', (e) => {
      _emitEvent(p.id, 'wheel', null, {
        time_stamp: performance.now() / 1000,
        modifiers: _modifiers(e),
        x: p.mouseX ?? 0, y: p.mouseY ?? 0,
        dx: e.deltaX, dy: e.deltaY,
      });
    }, { passive: true });
  }

  // ── generic redraw ────────────────────────────────────────────────────────
  function _redrawPanel(p) {
    if(!p.state) return;
    if(p.kind==='2d')      draw2d(p);
    else if(p.kind==='3d') draw3d(p);
    else if(p.kind==='bar') drawBar(p);
    else                   draw1d(p);
    // Keys live on their own canvas, so a data redraw does not erase them —
    // but the panel may have resized or the key state changed, and this is
    // the one path every state change and resize funnels through.
    drawKeys(p);
    // Region indications track the parent's zoom/pan: any panel redraw
    // refreshes ALL callouts (cheap no-op when there are none). Redrawing all
    // (not just this panel's) keeps rect + leaders consistent when a parent
    // and its inset live in different panels.
    _drawCallouts();
  }

  function redrawAll() {
    for(const p of panels.values()) _redrawPanel(p);
    _drawCallouts();
  }

  // ── PNG export ────────────────────────────────────────────────────────────
  //   opts: {scale, includeWidgets, panelId, source, theme}
  //   source 'view' (as displayed) | 'full' (whole extent) | 'native' (1 px/datum)
  //   theme  'current' | 'light' | 'dark'
  // panelId changes only the origin and extent, so a panel export is exactly the
  // matching sub-rectangle of the figure export.
  const EXPORT_MAX_SIDE = 16384;          // Chrome/Skia per-side canvas limit
  const EXPORT_MAX_AREA = 268435456;      // 2^28 — Chrome/Skia total-area limit
  let _exporting = false;

  // Undo _applyScale's transform:scale(s) — rects are visual px, the extent is
  // native px. Read s off the transform, not offsetWidth: a native export
  // resizes a panel mid-flight and would corrupt a layout-derived ratio.
  function _cssScale() {
    let t = '';
    try { t = window.getComputedStyle(outerDiv).transform || ''; } catch (_) { return 1; }
    if (!t || t === 'none') return 1;
    const m = t.match(/matrix\(\s*([-\d.eE+]+)/);
    const s = m ? parseFloat(m[1]) : 1;
    return (Number.isFinite(s) && s > 0) ? (1 / s) : 1;
  }

  // plotWrap is exactly pw×ph (2-D only); 1-D/3-D keep no wrapper on p, and the
  // grid cell is a centring flex box that can be wider than the panel.
  function _panelBox(p) {
    if (!p) return null;
    if (p.isInset) return p.insetDiv || p.cell || null;
    return p.plotWrap || (p.plotCanvas && p.plotCanvas.parentElement) || p.cell || null;
  }

  // Transiently show the whole data extent. Never writes the model: shared-axis
  // propagation runs only from event handlers and _emitViewChanged is gated on
  // _exporting, so nothing leaks to Python or to linked panels.
  function _neutralizeView(p) {
    const st = p.state; if (!st) return null;
    if (p.kind === '2d') {
      const s = { zoom: st.zoom, cx: st.center_x, cy: st.center_y,
                  db: st.detail_b64, dby: st.detail_b64_bytes,
                  dr: st.detail_region, dw: st.detail_width, dh: st.detail_height,
                  blend: p._detailBlend };
      st.zoom = 1; st.center_x = 0.5; st.center_y = 0.5;
      // The tile covers only the pre-reset region; left in place _blit2d would
      // stretch it over the whole fit-rect.
      st.detail_b64 = ''; st.detail_b64_bytes = null;
      st.detail_region = []; st.detail_width = 0; st.detail_height = 0;
      return s;
    }
    if (p.kind === '1d') {
      const s = { x0: st.view_x0, x1: st.view_x1 };
      st.view_x0 = 0; st.view_x1 = 1; return s;
    }
    if (p.kind === '3d') {
      // Zoom only — azimuth/elevation are content the user chose.
      const s = { zoom: st.zoom }; st.zoom = 1; return s;
    }
    return null;   // bar: value-axis limits are content, nothing to reset
  }

  function _restoreView(p, s) {
    if (!s) return;
    const st = p.state; if (!st) return;
    if (p.kind === '2d') {
      st.zoom = s.zoom; st.center_x = s.cx; st.center_y = s.cy;
      st.detail_b64 = s.db; st.detail_b64_bytes = s.dby;
      st.detail_region = s.dr; st.detail_width = s.dw; st.detail_height = s.dh;
      p._detailBlend = s.blend;
    } else if (p.kind === '1d') { st.view_x0 = s.x0; st.view_x1 = s.x1; }
    else if (p.kind === '3d')   { st.zoom = s.zoom; }
  }

  // Panel size whose inner image area is exactly image_width × image_height —
  // inverts the gutter math at the top of _resizePanelDOM; keep the two in step.
  // st.aspect is left to _resizePanelDOM so a stretched plot exports as shown.
  function _nativeGeom(p) {
    const st = p.state || {};
    const iw = st.image_width | 0, ih = st.image_height | 0;
    const hasPhysAxis = (st.is_mesh || st.has_axes)
                     && st.x_axis && st.x_axis.length >= 2
                     && st.y_axis && st.y_axis.length >= 2;
    // The same narrow-cell rule the on-screen layout applies, phrased for a
    // panel whose image is exactly iw wide: reserve the values only when the
    // native image is wide enough to keep them.
    const full = 16 + _cbTickW(st) + _cbLabelW(st);
    const cbW = _cbWidth(st, iw + full + _cbGap(st));
    return {
      iw, ih,
      pw: iw + (cbW ? cbW + _cbGap(st) : 0) + (hasPhysAxis ? PAD_L + PAD_R : 0),
      ph: ih + _padT(st) + (hasPhysAxis ? PAD_B : 0),
    };
  }

  // Returns null when a native export is possible, else the reason why not.
  function _nativeGuard(p) {
    if (!p) return "source:'native' needs a panelId — it exports one image panel, "
                 + "and different panels have different native sizes.";
    if (p.kind !== '2d')
      return "source:'native' is only available for 2-D image panels (this panel is "
           + p.kind + "). Use source:'view' or source:'full'.";
    const st = p.state;
    if (!st) return 'panel has no state yet';
    if (st.tile_enabled)
      return "source:'native' is unavailable here: this panel streams tiles, so the "
           + "browser holds only a " + (st.base_width | 0) + "×" + (st.base_height | 0)
           + " overview plus one detail tile — the full " + (st.image_width | 0)
           + "×" + (st.image_height | 0) + " data lives in Python. "
           + "Use fig.savefig(path, source='native').";
    const g = _nativeGeom(p);
    if (!g.iw || !g.ih) return 'panel has no image data';
    if (g.pw > EXPORT_MAX_SIDE || g.ph > EXPORT_MAX_SIDE || g.pw * g.ph > EXPORT_MAX_AREA)
      return "source:'native': " + g.pw + "×" + g.ph + " exceeds the browser canvas "
           + "limit (" + EXPORT_MAX_SIDE + " px per side, " + EXPORT_MAX_AREA + " px total). "
           + "Use source:'view' with a scale, or fig.savefig(path, source='native').";
    return null;
  }

  // Resize one 2-D panel to the data resolution, redraw the decorated stack, run
  // fn, restore. Synchronous throughout, so the intermediate size never paints.
  function _withNativeSize(p, fn) {
    const st = p.state;
    const g = _nativeGeom(p);
    const savedPw = p.pw, savedPh = p.ph, savedOv = p._dprOv;
    const savedGpuMode = st.gpu_mode;
    const savedView = _neutralizeView(p);
    p._dprOv = 1;                 // backing store in exact data pixels
    st.gpu_mode = 'off';          // a native-size WebGPU surface would have to
                                  // reconfigure far beyond the display
    try {
      _resizePanelDOM(p.id, g.pw, g.ph);
      _redrawPanel(p);
      return fn();
    } finally {
      p._dprOv = savedOv;
      st.gpu_mode = savedGpuMode;
      _restoreView(p, savedView);
      _resizePanelDOM(p.id, savedPw, savedPh);
      _redrawPanel(p);
    }
  }

  // Composite the on-screen canvases; the caller has already applied and
  // redrawn any theme/view/size change.
  function _compositeCanvas(o) {
    const includeWidgets = !!o.includeWidgets;
    const outScale = o.outScale;
    const cs = _cssScale();
    const target = o.panelId ? panels.get(o.panelId) : null;

    // WebGPU hazard: a WebGPU canvas's drawing buffer is only valid right after
    // its render pass.  Force a synchronous re-render of every active-GPU panel
    // FIRST — 2-D image rasters AND 3-D geometry (draw3d's active-GPU path
    // uploads + submits its render pass in-task, no rAF) — then composite in
    // the SAME task, so drawImage(gpuCanvas) reads freshly-rendered pixels
    // instead of a blank/cleared buffer.  Without the 3-D branch a scatter3d/
    // voxels panel exports as an empty background rectangle.
    for (const p of panels.values()) {
      if (p._gpu !== 'active' || !p.gpuCanvas
          || p.gpuCanvas.style.display === 'none') continue;
      if (p.kind === '2d' && p._gpuImg) {
        try { draw2d(p); } catch (_) {}
      } else if (p.kind === '3d' && p._gpuObj) {
        try { draw3d(p); } catch (_) {}
      }
    }

    const GRID_PAD = 8;   // gridDiv padding (see the gridDiv cssText)
    let rootRect, contentW, contentH;
    if (target) {
      // A panel's wrapper is explicitly sized pw×ph and cannot stretch, so its
      // measured rect IS the extent (unlike gridDiv — see the figure branch).
      const box = _panelBox(target);
      if (!box) throw new Error('exportPNG: panel has no DOM container');
      rootRect = box.getBoundingClientRect();
      contentW = rootRect.width  * cs;
      contentH = rootRect.height * cs;
    } else {
      // The figure background element (grid) defines the ORIGIN for every
      // relative rect.  Its top-left is the figure's top-left; the grid tracks
      // are fixed-px and left-anchored, so panel canvases sit at the correct
      // offset even if the grid container itself stretches wider than the
      // figure (it can in a bare mount() page with no .apl-outer inline-block
      // CSS constraining it).  So take the ORIGIN from the DOM but the EXTENT
      // from the true figure size — fig_width/height (the grid content) + the
      // 8 px gridDiv padding on each side.
      rootRect = gridDiv.getBoundingClientRect();
      const figW = Number(model.get('fig_width'))  || 0;
      const figH = Number(model.get('fig_height')) || 0;
      contentW = figW ? figW + 2 * GRID_PAD : rootRect.width  * cs;
      contentH = figH ? figH + 2 * GRID_PAD : rootRect.height * cs;
    }
    const W = Math.max(1, Math.round(contentW * outScale));
    const H = Math.max(1, Math.round(contentH * outScale));

    const out = document.createElement('canvas');
    out.width = W; out.height = H;
    const octx = out.getContext('2d');
    if (!octx) throw new Error('exportPNG: 2D context unavailable');
    octx.imageSmoothingEnabled = false;

    // Figure background first (matches the on-screen gridDiv background).
    octx.fillStyle = theme.bg;
    octx.fillRect(0, 0, W, H);

    // Draw one element scaled into the output at its position relative to root.
    // Skips hidden (display:none) or zero-area elements; catches per-element
    // draw failures (a tainted / uninitialised canvas) so one bad layer never
    // aborts the whole export.
    //
    // Coordinates are SNAPPED to output pixels: dx/dy round the element's
    // top-left, and dw/dh are derived from the ROUNDED right/bottom edges
    // (not by rounding width/height directly). Two adjacent elements that
    // share a boundary (e.g. neighbouring grid panels) therefore round to the
    // exact same output-pixel edge on both sides, instead of each picking up
    // an independent +/-1 px from its own width/height rounding — which is
    // what caused 1 px seams / overlaps at fractional scale (e.g. scale:1.25).
    // `rectElm` (defaults to `elm`) supplies the on-screen position/visibility
    // — used to blit an offscreen scratch canvas (no DOM rect of its own) at
    // the position of the live element it stands in for (see
    // _drawPanelWidgetsNoHandles below).
    const _drawEl = (elm, rectElm) => {
      if (!elm) return;
      const re = rectElm || elm;
      const cst = window.getComputedStyle(re);
      if (cst.display === 'none' || cst.visibility === 'hidden') return;
      // A canvas with 0×0 backing store has nothing to blit.
      if (elm.width === 0 || elm.height === 0) return;
      const r = re.getBoundingClientRect();
      if (r.width === 0 || r.height === 0) return;
      const left   = (r.left   - rootRect.left) * cs * outScale;
      const top    = (r.top    - rootRect.top)  * cs * outScale;
      const right  = (r.right  - rootRect.left) * cs * outScale;
      const bottom = (r.bottom - rootRect.top)  * cs * outScale;
      const dx = Math.round(left);
      const dy = Math.round(top);
      const dw = Math.round(right)  - dx;
      const dh = Math.round(bottom) - dy;
      if (dw <= 0 || dh <= 0) return;
      try { octx.drawImage(elm, dx, dy, dw, dh); } catch (_) {}
    };

    // Widget handle/node dots are edit-mode chrome (like figure-marker handles
    // — see _drawFigureMarkers(null, true) below), not exported content.  For
    // includeWidgets:true, redraw the panel's widgets onto a scratch canvas
    // (same backing size + DPR transform as the live overlayCanvas) with
    // handles forced off, and blit THAT (positioned via the live
    // overlayCanvas's own on-screen rect) instead of the live p.overlayCanvas
    // — so the on-screen canvas (and any handles currently visible on it) is
    // never touched, no flicker.
    const _drawPanelWidgetsNoHandles = (p) => {
      if (!p.overlayCanvas || !p.ovCtx) return null;
      const oc = p.overlayCanvas;
      if (oc.width === 0 || oc.height === 0) return null;
      const scratch = document.createElement('canvas');
      scratch.width = oc.width; scratch.height = oc.height;
      const sctx = scratch.getContext('2d');
      if (!sctx) return null;
      const D = p._dprOv || dpr;
      sctx.setTransform(D, 0, 0, D, 0, 0);
      try {
        drawOverlay2d(p, { ctx: sctx, imgW: p.imgW, imgH: p.imgH, forceNoHandles: true });
      } catch (_) { return null; }
      return scratch;
    };

    // Per-panel canvas stack, in visual z-order (see _buildCanvasStack).
    const _drawPanel = (p) => {
      _drawEl(p.gpuCanvas);      // z 0 — GPU image raster (beneath)
      _drawEl(p.plotCanvas);     // z 1 — image blit + inline decorations
      _drawEl(p.yAxisCanvas);    // physical axis gutters (no explicit z)
      _drawEl(p.xAxisCanvas);
      _drawEl(p.cbCanvas);       // colorbar strip + label
      if (includeWidgets) {      // z 5 — interactive widgets, handles suppressed
        const scratch = _drawPanelWidgetsNoHandles(p);
        if (scratch) _drawEl(scratch, p.overlayCanvas); else _drawEl(p.overlayCanvas);
      }
      _drawEl(p.markersCanvas);  // z 6 — static marker groups
      _drawEl(p.scaleBar);       // z 7 — physical scale bar
      // z 7 — floating image keys, `hover_only` ones included: the export
      // renders as though the pointer were over the panel. When one is not
      // currently on screen the scratch re-render below stands in for the live
      // canvas (null = live canvas already correct, undefined = nothing to
      // draw at all).
      const keyScratch = _drawPanelKeysForExport(p);
      if (keyScratch === null) _drawEl(p.keyCanvas);
      else if (keyScratch) _drawEl(keyScratch, p.keyCanvas);
      _drawEl(p.titleCanvas);    // z 8 — 2-D title strip
      // (statusBar / statsDiv are hover chrome — intentionally excluded.)
    };

    // Inset title bars are plain DOM (titleSpan text node), not a canvas, so
    // _drawEl (which only blits drawImage-able elements) never captures them.
    // Draw the title text directly onto the output canvas, positioned at the
    // titleBar's on-screen rect, approximating the CSS declared in
    // _createInsetDOM (11px sans-serif, theme.tickText colour, left-padded).
    const _drawInsetTitle = (p) => {
      if (!p.isInset || !p.titleBar || !p.insetSpec) return;
      const title = p.insetSpec.title;
      if (!title) return;
      const cst = window.getComputedStyle(p.titleBar);
      if (cst.display === 'none' || cst.visibility === 'hidden') return;
      const r = p.titleBar.getBoundingClientRect();
      if (r.width === 0 || r.height === 0) return;
      const left = (r.left - rootRect.left) * cs * outScale;
      const top  = (r.top  - rootRect.top)  * cs * outScale;
      octx.save();
      octx.fillStyle = theme.tickText;
      octx.textBaseline = 'middle';
      octx.textAlign = 'left';
      // 8px left padding matches titleBar's `padding:0 5px 0 8px`.
      _drawTex(octx, title, left + 8 * outScale,
               top + r.height * cs * outScale / 2,
               11 * outScale, { align: 'left' });
      octx.restore();
    };

    // Grid panels first, then insets on top (insets sit above grid content).
    for (const p of panels.values()) if (!p.isInset) _drawPanel(p);
    for (const p of panels.values()) if (p.isInset)  { _drawPanel(p); _drawInsetTitle(p); }

    // Callout indications (dashed source rects + leader lines) sit above panel
    // content and insets — composite them last so they overlay everything.
    // Force a fresh draw first so the canvas reflects the current view.
    try { _drawCallouts(); } catch (_) {}
    _drawEl(calloutCanvas);

    // Figure-level annotation layer is CONTENT — always composited (handles
    // suppressed for export). Hover/selection outlines are DOM styles and are
    // never on a canvas, so they are inherently excluded.
    try { _drawFigureMarkers(null, true); } catch (_) {}
    _drawEl(figMarkerCanvas);
    // Restore the on-screen draw (handles visible again if in edit mode).
    try { _drawFigureMarkers(); } catch (_) {}

    return { canvas: out, width: W, height: H };
  }

  // The whole pipeline (theme swap, view reset, native resize, composite,
  // restore) in ONE task, so no intermediate state ever paints.
  function exportCanvas(opts) {
    const o = opts || {};
    const scale   = (o.scale != null && o.scale > 0) ? o.scale : 1;
    const source  = o.source || 'view';
    const want    = o.theme  || 'current';
    const panelId = o.panelId || null;
    if (source !== 'view' && source !== 'full' && source !== 'native')
      throw new Error("exportPNG: source must be 'view', 'full' or 'native' (got "
                      + JSON.stringify(source) + ')');
    // Reject rather than fall back: a host that asked for a light export and
    // silently got the ambient theme has no way to notice.
    if (want !== 'current' && want !== 'light' && want !== 'dark')
      throw new Error("exportPNG: theme must be 'current', 'light' or 'dark' (got "
                      + JSON.stringify(want) + ')');
    const target = panelId ? panels.get(panelId) : null;
    if (panelId && !target)
      throw new Error('exportPNG: no panel with id ' + JSON.stringify(panelId));

    if (source === 'native') {
      const why = _nativeGuard(target);
      if (why) throw new Error(why);
    }

    const savedTheme = theme;
    const wantDark = want === 'dark' ? true : want === 'light' ? false : null;
    // drawImage copies a canvas's bitmap, never its CSS background, and every
    // draw function fills its own bitmap — so the swap needs no CSS work.
    const themeChanged = (wantDark !== null && wantDark !== theme.dark);
    const savedViews = [];
    _exporting = true;
    try {
      if (themeChanged) theme = _makeTheme(wantDark);

      if (source === 'native') {
        return _withNativeSize(target, () => _compositeCanvas({
          panelId, includeWidgets: o.includeWidgets, outScale: 1,
        }));
      }

      if (source === 'full') {
        for (const p of (target ? [target] : panels.values())) {
          const sv = _neutralizeView(p);
          if (sv) savedViews.push([p, sv]);
        }
      }
      if (themeChanged || savedViews.length) redrawAll();
      return _compositeCanvas({
        panelId, includeWidgets: o.includeWidgets,
        outScale: (window.devicePixelRatio || 1) * scale,
      });
    } finally {
      for (const [p, sv] of savedViews) _restoreView(p, sv);
      if (themeChanged) theme = savedTheme;
      if (themeChanged || savedViews.length) redrawAll();
      _exporting = false;
    }
  }

  // Promise-returning PNG data URL; public contract unchanged.
  function exportPNG(opts) {
    let r;
    try { r = exportCanvas(opts); }
    catch (e) { return Promise.reject(e instanceof Error ? e : new Error(String(e))); }
    let dataUrl;
    try {
      dataUrl = r.canvas.toDataURL('image/png');
    } catch (e) {
      return Promise.reject(new Error('exportPNG: toDataURL failed — ' + e));
    }
    return Promise.resolve({ dataUrl, width: r.width, height: r.height });
  }



  // ── export UI: toast, clipboard, download, context menu ───────────────────

  const _CTRL_LABEL = (typeof navigator !== 'undefined'
                       && /Mac|iPhone|iPad/.test(navigator.platform || ''))
                      ? '⌘' : 'Ctrl+';

  // Transient message, bottom-centre. Separate node from sizeLabel, which is
  // owned by the resize drag.
  const toastDiv = document.createElement('div');
  toastDiv.style.cssText =
    'position:absolute;left:50%;bottom:14px;transform:translateX(-50%);' +
    'padding:6px 12px;font-size:12px;font-family:sans-serif;' +
    'background:rgba(30,30,30,0.92);color:#fff;border-radius:5px;' +
    'pointer-events:none;white-space:nowrap;max-width:92%;overflow:hidden;' +
    'text-overflow:ellipsis;display:none;z-index:60;opacity:0;' +
    'transition:opacity 120ms linear;box-shadow:0 2px 8px rgba(0,0,0,0.45);';
  outerDiv.appendChild(toastDiv);
  let _toastTimer = null;

  function _toast(text, ms) {
    if (_toastTimer) { clearTimeout(_toastTimer); _toastTimer = null; }
    toastDiv.textContent = text;
    toastDiv.title = text;               // full text on hover when ellipsised
    toastDiv.style.display = 'block';
    // Force a style flush so the opacity transition actually runs.
    void toastDiv.offsetWidth;
    toastDiv.style.opacity = '1';
    _toastTimer = setTimeout(() => {
      toastDiv.style.opacity = '0';
      _toastTimer = setTimeout(() => { toastDiv.style.display = 'none'; }, 160);
    }, ms || 1800);
  }

  function _stamp() {
    const d = new Date(), z = (n) => String(n).padStart(2, '0');
    return '' + d.getFullYear() + z(d.getMonth() + 1) + z(d.getDate())
             + 'T' + z(d.getHours()) + z(d.getMinutes()) + z(d.getSeconds());
  }

  // Synchronous, unlike canvas.toBlob(): the clipboard write must stay in the
  // same task as the user gesture.
  function _dataUrlToBlob(dataUrl) {
    const bin = atob(dataUrl.slice(dataUrl.indexOf(',') + 1));
    const u8 = new Uint8Array(bin.length);
    for (let k = 0; k < bin.length; k++) u8[k] = bin.charCodeAt(k);
    return new Blob([u8], { type: 'image/png' });
  }

  function _canCopyImage() {
    return !!(window.isSecureContext && navigator.clipboard
              && window.ClipboardItem
              && typeof navigator.clipboard.write === 'function');
  }

  function _copyCanvas(canvas) {
    if (!_canCopyImage()) {
      _toast('Clipboard image copy needs a secure page (https or localhost) — '
             + 'use "Save PNG…" instead.', 4200);
      return Promise.resolve(false);
    }
    let blob;
    try { blob = _dataUrlToBlob(canvas.toDataURL('image/png')); }
    catch (e) { _toast('Copy failed — ' + e, 4200); return Promise.resolve(false); }
    try {
      return navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })])
        .then(() => { _toast('Image copied to clipboard'); return true; })
        .catch((e) => { _toast('Copy failed — ' + ((e && e.message) || e)
                               + '. Use "Save PNG…" instead.', 4200); return false; });
    } catch (e) {
      _toast('Copy failed — ' + ((e && e.message) || e)
             + '. Use "Save PNG…" instead.', 4200);
      return Promise.resolve(false);
    }
  }

  // Framed-document fallback: show the PNG and let the browser's own image
  // context menu save it. Needs no permission and is never blocked.
  let _previewDiv = null;
  function _showPngPreview(dataUrl, filename) {
    _hidePngPreview();
    const wrap = document.createElement('div');
    wrap.style.cssText =
      'position:absolute;inset:0;z-index:70;display:flex;flex-direction:column;' +
      'align-items:center;justify-content:center;gap:8px;padding:12px;' +
      'background:rgba(0,0,0,0.72);border-radius:4px;';
    const img = document.createElement('img');
    img.src = dataUrl;
    img.alt = filename;
    img.style.cssText =
      'max-width:100%;max-height:calc(100% - 52px);object-fit:contain;' +
      'background:#fff;border-radius:3px;box-shadow:0 4px 18px rgba(0,0,0,0.6);';
    const cap = document.createElement('div');
    cap.style.cssText =
      'font:12px sans-serif;color:#fff;text-align:center;line-height:1.5;';
    cap.textContent = 'Right-click the image → “Save image as…” to save '
                    + filename + '  ·  Esc to close';
    const close = document.createElement('div');
    close.textContent = '×';
    close.title = 'Close';
    close.style.cssText =
      'position:absolute;top:6px;right:8px;width:22px;height:22px;cursor:pointer;' +
      'display:flex;align-items:center;justify-content:center;color:#fff;' +
      'font:18px/1 sans-serif;border-radius:4px;background:rgba(255,255,255,0.16);';
    close.addEventListener('click', _hidePngPreview);
    wrap.appendChild(img); wrap.appendChild(cap); wrap.appendChild(close);
    wrap.addEventListener('mousedown', (e) => { if (e.target === wrap) _hidePngPreview(); });
    outerDiv.appendChild(wrap);
    _previewDiv = wrap;
  }
  function _hidePngPreview() {
    if (_previewDiv) { try { _previewDiv.remove(); } catch (_) {} _previewDiv = null; }
  }

  // A showSaveFilePicker rejection faster than this never showed a dialog.
  const PICKER_MIN_MS = 250;

  // Save routes:
  //   usePicker → showSaveFilePicker, a real system dialog (Chromium, secure
  //               context, user gesture) — costs a Chrome permission prompt
  //   otherwise → <a download>, straight to the downloads folder, no prompt
  //   framed    → an in-figure preview, since a sandboxed frame makes a.click()
  //               a SILENT no-op with nothing to feature detect
  // Is a system Save dialog available at all? Chromium only, secure context.
  function _canPickFile() {
    return !!(window.isSecureContext
              && typeof window.showSaveFilePicker === 'function');
  }

  async function _downloadCanvas(canvas, filename, usePicker) {
    let dataUrl;
    try { dataUrl = canvas.toDataURL('image/png'); }
    catch (e) { _toast('Export failed — ' + e, 4200); return; }
    const blob = _dataUrlToBlob(dataUrl);

    // Only when the caller asked: showSaveFilePicker hands the page a PERSISTENT
    // writable handle, so Chrome prompts for permission to edit files — too much
    // for a plain "save this image", but the right trade when the user has
    // explicitly chosen "Save as…".
    if (usePicker && _canPickFile()) {
      const t0 = performance.now();
      try {
        const h = await window.showSaveFilePicker({
          suggestedName: filename,
          types: [{ description: 'PNG image', accept: { 'image/png': ['.png'] } }],
        });
        const w = await h.createWritable();
        await w.write(blob);
        await w.close();
        _toast('Saved ' + (h.name || filename));
        return;
      } catch (e) {
        // A dialog the user closed and a dialog that never opened (headless, an
        // embedded webview, no transient activation) both reject with
        // AbortError, so the name cannot separate them — but one that never
        // rendered comes back almost instantly, whereas a human takes far
        // longer than this. Below the threshold, fall through and save anyway.
        const shown = (performance.now() - t0) >= PICKER_MIN_MS;
        if (e && e.name === 'AbortError' && shown) return;
      }
    }

    if (window.self !== window.top) {
      try {
        window.parent.postMessage({
          type: 'anyplotlib_export_png_result', requestId: null,
          dataUrl, width: canvas.width, height: canvas.height, filename }, '*');
      } catch (_) {}
      _showPngPreview(dataUrl, filename);
      return;
    }
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename;
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => { try { URL.revokeObjectURL(url); } catch (_) {} }, 10000);
    _toast('Saved ' + filename);
  }

  // ── downstream extensibility ──────────────────────────────────────────────
  const _exportActions = new Map();

  function registerExportAction(a) {
    if (!a || !a.id || typeof a.handler !== 'function')
      throw new Error('registerExportAction needs {id, label, handler}');
    _exportActions.set(a.id, Object.assign(
      { label: a.id, group: 'Actions', scope: 'both', order: 100, enabled: true }, a));
    return () => _exportActions.delete(a.id);
  }
  function unregisterExportAction(id) { return _exportActions.delete(String(id)); }

  function _actionCtx(panelId, ev) {
    const p = panelId ? panels.get(panelId) : null;
    const want = _menuTheme;
    const bind = (oo) => Object.assign(
      { panelId: panelId || null, theme: want }, oo || {});
    return {
      panelId: panelId || '',
      kind: p ? p.kind : null,
      isInset: !!(p && p.isInset),
      state: p ? p.state : null,
      theme: (want === 'current') ? theme : _makeTheme(want === 'dark'),
      themeName: want,
      figure: { width: Number(model.get('fig_width')) || 0,
                height: Number(model.get('fig_height')) || 0 },
      exportPNG: (oo) => exportPNG(bind(oo)),
      exportCanvas: (oo) => exportCanvas(bind(oo)),
      downloadPNG: (c, n) => _downloadCanvas((c && c.canvas) ? c.canvas : c,
                                             n || ('apl-' + _stamp() + '.png')),
      copyPNG: (c) => _copyCanvas((c && c.canvas) ? c.canvas : c),
      toast: (t, ms) => _toast(t, ms),
      model,
      event: ev || null,
    };
  }

  // ── context menu ──────────────────────────────────────────────────────────
  // Sticky per-figure theme, applied to every save/copy below it.
  let _menuTheme = 'current';
  let _menuDiv = null;
  let _menuOffHandlers = null;

  function _closeMenu() {
    if (_menuDiv) { try { _menuDiv.remove(); } catch (_) {} _menuDiv = null; }
    if (typeof exportBtn !== 'undefined') exportBtn.style.background = _BTN_BG;
    if (_menuOffHandlers) { _menuOffHandlers(); _menuOffHandlers = null; }
  }

  function _menuExport(mode, opts, name) {
    let r;
    try { r = exportCanvas(opts); }
    catch (e) { _toast(((e && e.message) || String(e)), 5000); return; }
    if (mode === 'copy') _copyCanvas(r.canvas);
    else _downloadCanvas(r.canvas, name, mode === 'saveAs');
  }

  function _menuRows(panelId) {
    const p = panelId ? panels.get(panelId) : null;
    const rows = [];
    const stamp = () => _stamp();
    if (p) {
      const short = String(panelId);
      const nativeWhy = _nativeGuard(p);
      rows.push({ type: 'header', label: p.isInset ? 'This inset' : 'This panel' });
      rows.push({ type: 'item', label: 'Copy image', accel: _CTRL_LABEL + 'C',
                  run: () => _menuExport('copy',
                    { panelId, source: 'view', theme: _menuTheme, includeWidgets: true }) });
      rows.push({ type: 'item', label: 'Save PNG…',
                  run: () => _menuExport('save',
                    { panelId, source: 'view', theme: _menuTheme, includeWidgets: true },
                    'apl-' + short + '-view-' + stamp() + '.png') });
      if (_canPickFile())
        rows.push({ type: 'item', label: 'Save as… (choose folder)',
                    run: () => _menuExport('saveAs',
                      { panelId, source: 'view', theme: _menuTheme, includeWidgets: true },
                      'apl-' + short + '-view-' + stamp() + '.png') });
      rows.push({ type: 'item', label: 'Save full view…',
                  run: () => _menuExport('save',
                    { panelId, source: 'full', theme: _menuTheme, includeWidgets: true },
                    'apl-' + short + '-full-' + stamp() + '.png') });
      rows.push({ type: 'item', label: 'Save at native resolution…',
                  disabled: !!nativeWhy, title: nativeWhy || '',
                  run: () => _menuExport('save',
                    { panelId, source: 'native', theme: _menuTheme, includeWidgets: true },
                    'apl-' + short + '-native-' + stamp() + '.png') });
    }
    rows.push({ type: 'header', label: 'Whole figure' });
    rows.push({ type: 'item', label: 'Copy figure',
                run: () => _menuExport('copy',
                  { source: 'view', theme: _menuTheme, includeWidgets: true }) });
    rows.push({ type: 'item', label: 'Save PNG…',
                run: () => _menuExport('save',
                  { source: 'view', theme: _menuTheme, includeWidgets: true },
                  'apl-figure-view-' + stamp() + '.png') });
    if (_canPickFile())
      rows.push({ type: 'item', label: 'Save as… (choose folder)',
                  run: () => _menuExport('saveAs',
                    { source: 'view', theme: _menuTheme, includeWidgets: true },
                    'apl-figure-view-' + stamp() + '.png') });
    rows.push({ type: 'item', label: 'Save full view…',
                run: () => _menuExport('save',
                  { source: 'full', theme: _menuTheme, includeWidgets: true },
                  'apl-figure-full-' + stamp() + '.png') });
    // No figure-level native: panels have different native sizes.
    rows.push({ type: 'header', label: 'Theme' });
    rows.push({ type: 'radio', options: ['current', 'light', 'dark'] });

    const extras = [..._exportActions.values()]
      .filter((a) => a.scope === 'both'
                  || (a.scope === 'panel' && p) || (a.scope === 'figure' && !p))
      .sort((a, b) => (a.order - b.order) || String(a.label).localeCompare(String(b.label)));
    let lastGroup = null;
    for (const a of extras) {
      if (a.group !== lastGroup) { rows.push({ type: 'header', label: a.group }); lastGroup = a.group; }
      let dis = false;
      try { dis = (typeof a.enabled === 'function') ? !a.enabled(_actionCtx(panelId, null)) : !a.enabled; }
      catch (_) { dis = true; }
      rows.push({ type: 'item', label: a.label, disabled: dis, actionId: a.id,
                  run: (ev) => { try { a.handler(_actionCtx(panelId, ev)); }
                                 catch (e) { _toast(((e && e.message) || String(e)), 5000); } } });
    }
    return rows;
  }


  function _openMenu(panelId, clientX, clientY, ev) {
    _closeMenu();
    const dark = theme.dark;
    const menu = document.createElement('div');
    menu.setAttribute('data-apl-menu', '1');
    menu.style.cssText =
      'position:absolute;z-index:60;min-width:210px;padding:5px 0;' +
      'font:12px sans-serif;border-radius:6px;user-select:none;' +
      'background:' + (dark ? 'rgba(28,28,38,0.98)' : 'rgba(252,252,253,0.99)') + ';' +
      'color:' + (dark ? '#e0e0e8' : '#1e1e28') + ';' +
      'border:1px solid ' + (dark ? 'rgba(120,120,160,0.32)' : 'rgba(0,0,0,0.16)') + ';' +
      'box-shadow:0 6px 22px rgba(0,0,0,' + (dark ? '0.62' : '0.28') + ');';

    const mkHeader = (label) => {
      const d = document.createElement('div');
      d.textContent = label;
      d.style.cssText = 'padding:5px 12px 3px;font-size:10px;font-weight:600;'
        + 'letter-spacing:0.06em;text-transform:uppercase;opacity:0.55;';
      return d;
    };
    const mkItem = (row) => {
      const d = document.createElement('div');
      d.style.cssText = 'padding:5px 12px;display:flex;gap:16px;'
        + 'align-items:center;justify-content:space-between;'
        + (row.disabled ? 'opacity:0.42;cursor:default;' : 'cursor:pointer;');
      const t = document.createElement('span');
      t.textContent = row.label;
      d.appendChild(t);
      if (row.accel) {
        const a = document.createElement('span');
        a.textContent = row.accel;
        a.style.cssText = 'opacity:0.5;font-size:11px;';
        d.appendChild(a);
      }
      if (row.title) d.title = row.title;
      if (row.actionId) d.setAttribute('data-apl-action', row.actionId);
      if (!row.disabled) {
        d.addEventListener('mouseenter', () => {
          d.style.background = dark ? 'rgba(90,120,200,0.30)' : 'rgba(60,110,220,0.13)';
        });
        d.addEventListener('mouseleave', () => { d.style.background = ''; });
        d.addEventListener('click', (e) => {
          e.stopPropagation(); _closeMenu(); row.run(e);
        });
      }
      return d;
    };
    const mkRadio = (options) => {
      const d = document.createElement('div');
      d.style.cssText = 'padding:3px 12px 6px;display:flex;gap:10px;';
      for (const opt of options) {
        const b = document.createElement('span');
        b.setAttribute('data-apl-theme-opt', opt);
        const on = (_menuTheme === opt);
        b.textContent = (on ? '● ' : '○ ') + opt;
        b.style.cssText = 'cursor:pointer;font-size:11px;'
          + (on ? 'opacity:1;font-weight:600;' : 'opacity:0.62;');
        b.addEventListener('click', (e) => {
          e.stopPropagation();
          _menuTheme = opt;
          _openMenu(panelId, clientX, clientY, ev);   // rebuild in place
        });
        d.appendChild(b);
      }
      return d;
    };
    const mkSep = () => {
      const d = document.createElement('div');
      d.style.cssText = 'height:1px;margin:4px 0;background:'
        + (dark ? 'rgba(140,140,180,0.20)' : 'rgba(0,0,0,0.10)') + ';';
      return d;
    };

    const rows = _menuRows(panelId);
    let first = true;
    for (const row of rows) {
      if (row.type === 'header') { if (!first) menu.appendChild(mkSep());
                                   menu.appendChild(mkHeader(row.label)); }
      else if (row.type === 'radio') menu.appendChild(mkRadio(row.options));
      else menu.appendChild(mkItem(row));
      first = false;
    }

    // Positioned in outerDiv, edge-flipped like _showTooltip.
    outerDiv.appendChild(menu);
    const host = outerDiv.getBoundingClientRect();
    const mw = menu.offsetWidth || 210, mh = menu.offsetHeight || 200;
    const vw = window.innerWidth, vh = window.innerHeight;
    let lx = clientX + 2, ly = clientY + 2;
    if (lx + mw > vw - 8) lx = Math.max(8, clientX - mw - 2);
    if (ly + mh > vh - 8) ly = Math.max(8, vh - mh - 8);
    const sc = _cssScale();
    menu.style.left = ((lx - host.left) * sc) + 'px';
    menu.style.top  = ((ly - host.top)  * sc) + 'px';
    _menuDiv = menu;
    _showExportBtn(true);
    exportBtn.style.background = _BTN_BG_ACTIVE;

    const onDown = (e) => { if (!menu.contains(e.target)) _closeMenu(); };
    const onKey  = (e) => { if (e.key === 'Escape') { _closeMenu(); e.stopPropagation(); } };
    const onScroll = () => _closeMenu();
    document.addEventListener('mousedown', onDown, true);
    document.addEventListener('keydown', onKey, true);
    window.addEventListener('scroll', onScroll, true);
    _menuOffHandlers = () => {
      document.removeEventListener('mousedown', onDown, true);
      document.removeEventListener('keydown', onKey, true);
      window.removeEventListener('scroll', onScroll, true);
    };
  }

  // Insets sit above grid content, so test them first (panels is grid-then-inset).
  function _panelAtPoint(node) {
    const insets = [], grid = [];
    for (const p of panels.values()) (p.isInset ? insets : grid).push(p);
    for (const p of insets.concat(grid)) {
      const box = p.isInset ? (p.insetDiv || p.cell) : (p.cell || _panelBox(p));
      if (box && box.contains(node)) return p.id;
    }
    return null;
  }

  // The panel a menu/copy should act on: the one with keyboard focus
  // (mouseenter focuses a panel's overlay canvas), else the whole figure.
  function _focusedPanelId() {
    for (const p of panels.values())
      if (p.overlayCanvas === document.activeElement) return p.id;
    return null;
  }

  // On outerDiv, not per overlayCanvas: the overlay covers only the image area,
  // so the axis gutters, colorbar and title strip are not under it.
  // Keep focus on whichever panel the pointer came from, so the menu is scoped
  // to that panel rather than falling back to the whole figure.
  exportBtn.addEventListener('mousedown', (e) => e.preventDefault());
  // Tabbing to the badge has to reveal it: it is hidden until the pointer moves,
  // and a keyboard-only user never moves one.
  exportBtn.addEventListener('focus', () => {
    _showExportBtn(true);
    exportBtn.style.outline = '2px solid ' + _BTN_BG_ACTIVE;
    exportBtn.style.outlineOffset = '1px';
  });
  exportBtn.addEventListener('blur', () => {
    exportBtn.style.outline = '';
    if (!_menuDiv && !_helpHovered) _showExportBtn(false);
  });
  exportBtn.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter' && e.key !== ' ' && e.key !== 'Spacebar') return;
    e.preventDefault();
    e.stopPropagation();
    exportBtn.click();
  });
  exportBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    if (_menuDiv) { _closeMenu(); return; }
    const r = exportBtn.getBoundingClientRect();
    _openMenu(_focusedPanelId(), r.left, r.bottom + 2, e);
  });

  outerDiv.addEventListener('contextmenu', (e) => {
    e.preventDefault();
    e.stopPropagation();
    _openMenu(_panelAtPoint(e.target), e.clientX, e.clientY, e);
  });

  // Panel-scoped when a panel has focus (mouseenter focuses its overlay),
  // figure-scoped otherwise. On outerDiv, not document, so it never hijacks
  // Ctrl+C for the surrounding notebook.
  outerDiv.addEventListener('keydown', (e) => {
    if (!(e.ctrlKey || e.metaKey) || e.altKey || e.shiftKey) return;
    if (String(e.key).toLowerCase() !== 'c') return;
    const hit = _focusedPanelId();
    e.preventDefault();
    e.stopPropagation();
    _menuExport('copy', { panelId: hit, source: 'view',
                          theme: _menuTheme, includeWidgets: true });
  });

  // Test hooks.
  try {
    globalThis.__apl_menuItems = () => {
      if (!_menuDiv) return null;
      return [...(_menuDiv.children || [])].map((c) => ({
        text: c.textContent,
        disabled: (c.style.cursor === 'default'),
        actionId: c.getAttribute && c.getAttribute('data-apl-action') || null,
      }));
    };
    globalThis.__apl_toastText = () => ({
      text: toastDiv.textContent,
      shown: toastDiv.style.display !== 'none' && toastDiv.style.opacity !== '0',
    });
    globalThis.__apl_menuTheme = () => _menuTheme;
    globalThis.__apl_previewOpen = () => !!_previewDiv;
    globalThis.__apl_nativeLimits = () => ({ maxSide: EXPORT_MAX_SIDE,
                                             maxArea: EXPORT_MAX_AREA });
    globalThis.__apl_nativeGuard = (pid) => _nativeGuard(panels.get(pid));
  } catch (_) {}


  // ── cell-aware CSS scaling ────────────────────────────────────────────────
  // When the notebook cell (or any container) is narrower than the figure's
  // native size, apply CSS transform:scale() to outerDiv so it shrinks
  // proportionally without re-rendering canvases or writing to the model.
  // Full canvas resolution is preserved; CSS transforms correctly route
  // pointer events so all interactive features (drag, zoom, pan) keep working.
  // Also called after layout/resize changes so the scale stays in sync.
  //
  // Prerequisite: .apl-outer must carry `min-width: max-content` (set in the
  // _css traitlet).  Without it, the inline-block shrinks to match its
  // constrained parent and outerDiv.offsetWidth == cellW, giving s = 1 always.
  function _applyScale() {
    const cellW = el.getBoundingClientRect().width;
    if (!cellW) return;
    // offsetWidth is the pre-transform layout width — unaffected by any
    // currently applied transform AND pinned ≥ content width by
    // min-width:max-content, so it always reflects the true native figure size.
    const nativeW = outerDiv.offsetWidth;
    const nativeH = outerDiv.offsetHeight;
    if (!nativeW) return;
    const s = Math.min(1.0, cellW / nativeW);
    // transform-origin:top left (set in _css) means scale(s) shrinks the
    // figure from the top-left corner.  With width:100% on scaleWrap the
    // scaled figure (nativeW*s ≤ cellW) always fits — no overflow, no
    // clipping, no cross-browser layout-box vs visual-box discrepancies.
    outerDiv.style.transform = s < 1 ? `scale(${s})` : '';
    // transform:scale does not affect layout — outerDiv still occupies
    // nativeH px in the flow even when visually shorter.  A negative
    // marginBottom compensates exactly, pulling subsequent content up by
    // the difference without ever touching scaleWrap's own dimensions.
    // This eliminates any ResizeObserver feedback loop.
    outerDiv.style.marginBottom = (s < 1 && nativeH)
      ? Math.round(nativeH * (s - 1)) + 'px'
      : '';
  }

  if (typeof ResizeObserver !== 'undefined') {
    let _lastCellW = 0;
    let _lastRoW = 0, _lastRoH = 0;
    let _roTimer = null;
    let _wasZeroSize = true;
    new ResizeObserver(entries => {
      const cr = entries[0].contentRect;
      const cellW = cr.width, cellH = cr.height;
      // (0) Reveal detection: a host (SpyDE) can mount a panel HIDDEN
      // (display:none) and reveal it later by toggling display alone, WITHOUT
      // any layout_json / fig_width change (so neither model listener below
      // fires a redraw).  A 3-D GPU panel that skipped init while zero-size
      // (see the hasDrawableSize guard in draw3d) would then stay on Canvas2D
      // forever.  When the observed element transitions from zero-size to a
      // real size, re-attempt GPU init on any 3-D panel still on the canvas
      // path and redraw it, so the reveal actually flips it to WebGPU.
      const _nowZero = !(cellW > 0 && cellH > 0);
      if (_wasZeroSize && !_nowZero) {
        _wasZeroSize = false;
        requestAnimationFrame(() => {
          let _need = false;
          for (const p of panels.values()) {
            if (p.kind === '3d' && p._gpu === undefined && p.state
                && _gpuWanted(p.state, !!(p._3dTex && p._3dTex.ready))) {
              _need = true; break;
            }
          }
          if (_need) redrawAll();
        });
      } else if (_nowZero) {
        _wasZeroSize = true;
      }
      // (1) Jupyter fit-to-cell down-scale — width-only to avoid a feedback
      // loop (our own scaleWrap height updates would re-trigger the observer).
      if (cellW !== _lastCellW) {
        _lastCellW = cellW;
        requestAnimationFrame(_applyScale);
      }
      // (2) Container-resize hook for an embedding host (SpyDE): fire onResize
      // with the new root-container CSS px so the host can drive a real
      // relayout (e.g. handle.resize(w,h) → fig_width/height → applyLayout).
      // Debounced (rAF-coalesced trailing) so a drag-resize fires once on
      // settle, not per-frame.  Fires on width OR height change; the host owns
      // whether to scale, relayout, or ignore.
      if (typeof onResize === 'function' &&
          (Math.round(cellW) !== _lastRoW || Math.round(cellH) !== _lastRoH)) {
        _lastRoW = Math.round(cellW); _lastRoH = Math.round(cellH);
        if (_roTimer) cancelAnimationFrame(_roTimer);
        _roTimer = requestAnimationFrame(() => {
          _roTimer = null;
          try { onResize({ width: _lastRoW, height: _lastRoH }); } catch (_) {}
        });
      }
    }).observe(el);
    requestAnimationFrame(_applyScale);
  }

  // ── model listeners ───────────────────────────────────────────────────────
  model.on('change:layout_json', () => { applyLayout(); redrawAll(); requestAnimationFrame(_applyScale); });
  model.on('change:fig_width change:fig_height', () => { applyLayout(); redrawAll(); requestAnimationFrame(_applyScale); });

  // Toggle the per-panel stats overlay when display_stats changes.
  // Hiding is immediate; showing waits for the next natural redraw to
  // populate the overlay text — but we also call redrawAll() here so the
  // stats appear instantly without having to interact with the figure first.
  model.on('change:display_stats', () => {
    const show = model.get('display_stats');
    for (const p of panels.values()) {
      if (!show && p.statsDiv) {
        p.statsDiv.style.display = 'none';
      }
    }
    if (show) redrawAll();
  });

  // Python→JS targeted widget update (source:"python" in event_json).
  // Applies changed fields directly to the widget in overlay_widgets and
  // redraws the panel — no image re-decode, no Python echo.
  model.on('change:event_json', () => {
    try {
      const msg = JSON.parse(model.get('event_json') || '{}');
      if (!msg || msg.source !== 'python') return;
      const p = panels.get(msg.panel_id);
      if (!p || !p.state) return;
      const ws = p.state.overlay_widgets || [];
      const wi = ws.findIndex(w => w.id === msg.widget_id);
      if (wi < 0) return;
      // Apply every field from the message except protocol keys
      const skip = new Set(['source', 'panel_id', 'widget_id']);
      for (const [k, v] of Object.entries(msg)) {
        if (!skip.has(k)) ws[wi][k] = v;
      }
      _redrawPanel(p);
    } catch(_) {}
  });

  // ── edit-chrome / figure-marker listeners ─────────────────────────────────
  model.on('change:edit_chrome',    () => { _applyEditMode(); });
  model.on('change:selected_panel', () => { _applyPanelChrome(); });
  model.on('change:figure_markers_json', () => { _loadFigMarkers(); _drawFigureMarkers(); });

  // ── initial render ────────────────────────────────────────────────────────
  _loadFigMarkers();
  applyLayout();
  _applyEditMode();

  // Internal API surface returned to mount().  anywidget ignores render()'s
  // return value; mount() captures it so its handle can reach the closure's
  // panel map + drawing helpers (exportPNG, dispose) that are otherwise
  // inaccessible from module scope.
  return {
    panels,
    exportPNG,
    exportCanvas,       // synchronous {canvas,width,height} producer
    registerExportAction,
    unregisterExportAction,
    calloutCanvas,      // figure-level region-indication overlay
    _drawCallouts,      // force a callout redraw (tests / external layout sync)
    figMarkerCanvas,    // figure-level annotation overlay (content, exported)
    _drawFigureMarkers, // force a figure-marker redraw (tests / external sync)
    _gpuDisposeImagePanel,
    _gpuDisposePanel,
  };
}

export default { render };

// ═══════════════════════════════════════════════════════════════════════════
// Embedding API — use anyplotlib WITHOUT Jupyter or the anywidget runtime.
//
// For Electron apps, MDI sub-windows, or any plain web page:
//
//   import apl, { mount } from './figure_esm.js';
//
//   const handle = mount(document.getElementById('plot'), state, {
//     onEvent: (ev) => console.log(ev.event_type, ev.xdata, ev.ydata),
//   });
//   handle.setPanelState(panelId, newPanelState);   // live data update
//   handle.resize(800, 500);
//   handle.dispose();
//
// `state` is the serialised figure state produced by the Python side:
// `anyplotlib.embed.figure_state(fig)` — a plain JSON dict of
// {layout_json, fig_width, fig_height, event_json, panel_<id>_json, ...}.
//
// For a live Python backend (e.g. an Electron app with a Python sidecar over
// WebSocket/stdio), pair `mount(..., {onSync})` with
// `anyplotlib.embed.FigureBridge` on the Python side:
//   JS → Python:  onSync(key, value)            → bridge.receive(key, value)
//   Python → JS:  FigureBridge(fig, send=...)   → handle.applyUpdate(key, value)
// ═══════════════════════════════════════════════════════════════════════════

// Minimal stand-in for the anywidget model: get/set/save_changes/on/off.
// set() fires per-key listeners synchronously (matching anywidget semantics);
// save_changes() flushes dirty keys to the optional outbound sync handler.
export function createLocalModel(initialState) {
  const _data   = Object.assign({}, initialState || {});
  const _cbs    = {};
  const _anyCbs = [];
  const _dirty  = new Set();
  let _onSync   = null;

  return {
    get(key) { return _data[key]; },
    set(key, val) {
      _data[key] = val;
      _dirty.add(key);
      const ev = 'change:' + key;
      if (_cbs[ev]) for (const cb of [..._cbs[ev]]) { try { cb({ new: val }); } catch (_) {} }
      for (const cb of [..._anyCbs]) { try { cb(); } catch (_) {} }
    },
    save_changes() {
      const keys = [..._dirty];
      _dirty.clear();
      if (_onSync) {
        for (const k of keys) { try { _onSync(k, _data[k]); } catch (_) {} }
      }
    },
    on(event, cb) {
      if (event === 'change') { _anyCbs.push(cb); return; }
      (_cbs[event] = _cbs[event] || []).push(cb);
    },
    off(event, cb) {
      if (!event) { for (const k in _cbs) _cbs[k] = []; _anyCbs.length = 0; return; }
      if (_cbs[event]) _cbs[event] = _cbs[event].filter((c) => c !== cb);
    },
    // Apply an update that originated OUTSIDE this view (e.g. from a Python
    // bridge): listeners fire so the figure re-renders, but the key is not
    // marked dirty, so it is never echoed back through onSync.
    applyRemote(key, val) {
      this.set(key, val);
      _dirty.delete(key);
    },
    _setSyncHandler(fn) { _onSync = fn; },
    get model() { return this; },
  };
}

// Mount a figure into *el* and return a control handle.
//   opts.onEvent(ev)        — parsed interaction events (pointer/key/wheel …)
//   opts.onSync(key, value) — raw outbound model writes, for a Python bridge
//   opts.onResize({width,height}) — fired (debounced) when the ROOT CONTAINER
//                             el resizes, so the host can relayout the figure
//                             to its new box (e.g. call handle.resize(w,h)).
//   opts.onReadout(info)    — 2-D hover readout: {panel_id, img_x, img_y, col, row,
//                             xdata, ydata, units, value, exact, rgba, text}, or
//                             null when the cursor leaves the image. Render it in
//                             your own chrome (e.g. a status line in the window
//                             corner) and call Plot2D.set_readout_visible(False) to
//                             drop the on-image pill. The same payload also arrives
//                             as an `apl:readout` CustomEvent bubbling off `el`.
export function mount(el, state, opts) {
  // Diagnostic marker: proves THIS (WebGPU-2D) build of figure_esm.js is loaded.
  try { globalThis.__apl_build = 'webgpu-2d'; } catch (_) {}
  const o = opts || {};
  const model = createLocalModel(state);
  if (o.onSync) model._setSyncHandler(o.onSync);
  if (o.onEvent) {
    model.on('change:event_json', () => {
      try {
        const ev = JSON.parse(model.get('event_json') || '{}');
        if (ev && ev.event_type && ev.source !== 'python') o.onEvent(ev);
      } catch (_) {}
    });
  }
  // Capture render()'s internal API so the handle can reach the closure's
  // panel map + drawing helpers (exportPNG / GPU dispose).  opts.onResize (if
  // given) is fired with {width,height} when the ROOT CONTAINER resizes, so an
  // embedding host can relayout the figure to its new box.
  const api = render({ model, el,
                       onResize: o.onResize, onReadout: o.onReadout }) || {};

  // Raw-pixel pushes (setImage) coalesce onto one animation frame per panel:
  // several frames handed over inside one task repaint once, showing the last.
  // Without this a scrub pays the full LUT blit per frame on the caller's
  // thread, which is the cost the binary path exists to avoid.
  const pendingImages = new Map();      // panel id → the frame to paint next
  let imageFrameRequest = null;

  function commitImages() {
    imageFrameRequest = null;
    const frames = [...pendingImages];
    pendingImages.clear();
    for (const [panelId, frame] of frames) {
      const panel = api.panels && api.panels.get(panelId);
      if (!panel) continue;
      // Geometry is patched HERE rather than at push time so it lands in the
      // same task as the bytes it describes: a frame of a new size would
      // otherwise paint once at the new dimensions over the previous bytes.
      const patch = imagePatch(panel.state || {}, frame);
      if (Object.keys(patch).length) handle.patchPanel(panelId, patch);
      const slot = `panel_${panelId}_geom::image_b64`;
      const table = globalThis.__apl_pixbytes || (globalThis.__apl_pixbytes = {});
      table[slot] = frame.bytes;
      // The blit cache keys on the geom's image_b64 string, so a frame pushed
      // under an unchanged key would never reach the canvas. The counter is
      // per DOCUMENT, not per handle: the side table is global and panel ids
      // repeat across figures of the same layout.
      const sequence = (globalThis.__apl_pixseq = (globalThis.__apl_pixseq || 0) + 1);
      if (!panel._geomCache) panel._geomCache = {};
      panel._geomCache.image_b64 = `\u0000bin:${sequence}`;
      panel._geomCache.detail_b64 = '';
      delete panel._geomCache.detail_b64_bytes;
      delete panel._detailBlit;
      delete globalThis.__apl_pixbytes[`panel_${panelId}_geom::detail_b64`];
      model.applyRemote(slot, `${frame.bytes.length}:${sequence}`);
    }
  }

  // The state fields a pushed frame implies, limited to the ones that differ.
  function imagePatch(current, frame) {
    const patch = {};
    if (current.image_width !== frame.width) patch.image_width = frame.width;
    if (current.image_height !== frame.height) patch.image_height = frame.height;
    if (!!current.is_rgb !== frame.rgb) patch.is_rgb = frame.rgb;
    // These bytes are the whole frame, so any overview/tile geometry the panel
    // was built with no longer describes them.
    if (current.base_width) patch.base_width = 0;
    if (current.base_height) patch.base_height = 0;
    if (current.tile_enabled) patch.tile_enabled = false;
    // A detail tile is a crop of the PREVIOUS frame at a zoom the viewer may
    // still be at, and _blit2d composites it over the base. Clearing only the
    // light field leaves the bytes and the region in the geom cache, which
    // _applyGeom splices straight back in.
    if (current.detail_b64 || current.detail_width || current.detail_height)
      Object.assign(patch, { detail_b64: '', detail_region: [],
                             detail_width: 0, detail_height: 0,
                             detail_min: null, detail_max: null,
                             detail_is_int: false });
    // display_* is the colour window; raw_* is the band the codes span. The
    // caller hands over codes already mapped to its window, so they agree.
    if (frame.displayMin !== undefined && current.display_min !== frame.displayMin) {
      patch.display_min = frame.displayMin;
      patch.raw_min = frame.displayMin;
    }
    if (frame.displayMax !== undefined && current.display_max !== frame.displayMax) {
      patch.display_max = frame.displayMax;
      patch.raw_max = frame.displayMax;
    }
    return patch;
  }

  function flushImages() {
    if (imageFrameRequest !== null) cancelAnimationFrame(imageFrameRequest);
    if (pendingImages.size) commitImages();
    imageFrameRequest = null;
  }

  const handle = {
    model,
    api,               // internal render() API (panels, calloutCanvas, _drawCallouts, …)
    get(key) { return model.get(key); },
    set(key, value) { model.set(key, value); model.save_changes(); },
    // Replace one panel's full state (object or pre-serialised JSON string).
    setPanelState(panelId, panelState) {
      const v = typeof panelState === 'string' ? panelState : JSON.stringify(panelState);
      this.set('panel_' + panelId + '_json', v);
    },
    // Merge *partial* into one panel's state and re-render it.  Values are
    // stored verbatim, so this is how markers, extra_lines, display_min /
    // display_max and overlay_widgets are driven from JS.
    patchPanel(panelId, partial) {
      const key = `panel_${panelId}_json`;
      if (model.get(key) === undefined)
        throw new Error(`patchPanel: unknown panel id ${panelId}`);
      let current = {};
      try { current = JSON.parse(model.get(key) || '{}'); } catch (_) {}
      model.applyRemote(key, JSON.stringify(Object.assign(current, partial)));
    },
    // The panel ids in layout order, so a host need not parse layout_json.
    panelIds() {
      try {
        const layout = JSON.parse(model.get('layout_json') || '{}');
        return (layout.panel_specs || []).map((spec) => spec.id);
      } catch (_) { return []; }
    },
    // Replace a 2-D panel's image with RAW pixel bytes, skipping base64.
    //   bytes   Uint8Array of width*height colormap codes, or width*height*4
    //           RGBA bytes when opts.rgb is true.
    //   opts    {rgb, display_min, display_max}. Each is patched into the
    //           panel's state first when it differs, so the geometry and the
    //           colour window match the bytes on the very frame they arrive.
    // Throws on an unknown panel or a byte count that is not width*height.
    // The repaint lands on the next animation frame; exportPNG flushes first.
    setImage(panelId, bytes, width, height, opts) {
      const panel = api.panels && api.panels.get(panelId);
      if (!panel) throw new Error(`setImage: unknown panel id ${panelId}`);
      if (panel.kind !== '2d')
        throw new Error(`setImage: panel ${panelId} is a ${panel.kind} panel; ` +
                        `only a 2-D image panel draws pixel bytes`);
      if (model.get(`panel_${panelId}_geom`) === undefined)
        throw new Error(`setImage: panel ${panelId} has no image channel`);
      const settings = opts || {};
      const rgb = !!settings.rgb;
      const expected = width * height * (rgb ? 4 : 1);
      if (!bytes || bytes.length !== expected)
        throw new Error(`setImage: expected ${expected} bytes for ${width}x${height}` +
                        `${rgb ? ' RGBA' : ''}, got ${bytes ? bytes.length : 0}`);

      pendingImages.set(panelId, {
        bytes, width, height, rgb,
        displayMin: settings.display_min, displayMax: settings.display_max,
      });
      if (imageFrameRequest === null)
        imageFrameRequest = requestAnimationFrame(commitImages);
    },
    // Paint every pending setImage frame now instead of on the next frame.
    flushImages,
    // Inbound update from a Python bridge — renders without echoing to onSync.
    applyUpdate(key, value) { model.applyRemote(key, value); },
    resize(width, height) {
      model.set('fig_width', Math.round(width));
      model.set('fig_height', Math.round(height));
      model.save_changes();
    },
    // Composite the figure (or one panel) to a PNG data URL.
    //   opts.scale (1)               extra multiplier over devicePixelRatio
    //   opts.includeWidgets (false)  include the interactive widget overlay
    //   opts.panelId (null)          crop to one panel instead of the figure
    //   opts.source ('view')         'view' | 'full' | 'native'
    //   opts.theme ('current')       'current' | 'light' | 'dark'
    // Resolves to {dataUrl, width, height}; rejects with a useful message.
    exportPNG(opts) {
      if (typeof api.exportPNG !== 'function') {
        return Promise.reject(new Error('exportPNG unavailable (render() returned no API)'));
      }
      try { flushImages(); return api.exportPNG(opts); }
      catch (e) { return Promise.reject(e); }
    },
    // Same, but synchronous and returning the raw {canvas, width, height} so a
    // host can encode it itself (TIFF, JPEG, a PDF page, …). Throws on a bad
    // request rather than rejecting.
    exportCanvas(opts) {
      if (typeof api.exportCanvas !== 'function')
        throw new Error('exportCanvas unavailable (render() returned no API)');
      flushImages();
      return api.exportCanvas(opts);
    },
    // Add an entry to the right-click export menu. Returns an unregister fn.
    //   {id, label, group, scope:'panel'|'figure'|'both', order, enabled,
    //    handler(ctx)}
    // ctx: {panelId, kind, isInset, state, theme, themeName, figure,
    //       exportPNG, exportCanvas, downloadPNG, copyPNG, toast, model, event}
    registerExportAction(action) {
      if (typeof api.registerExportAction !== 'function')
        throw new Error('registerExportAction unavailable (render() returned no API)');
      return api.registerExportAction(action);
    },
    unregisterExportAction(id) {
      if (typeof api.unregisterExportAction !== 'function') return false;
      return api.unregisterExportAction(id);
    },
    // Remove the figure's DOM.  (Window-level listeners registered by the
    // renderer are inert once the DOM is gone; for complete cleanup, discard
    // the containing element or iframe.)
    dispose() {
      // Free GPU resources for every panel before tearing down the DOM.
      try { if (api.panels) for (const p of api.panels.values()) {
        api._gpuDisposeImagePanel(p); api._gpuDisposePanel(p);
      } } catch (_) {}
      model.off(); el.replaceChildren();
    },
  };
  return handle;
}







// ═══════════════════════════════════════════════════════════════════════════
// Navigated-embed runtime: a page that owns its data and dispatches on it.
//
// A navigated page is a navigator panel whose widget drives one or more other
// panels: move the crosshair, the signal panel shows that position's frame and
// its overlays follow.  The page carries the whole dataset as one binary blob
// plus a list of bindings that say which block feeds which panel, so the
// dispatch is a table lookup and a `setImage`, not a program per result kind.
//
//   import { mountNavigated } from './figure_esm.js';
//   const handle = await mountNavigated(host, page);   // page from Python
//   handle.dispatch([3, 5]);                           // navigate from code
//
// `page` is what `anyplotlib.embed.navigated_html` inlines:
//   {state, blocks: {data, manifest}, bindings: [...], chrome: {...}}
// ═══════════════════════════════════════════════════════════════════════════

const BLOCK_ARRAY_TYPES = {
  uint8: Uint8Array, int8: Int8Array,
  uint16: Uint16Array, int16: Int16Array,
  uint32: Uint32Array, int32: Int32Array,
  float32: Float32Array, float64: Float64Array,
};

function blockArrayView(buffer, spec) {
  const ArrayType = BLOCK_ARRAY_TYPES[spec.dtype];
  if (!ArrayType) throw new Error(`unsupported block dtype ${spec.dtype}`);
  return new ArrayType(buffer, spec.offset, spec.nbytes / ArrayType.BYTES_PER_ELEMENT);
}

// Decode one packed blob into typed-array views over a single ArrayBuffer.
// `packed` is {data: base64 string, manifest: {name: entry}} as produced by
// `anyplotlib.embed.pack_blocks`; every view aliases the same buffer, so
// nothing is copied per block.
async function decodeBlocks(packed) {
  const manifest = (packed && packed.manifest) || {};
  const payload = (packed && packed.data) || '';
  const buffer = payload
    ? await (await fetch(`data:application/octet-stream;base64,${payload}`)).arrayBuffer()
    : new ArrayBuffer(0);
  const blocks = {};
  for (const name of Object.keys(manifest)) {
    const entry = manifest[name];
    if (entry.kind === 'ragged') {
      const columns = {};
      for (const column of Object.keys(entry.columns))
        columns[column] = blockArrayView(buffer, entry.columns[column]);
      blocks[name] = { kind: 'ragged', columns,
                       offsets: blockArrayView(buffer, entry.offsets),
                       navShape: entry.nav_shape || null };
    } else {
      blocks[name] = { kind: 'dense', shape: entry.shape,
                       array: blockArrayView(buffer, entry) };
    }
  }
  return blocks;
}

// Reader over a dense block whose LEADING dimensions are the navigation axes.
// `at` returns a view (never a copy); `gather` and `reduce` return new arrays.
function dense(block) {
  const shape = block.shape;
  const array = block.array;

  function frameLength(navigationDimensions) {
    let length = 1;
    for (let axis = navigationDimensions; axis < shape.length; axis++) length *= shape[axis];
    return length;
  }

  function flatPosition(index) {
    const parts = Array.isArray(index) ? index : [index];
    let flat = 0;
    for (let axis = 0; axis < parts.length; axis++) {
      const extent = shape[axis];
      const clamped = Math.max(0, Math.min(extent - 1, Math.round(parts[axis])));
      flat = flat * extent + clamped;
    }
    return flat;
  }

  return {
    kind: 'dense',
    shape,
    at(index) {
      const parts = Array.isArray(index) ? index : [index];
      const length = frameLength(parts.length);
      const start = flatPosition(parts) * length;
      return array.subarray(start, start + length);
    },
    gather(indices) {
      if (!indices.length) return new Float32Array(0);
      const total = new Float32Array(this.at(indices[0]).length);
      for (const index of indices) {
        const frame = this.at(index);
        for (let i = 0; i < total.length; i++) total[i] += frame[i];
      }
      const scale = 1 / indices.length;
      for (let i = 0; i < total.length; i++) total[i] *= scale;
      return total;
    },
    // One value per navigation position: sum(frame * mask) over the signal
    // grid.  `mask` is a Uint8Array covering the trailing two dimensions.
    reduce(mask) {
      const signalLength = shape[shape.length - 2] * shape[shape.length - 1];
      if (mask.length !== signalLength)
        throw new Error(`reduce: mask of ${mask.length} does not cover the ` +
                        `${shape[shape.length - 2]}x${shape[shape.length - 1]} signal grid`);
      const selected = [];
      for (let i = 0; i < signalLength; i++) if (mask[i]) selected.push(i);
      const positions = Math.floor(array.length / signalLength);
      const out = new Float32Array(positions);
      for (let position = 0; position < positions; position++) {
        const base = position * signalLength;
        let total = 0;
        for (let i = 0; i < selected.length; i++) total += array[base + selected[i]];
        out[position] = total;
      }
      return out;
    },
  };
}

// Reader over a ragged block: a row-pointer array plus one value array per
// column, so each navigation position owns a variable number of rows.
function ragged(block) {
  const offsets = block.offsets;
  const columns = block.columns;
  const columnNames = Object.keys(columns);
  const navShape = block.navShape || [offsets.length - 1];

  function flatPosition(index) {
    const parts = Array.isArray(index) ? index : [index];
    if (parts.length !== navShape.length)
      throw new Error(`ragged index of length ${parts.length} into a ` +
                      `${navShape.length}-D navigation grid; pack the block ` +
                      `with nav_shape if it has more than one axis`);
    let flat = 0;
    for (let axis = 0; axis < navShape.length; axis++) {
      const extent = navShape[axis];
      const clamped = Math.max(0, Math.min(extent - 1, Math.round(parts[axis])));
      flat = flat * extent + clamped;
    }
    return flat;
  }

  return {
    kind: 'ragged',
    navShape,
    columnNames,
    at(index) {
      const position = flatPosition(index);
      const start = offsets[position], stop = offsets[position + 1];
      const rows = {};
      for (const name of columnNames) rows[name] = columns[name].subarray(start, stop);
      return rows;
    },
    gather(indices) {
      const spans = [];
      let total = 0;
      for (const index of indices) {
        const position = flatPosition(index);
        const start = offsets[position], stop = offsets[position + 1];
        spans.push([start, stop]);
        total += stop - start;
      }
      const rows = {};
      for (const name of columnNames) {
        const values = columns[name];
        const out = new values.constructor(total);
        let written = 0;
        for (const [start, stop] of spans) {
          out.set(values.subarray(start, stop), written);
          written += stop - start;
        }
        rows[name] = out;
      }
      return rows;
    },
    // The sparse virtual image: one value per navigation position, summing
    // `valueColumn` over the rows whose rounded (x, y) falls inside the mask.
    reduce(mask, xColumn, yColumn, valueColumn) {
      const xs = columns[xColumn || 'x'];
      const ys = columns[yColumn || 'y'];
      const values = valueColumn ? columns[valueColumn] : null;
      const width = mask.width, height = mask.height;
      const positions = offsets.length - 1;
      const out = new Float32Array(positions);
      for (let position = 0; position < positions; position++) {
        let total = 0;
        for (let row = offsets[position]; row < offsets[position + 1]; row++) {
          const column = Math.round(xs[row]), line = Math.round(ys[row]);
          if (column < 0 || line < 0 || column >= width || line >= height) continue;
          if (mask[line * width + column]) total += values ? values[row] : 1;
        }
        out[position] = total;
      }
      return out;
    },
  };
}

// Selection mask for a rectangle, circle or annulus widget dict as it appears
// in `overlay_widgets`, in image pixels.  A pixel belongs to the mask when its
// integer coordinate lies inside the shape: `x <= column < x + w` for a
// rectangle, `distance <= r` for a circle, `r_inner <= distance <= r_outer`
// for an annulus.  The returned array carries `width` and `height` so a
// consumer can index it without being told the grid again.
function maskFromWidget(widget, width, height) {
  const mask = new Uint8Array(width * height);
  mask.width = width;
  mask.height = height;
  const type = widget && widget.type;
  if (type === 'rectangle') {
    const left = Math.max(0, Math.ceil(widget.x));
    const top = Math.max(0, Math.ceil(widget.y));
    const right = Math.min(width - 1, Math.ceil(widget.x + widget.w) - 1);
    const bottom = Math.min(height - 1, Math.ceil(widget.y + widget.h) - 1);
    for (let line = top; line <= bottom; line++)
      for (let column = left; column <= right; column++) mask[line * width + column] = 1;
    return mask;
  }
  if (type === 'circle' || type === 'annular') {
    const centreX = widget.cx, centreY = widget.cy;
    const outer = type === 'circle' ? widget.r : widget.r_outer;
    const inner = type === 'circle' ? 0 : widget.r_inner;
    const outerSquared = outer * outer, innerSquared = inner * inner;
    const top = Math.max(0, Math.floor(centreY - outer));
    const bottom = Math.min(height - 1, Math.ceil(centreY + outer));
    const left = Math.max(0, Math.floor(centreX - outer));
    const right = Math.min(width - 1, Math.ceil(centreX + outer));
    for (let line = top; line <= bottom; line++) {
      const dy = line - centreY;
      for (let column = left; column <= right; column++) {
        const dx = column - centreX;
        const distanceSquared = dx * dx + dy * dy;
        if (distanceSquared <= outerSquared && distanceSquared >= innerSquared)
          mask[line * width + column] = 1;
      }
    }
    return mask;
  }
  throw new Error(`maskFromWidget: unsupported widget type ${type}`);
}

// Splat `{x, y, intensity}` rows as filled disks into a Float32 image.  This
// is how a vectors panel gets a base image: `combine` is "max" for one
// position's rows and "sum" when several positions were gathered.
function rasterDisks(rows, width, height, radius, combine) {
  const out = new Float32Array(width * height);
  const xs = rows.x, ys = rows.y;
  const intensity = rows.intensity || null;
  const accumulate = combine === 'sum';
  const reach = Math.ceil(radius);
  const radiusSquared = radius * radius;
  for (let row = 0; row < xs.length; row++) {
    const centreX = Math.round(xs[row]), centreY = Math.round(ys[row]);
    const value = intensity ? intensity[row] : 1;
    for (let dy = -reach; dy <= reach; dy++) {
      const line = centreY + dy;
      if (line < 0 || line >= height) continue;
      for (let dx = -reach; dx <= reach; dx++) {
        if (dx * dx + dy * dy > radiusSquared) continue;
        const column = centreX + dx;
        if (column < 0 || column >= width) continue;
        const at = line * width + column;
        out[at] = accumulate ? out[at] + value : Math.max(out[at], value);
      }
    }
  }
  return out;
}

// Percentile display window over the finite values, as [low, high].  `lo` and
// `hi` are percentages; 0 and 100 return the exact extremes, anything between
// is read off a 1024-bin histogram so the cost stays one pass over the data
// rather than a sort.
function robustLevels(values, lo, hi) {
  const lowPercent = lo === undefined ? 2 : lo;
  const highPercent = hi === undefined ? 98 : hi;
  const BINS = 1024;
  let minimum = Infinity, maximum = -Infinity, finite = 0;
  for (let i = 0; i < values.length; i++) {
    const value = values[i];
    if (!Number.isFinite(value)) continue;
    if (value < minimum) minimum = value;
    if (value > maximum) maximum = value;
    finite++;
  }
  if (!finite) return [0, 1];
  if (maximum <= minimum) return [minimum, minimum + 1];
  const span = maximum - minimum;
  const histogram = new Int32Array(BINS);
  const scale = BINS / span;
  for (let i = 0; i < values.length; i++) {
    const value = values[i];
    if (!Number.isFinite(value)) continue;
    const bin = Math.min(BINS - 1, Math.floor((value - minimum) * scale));
    histogram[bin]++;
  }
  function percentile(percent) {
    if (percent <= 0) return minimum;
    if (percent >= 100) return maximum;
    const target = (percent / 100) * finite;
    let seen = 0;
    for (let bin = 0; bin < BINS; bin++) {
      seen += histogram[bin];
      if (seen >= target) return minimum + ((bin + 0.5) * span) / BINS;
    }
    return maximum;
  }
  const low = percentile(lowPercent), high = percentile(highPercent);
  return high > low ? [low, high] : [minimum, maximum];
}

// Map values onto the 8-bit colormap codes the renderer blits.  Matches the
// Python quantiser: clip into [0, 255], then truncate.  An infinity saturates
// at whichever end it lies past; a NaN fails every comparison and becomes 0.
function toU8(values, vmin, vmax) {
  const out = new Uint8Array(values.length);
  const scale = 255 / ((vmax - vmin) || 1);
  for (let i = 0; i < values.length; i++) {
    const code = (values[i] - vmin) * scale;
    out[i] = code > 255 ? 255 : (code > 0 ? code : 0);
  }
  return out;
}

// ── page chrome ────────────────────────────────────────────────────────────

// Forward touches to the renderer's mouse handlers.  The draw path listens for
// mousedown/mousemove/mouseup only, so without this a phone can see the page
// but cannot drag a widget.
function installTouchShim(el) {
  function forward(touchEvent, mouseType) {
    const touch = touchEvent.changedTouches[0];
    if (!touch) return;
    const target = document.elementFromPoint(touch.clientX, touch.clientY) || el;
    target.dispatchEvent(new MouseEvent(mouseType, {
      bubbles: true, cancelable: true, view: window,
      clientX: touch.clientX, clientY: touch.clientY, buttons: 1,
    }));
    touchEvent.preventDefault();
  }
  el.addEventListener('touchstart', (e) => forward(e, 'mousedown'), { passive: false });
  el.addEventListener('touchmove', (e) => forward(e, 'mousemove'), { passive: false });
  el.addEventListener('touchend', (e) => forward(e, 'mouseup'), { passive: false });
  el.addEventListener('touchcancel', (e) => forward(e, 'mouseup'), { passive: false });
}

// Tell a host iframe how tall the page is, so it can size itself to the
// content instead of guessing or scrolling.
function reportEmbedHeight() {
  function send() {
    try {
      const height = Math.ceil(document.documentElement.scrollHeight);
      if (window.parent && window.parent !== window)
        window.parent.postMessage({ aplEmbedHeight: height }, '*');
    } catch (_) {}
  }
  send();
  if (typeof ResizeObserver !== 'undefined')
    new ResizeObserver(send).observe(document.documentElement);
  window.addEventListener('resize', send);
}

// ── dispatch ───────────────────────────────────────────────────────────────

// A 3-D panel's cloud rides `panel_<id>_geom` as base64: the binary
// side-table path is registered for image pixels only, and a cloud changes on
// a view click rather than per navigator move, so the encode is not on a hot
// path.
function encodeBase64(bytes) {
  const CHUNK = 0x8000;
  let binary = '';
  for (let at = 0; at < bytes.length; at += CHUNK)
    binary += String.fromCharCode.apply(null, bytes.subarray(at, at + CHUNK));
  return btoa(binary);
}

function typedArrayBytes(array) {
  return new Uint8Array(array.buffer, array.byteOffset, array.byteLength);
}

// Marker and extra-line groups the dispatch writes carry this prefix, so a
// refresh can tell its own groups from the page's.
const OVERLAY_ID_PREFIX = 'apl-overlay-';

function indexList(index) {
  if (index === null || index === undefined) return [];
  if (Array.isArray(index)) return Array.isArray(index[0]) ? index : [index];
  return [[index]];
}

// A 1-D panel's x axis travels as base64 (`x_axis_b64`), and `draw1d` caches
// the decoded copy on the panel, so read that and fall back to decoding.
function panelAxis(panel) {
  if (panel && panel._1dXArr && panel._1dXArr.length) return panel._1dXArr;
  const state = (panel && panel.state) || {};
  if (state.x_axis_b64) {
    const binary = atob(state.x_axis_b64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return new Float64Array(bytes.buffer);
  }
  return state.x_axis || [];
}

function nearestAxisIndex(axis, value) {
  if (!axis || !axis.length) return 0;
  let best = 0, bestDistance = Infinity;
  for (let i = 0; i < axis.length; i++) {
    const distance = Math.abs(axis[i] - value);
    if (distance < bestDistance) { bestDistance = distance; best = i; }
  }
  return best;
}

// Mount a navigated page and wire its navigator widgets to its bindings.
// Resolves to the `mount()` handle extended with `dispatch(index)`, the
// current `index`, and the decoded `blocks`.
export async function mountNavigated(el, page, opts) {
  const options = opts || {};
  const bindings = page.bindings || [];
  const chrome = page.chrome || {};
  const blocks = await decodeBlocks(page.blocks || {});

  const readers = new Map();
  function readerFor(name) {
    if (!readers.has(name)) {
      const block = blocks[name];
      if (!block) throw new Error(`unknown block ${name}`);
      readers.set(name, block.kind === 'ragged' ? ragged(block) : dense(block));
    }
    return readers.get(name);
  }

  // Both kinds of refresh coalesce onto one animation frame, latest wins: a
  // drag fires an event per pointer move, and each one is a pass over a block.
  let queuedIndex = null;
  let dispatchRequest = null;
  let queuedReduce = null;
  let reduceRequest = null;

  const handle = mount(el, page.state, Object.assign({}, options, {
    onEvent(event) {
      handleEvent(event);
      if (options.onEvent) options.onEvent(event);
    },
  }));

  function panelFor(panelId) {
    return (handle.api.panels && handle.api.panels.get(panelId)) || null;
  }

  function panelState(panelId) {
    const panel = panelFor(panelId);
    return (panel && panel.state) || {};
  }

  function bindingFor(panelId) {
    return bindings.find((binding) => binding.panel_id === panelId) || null;
  }

  // A navigator widget's position, as a navigation index or a set of them.
  // The navigator panel IS the navigation grid, so a 2-D widget's image pixels
  // are already the index and a 1-D widget's data coordinate resolves through
  // the panel's own x axis.
  function indexFromWidget(binding, widget) {
    const state = panelState(binding.panel_id);
    const columns = state.image_width || 1, lines = state.image_height || 1;
    if (widget.type === 'crosshair')
      return [Math.round(widget.cy), Math.round(widget.cx)];
    if (widget.type === 'rectangle') {
      const maxColumns = widget.max_w == null ? widget.w : Math.min(widget.w, widget.max_w);
      const maxLines = widget.max_h == null ? widget.h : Math.min(widget.h, widget.max_h);
      const firstColumn = Math.max(0, Math.round(widget.x));
      const firstLine = Math.max(0, Math.round(widget.y));
      const lastColumn = Math.min(columns - 1, Math.round(widget.x + maxColumns) - 1);
      const lastLine = Math.min(lines - 1, Math.round(widget.y + maxLines) - 1);
      const indices = [];
      for (let line = firstLine; line <= lastLine; line++)
        for (let column = firstColumn; column <= lastColumn; column++) indices.push([line, column]);
      return indices.length ? indices : [[firstLine, firstColumn]];
    }
    const axis = panelAxis(panelFor(binding.panel_id));
    if (widget.type === 'vline' || widget.type === 'point')
      return [nearestAxisIndex(axis, widget.x)];
    // The span selector is the 1-D analogue of the rectangle: it selects a
    // run of positions, and its own max_extent has already capped the drag.
    if (widget.type === 'range') {
      const first = nearestAxisIndex(axis, Math.min(widget.x0, widget.x1));
      const last = nearestAxisIndex(axis, Math.max(widget.x0, widget.x1));
      const indices = [];
      for (let position = first; position <= last; position++) indices.push([position]);
      return indices;
    }
    return null;
  }

  // Which of a `views` binding's entries the page's segmented control is on.
  // Held by POSITION: two views may read the same block with different
  // colours, which is what a direction toggle over one cloud looks like.
  const activeViews = new Map();

  function activeView(binding) {
    if (!binding.views || !binding.views.length) return null;
    return binding.views[activeViews.get(binding.panel_id) || 0] || binding.views[0];
  }

  function frameBlock(binding) {
    const view = activeView(binding);
    if (view) return view.block;
    if (binding.frame && binding.frame.block) return binding.frame.block;
    throw new Error(`binding for panel ${binding.panel_id} names no frame block`);
  }

  // The per-point colours that go with the entry currently shown.
  function frameColorsBlock(binding) {
    const view = activeView(binding);
    if (view && view.colors) return view.colors;
    return binding.frame && binding.frame.colors;
  }

  function frameValues(binding, indices) {
    const reader = readerFor(frameBlock(binding));
    const single = indices.length === 1;
    if (binding.frame.kind === 'disks') {
      const rows = single ? reader.at(indices[0]) : reader.gather(indices);
      const state = panelState(binding.panel_id);
      const width = binding.frame.width || state.image_width;
      const height = binding.frame.height || state.image_height;
      const combine = binding.frame.combine || (single ? 'max' : 'sum');
      return { values: rasterDisks(rows, width, height, binding.frame.radius || 3, combine),
               width, height };
    }
    const values = single ? reader.at(indices[0]) : reader.gather(indices);
    const shape = blocks[frameBlock(binding)].shape;
    return { values, width: shape[shape.length - 1], height: shape[shape.length - 2] };
  }

  // The panel's own colour window when it has one: a window recomputed per
  // frame both costs two passes over the data and makes the contrast jump
  // between neighbouring positions, which reads as the data changing.
  function frameLevels(binding, values) {
    if (binding.frame && binding.frame.levels) return binding.frame.levels;
    const state = panelState(binding.panel_id);
    if (Number.isFinite(state.display_min) && Number.isFinite(state.display_max)
        && state.display_max > state.display_min)
      return [state.display_min, state.display_max];
    return robustLevels(values, 2, 98);
  }

  // A cloud is the whole dataset, not one position's frame, so it is pushed
  // when the binding first shows it and again when a view click swaps it, not
  // on every navigator move.
  const shownClouds = new Map();

  function paintPoints3d(binding) {
    const name = frameBlock(binding);
    const colorsName = frameColorsBlock(binding);
    const shown = `${name}|${colorsName || ''}`;
    if (shownClouds.get(binding.panel_id) === shown) return;
    shownClouds.set(binding.panel_id, shown);

    const points = blocks[name];
    if (!points || points.kind !== 'dense' || points.shape.length !== 2
        || points.shape[1] !== 3)
      throw new Error(`points3d block ${name} must be dense (M, 3), got ` +
                      `${points ? points.shape : 'nothing'}`);
    const count = points.shape[0];
    const depth = new Float32Array(count);
    for (let point = 0; point < count; point++) depth[point] = points.array[point * 3 + 2];

    const geomKey = `panel_${binding.panel_id}_geom`;
    let geom = {};
    try { geom = JSON.parse(handle.get(geomKey) || '{}'); } catch (_) {}
    geom.vertices_b64 = encodeBase64(typedArrayBytes(points.array));
    geom.z_values_b64 = encodeBase64(typedArrayBytes(depth));
    if (colorsName) {
      const colors = blocks[colorsName];
      if (!colors || colors.kind !== 'dense' || colors.shape[0] !== count)
        throw new Error(`colors block ${colorsName} must be dense with ` +
                        `${count} rows, got ${colors ? colors.shape : 'nothing'}`);
      geom.point_colors_b64 = encodeBase64(typedArrayBytes(colors.array));
    }
    handle.applyUpdate(geomKey, JSON.stringify(geom));
    // vertices_count and a bumped revision live on the LIGHT trait; without
    // them the renderer draws the old cloud's point count.
    const state = panelState(binding.panel_id);
    handle.patchPanel(binding.panel_id, {
      vertices_count: count,
      _geom_rev: (state._geom_rev || 0) + 1,
    });
  }

  function paintFrame(binding, indices) {
    const panel = panelFor(binding.panel_id);
    if ((binding.frame && binding.frame.kind === 'points3d')
        || (panel && panel.kind === '3d')) {
      paintPoints3d(binding);
      return;
    }
    const { values, width, height } = frameValues(binding, indices);
    const levels = frameLevels(binding, values);
    handle.setImage(binding.panel_id, toU8(values, levels[0], levels[1]), width, height,
                    { display_min: levels[0], display_max: levels[1] });
  }

  // One overlay entry → a marker group for a 2-D panel, or an extra line for a
  // 1-D one.  Columns default to x/y (and u/v, x1/y1/x2/y2, value) so a plain
  // block needs no column map.
  function overlayWire(overlay, rows) {
    const style = overlay.style || {};
    const names = overlay.columns || {};
    const xs = rows[names.x || 'x'], ys = rows[names.y || 'y'];
    const count = xs ? xs.length : 0;
    // The style IS the wire dict (the keys MarkerGroup.to_wire emits), carried
    // through whole: an allow-list here silently drops whatever it has not
    // heard of, and `fill_alpha: 0` reads as "unset" to the renderer's default.
    const wire = Object.assign({}, style);
    delete wire.radius;          // an input for `sizes`, not a wire field
    wire.id = `apl-overlay-${overlay.block}`;
    wire.name = overlay.block;
    if (wire.color === undefined) wire.color = '#ff0000';
    if (overlay.kind === 'curves') {
      wire.data = Array.from(rows[names.value || 'value'] || []);
      wire.x_axis = Array.from(xs || []);
      if (wire.linewidth === undefined) wire.linewidth = 1.5;
      if (wire.linestyle === undefined) wire.linestyle = 'solid';
      if (wire.alpha === undefined) wire.alpha = 1;
      if (wire.marker === undefined) wire.marker = 'none';
      if (wire.markersize === undefined) wire.markersize = 4;
      if (wire.label === undefined) wire.label = '';
      if (wire.axis === undefined) wire.axis = 'left';
      return wire;
    }
    const offsets = [];
    for (let row = 0; row < count; row++) offsets.push([xs[row], ys[row]]);
    wire.type = overlay.kind;
    if (wire.linewidth === undefined) wire.linewidth = 1.5;
    if (overlay.kind === 'circles') {
      wire.offsets = offsets;
      const radiusColumn = names.radius ? rows[names.radius] : null;
      const radius = style.radius === undefined ? 5 : style.radius;
      wire.sizes = offsets.map((_, row) => (radiusColumn ? radiusColumn[row] : radius));
    } else if (overlay.kind === 'arrows') {
      wire.offsets = offsets;
      const us = rows[names.u || 'u'], vs = rows[names.v || 'v'];
      wire.U = offsets.map((_, row) => (us ? us[row] : 0));
      wire.V = offsets.map((_, row) => (vs ? vs[row] : 0));
    } else if (overlay.kind === 'lines') {
      const x1 = rows[names.x1 || 'x1'], y1 = rows[names.y1 || 'y1'];
      const x2 = rows[names.x2 || 'x2'], y2 = rows[names.y2 || 'y2'];
      const segments = [];
      for (let row = 0; row < (x1 ? x1.length : 0); row++)
        segments.push([[x1[row], y1[row]], [x2[row], y2[row]]]);
      wire.segments = segments;
    } else {
      throw new Error(`unsupported overlay kind ${overlay.kind}`);
    }
    return wire;
  }

  // Keep every group the figure was built with, replacing only the ones this
  // runtime owns: a dispatch that assigned the list wholesale would wipe the
  // page's own annotations on the first crosshair move.
  function mergeOverlayGroups(existing, fresh) {
    const kept = (existing || []).filter(
      (group) => !String(group && group.id).startsWith(OVERLAY_ID_PREFIX));
    return kept.concat(fresh);
  }

  // One 3-D point marked on the panel, optionally turning the camera to face
  // it. The rule is not "some angle pointing that way": atan2(y, x) - 90 names
  // the same direction 180 degrees out and lands the point on the far edge.
  function paintHighlight(binding, overlay, indices) {
    const reader = readerFor(overlay.block);
    const rows = reader.at(indices[0]);
    let x, y, z;
    if (reader.kind === 'ragged') {
      const names = overlay.columns || {};
      const xs = rows[names.x || 'x'], ys = rows[names.y || 'y'];
      const zs = rows[names.z || 'z'];
      if (!xs || !xs.length) return;
      x = xs[0]; y = ys[0]; z = zs[0];
    } else {
      if (rows.length < 3) return;
      x = rows[0]; y = rows[1]; z = rows[2];
    }
    if (!Number.isFinite(x) || !Number.isFinite(y) || !Number.isFinite(z)) return;

    const patch = { highlight: Object.assign(
      { color: '#ff1744', size: 7 }, overlay.style || {}, { x, y, z }) };
    const faceCamera = overlay.face_camera || binding.face_camera;
    if (faceCamera) {
      const radius = Math.hypot(x, y, z) || 1;
      patch.azimuth = Math.atan2(x, -y) * 180 / Math.PI;
      patch.elevation = Math.asin(Math.max(-1, Math.min(1, z / radius))) * 180 / Math.PI;
    }
    // Written either way: the flag persists on the trait, so leaving a
    // previous face_camera push's `true` in place would let a later highlight
    // discard the orbit the reader is holding.
    patch._view_from_python = !!faceCamera;
    handle.patchPanel(binding.panel_id, patch);
  }

  function paintOverlays(binding, indices) {
    const markers = [];
    const lines = [];
    let anyMarkers = false;
    for (const overlay of binding.overlays) {
      if (overlay.kind === 'highlight') { paintHighlight(binding, overlay, indices); continue; }
      const reader = readerFor(overlay.block);
      const rows = indices.length === 1 ? reader.at(indices[0]) : reader.gather(indices);
      if (overlay.kind === 'curves') { lines.push(overlayWire(overlay, rows)); continue; }
      anyMarkers = true;
      markers.push(overlayWire(overlay, rows));
    }
    const state = panelState(binding.panel_id);
    const patch = {};
    if (anyMarkers) patch.markers = mergeOverlayGroups(state.markers, markers);
    if (lines.length) patch.extra_lines = mergeOverlayGroups(state.extra_lines, lines);
    if (Object.keys(patch).length) handle.patchPanel(binding.panel_id, patch);
  }

  function formatReadout(binding, indices) {
    const spec = binding.readout;
    const reader = readerFor(spec.block);
    const rows = reader.kind === 'dense'
      ? { value: reader.at(indices[0]) } : reader.at(indices[0]);
    const names = spec.names || Object.keys(rows);
    const units = spec.units || {};
    return names.map((name) => {
      const values = rows[name];
      const value = values && values.length ? values[0] : NaN;
      const unit = units[name] ? ` ${units[name]}` : '';
      return `${name} ${Number.isFinite(value) ? value.toPrecision(4) : '-'}${unit}`;
    }).join('   ');
  }

  function writeText(id, text) {
    const node = document.getElementById(id);
    if (node) node.textContent = text;
  }

  // Wire the page's segmented control for a `views` binding: each button names
  // a block, and picking one re-reads the panel's frame from it at the
  // position the navigator is already on.
  function installViews(binding) {
    activeViews.set(binding.panel_id, 0);
    const group = document.getElementById(`apl-views-${binding.panel_id}`);
    if (!group) return;
    const buttons = [...group.querySelectorAll('button[data-view]')];
    const mark = () => {
      const chosen = activeViews.get(binding.panel_id);
      for (const button of buttons)
        button.setAttribute('aria-pressed',
          Number(button.dataset.view) === chosen ? 'true' : 'false');
    };
    for (const button of buttons)
      button.addEventListener('click', () => {
        activeViews.set(binding.panel_id, Number(button.dataset.view));
        mark();
        if (handle.index !== null) dispatch(handle.index);
      });
    mark();
  }

  // Refresh every driven binding for one navigation index (or index set).
  function dispatch(index) {
    const indices = indexList(index);
    if (!indices.length) return;
    handle.index = index;
    for (const binding of bindings) {
      if (binding.role !== 'driven') continue;
      if (binding.frame || binding.views) paintFrame(binding, indices);
      if (binding.overlays && binding.overlays.length) paintOverlays(binding, indices);
      if (binding.readout)
        writeText(`apl-readout-${binding.panel_id}`, formatReadout(binding, indices));
    }
  }

  function requestDispatch(index) {
    queuedIndex = index;
    if (dispatchRequest !== null) return;
    dispatchRequest = requestAnimationFrame(() => {
      dispatchRequest = null;
      const next = queuedIndex;
      queuedIndex = null;
      dispatch(next);
    });
  }

  // A detector widget on a driven panel reduces the whole block back onto the
  // navigator: the navigator image becomes sum(frame * mask) per position.
  // Only these three define a region of the signal grid to sum over; any other
  // widget on the same panel is left to do whatever else it is there for.
  const DETECTOR_TYPES = ['rectangle', 'circle', 'annular'];

  function paintReduced(binding, widget) {
    const spec = binding.reduce;
    const state = panelState(binding.panel_id);
    const mask = maskFromWidget(widget, state.image_width, state.image_height);
    const reader = readerFor(spec.block);
    const values = reader.kind === 'ragged'
      ? reader.reduce(mask, spec.x, spec.y, spec.value) : reader.reduce(mask);
    const navigatorState = panelState(spec.navigator_panel);
    const levels = robustLevels(values, 0, 100);
    handle.setImage(spec.navigator_panel, toU8(values, levels[0], levels[1]),
                    navigatorState.image_width, navigatorState.image_height,
                    { display_min: levels[0], display_max: levels[1] });
  }

  function requestReduce(binding, widget) {
    queuedReduce = [binding, widget];
    if (reduceRequest !== null) return;
    reduceRequest = requestAnimationFrame(() => {
      reduceRequest = null;
      const next = queuedReduce;
      queuedReduce = null;
      paintReduced(next[0], next[1]);
    });
  }

  function handleEvent(event) {
    if (!event || !event.widget_id) return;
    if (event.event_type !== 'pointer_move' && event.event_type !== 'pointer_up') return;
    const binding = bindingFor(event.panel_id);
    if (!binding) return;
    if (binding.role === 'navigator') {
      const index = indexFromWidget(binding, event);
      if (index) requestDispatch(index);
      return;
    }
    if (binding.role === 'driven' && binding.reduce
        && DETECTOR_TYPES.includes(event.type)) requestReduce(binding, event);
  }

  if (chrome.touch !== false) installTouchShim(el);
  if (chrome.height_report !== false) reportEmbedHeight();

  // A binding may carry its panel's widgets, so a page can declare the
  // navigator's crosshair or detector next to what it drives.
  for (const binding of bindings)
    if (binding.widgets) handle.patchPanel(binding.panel_id,
                                           { overlay_widgets: binding.widgets });

  for (const binding of bindings) {
    if (binding.views && binding.views.length) installViews(binding);
    if (!binding.reduce) continue;
    // A reduce binding with no detector on its panel can never fire, and the
    // page author has no other way to find that out.
    const widgets = panelState(binding.panel_id).overlay_widgets || [];
    if (!widgets.some((widget) => DETECTOR_TYPES.includes(widget.type)))
      throw new Error(`panel ${binding.panel_id} reduces onto ` +
                      `${binding.reduce.navigator_panel} but carries no ` +
                      `${DETECTOR_TYPES.join('/')} widget to reduce under`);
  }

  handle.dispatch = dispatch;
  handle.blocks = blocks;
  handle.index = null;

  const navigatorBinding = bindings.find((binding) => binding.role === 'navigator');
  const navigatorState = navigatorBinding ? panelState(navigatorBinding.panel_id) : {};
  const initial = (navigatorBinding && navigatorBinding.initial_index)
    || (navigatorState.image_height ? [0, 0] : [0]);
  dispatch(initial);
  return handle;
}

// The readers are one namespace rather than seven top-level exports: they are
// generic names (`dense`, `ragged`, `toU8`) that would otherwise sit beside
// `mount` and `render` in every importer's completion list.
export const embed = {
  mountNavigated, decodeBlocks, dense, ragged,
  maskFromWidget, rasterDisks, robustLevels, toU8,
};
