// figure_esm.js
// Unified JS renderer for the Figure widget.
// Each panel gets its own three-canvas stack (plot / overlay / markers).
// Panels are drawn independently; only the changed panel's listener fires.

function render({ model, el }) {
  const dpr = window.devicePixelRatio || 1;

  // ── shared plot-area padding (mirrors 1D drawing constants) ─────────────
  // The image/plot area for BOTH 1D and 2D panels sits at:
  //   x: PAD_L → pw-PAD_R,   y: PAD_T → ph-PAD_B
  // This guarantees pixel-perfect alignment of all panels in a row/column.
  const PAD_L=58, PAD_R=12, PAD_T=12, PAD_B=42;

  // ── theme ────────────────────────────────────────────────────────────────
  function _isDarkBg(node) {
    while (node && node !== document.body) {
      const bg = window.getComputedStyle(node).backgroundColor;
      const m  = bg.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
      if (m) {
        const [r,g,b] = [+m[1],+m[2],+m[3]];
        if (!(r===0&&g===0&&b===0&&bg.includes('0)')))
          return (0.299*r + 0.587*g + 0.114*b) < 128;
      }
      node = node.parentElement;
    }
    return window.matchMedia('(prefers-color-scheme: dark)').matches;
  }

  function _makeTheme(dark) {
    return dark ? {
      bg:'#1e1e2e', bgPlot:'#181825', bgCanvas:'#181825',
      border:'#44475a', axisBg:'#1e1e2e',
      axisStroke:'rgba(98,114,164,0.5)', gridStroke:'rgba(98,114,164,0.18)',
      tickStroke:'#6272a4', tickText:'rgba(205,214,244,0.75)',
      unitText:'rgba(98,114,164,0.85)', dark:true,
    } : {
      bg:'#f0f0f0', bgPlot:'#ffffff', bgCanvas:'#ffffff',
      border:'#cccccc', axisBg:'#f0f0f0',
      axisStroke:'rgba(0,0,0,0.35)', gridStroke:'rgba(0,0,0,0.07)',
      tickStroke:'#666666', tickText:'rgba(40,40,40,0.85)',
      unitText:'rgba(100,100,100,0.85)', dark:false,
    };
  }

  let theme = _makeTheme(_isDarkBg(el));
  const _mq = window.matchMedia('(prefers-color-scheme: dark)');
  _mq.addEventListener('change', () => { theme = _makeTheme(_isDarkBg(el)); redrawAll(); });
  new MutationObserver(() => { theme = _makeTheme(_isDarkBg(el)); redrawAll(); })
    .observe(document.documentElement, { attributes:true,
      attributeFilter:['data-jp-theme-name','data-vscode-theme-kind','class'] });

  // ── shared math helpers ──────────────────────────────────────────────────
  function findNice(t) {
    if (t<=0) return 1;
    const mag = Math.pow(10, Math.floor(Math.log10(t)));
    let best=mag, bd=Math.abs(t-mag);
    for (const n of [1,2,2.5,5,10]) { const v=n*mag,d=Math.abs(t-v); if(d<bd){best=v;bd=d;} }
    return best;
  }
  function fmtVal(v) {
    const a=Math.abs(v);
    if(a===0) return '0';
    if(a>=1e4) return v.toExponential(1);
    if(a>=100) return v.toFixed(0);
    if(a>=1)   return v.toFixed(2);
    if(a>=1e-2)return v.toFixed(4);
    return v.toExponential(1);
  }
  function _axisValToFrac(arr,val) {
    if(arr.length<2) return 0;
    const n=arr.length, asc=arr[n-1]>=arr[0];
    if(asc?val<=arr[0]:val>=arr[0]) return 0;
    if(asc?val>=arr[n-1]:val<=arr[n-1]) return 1;
    let lo=0,hi=n-2;
    while(lo<hi){const mid=(lo+hi)>>1;const ok=asc?(arr[mid]<=val&&val<arr[mid+1]):(arr[mid]>=val&&val>arr[mid+1]);if(ok){lo=mid;break;}if(asc?arr[mid+1]<=val:arr[mid+1]>=val)lo=mid+1;else hi=mid;}
    return (lo+(val-arr[lo])/(arr[lo+1]-arr[lo]))/(n-1);
  }
  function _axisFracToVal(arr,frac) {
    if(arr.length<2) return arr.length?arr[0]:0;
    const n=arr.length, pos=Math.max(0,Math.min(1,frac))*(n-1), lo=Math.min(Math.floor(pos),n-2), t=pos-lo;
    return arr[lo]+t*(arr[lo+1]-arr[lo]);
  }
  // Blend a #rrggbb / #rgb colour toward white by `amt` (0=unchanged, 1=white).
  function _brightenColor(hex, amt=0.45) {
    if(!hex||hex[0]!=='#') return hex;
    let r,g,b;
    if(hex.length===4){r=parseInt(hex[1]+hex[1],16);g=parseInt(hex[2]+hex[2],16);b=parseInt(hex[3]+hex[3],16);}
    else{r=parseInt(hex.slice(1,3),16);g=parseInt(hex.slice(3,5),16);b=parseInt(hex.slice(5,7),16);}
    if(isNaN(r)||isNaN(g)||isNaN(b)) return hex;
    r=Math.min(255,Math.round(r+(255-r)*amt));g=Math.min(255,Math.round(g+(255-g)*amt));b=Math.min(255,Math.round(b+(255-b)*amt));
    return `#${r.toString(16).padStart(2,'0')}${g.toString(16).padStart(2,'0')}${b.toString(16).padStart(2,'0')}`;
  }

  // ── b64 array decode helpers ─────────────────────────────────────────────
  // Convert a base-64 string (little-endian raw bytes) to a JS TypedArray.
  // TypedArrays support .length and [i] indexing so they are drop-in
  // replacements for plain arrays in all draw / hit-test functions.
  function _decodeF64(b64) {
    const bin = atob(b64);
    const buf = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) buf[i] = bin.charCodeAt(i);
    return new Float64Array(buf.buffer);
  }
  function _decodeF32(b64) {
    const bin = atob(b64);
    const buf = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) buf[i] = bin.charCodeAt(i);
    return new Float32Array(buf.buffer);
  }
  function _decodeI32(b64) {
    const bin = atob(b64);
    const buf = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) buf[i] = bin.charCodeAt(i);
    return new Int32Array(buf.buffer);
  }

  // ── per-panel frame timing ────────────────────────────────────────────────
  // Called at the entry of every draw function (draw2d / draw1d / draw3d /
  // drawBar).  Records a high-resolution timestamp in a 60-entry rolling
  // buffer on the panel object, then:
  //   • updates window._aplTiming[p.id]  — always, for Playwright readback
  //   • updates p.statsDiv text          — only when display_stats is true
  //
  // Placing the call at the *start* of each draw function means we measure
  // the inter-trigger interval: how often the CPU initiates a render, which
  // is the right metric for both interactive (pan/zoom) and data-push paths.
  const _FRAME_BUF = 60;

  function _recordFrame(p) {
    const now = performance.now();
    p.frameTimes.push(now);
    if (p.frameTimes.length > _FRAME_BUF) p.frameTimes.shift();

    const n = p.frameTimes.length;

    // Always keep the global timing dict fresh so Playwright can read it back
    // at any point via window._aplTiming[panelId].
    if (!window._aplTiming) window._aplTiming = {};

    if (n >= 2) {
      let sum = 0, minDt = Infinity, maxDt = -Infinity;
      for (let i = 1; i < n; i++) {
        const dt = p.frameTimes[i] - p.frameTimes[i - 1];
        sum += dt; if (dt < minDt) minDt = dt; if (dt > maxDt) maxDt = dt;
      }
      const mean_ms = sum / (n - 1);
      const fps     = 1000 * (n - 1) / (now - p.frameTimes[0]);
      window._aplTiming[p.id] = {
        count: n, fps, mean_ms, min_ms: minDt, max_ms: maxDt,
      };

      if (p.statsDiv && model.get('display_stats')) {
        p.statsDiv.style.display = 'block';
        p.statsDiv.textContent   =
          `FPS  ${fps.toFixed(1)}\n` +
          ` dt  ${mean_ms.toFixed(1)} ms\n` +
          `min  ${minDt.toFixed(1)} ms\n` +
          `max  ${maxDt.toFixed(1)} ms`;
      }
    }
  }
  // Static layout styles live in the _css traitlet (.apl-scale-wrap /
  // .apl-outer).  Only the two dynamic properties — transform and
  // marginBottom — are ever written here at runtime.
  const scaleWrap = document.createElement('div');
  scaleWrap.classList.add('apl-scale-wrap');
  el.appendChild(scaleWrap);

  const outerDiv = document.createElement('div');
  outerDiv.classList.add('apl-outer');
  scaleWrap.appendChild(outerDiv);

  const gridDiv = document.createElement('div');
  gridDiv.style.cssText = `display:grid;gap:4px;background:${theme.bg};padding:8px;border-radius:4px;`;
  outerDiv.appendChild(gridDiv);

  // ── Inset overlay container ───────────────────────────────────────────────
  // Covers the grid content area (inside gridDiv's 8 px padding).
  // Individual insetDivs restore pointer-events:all so they capture mouse events.
  const insetsContainer = document.createElement('div');
  insetsContainer.style.cssText =
    'position:absolute;top:8px;left:8px;pointer-events:none;z-index:20;overflow:visible;';
  outerDiv.appendChild(insetsContainer);

  // Inset layout constants
  const INSET_TITLE_H = 22;   // px — title bar height
  const INSET_GAP     = 8;    // px — gap between stacked insets in same corner
  const INSET_MARGIN  = 10;   // px — distance from figure edge to first inset

  // Resize handle (figure-level)
  const resizeHandle = document.createElement('div');
  resizeHandle.style.cssText =
    'position:absolute;bottom:2px;right:2px;width:16px;height:16px;cursor:nwse-resize;' +
    'background:linear-gradient(135deg,transparent 50%,#888 50%);border-radius:0 0 4px 0;z-index:100;';
  resizeHandle.title = 'Drag to resize figure';
  outerDiv.appendChild(resizeHandle);

  const sizeLabel = document.createElement('div');
  sizeLabel.style.cssText =
    'position:absolute;bottom:22px;right:22px;padding:7px 14px;background:rgba(0,0,0,0.65);' +
    'color:white;font-size:12px;font-family:monospace;border-radius:5px;display:none;pointer-events:none;z-index:21;';
  outerDiv.appendChild(sizeLabel);

  // ── Help badge (figure-level) ─────────────────────────────────────────────
  // A small '?' button in the top-right corner of the figure.
  //   • Hidden until the mouse enters outerDiv (plot "active").
  //   • Stays visible while the help card is open, even after mouse-leave.
  //   • Rounded square, tucked into the right padding band so it never
  //     overlaps plot content.
  //   • Clicking toggles the help card; click again (or mouse-leave with
  //     card closed) hides the button again.
  const _BTN_BG        = 'rgba(100,100,120,0.72)';
  const _BTN_BG_ACTIVE = 'rgba(75,120,210,0.92)';

  const helpBtn = document.createElement('div');
  helpBtn.style.cssText =
    'position:absolute;top:9px;right:6px;width:20px;height:20px;' +
    'border-radius:4px;background:' + _BTN_BG + ';color:#fff;' +
    'font-size:12px;font-weight:bold;font-family:sans-serif;' +
    'display:none;align-items:center;justify-content:center;' +
    'cursor:pointer;z-index:50;user-select:none;line-height:1;' +
    'box-shadow:0 1px 4px rgba(0,0,0,0.35);';
  helpBtn.textContent = '?';
  helpBtn.title = 'Show help';
  outerDiv.appendChild(helpBtn);

  const helpCard = document.createElement('div');
  helpCard.style.cssText =
    'position:absolute;top:33px;right:6px;padding:10px 14px;' +
    'background:rgba(28,28,38,0.95);color:#e0e0e8;font-size:12px;' +
    'font-family:sans-serif;border-radius:6px;line-height:1.7;' +
    'white-space:pre-wrap;max-width:300px;display:none;z-index:51;' +
    'box-shadow:0 4px 14px rgba(0,0,0,0.55);pointer-events:none;' +
    'border:1px solid rgba(120,120,160,0.3);';
  outerDiv.appendChild(helpCard);

  let _helpExists  = false;   // true when help_text is non-empty
  let _helpHovered = false;   // true while mouse is inside outerDiv
  let _helpOpen    = false;   // true while the card is shown

  function _updateHelp() {
    const txt = model.get('help_text') || '';
    _helpExists          = !!txt;
    helpCard.textContent = txt;
    if (!txt) {
      // Help removed — hide everything immediately.
      helpBtn.style.display    = 'none';
      helpCard.style.display   = 'none';
      helpBtn.style.background = _BTN_BG;
      _helpOpen = false;
    } else if (_helpHovered || _helpOpen) {
      // Already hovered or card open — make badge visible.
      helpBtn.style.display = 'flex';
    }
  }
  _updateHelp();

  outerDiv.addEventListener('mouseenter', () => {
    _helpHovered = true;
    if (_helpExists) helpBtn.style.display = 'flex';
  });

  outerDiv.addEventListener('mouseleave', () => {
    _helpHovered = false;
    // Only hide the button if the card is also closed.
    if (!_helpOpen) helpBtn.style.display = 'none';
  });

  helpBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    _helpOpen = !_helpOpen;
    helpCard.style.display   = _helpOpen ? 'block' : 'none';
    helpBtn.style.background = _helpOpen ? _BTN_BG_ACTIVE : _BTN_BG;
    // If closing the card while the mouse has already left, hide the button too.
    if (!_helpOpen && !_helpHovered) helpBtn.style.display = 'none';
  });

  model.on('change:help_text', _updateHelp);
  const tooltip = document.createElement('div');
  tooltip.style.cssText =
    'position:fixed;padding:5px 9px;font-size:12px;font-family:sans-serif;' +
    'background:rgba(30,30,30,0.92);color:#fff;border-radius:4px;' +
    'pointer-events:none;white-space:pre;display:none;z-index:9999;' +
    'box-shadow:0 2px 6px rgba(0,0,0,0.4);max-width:260px;';
  document.body.appendChild(tooltip);

  function _showTooltip(text,cx,cy) {
    tooltip.textContent=text; tooltip.style.display='block';
    const tw=tooltip.offsetWidth||160, th=tooltip.offsetHeight||28;
    const vw=window.innerWidth, vh=window.innerHeight;  // both used below
    let lx=cx+14, ly=cy-th-8;
    if(lx+tw>vw-8) lx=cx-tw-14;
    if(ly<8) ly=cy+18;
    if(ly+th>vh-8) ly=vh-th-8;
    tooltip.style.left=lx+'px'; tooltip.style.top=ly+'px';
  }

  // ── coordinate helper: undo CSS transform:scale() ───────────────────────
  // _applyScale() shrinks outerDiv with transform:scale(s).  After that,
  // getBoundingClientRect() reports *visual* (CSS-pixel) dimensions, while
  // canvas drawing coordinates live in the *native* (un-scaled) space.
  // Every event handler that does (e.clientX - rect.left) therefore receives
  // a value in [0, nativeW*s] instead of [0, nativeW].
  //
  // _clientPos converts one mouse event back to canvas-pixel space:
  //   sfX = nativeW / rect.width  = 1/s   (1.0 when no scale is active)
  //   mx  = (e.clientX - rect.left) * sfX
  //
  // Usage:
  //   const {mx, my} = _clientPos(e, overlayCanvas, p.pw, p.ph);   // 1D / bar
  //   const {mx, my} = _clientPos(e, overlayCanvas, imgW, imgH);   // 2D
  function _clientPos(e, canvas, nativeW, nativeH) {
    const rect = canvas.getBoundingClientRect();
    const sfX  = rect.width  > 0 ? nativeW / rect.width  : 1;
    const sfY  = rect.height > 0 ? nativeH / rect.height : 1;
    return { mx: (e.clientX - rect.left) * sfX,
             my: (e.clientY - rect.top ) * sfY, sfX, sfY };
  }

  // ── per-panel state maps ──────────────────────────────────────────────────
  const panels = new Map();
  let _suppressLayoutUpdate = false;  // block re-entry during live resize

  // ── layout application ───────────────────────────────────────────────────
  function applyLayout() {
    if (_suppressLayoutUpdate) return;
    let layout;
    try { layout = JSON.parse(model.get('layout_json')); } catch(_) { return; }

    const { nrows, ncols, panel_specs } = layout;

    // Build grid tracks directly from panel pixel sizes.
    // Python already guarantees all panels in a row share the same height,
    // and all panels in a col share the same width.
    const colPx = new Array(ncols).fill(0);
    const rowPx = new Array(nrows).fill(0);
    for (const spec of panel_specs) {
      const perCol = Math.round(spec.panel_width  / (spec.col_stop - spec.col_start));
      const perRow = Math.round(spec.panel_height / (spec.row_stop - spec.row_start));
      for (let c = spec.col_start; c < spec.col_stop; c++) colPx[c] = Math.max(colPx[c], perCol);
      for (let r = spec.row_start; r < spec.row_stop; r++) rowPx[r] = Math.max(rowPx[r], perRow);
    }

    gridDiv.style.gridTemplateColumns = colPx.map(px => px + 'px').join(' ');
    gridDiv.style.gridTemplateRows    = rowPx.map(px => px + 'px').join(' ');
    gridDiv.style.width  = '';
    gridDiv.style.height = '';
    const meanColPx = colPx.length ? colPx.reduce((a,b)=>a+b,0)/colPx.length : 0;
    const meanRowPx = rowPx.length ? rowPx.reduce((a,b)=>a+b,0)/rowPx.length : 0;
    // Only override the default gap:4px when the Python caller explicitly set a value.
    if (layout.wspace != null) gridDiv.style.columnGap = (meanColPx ? Math.round(layout.wspace*meanColPx) : 0)+'px';
    if (layout.hspace != null) gridDiv.style.rowGap    = (meanRowPx ? Math.round(layout.hspace*meanRowPx) : 0)+'px';

    const seen = new Set();
    for (const spec of panel_specs) {
      seen.add(spec.id);
      if (!panels.has(spec.id)) {
        _createPanelDOM(spec.id, spec.kind, spec.panel_width, spec.panel_height, spec);
      } else {
        _resizePanelDOM(spec.id, spec.panel_width, spec.panel_height);
      }
    }

    // Handle inset panels
    const insetSpecs = layout.inset_specs || [];
    for (const spec of insetSpecs) {
      seen.add(spec.id);
      const existing = panels.get(spec.id);
      if (!existing) {
        _createInsetDOM(spec);
      } else {
        existing.insetSpec = spec;
      }
    }

    for (const [id, p] of panels) {
      if (!seen.has(id)) { p.cell.remove(); panels.delete(id); }
    }

    // Update insetsContainer size and reposition all insets
    insetsContainer.style.width  = (layout.fig_width  || 640) + 'px';
    insetsContainer.style.height = (layout.fig_height || 480) + 'px';
    if (insetSpecs.length) _applyAllInsetStates(layout);
  }

  // ── _buildCanvasStack ─────────────────────────────────────────────────────
  // Creates the canvas/element stack for one panel kind and appends the
  // top-level wrapper to `outerContainer`.  Returns all canvas/element refs.
  // Used by both _createPanelDOM (cell → gridDiv) and _createInsetDOM
  // (contentDiv → insetDiv).
  function _buildCanvasStack(kind, pw, ph, outerContainer) {
    let plotCanvas, overlayCanvas, markersCanvas, statusBar;
    let xAxisCanvas=null, yAxisCanvas=null, scaleBar=null;
    let cbCanvas=null, cbCtx=null, plotWrap=null, wrapNode=null;
    let titleCanvas=null;

    if (kind === '2d') {
      plotWrap = document.createElement('div');
      plotWrap.style.cssText = `position:relative;display:inline-block;vertical-align:top;line-height:0;` +
        `width:${pw}px;height:${ph}px;overflow:visible;flex-shrink:0;`;

      plotCanvas = document.createElement('canvas');
      plotCanvas.style.cssText =
        `position:absolute;display:block;border-radius:2px;background:${theme.bgCanvas};`;
      overlayCanvas = document.createElement('canvas');
      overlayCanvas.style.cssText =
        'position:absolute;z-index:5;cursor:default;pointer-events:all;outline:none;';
      overlayCanvas.tabIndex = 0;
      markersCanvas = document.createElement('canvas');
      markersCanvas.style.cssText = 'position:absolute;pointer-events:none;z-index:6;';
      scaleBar = document.createElement('canvas');
      scaleBar.style.cssText = 'position:absolute;pointer-events:none;display:none;z-index:7;';
      statusBar = document.createElement('div');
      statusBar.style.cssText =
        'position:absolute;padding:7px 14px;background:rgba(0,0,0,0.65);color:white;' +
        'font-size:12px;font-family:monospace;border-radius:5px;pointer-events:none;' +
        'white-space:nowrap;display:none;z-index:9;';
      yAxisCanvas = document.createElement('canvas');
      yAxisCanvas.style.cssText =
        `position:absolute;display:none;background:${theme.axisBg};`;
      xAxisCanvas = document.createElement('canvas');
      xAxisCanvas.style.cssText =
        `position:absolute;display:none;background:${theme.axisBg};`;
      cbCanvas = document.createElement('canvas');
      cbCanvas.style.cssText =
        'position:absolute;display:none;pointer-events:none;border-radius:0 2px 2px 0;';
      cbCtx = cbCanvas.getContext('2d');

      titleCanvas = document.createElement('canvas');
      titleCanvas.style.cssText = `position:absolute;pointer-events:none;z-index:8;background:transparent;display:none;`;

      plotWrap.appendChild(plotCanvas);
      plotWrap.appendChild(overlayCanvas);
      plotWrap.appendChild(markersCanvas);
      plotWrap.appendChild(yAxisCanvas);
      plotWrap.appendChild(xAxisCanvas);
      plotWrap.appendChild(cbCanvas);
      plotWrap.appendChild(scaleBar);
      plotWrap.appendChild(statusBar);
      plotWrap.appendChild(titleCanvas);
      outerContainer.appendChild(plotWrap);
      wrapNode = plotWrap;

    } else if (kind === '3d') {
      plotCanvas = document.createElement('canvas');
      plotCanvas.style.cssText =
        `display:block;border-radius:2px;background:${theme.bgPlot};`;
      const wrap3 = document.createElement('div');
      wrap3.style.cssText = 'position:relative;display:inline-block;line-height:0;';
      wrap3.appendChild(plotCanvas);
      outerContainer.appendChild(wrap3);
      overlayCanvas = document.createElement('canvas');
      overlayCanvas.style.cssText =
        'position:absolute;top:0;left:0;z-index:5;pointer-events:all;outline:none;';
      wrap3.appendChild(overlayCanvas);
      markersCanvas = document.createElement('canvas');
      markersCanvas.style.cssText =
        'position:absolute;top:0;left:0;pointer-events:none;z-index:6;display:none;';
      wrap3.appendChild(markersCanvas);
      statusBar = document.createElement('div');
      statusBar.style.cssText =
        'position:absolute;bottom:4px;right:4px;padding:2px 6px;display:none;';
      wrap3.appendChild(statusBar);
      wrapNode = wrap3;

    } else {
      // 1D / bar
      plotCanvas = document.createElement('canvas');
      plotCanvas.tabIndex = 1;
      plotCanvas.style.cssText =
        'outline:none;cursor:crosshair;display:block;border-radius:2px;';
      const wrap = document.createElement('div');
      wrap.style.cssText = 'position:relative;display:inline-block;line-height:0;';
      wrap.appendChild(plotCanvas);
      outerContainer.appendChild(wrap);
      overlayCanvas = document.createElement('canvas');
      overlayCanvas.style.cssText =
        'position:absolute;top:0;left:0;z-index:5;cursor:crosshair;pointer-events:all;';
      wrap.appendChild(overlayCanvas);
      markersCanvas = document.createElement('canvas');
      markersCanvas.style.cssText =
        'position:absolute;top:0;left:0;pointer-events:none;z-index:6;';
      wrap.appendChild(markersCanvas);
      statusBar = document.createElement('div');
      statusBar.style.cssText =
        'position:absolute;bottom:4px;right:4px;padding:7px 14px;' +
        'background:rgba(0,0,0,0.65);color:white;font-size:12px;font-family:monospace;' +
        'border-radius:5px;pointer-events:none;white-space:nowrap;display:none;z-index:9;';
      wrap.appendChild(statusBar);
      wrapNode = wrap;
    }

    return { plotCanvas, overlayCanvas, markersCanvas, statusBar,
             xAxisCanvas, yAxisCanvas, scaleBar,
             cbCanvas, cbCtx, plotWrap, wrapNode, titleCanvas };
  }

  function _createPanelDOM(id, kind, pw, ph, spec) {
    const cell = document.createElement('div');
    cell.style.cssText =
      'position:relative;overflow:visible;line-height:0;' +
      'display:flex;justify-content:center;align-items:flex-start;';
    cell.style.gridRow    = `${spec.row_start+1} / ${spec.row_stop+1}`;
    cell.style.gridColumn = `${spec.col_start+1} / ${spec.col_stop+1}`;
    gridDiv.appendChild(cell);

    const stack = _buildCanvasStack(kind, pw, ph, cell);

    const plotCtx = stack.plotCanvas.getContext('2d');
    const ovCtx   = stack.overlayCanvas.getContext('2d');
    const mkCtx   = stack.markersCanvas.getContext('2d');
    const xCtx    = stack.xAxisCanvas ? stack.xAxisCanvas.getContext('2d') : null;
    const yCtx    = stack.yAxisCanvas ? stack.yAxisCanvas.getContext('2d') : null;
    const titleCtx = stack.titleCanvas ? stack.titleCanvas.getContext('2d') : null;

    const blitCache = { bitmap:null, bytesKey:null, lutKey:null, w:0, h:0 };

    const statsDiv = document.createElement('div');
    statsDiv.style.cssText =
      'position:absolute;top:4px;left:4px;padding:4px 7px;' +
      'background:rgba(0,0,0,0.65);color:#e0e0e0;font-size:10px;' +
      'font-family:monospace;border-radius:4px;pointer-events:none;' +
      'white-space:pre;line-height:1.5;z-index:20;display:none;';
    if (stack.wrapNode) stack.wrapNode.appendChild(statsDiv);

    const p = {
      id, kind, cell, pw, ph,
      plotCanvas:    stack.plotCanvas,
      overlayCanvas: stack.overlayCanvas,
      markersCanvas: stack.markersCanvas,
      plotCtx, ovCtx, mkCtx,
      xAxisCanvas:   stack.xAxisCanvas,
      yAxisCanvas:   stack.yAxisCanvas,
      xCtx, yCtx,
      titleCanvas:   stack.titleCanvas || null,
      titleCtx,
      scaleBar:      stack.scaleBar,
      statusBar:     stack.statusBar,
      statsDiv,
      frameTimes: [],
      blitCache,
      ovDrag: null, ovDrag2d: null,
      isPanning: false, panStart: {},
      state: null,
      _hoverSi: -1, _hoverI: -1,
      _hovBar: null,
      lastWidgetId: null,
      mouseX: 0, mouseY: 0,
      cbCanvas:  stack.cbCanvas,
      cbCtx:     stack.cbCtx,
      sbLine:    null,
      sbLabel:   null,
      plotWrap:  stack.plotWrap,
    };
    panels.set(id, p);

    _resizePanelDOM(id, pw, ph);
    _attachPanelEvents(p);

    model.on(`change:panel_${id}_json`, () => {
      const p2 = panels.get(id);
      if (!p2) return;
      try {
        const newState = JSON.parse(model.get(`panel_${id}_json`));
        // Preserve the current view (zoom/pan) so Python data pushes don't
        // reset it — but only when Python has NOT explicitly requested a view
        // change (set_view / reset_view set _view_from_python: true).
        if (p2.state && p2.kind === '2d' && !newState._view_from_python) {
          newState.zoom     = p2.state.zoom;
          newState.center_x = p2.state.center_x;
          newState.center_y = p2.state.center_y;
        } else if (p2.state && (p2.kind === '1d' || p2.kind === 'bar') && !newState._view_from_python) {
          newState.view_x0 = p2.state.view_x0;
          newState.view_x1 = p2.state.view_x1;
        } else if (p2.state && p2.kind === '3d' && !newState._view_from_python) {
          newState.azimuth   = p2.state.azimuth;
          newState.elevation = p2.state.elevation;
          newState.zoom      = p2.state.zoom;
        }
        p2.state = newState;
      }
      catch(_) { return; }
      p2._hoverSi = -1; p2._hoverI = -1;
      _redrawPanel(p2);
    });

    try { p.state = JSON.parse(model.get(`panel_${id}_json`)); } catch(_) {}
    _redrawPanel(p);
  }

  // ── _createInsetDOM ───────────────────────────────────────────────────────
  // Builds a floating inset panel:
  //   insetDiv (position:absolute inside insetsContainer)
  //     ├── titleBar  — always visible; click to toggle min/normal
  //     │    ├── titleSpan
  //     │    └── maxBtn (⤢ / ⤡)
  //     └── contentDiv — canvas stack; display:none when minimized
  //          └── _buildCanvasStack(kind, pw, ph)
  function _createInsetDOM(spec) {
    const { id, kind, panel_width: pw, panel_height: ph, title, inset_state } = spec;

    const insetDiv = document.createElement('div');
    insetDiv.style.cssText =
      'position:absolute;pointer-events:all;border-radius:4px;overflow:hidden;' +
      `box-shadow:0 2px 14px rgba(0,0,0,0.55);border:1px solid ${theme.border};z-index:25;background:${theme.bg};`;
    insetsContainer.appendChild(insetDiv);

    // Title bar
    const tbBg = theme.dark ? 'rgba(30,32,46,0.97)' : 'rgba(210,213,224,0.97)';
    const titleBar = document.createElement('div');
    titleBar.style.cssText =
      `display:flex;align-items:center;height:${INSET_TITLE_H}px;` +
      `cursor:pointer;padding:0 5px 0 8px;user-select:none;background:${tbBg};` +
      `border-bottom:1px solid ${theme.border};box-sizing:border-box;flex-shrink:0;`;
    insetDiv.appendChild(titleBar);

    const titleSpan = document.createElement('span');
    titleSpan.style.cssText =
      `flex:1;font-size:11px;font-family:sans-serif;overflow:hidden;` +
      `text-overflow:ellipsis;white-space:nowrap;color:${theme.tickText};`;
    titleSpan.textContent = title || '';
    titleBar.appendChild(titleSpan);


    // Content div — wraps the canvas stack
    const contentDiv = document.createElement('div');
    contentDiv.style.cssText =
      `overflow:hidden;display:${inset_state === 'minimized' ? 'none' : 'block'};`;
    insetDiv.appendChild(contentDiv);

    // Canvas stack inside contentDiv
    const stack = _buildCanvasStack(kind, pw, ph, contentDiv);

    const plotCtx = stack.plotCanvas.getContext('2d');
    const ovCtx   = stack.overlayCanvas.getContext('2d');
    const mkCtx   = stack.markersCanvas.getContext('2d');
    const xCtx    = stack.xAxisCanvas ? stack.xAxisCanvas.getContext('2d') : null;
    const yCtx    = stack.yAxisCanvas ? stack.yAxisCanvas.getContext('2d') : null;

    const blitCache = { bitmap:null, bytesKey:null, lutKey:null, w:0, h:0 };

    const statsDiv = document.createElement('div');
    statsDiv.style.cssText =
      'position:absolute;top:4px;left:4px;padding:4px 7px;' +
      'background:rgba(0,0,0,0.65);color:#e0e0e0;font-size:10px;' +
      'font-family:monospace;border-radius:4px;pointer-events:none;' +
      'white-space:pre;line-height:1.5;z-index:20;display:none;';
    if (stack.wrapNode) stack.wrapNode.appendChild(statsDiv);

    const p = {
      id, kind, pw, ph,
      cell: insetDiv,   // stale-cleanup compatibility (p.cell.remove())
      isInset: true, insetDiv, contentDiv, titleBar,
      insetSpec: spec,
      plotCanvas:    stack.plotCanvas,
      overlayCanvas: stack.overlayCanvas,
      markersCanvas: stack.markersCanvas,
      plotCtx, ovCtx, mkCtx,
      xAxisCanvas:   stack.xAxisCanvas,
      yAxisCanvas:   stack.yAxisCanvas,
      xCtx, yCtx,
      scaleBar:      stack.scaleBar,
      statusBar:     stack.statusBar,
      statsDiv,
      frameTimes: [], blitCache,
      ovDrag: null, ovDrag2d: null,
      isPanning: false, panStart: {},
      state: null,
      _hoverSi: -1, _hoverI: -1,
      _hovBar: null,
      lastWidgetId: null, mouseX: 0, mouseY: 0,
      cbCanvas:  stack.cbCanvas,
      cbCtx:     stack.cbCtx,
      sbLine:    null, sbLabel: null,
      plotWrap:  stack.plotWrap,
    };
    panels.set(id, p);

    _resizePanelDOM(id, pw, ph);
    _attachPanelEvents(p);

    // Title bar click: toggle normal ↔ minimized
    titleBar.addEventListener('click', (e) => {
      const cur = p.insetSpec ? p.insetSpec.inset_state : 'normal';
      _applyButtonState(p, cur === 'minimized' ? 'normal' : 'minimized');
    });


    model.on(`change:panel_${id}_json`, () => {
      const p2 = panels.get(id);
      if (!p2) return;
      try {
        const newState = JSON.parse(model.get(`panel_${id}_json`));
        // Preserve the current view (zoom/pan) so Python data pushes don't
        // reset it — but only when Python has NOT explicitly requested a view
        // change (set_view / reset_view set _view_from_python: true).
        if (p2.state && p2.kind === '2d' && !newState._view_from_python) {
          newState.zoom     = p2.state.zoom;
          newState.center_x = p2.state.center_x;
          newState.center_y = p2.state.center_y;
        } else if (p2.state && (p2.kind === '1d' || p2.kind === 'bar') && !newState._view_from_python) {
          newState.view_x0 = p2.state.view_x0;
          newState.view_x1 = p2.state.view_x1;
        } else if (p2.state && p2.kind === '3d' && !newState._view_from_python) {
          newState.azimuth   = p2.state.azimuth;
          newState.elevation = p2.state.elevation;
          newState.zoom      = p2.state.zoom;
        }
        p2.state = newState;
      }
      catch(_) { return; }
      p2._hoverSi = -1; p2._hoverI = -1;
      _redrawPanel(p2);
    });

    try { p.state = JSON.parse(model.get(`panel_${id}_json`)); } catch(_) {}
    _redrawPanel(p);
  }

  // Optimistic local state update + Python notification.
  function _applyButtonState(p, newState) {
    try {
      const layout = JSON.parse(model.get('layout_json'));
      const spec = (layout.inset_specs || []).find(s => s.id === p.id);
      if (spec) {
        spec.inset_state = newState;
        p.insetSpec = spec;
        _applyAllInsetStates(layout);
      }
    } catch(_) {}
    _emitEvent(p.id, 'inset_state_change', null, { new_state: newState });
  }

  // ── _applyAllInsetStates ──────────────────────────────────────────────────
  // Positions every inset for the given layout snapshot.
  // Groups insets by corner, stacks with INSET_GAP spacing.
  // Minimized insets contribute only INSET_TITLE_H to the stack height.
  // Maximized insets float centred at z-index:45, outside the stack.
  function _applyAllInsetStates(layout) {
    const insetSpecs = layout.inset_specs || [];
    const fw = layout.fig_width  || 640;
    const fh = layout.fig_height || 480;

    insetsContainer.style.width  = fw + 'px';
    insetsContainer.style.height = fh + 'px';

    // Group by corner, preserving insertion order
    const byCorner = {};
    for (const spec of insetSpecs) {
      (byCorner[spec.corner] = byCorner[spec.corner] || []).push(spec);
    }

    for (const [corner, group] of Object.entries(byCorner)) {
      const isBottom = corner.startsWith('bottom');
      const isRight  = corner.endsWith('right');
      // Bottom corners: first-added is closest to the corner (stack upward),
      // so reverse for the position loop (offset grows from the corner outward).
      const walk = isBottom ? [...group].reverse() : group;
      let offset = INSET_MARGIN;

      for (const spec of walk) {
        const p = panels.get(spec.id);
        if (!p || !p.isInset) continue;

        const pw    = spec.panel_width;
        const ph    = spec.panel_height;
        const state = spec.inset_state;


        // Normal or minimized: compute position from corner
        const stackH = state === 'minimized' ? INSET_TITLE_H : INSET_TITLE_H + ph;
        const left   = isRight ? fw - pw - INSET_MARGIN : INSET_MARGIN;
        const top    = isBottom ? fh - offset - stackH  : offset;

        p.insetDiv.style.left   = left + 'px';
        p.insetDiv.style.top    = top  + 'px';
        p.insetDiv.style.width  = pw   + 'px';
        p.insetDiv.style.height = stackH + 'px';
        p.insetDiv.style.zIndex = '25';

        if (state === 'minimized') {
          p.contentDiv.style.display = 'none';
        } else {
          p.contentDiv.style.display = 'block';
          p.contentDiv.style.height  = ph + 'px';
          if (p.pw !== pw || p.ph !== ph) {
            p.pw = pw; p.ph = ph;
            _resizePanelDOM(spec.id, pw, ph);
            _redrawPanel(p);
          }
        }

        offset += stackH + INSET_GAP;
      }
    }
  }

  function _resizePanelDOM(id, pw, ph) {
    const p = panels.get(id);
    if (!p) return;
    p.pw = pw; p.ph = ph;

    function _sz(c, ctx, w, h) {
      c.style.width=w+'px'; c.style.height=h+'px';
      c.width=w*dpr; c.height=h*dpr;
      ctx.setTransform(dpr,0,0,dpr,0,0);
    }

    if (p.kind === '2d') {
      // ── 2D: all elements absolutely positioned within pw×ph container ──
      // When physical axes are present, reserve PAD gutters for tick labels.
      // When there are no axes (plain imshow) use the full canvas area so
      // no dead space appears on the left / bottom.
      const st = p.state;
      const hasPhysAxis = st && (st.is_mesh || st.has_axes)
                       && st.x_axis && st.x_axis.length >= 2
                       && st.y_axis && st.y_axis.length >= 2;
      // Always reserve the PAD_T top strip for the title (mirrors 1D behaviour).
      // Left/right/bottom gutters are only used when physical axes are present.
      const imgX = hasPhysAxis ? PAD_L : 0;
      const imgY = PAD_T;
      const imgW = hasPhysAxis ? Math.max(1, pw - PAD_L - PAD_R) : pw;
      let   imgH = Math.max(1, ph - PAD_T - (hasPhysAxis ? PAD_B : 0));
      // Enforce aspect ratio (st.aspect = number or "equal" → 1.0).
      if (st && st.aspect != null) {
        const asp = (st.aspect === 'equal') ? 1.0 : parseFloat(st.aspect);
        if (Number.isFinite(asp) && asp > 0) imgH = Math.max(1, Math.round(imgW / asp));
      }
      // Store on panel so event handlers and draw functions don't recompute.
      p.imgX = imgX; p.imgY = imgY; p.imgW = imgW; p.imgH = imgH;

      // Title canvas: always sits in the PAD_T strip above the image area
      if (p.titleCanvas && p.titleCtx) {
        p.titleCanvas.style.left    = imgX + 'px';
        p.titleCanvas.style.top     = '0px';
        p.titleCanvas.style.display = 'block';
        p.titleCanvas.style.width   = imgW + 'px';
        p.titleCanvas.style.height  = PAD_T + 'px';
        p.titleCanvas.width  = imgW * dpr;
        p.titleCanvas.height = PAD_T * dpr;
        p.titleCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
      }

      if (p.plotWrap) {
        p.plotWrap.style.width  = pw + 'px';
        p.plotWrap.style.height = ph + 'px';
      }

      // Image canvas at the inner plot area
      p.plotCanvas.style.left = imgX + 'px';
      p.plotCanvas.style.top  = imgY + 'px';
      _sz(p.plotCanvas, p.plotCtx, imgW, imgH);

      // Overlay and markers match the image canvas exactly
      p.overlayCanvas.style.left = imgX + 'px';
      p.overlayCanvas.style.top  = imgY + 'px';
      _sz(p.overlayCanvas, p.ovCtx, imgW, imgH);
      p.markersCanvas.style.left = imgX + 'px';
      p.markersCanvas.style.top  = imgY + 'px';
      _sz(p.markersCanvas, p.mkCtx, imgW, imgH);

      // Status bar: 4px above bottom of image area, 4px right of left edge
      if (p.statusBar) {
        p.statusBar.style.left   = (imgX + 4) + 'px';
        p.statusBar.style.bottom = (ph - imgY - imgH + 4) + 'px';
        p.statusBar.style.top    = '';
      }

      // Scale bar: 12px above bottom-right of image area
      if (p.scaleBar) {
        p.scaleBar.style.right  = (pw - imgX - imgW + 12) + 'px';
        p.scaleBar.style.bottom = (ph - imgY - imgH + 12) + 'px';
        p.scaleBar.style.left   = '';
        p.scaleBar.style.top    = '';
      }


      // y-axis: left gutter [0, PAD_T]..[PAD_L, ph-PAD_B]
      if (p.yAxisCanvas && p.yCtx) {
        if (hasPhysAxis) {
          p.yAxisCanvas.style.display = 'block';
          p.yAxisCanvas.style.left = '0px';
          p.yAxisCanvas.style.top  = imgY + 'px';
          p.yAxisCanvas.style.width  = PAD_L + 'px';
          p.yAxisCanvas.style.height = imgH + 'px';
          p.yAxisCanvas.width  = PAD_L * dpr;
          p.yAxisCanvas.height = imgH * dpr;
          p.yCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
        } else {
          p.yAxisCanvas.style.display = 'none';
        }
      }

      // x-axis: bottom gutter [PAD_L, ph-PAD_B]..[pw-PAD_R, ph]
      if (p.xAxisCanvas && p.xCtx) {
        if (hasPhysAxis) {
          p.xAxisCanvas.style.display = 'block';
          p.xAxisCanvas.style.left = imgX + 'px';
          p.xAxisCanvas.style.top  = (ph - PAD_B) + 'px';
          p.xAxisCanvas.style.width  = imgW + 'px';
          p.xAxisCanvas.style.height = PAD_B + 'px';
          p.xAxisCanvas.width  = imgW * dpr;
          p.xAxisCanvas.height = PAD_B * dpr;
          p.xCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
        } else {
          p.xAxisCanvas.style.display = 'none';
        }
      }

      // Colorbar: narrow strip to the right of the image area
      if (p.cbCanvas && p.cbCtx) {
        const cbStripW = 16;
        const cbTotalW = (st && st.colorbar_label) ? cbStripW + 14 : cbStripW;
        const vis = st && st.show_colorbar;
        if (vis) {
          p.cbCanvas.style.display = 'block';
          p.cbCanvas.style.left = (imgX + imgW + 2) + 'px';
          p.cbCanvas.style.top  = imgY + 'px';
          _sz(p.cbCanvas, p.cbCtx, cbTotalW, imgH);
        } else {
          p.cbCanvas.style.display = 'none';
        }
      }

    } else if (p.kind === '3d') {
      // ── 3D: full-panel canvases ──
      _sz(p.plotCanvas,    p.plotCtx, pw, ph);
      _sz(p.overlayCanvas, p.ovCtx,   pw, ph);
    } else {
      // ── 1D: canvas is the full pw×ph, padding is drawn internally ──
      _sz(p.plotCanvas,    p.plotCtx,    pw, ph);
      _sz(p.overlayCanvas, p.ovCtx,      pw, ph);
      _sz(p.markersCanvas, p.mkCtx,      pw, ph);
    }
  }

  // ── 2D drawing ───────────────────────────────────────────────────────────

  // Largest rect with the image's natural aspect that fits inside cw×ch,
  // centred.  All 2-D coordinate functions derive from this single rect so
  // draw, hit-test, and coordinate conversion are always consistent.
  // s = uniform scale factor (canvas px per image px).
  function _imgFitRect(iw, ih, cw, ch) {
    const s = Math.min(cw / iw, ch / ih);
    const fw = iw * s, fh = ih * s;
    return { x: (cw - fw) / 2, y: (ch - fh) / 2, w: fw, h: fh, s };
  }

  function _buildLut32(st) {
    const dMin=st.display_min, dMax=st.display_max;
    const hMin=st.raw_min!=null?st.raw_min:dMin;
    const hMax=st.raw_max!=null?st.raw_max:dMax;
    const mode=st.scale_mode||'linear';
    const range=hMax-hMin||1;
    const cmapData=st.colormap_data||[];
    let cmapFlat=null;
    if(cmapData.length===256){
      cmapFlat=new Uint8Array(256*4);
      for(let i=0;i<256;i++){cmapFlat[i*4]=cmapData[i][0];cmapFlat[i*4+1]=cmapData[i][1];cmapFlat[i*4+2]=cmapData[i][2];cmapFlat[i*4+3]=255;}
    }
    const lut=new Uint32Array(256);
    const buf=new ArrayBuffer(4); const dv=new DataView(buf); const u32=new Uint32Array(buf);
    for(let raw=0;raw<256;raw++){
      const val=hMin+(raw/255)*range;
      let t;
      if(mode==='log'){const dMC=Math.max(dMin,1e-10),dXC=Math.max(dMax,dMC+1e-10);t=(Math.log10(Math.max(val,1e-10))-Math.log10(dMC))/(Math.log10(dXC)-Math.log10(dMC));}
      else if(mode==='symlog'){const lt=Math.max((dMax-dMin)*0.01,1e-10);const sl=v=>v>=0?(v<=lt?v/lt:1+Math.log10(v/lt)):-(Math.abs(v)<=lt?Math.abs(v)/lt:1+Math.log10(Math.abs(v)/lt));t=(sl(val)-sl(dMin))/((sl(dMax)-sl(dMin))||1);}
      else{t=(val-dMin)/((dMax-dMin)||1);}
      const idx=Math.max(0,Math.min(255,Math.round(t*255)));
      if(cmapFlat){dv.setUint8(0,cmapFlat[idx*4]);dv.setUint8(1,cmapFlat[idx*4+1]);dv.setUint8(2,cmapFlat[idx*4+2]);dv.setUint8(3,255);}
      else{dv.setUint8(0,idx);dv.setUint8(1,idx);dv.setUint8(2,idx);dv.setUint8(3,255);}
      lut[raw]=u32[0];
    }
    return lut;
  }

  function _lutKey(st) {
    return [st.display_min,st.display_max,st.raw_min,st.raw_max,st.scale_mode,st.colormap_name].join('|');
  }

  function _imgToCanvas2d(ix, iy, st, pw, ph) {
    const { x, y, w, h } = _imgFitRect(st.image_width, st.image_height, pw, ph);
    const zoom = st.zoom, cx = st.center_x, cy = st.center_y;
    const iw = st.image_width, ih = st.image_height;
    // +0.5: image coordinate i is the centre of pixel i, which renders at
    // (i + 0.5) * scale in the canvas — not the leading edge (i * scale).
    if (zoom < 1.0) {
      const dstW = w * zoom, dstH = h * zoom;
      const dstX = x + (w - dstW) / 2, dstY = y + (h - dstH) / 2;
      return [dstX + (ix + 0.5) / iw * dstW, dstY + (iy + 0.5) / ih * dstH];
    }
    const visW = iw / zoom, visH = ih / zoom;
    const srcX = Math.max(0, Math.min(iw - visW, cx * iw - visW / 2));
    const srcY = Math.max(0, Math.min(ih - visH, cy * ih - visH / 2));
    return [x + (ix + 0.5 - srcX) / visW * w, y + (iy + 0.5 - srcY) / visH * h];
  }

  // Returns canvas-px per image-px at the current zoom (uniform in x and y).
  function _imgScale2d(st, pw, ph) {
    return _imgFitRect(st.image_width, st.image_height, pw, ph).s * st.zoom;
  }

  function _blit2d(bitmap, st, pw, ph, ctx) {
    const { x, y, w, h } = _imgFitRect(st.image_width, st.image_height, pw, ph);
    const zoom = st.zoom, cx = st.center_x, cy = st.center_y;
    const iw = st.image_width, ih = st.image_height;
    ctx.clearRect(0, 0, pw, ph);
    ctx.fillStyle = theme.bgCanvas;
    ctx.fillRect(0, 0, pw, ph);
    ctx.imageSmoothingEnabled = false;
    if (zoom >= 1.0) {
      // Zoomed in: show a portion of the image filling the fit-rect.
      const visW = iw / zoom, visH = ih / zoom;
      const srcX = Math.max(0, Math.min(iw - visW, cx * iw - visW / 2));
      const srcY = Math.max(0, Math.min(ih - visH, cy * ih - visH / 2));
      ctx.drawImage(bitmap, srcX, srcY, visW, visH, x, y, w, h);
    } else {
      // Zoomed out: shrink the fit-rect proportionally, keep it centred.
      const dstW = w * zoom, dstH = h * zoom;
      ctx.drawImage(bitmap, 0, 0, iw, ih,
        x + (w - dstW) / 2, y + (h - dstH) / 2, dstW, dstH);
    }
  }

  function draw2d(p) {
    const st=p.state;
    if(!st) return;
    _recordFrame(p);
    // Re-sync axis/histogram canvas visibility whenever state changes
    _resizePanelDOM(p.id, p.pw, p.ph);
    const {pw,ph,plotCtx:ctx,blitCache} = p;
    // p.imgW/imgH are set by _resizePanelDOM above (full panel when no axes,
    // padded inner area when physical axes are present).
    const imgW = p.imgW || Math.max(1, pw - PAD_L - PAD_R);
    const imgH = p.imgH || Math.max(1, ph - PAD_T - PAD_B);

    // Decode base64 image bytes
    const b64=st.image_b64||'';
    const iw=st.image_width, ih=st.image_height;

    if(!b64||iw===0||ih===0){ctx.clearRect(0,0,imgW,imgH);return;}

    const lk=_lutKey(st);
    const needRebuild = b64!==blitCache.bytesKey || lk!==blitCache.lutKey
                     || !blitCache.bitmap || blitCache.w!==iw || blitCache.h!==ih;
    if(!needRebuild && blitCache.bitmap){
      _blit2d(blitCache.bitmap, st, imgW, imgH, ctx);
    } else {
      let bytes;
      try {
        const bin=atob(b64);
        bytes=new Uint8Array(bin.length);
        for(let i=0;i<bin.length;i++) bytes[i]=bin.charCodeAt(i);
      } catch(_){return;}
      const lut=_buildLut32(st);
      const imgData=new ImageData(iw,ih);
      const out32=new Uint32Array(imgData.data.buffer);
      for(let i=0;i<iw*ih;i++) out32[i]=lut[bytes[i]];
      const oc=new OffscreenCanvas(iw,ih);
      oc.getContext('2d').putImageData(imgData,0,0);
      blitCache.bitmap=oc; blitCache.bytesKey=b64; blitCache.lutKey=lk;
      blitCache.w=iw; blitCache.h=ih;
      _blit2d(oc, st, imgW, imgH, ctx);
    }

    // ── Overlay mask compositing ─────────────────────────────────────────────
    // overlay_mask_b64: base64 uint8 bytes (0|255), same iw×ih as image.
    // Rendered at overlay_mask_alpha on top of the base image without clearing.
    const mob64=st.overlay_mask_b64||'';
    if(!mob64){
      // Mask cleared — release cached bitmap so memory can be reclaimed.
      if(p.maskCache) p.maskCache=null;
    } else {
      const mColor=st.overlay_mask_color||'#ff4444';
      const mAlpha=st.overlay_mask_alpha!=null?st.overlay_mask_alpha:0.4;
      // Compare fields individually to avoid building a large concatenated key
      // on every redraw during pan/zoom (mob64 can be very large).
      if(!p.maskCache||p.maskCache.b64!==mob64||p.maskCache.color!==mColor||p.maskCache.alpha!==mAlpha){
        // Parse hex colour → r,g,b
        let mr=255,mg=68,mb=68;
        if(mColor.startsWith('#')&&mColor.length===7){
          mr=parseInt(mColor.slice(1,3),16);
          mg=parseInt(mColor.slice(3,5),16);
          mb=parseInt(mColor.slice(5,7),16);
        }
        let mBytes;
        try{const bin=atob(mob64);mBytes=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)mBytes[i]=bin.charCodeAt(i);}catch(_){mBytes=null;}
        if(mBytes&&mBytes.length===iw*ih){
          const mImg=new ImageData(iw,ih);
          // Write colour where mask=255; transparent where mask=0.
          // Store full-alpha pixel; globalAlpha controls final transparency.
          const buf4=new ArrayBuffer(4);const dv4=new DataView(buf4);const u32m=new Uint32Array(buf4);
          dv4.setUint8(0,mr);dv4.setUint8(1,mg);dv4.setUint8(2,mb);dv4.setUint8(3,255);
          const opaque=u32m[0];
          const out32m=new Uint32Array(mImg.data.buffer);
          for(let i=0;i<mBytes.length;i++)out32m[i]=mBytes[i]?opaque:0;
          const moc=new OffscreenCanvas(iw,ih);
          moc.getContext('2d').putImageData(mImg,0,0);
           p.maskCache={b64:mob64,color:mColor,alpha:mAlpha,bitmap:moc};
        }else{p.maskCache=null;}
      }
      if(p.maskCache&&p.maskCache.bitmap){
        // Blit at the same zoom/pan as the base image (inline, no clearRect).
        const {x:_mx,y:_my,w:_mw,h:_mh}=_imgFitRect(iw,ih,imgW,imgH);
        const _mz=st.zoom,_mcx=st.center_x,_mcy=st.center_y;
        ctx.save();ctx.globalAlpha=mAlpha;ctx.imageSmoothingEnabled=false;
        if(_mz>=1.0){
          const _vw=iw/_mz,_vh=ih/_mz;
          const _sx=Math.max(0,Math.min(iw-_vw,_mcx*iw-_vw/2));
          const _sy=Math.max(0,Math.min(ih-_vh,_mcy*ih-_vh/2));
          ctx.drawImage(p.maskCache.bitmap,_sx,_sy,_vw,_vh,_mx,_my,_mw,_mh);
        }else{
          const _dw=_mw*_mz,_dh=_mh*_mz;
          ctx.drawImage(p.maskCache.bitmap,0,0,iw,ih,_mx+(_mw-_dw)/2,_my+(_mh-_dh)/2,_dw,_dh);
        }
        ctx.restore();
      }
    }
    // Axes / scalebar / colorbar
    _drawAxes2d(p);
    drawScaleBar2d(p);
    drawColorbar2d(p);
    drawOverlay2d(p);
    drawMarkers2d(p);
  }

  function drawScaleBar2d(p) {
    const st=p.state; if(!st||!p.scaleBar) return;
    // pcolormesh panels have non-uniform axes: no meaningful single pixel scale
    if(st.is_mesh){p.scaleBar.style.display='none';return;}
    const units=st.units||'px';
    const scaleX=st.scale_x||0;
    if(!scaleX||units==='px'){p.scaleBar.style.display='none';return;}

    const imgW=p.imgW||Math.max(1,p.pw-PAD_L-PAD_R);
    const imgH=p.imgH||Math.max(1,p.ph-PAD_T-PAD_B);

    // Compute bar width in the fit-rect pixel space
    const zoom=st.zoom||1;
    const iw=st.image_width||imgW;
    const fr=_imgFitRect(iw, st.image_height||imgH, imgW, imgH);
    const visDataW=(zoom>=1?iw/zoom:iw)*scaleX;
    const targetDataWidth=visDataW*0.2;
    const niceWidth=findNice(targetDataWidth);
    const barPx=Math.round((niceWidth/visDataW)*fr.w);  // use fit-rect width
    if(barPx<4){p.scaleBar.style.display='none';return;}

    // Layout constants (CSS pixels)
    const fontSize  = 11;
    const lineH     = 3;
    const gap       = 6;   // space between bottom of text and top of line
    const padX      = 8;
    const padTop    = 5;
    const padBot    = 5;

    // Measure text to size the canvas
    const label=`${fmtVal(niceWidth)} ${units}`;
    const cvW=Math.max(barPx, fontSize*label.length*0.6|0) + padX*2;
    const cvH=padTop + fontSize + gap + lineH + padBot;

    const sb=p.scaleBar;
    if(sb.width!==Math.round(cvW*dpr)||sb.height!==Math.round(cvH*dpr)){
      sb.width=Math.round(cvW*dpr);
      sb.height=Math.round(cvH*dpr);
      sb.style.width=cvW+'px';
      sb.style.height=cvH+'px';
    }
    const ctx=sb.getContext('2d');
    ctx.setTransform(dpr,0,0,dpr,0,0);
    ctx.clearRect(0,0,cvW,cvH);

    // Background pill
    ctx.fillStyle='rgba(0,0,0,0.60)';
    const r=5;
    ctx.beginPath();
    ctx.moveTo(r,0);ctx.lineTo(cvW-r,0);ctx.arcTo(cvW,0,cvW,r,r);
    ctx.lineTo(cvW,cvH-r);ctx.arcTo(cvW,cvH,cvW-r,cvH,r);
    ctx.lineTo(r,cvH);ctx.arcTo(0,cvH,0,cvH-r,r);
    ctx.lineTo(0,r);ctx.arcTo(0,0,r,0,r);
    ctx.closePath();ctx.fill();

    // Label (centred over the bar line)
    const lineX=(cvW-barPx)/2;
    const textY=padTop+fontSize;
    ctx.fillStyle='white';
    ctx.font=`bold ${fontSize}px sans-serif`;
    ctx.textAlign='center';
    ctx.textBaseline='alphabetic';
    ctx.fillText(label, cvW/2, textY);

    // Bar line
    const lineY=padTop+fontSize+gap;
    ctx.fillStyle='white';
    ctx.fillRect(lineX, lineY, barPx, lineH);

    // End ticks
    ctx.fillRect(lineX, lineY-3, 2, lineH+3);
    ctx.fillRect(lineX+barPx-2, lineY-3, 2, lineH+3);

    sb.style.display='block';
  }

  function drawColorbar2d(p) {
    const st=p.state; if(!st||!p.cbCanvas||!p.cbCtx) return;
    const vis=st.show_colorbar||false;
    p.cbCanvas.style.display = vis ? 'block' : 'none';
    if(!vis) return;

    const cbStripW=16;
    const cbLabel=st.colorbar_label||'';
    const cbW=cbLabel?(cbStripW+14):cbStripW;
    const imgH=p.imgH||Math.max(1,p.ph-PAD_T-PAD_B);
    const ctx=p.cbCtx;
    ctx.clearRect(0,0,cbW,imgH);

    // Gradient strip
    if(st.colormap_data&&st.colormap_data.length===256){
      for(let py=0;py<imgH;py++){
        const frac=1-py/(imgH-1||1);
        const ci=Math.max(0,Math.min(255,Math.round(frac*255)));
        const [r2,g2,b2]=st.colormap_data[ci];
        ctx.fillStyle=`rgb(${r2},${g2},${b2})`;
        ctx.fillRect(0,py,cbStripW,1);
      }
    } else {
      ctx.fillStyle=theme.dark?'#444':'#ccc';
      ctx.fillRect(0,0,cbStripW,imgH);
    }

    // Border
    ctx.strokeStyle=theme.border||'#888';
    ctx.lineWidth=0.5;
    ctx.strokeRect(0,0,cbStripW,imgH);

    // display_min / display_max tick marks
    const dMin=st.display_min, dMax=st.display_max;
    const hMin=st.raw_min!=null?st.raw_min:dMin;
    const hMax=st.raw_max!=null?st.raw_max:dMax;
    const vRange=(hMax-hMin)||1;
    function _vToY(v){return imgH-1-((v-hMin)/vRange)*(imgH-1);}
    ctx.strokeStyle='rgba(255,255,255,0.85)'; ctx.lineWidth=1.5;
    ctx.beginPath();ctx.moveTo(0,_vToY(dMax));ctx.lineTo(cbStripW,_vToY(dMax));ctx.stroke();
    ctx.beginPath();ctx.moveTo(0,_vToY(dMin));ctx.lineTo(cbStripW,_vToY(dMin));ctx.stroke();

    // Colorbar label (rotated −90° to the right of the strip)
    if(cbLabel){
      ctx.save();
      ctx.translate(cbStripW+9, imgH/2);
      ctx.rotate(-Math.PI/2);
      ctx.textAlign='center'; ctx.textBaseline='middle';
      ctx.fillStyle=theme.unitText;
      ctx.font='10px sans-serif';
      ctx.fillText(cbLabel,0,0);
      ctx.restore();
    }
  }


  function _drawAxes2d(p) {
    const st=p.state; if(!st) return;
    const {pw,ph} = p;
    const imgW = p.imgW||Math.max(1, pw - PAD_L - PAD_R);
    const imgH = p.imgH||Math.max(1, ph - PAD_T - PAD_B);
    const xArr=st.x_axis||[], yArr=st.y_axis||[];
    const TICK=6;
    const zoom=st.zoom, cx=st.center_x, cy=st.center_y;
    const units=st.units||'px';
    const hasPhysAxis = (st.is_mesh || st.has_axes) && xArr.length>=2 && yArr.length>=2;
    if(st.axis_visible===false){
      if(p.xAxisCanvas) p.xAxisCanvas.style.display='none';
      if(p.yAxisCanvas) p.yAxisCanvas.style.display='none';
    } else if(hasPhysAxis){
      if(st.x_ticks_visible===false&&p.xAxisCanvas) p.xAxisCanvas.style.display='none';
      if(st.y_ticks_visible===false&&p.yAxisCanvas) p.yAxisCanvas.style.display='none';
    }
    const hasX=hasPhysAxis&&st.axis_visible!==false&&st.x_ticks_visible!==false&&p.xCtx&&p.xAxisCanvas&&p.xAxisCanvas.style.display!=='none';
    const hasY=hasPhysAxis&&st.axis_visible!==false&&st.y_ticks_visible!==false&&p.yCtx&&p.yAxisCanvas&&p.yAxisCanvas.style.display!=='none';

    function _visFrac(z,c){
      if(z>=1.0){const h=0.5/z;const cc=Math.max(h,Math.min(1-h,c));return[cc-h,cc+h];}
      return[0,1];
    }
    function _fracToPx(frac, z, center, span) {
      if(z>=1.0){
        const h=0.5/z, cc=Math.max(h,Math.min(1-h,center));
        return (frac-(cc-h))/(2*h)*span;
      }
      return (span-span*z)/2+frac*span*z;
    }

    // ── X axis canvas: imgW × PAD_B, origin at top-left ─────────────────
    // x=0 aligns with the left edge of the image, spans imgW pixels
    if(hasX){
      const aw=imgW, ah=PAD_B;
      p.xCtx.clearRect(0,0,aw,ah);
      p.xCtx.fillStyle=theme.axisBg; p.xCtx.fillRect(0,0,aw,ah);
      p.xCtx.strokeStyle=theme.axisStroke; p.xCtx.lineWidth=1;
      p.xCtx.beginPath(); p.xCtx.moveTo(0,0); p.xCtx.lineTo(aw,0); p.xCtx.stroke();
      const [xF0,xF1]=_visFrac(zoom,cx);
      const xVMin=_axisFracToVal(xArr,xF0), xVMax=_axisFracToVal(xArr,xF1);
      const step=findNice((xVMax-xVMin)/Math.max(3,Math.floor(imgW/60)));
      p.xCtx.strokeStyle=theme.tickStroke;
      p.xCtx.fillStyle=theme.tickText; p.xCtx.font='10px sans-serif';
      p.xCtx.textAlign='center'; p.xCtx.textBaseline='top';
      // Generate nice tick values; place each at its true canvas position
      // via binary-search into the axis array (works for both linear and
      // non-linear / pcolormesh edge arrays).
      const xTicks=[];
      for(let v=Math.ceil(xVMin/step)*step; v<=xVMax+step*0.01; v+=step) xTicks.push(v);
      // Clamp first/last label so it doesn't overflow the canvas edges
      const minLabelGap=28; // px — minimum gap between adjacent labels
      let lastPx=-Infinity;
      for(let ti=0;ti<xTicks.length;ti++){
        const v=xTicks[ti];
        const frac=_axisValToFrac(xArr,v);
        const px2=_fracToPx(frac,zoom,cx,imgW);
        if(px2<0||px2>imgW) continue;
        p.xCtx.beginPath(); p.xCtx.moveTo(px2,0); p.xCtx.lineTo(px2,TICK); p.xCtx.stroke();
        // Skip label if too close to the previous one
        if(px2-lastPx>=minLabelGap){
          p.xCtx.fillText(fmtVal(v), px2, TICK+2);
          lastPx=px2;
        }
      }
      p.xCtx.textAlign='right'; p.xCtx.textBaseline='bottom';
      p.xCtx.fillStyle=theme.unitText; p.xCtx.font='9px sans-serif';
      p.xCtx.fillText(units, aw-2, ah-1);
      const xlabel=st.x_label||'';
      if(xlabel){p.xCtx.fillStyle=theme.tickText;p.xCtx.font='11px sans-serif';p.xCtx.textAlign='center';p.xCtx.textBaseline='bottom';p.xCtx.fillText(xlabel,aw/2,ah-2);}
    }

    // ── Y axis canvas: PAD_L × imgH, origin at top-left ─────────────────
    // y=0 aligns with the top edge of the image, spans imgH pixels
    if(hasY){
      const aw=PAD_L, ah=imgH;
      p.yCtx.clearRect(0,0,aw,ah);
      p.yCtx.fillStyle=theme.axisBg; p.yCtx.fillRect(0,0,aw,ah);
      p.yCtx.strokeStyle=theme.axisStroke; p.yCtx.lineWidth=1;
      p.yCtx.beginPath(); p.yCtx.moveTo(aw,0); p.yCtx.lineTo(aw,ah); p.yCtx.stroke();
      const [yF0,yF1]=_visFrac(zoom,cy);
      const yVMin=_axisFracToVal(yArr,yF0), yVMax=_axisFracToVal(yArr,yF1);
      const step=findNice((yVMax-yVMin)/Math.max(3,Math.floor(imgH/60)));
      p.yCtx.strokeStyle=theme.tickStroke;
      p.yCtx.fillStyle=theme.tickText; p.yCtx.font='10px sans-serif';
      p.yCtx.textAlign='right'; p.yCtx.textBaseline='middle';
      const yTicks=[];
      for(let v=Math.ceil(yVMin/step)*step; v<=yVMax+step*0.01; v+=step) yTicks.push(v);
      const minLabelGapY=14; // px
      let lastPy=-Infinity;
      for(let ti=0;ti<yTicks.length;ti++){
        const v=yTicks[ti];
        const frac=_axisValToFrac(yArr,v);
        const py2=_fracToPx(frac,zoom,cy,imgH);
        if(py2<0||py2>imgH) continue;
        p.yCtx.beginPath(); p.yCtx.moveTo(aw,py2); p.yCtx.lineTo(aw-TICK,py2); p.yCtx.stroke();
        if(py2-lastPy>=minLabelGapY){
          p.yCtx.fillText(fmtVal(v), aw-TICK-2, py2);
          lastPy=py2;
        }
      }
      // Units label: top-left corner of y-axis gutter
      p.yCtx.textAlign='left'; p.yCtx.textBaseline='top';
      p.yCtx.fillStyle=theme.unitText; p.yCtx.font='9px sans-serif';
      p.yCtx.fillText(units, 2, 1);
      const ylabel=st.y_label||'';
      if(ylabel){
        p.yCtx.save();
        p.yCtx.translate(Math.round(aw*0.15),ah/2);
        p.yCtx.rotate(-Math.PI/2);
        p.yCtx.textAlign='center'; p.yCtx.textBaseline='middle';
        p.yCtx.fillStyle=theme.tickText; p.yCtx.font='11px sans-serif';
        p.yCtx.fillText(ylabel,0,0);
        p.yCtx.restore();
      }
    }
    const title2d = st.title || '';
    if (p.titleCanvas && p.titleCtx) {
      const tw = p.imgW || imgW;
      p.titleCtx.clearRect(0, 0, tw, PAD_T);
      if (title2d) {
        p.titleCtx.fillStyle = theme.tickText;
        p.titleCtx.font = 'bold 11px sans-serif';
        p.titleCtx.textAlign = 'center';
        p.titleCtx.textBaseline = 'middle';
        p.titleCtx.fillText(title2d, tw / 2, PAD_T / 2);
      }
    }
  }

  function drawOverlay2d(p) {
    const st=p.state; if(!st) return;
    const {pw,ph,ovCtx} = p;
    const imgW=p.imgW||Math.max(1,pw-PAD_L-PAD_R), imgH=p.imgH||Math.max(1,ph-PAD_T-PAD_B);
    ovCtx.clearRect(0,0,imgW,imgH);
    const widgets=st.overlay_widgets||[];
    const scale=_imgScale2d(st,imgW,imgH);
    for(const w of widgets){
      if(w.visible === false) continue;
      ovCtx.save(); ovCtx.strokeStyle=w.color||'#00e5ff'; ovCtx.lineWidth=2;
      if(w.type==='circle'){
        const [ccx,ccy]=_imgToCanvas2d(w.cx,w.cy,st,imgW,imgH);
        ovCtx.beginPath(); ovCtx.arc(ccx,ccy,w.r*scale,0,Math.PI*2); ovCtx.stroke();
        _drawHandle2d(ovCtx,ccx+w.r*scale,ccy,w.color);
      } else if(w.type==='annular'){
        const [ccx,ccy]=_imgToCanvas2d(w.cx,w.cy,st,imgW,imgH);
        ovCtx.beginPath();ovCtx.arc(ccx,ccy,w.r_outer*scale,0,Math.PI*2);ovCtx.stroke();
        ovCtx.beginPath();ovCtx.arc(ccx,ccy,w.r_inner*scale,0,Math.PI*2);ovCtx.stroke();
        _drawHandle2d(ovCtx,ccx+w.r_outer*scale,ccy,w.color);
        _drawHandle2d(ovCtx,ccx+w.r_inner*scale,ccy-w.r_inner*scale*0.3,w.color);
      } else if(w.type==='rectangle'){
        const [rx,ry]=_imgToCanvas2d(w.x,w.y,st,imgW,imgH);
        const rw=w.w*scale, rh=w.h*scale;
        ovCtx.strokeRect(rx,ry,rw,rh);
        _drawHandle2d(ovCtx,rx,ry,w.color);_drawHandle2d(ovCtx,rx+rw,ry,w.color);
        _drawHandle2d(ovCtx,rx,ry+rh,w.color);_drawHandle2d(ovCtx,rx+rw,ry+rh,w.color);
      } else if(w.type==='crosshair'){
        const [ccx,ccy]=_imgToCanvas2d(w.cx,w.cy,st,imgW,imgH);
        ovCtx.beginPath();ovCtx.moveTo(0,ccy);ovCtx.lineTo(imgW,ccy);ovCtx.stroke();
        ovCtx.beginPath();ovCtx.moveTo(ccx,0);ovCtx.lineTo(ccx,imgH);ovCtx.stroke();
        ovCtx.beginPath();ovCtx.arc(ccx,ccy,4,0,Math.PI*2);ovCtx.fillStyle=w.color||'#00e5ff';ovCtx.fill();
      } else if(w.type==='polygon'){
        const verts=w.vertices||[];
        if(verts.length>=2){
          ovCtx.beginPath();
          const [px0,py0]=_imgToCanvas2d(verts[0][0],verts[0][1],st,imgW,imgH);
          ovCtx.moveTo(px0,py0);
          for(let k=1;k<verts.length;k++){const[px,py]=_imgToCanvas2d(verts[k][0],verts[k][1],st,imgW,imgH);ovCtx.lineTo(px,py);}
          ovCtx.closePath();ovCtx.stroke();
          for(const v of verts){const[px,py]=_imgToCanvas2d(v[0],v[1],st,imgW,imgH);_drawHandle2d(ovCtx,px,py,w.color);}
        }
      } else if(w.type==='label'){
        const [lx,ly]=_imgToCanvas2d(w.x,w.y,st,imgW,imgH);
        ovCtx.font=`${w.fontsize||14}px sans-serif`;ovCtx.fillStyle=w.color||'#00e5ff';
        ovCtx.textAlign='left';ovCtx.textBaseline='top';ovCtx.fillText(w.text||'',lx,ly);
        _drawHandle2d(ovCtx,lx,ly,w.color);
      }
      ovCtx.restore();
    }
  }

  function _drawHandle2d(ctx,x,y,color){
    ctx.save();ctx.fillStyle='#fff';ctx.strokeStyle=color||'#00e5ff';ctx.lineWidth=1.5;
    ctx.beginPath();ctx.arc(x,y,5,0,Math.PI*2);ctx.fill();ctx.stroke();ctx.restore();
  }

  function drawMarkers2d(p, hoverState) {
    const st=p.state; if(!st) return;
    const {pw,ph,mkCtx} = p;
    const imgW=p.imgW||Math.max(1,pw-PAD_L-PAD_R), imgH=p.imgH||Math.max(1,ph-PAD_T-PAD_B);
    mkCtx.clearRect(0,0,imgW,imgH);
    const sets=st.markers||[];
    if(!sets.length) return;
    const scale=_imgScale2d(st,imgW,imgH);
    const hsi = hoverState ? hoverState.si : -1;

    for(let si=0;si<sets.length;si++){
      const ms=sets[si];
      const isHov = si===hsi;
      const color = ms.color      || '#ff0000';
      const fc    = ms.fill_color || null;
      const fa    = ms.fill_alpha != null ? ms.fill_alpha : 0.3;
      const lw    = ms.linewidth  != null ? ms.linewidth  : 1.5;
      // Hover colours: only applied when explicitly set — no default fallback.
      // When hovered the whole group switches colour; linewidth bumped by 1.
      const ec  = isHov && ms.hover_color     ? ms.hover_color     : color;
      const fch = isHov && ms.hover_facecolor ? ms.hover_facecolor : fc;
      const dlw = isHov && (ms.hover_color || ms.hover_facecolor) ? lw+1 : lw;
      const type = ms.type || 'circles';

      // Coordinate transform dispatch: "data" (default), "axes", "display".
      // For non-data transforms sizes are in pixels, not scaled by zoom.
      const tfm = ms.transform || 'data';
      let _tc;
      if(tfm==='axes'){
        const fr=_imgFitRect(st.image_width,st.image_height,imgW,imgH);
        _tc=(fx,fy)=>[fr.x+fx*fr.w, fr.y+(1-fy)*fr.h];
      } else if(tfm==='display'){
        _tc=(ix,iy)=>[ix,iy];
      } else {
        _tc=(ix,iy)=>_imgToCanvas2d(ix,iy,st,imgW,imgH);
      }
      const scl = tfm==='data' ? scale : 1;

      mkCtx.save();
      mkCtx.strokeStyle=ec; mkCtx.fillStyle=ec; mkCtx.lineWidth=dlw;

      if(type==='circles'){
        for(let i=0;i<ms.offsets.length;i++){
          const [cx,cy]=_tc(ms.offsets[i][0],ms.offsets[i][1]);
          const r=Math.max(1,(ms.sizes[i]!=null?ms.sizes[i]:ms.sizes[0]||5)*scl);
          mkCtx.beginPath();mkCtx.arc(cx,cy,r,0,Math.PI*2);
          if(fch){mkCtx.save();mkCtx.globalAlpha=fa;mkCtx.fillStyle=fch;mkCtx.fill();mkCtx.restore();}
          mkCtx.stroke();
        }
      } else if(type==='arrows'){
        const HL=8;
        for(let i=0;i<ms.offsets.length;i++){
          const [x1,y1]=_tc(ms.offsets[i][0],ms.offsets[i][1]);
          const u=(ms.U[i]||0)*scl, v=(ms.V[i]||0)*scl;
          const x2=x1+u,y2=y1+v,ang=Math.atan2(y2-y1,x2-x1);
          mkCtx.beginPath();mkCtx.moveTo(x1,y1);mkCtx.lineTo(x2,y2);mkCtx.stroke();
          mkCtx.beginPath();mkCtx.moveTo(x2,y2);
          mkCtx.lineTo(x2-HL*Math.cos(ang-Math.PI/6),y2-HL*Math.sin(ang-Math.PI/6));
          mkCtx.lineTo(x2-HL*Math.cos(ang+Math.PI/6),y2-HL*Math.sin(ang+Math.PI/6));
          mkCtx.closePath();mkCtx.fill();
        }
      } else if(type==='ellipses'){
        for(let i=0;i<ms.offsets.length;i++){
          const [cx,cy]=_tc(ms.offsets[i][0],ms.offsets[i][1]);
          const rw=Math.max(1,(ms.widths[i]||ms.widths[0]||10)*scl/2);
          const rh=Math.max(1,(ms.heights[i]||ms.heights[0]||10)*scl/2);
          const ang=((ms.angles[i]||ms.angles[0]||0)*Math.PI)/180;
          mkCtx.beginPath();mkCtx.ellipse(cx,cy,rw,rh,ang,0,Math.PI*2);
          if(fch){mkCtx.save();mkCtx.globalAlpha=fa;mkCtx.fillStyle=fch;mkCtx.fill();mkCtx.restore();}
          mkCtx.stroke();
        }
      } else if(type==='lines'){
        for(const seg of (ms.segments||[])){
          const [x1,y1]=_tc(seg[0][0],seg[0][1]);
          const [x2,y2]=_tc(seg[1][0],seg[1][1]);
          mkCtx.beginPath();mkCtx.moveTo(x1,y1);mkCtx.lineTo(x2,y2);mkCtx.stroke();
        }
      } else if(type==='rectangles'||type==='squares'){
        const heights=type==='squares'?ms.widths:ms.heights;
        for(let i=0;i<ms.offsets.length;i++){
          const [cx,cy]=_tc(ms.offsets[i][0],ms.offsets[i][1]);
          const rw=(ms.widths[i]||ms.widths[0]||20)*scl;
          const rh=((heights[i]||heights[0]||20))*scl;
          const ang=((ms.angles&&(ms.angles[i]||ms.angles[0])||0)*Math.PI)/180;
          mkCtx.save();mkCtx.translate(cx,cy);mkCtx.rotate(ang);
          if(fch){mkCtx.save();mkCtx.globalAlpha=fa;mkCtx.fillStyle=fch;mkCtx.fillRect(-rw/2,-rh/2,rw,rh);mkCtx.restore();}
          mkCtx.strokeRect(-rw/2,-rh/2,rw,rh);
          mkCtx.restore();
        }
      } else if(type==='polygons'){
        for(let i=0;i<(ms.vertices_list||[]).length;i++){
          const verts=ms.vertices_list[i];
          if(!verts||verts.length<2) continue;
          const [px0,py0]=_tc(verts[0][0],verts[0][1]);
          mkCtx.beginPath();mkCtx.moveTo(px0,py0);
          for(let k=1;k<verts.length;k++){const[px,py]=_tc(verts[k][0],verts[k][1]);mkCtx.lineTo(px,py);}
          mkCtx.closePath();
          if(fch){mkCtx.save();mkCtx.globalAlpha=fa;mkCtx.fillStyle=fch;mkCtx.fill();mkCtx.restore();}
          mkCtx.stroke();
        }
      } else if(type==='texts'){
        const fs=ms.fontsize||12;
        mkCtx.font=`${fs}px sans-serif`;mkCtx.textAlign='left';mkCtx.textBaseline='top';
        for(let i=0;i<ms.offsets.length;i++){
          const [cx,cy]=_tc(ms.offsets[i][0],ms.offsets[i][1]);
          mkCtx.fillText(String(ms.texts[i]||''),cx,cy);
        }
      }
      mkCtx.restore();
    }
  }

  // ── 3D drawing ───────────────────────────────────────────────────────────

  function _rot3(az, el) {
    // Rotation matrix: Ry(az) * Rx(-el)  (azimuth around world-Y, elevation around screen-X)
    const azR = az * Math.PI / 180, elR = el * Math.PI / 180;
    const ca = Math.cos(azR), sa = Math.sin(azR);
    const ce = Math.cos(elR), se = Math.sin(elR);
    // R = Ry(az) * Rx(-el):
    return [
      [ ca,      sa*se,   sa*ce],
      [ 0,       ce,     -se   ],
      [-sa,      ca*se,   ca*ce],
    ];
  }

  function _applyRot(R, v) {
    return [
      R[0][0]*v[0] + R[0][1]*v[1] + R[0][2]*v[2],
      R[1][0]*v[0] + R[1][1]*v[1] + R[1][2]*v[2],
      R[2][0]*v[0] + R[2][1]*v[1] + R[2][2]*v[2],
    ];
  }

  function _project3(rv, cx, cy, scale) {
    // Weak perspective: x→right, z→up on screen
    return [cx + rv[0] * scale, cy - rv[2] * scale];
  }

  function _colourFromLut(lut, t) {
    // t in [0,1] → CSS colour from 256-entry [[r,g,b],...] lut
    const i = Math.max(0, Math.min(255, Math.round(t * 255)));
    const c = lut[i];
    if (!c) return '#888';
    return `rgb(${c[0]},${c[1]},${c[2]})`;
  }

  function draw3d(p) {
    const st = p.state; if (!st) return;
    _recordFrame(p);
    const { pw, ph, plotCtx: ctx } = p;

    ctx.clearRect(0, 0, pw, ph);
    ctx.fillStyle = theme.bgPlot;
    ctx.fillRect(0, 0, pw, ph);

    // ── decode + cache b64 geometry (only when state changes) ──────────────
    const vKey = st.vertices_b64 || '';
    const fKey = st.faces_b64    || '';
    const zKey = st.z_values_b64 || '';
    if (p._3dVertsKey !== vKey) {
      p._3dVertsKey = vKey;
      if (vKey) {
        const vf = _decodeF32(vKey);
        const nv = vf.length / 3;
        const arr = new Array(nv);
        for (let i = 0; i < nv; i++) arr[i] = [vf[i*3], vf[i*3+1], vf[i*3+2]];
        p._3dVerts = arr;
      } else { p._3dVerts = st.vertices || []; }
    }
    if (p._3dFacesKey !== fKey) {
      p._3dFacesKey = fKey;
      if (fKey) {
        const ff = _decodeI32(fKey);
        const nf = ff.length / 3;
        const arr = new Array(nf);
        for (let i = 0; i < nf; i++) arr[i] = [ff[i*3], ff[i*3+1], ff[i*3+2]];
        p._3dFaces = arr;
      } else { p._3dFaces = st.faces || []; }
    }
    if (p._3dZKey !== zKey) {
      p._3dZKey = zKey;
      p._3dZVals = zKey ? _decodeF32(zKey) : (st.z_values || []);
    }
    const verts = p._3dVerts  || [];
    const faces = p._3dFaces  || [];
    const zVals = p._3dZVals  || [];

    const lut      = st.colormap_data || [];
    const geom     = st.geom_type   || 'surface';
    const bnds     = st.data_bounds || {};
    const az       = st.azimuth     || 0;
    const el       = st.elevation   || 30;
    const zoom     = st.zoom        || 1.0;
    const color    = st.color       || '#4fc3f7';
    const ptSize   = st.point_size  || 4;
    const lw       = st.linewidth   || 1.5;

    // Normalise vertices to [-1,1]³
    const xr = (bnds.xmax - bnds.xmin) || 1;
    const yr = (bnds.ymax - bnds.ymin) || 1;
    const zr = (bnds.zmax - bnds.zmin) || 1;
    const maxR = Math.max(xr, yr, zr);
    function norm(v) {
      return [
        2 * (v[0] - bnds.xmin) / maxR - xr / maxR,
        2 * (v[1] - bnds.ymin) / maxR - yr / maxR,
        2 * (v[2] - bnds.zmin) / maxR - zr / maxR,
      ];
    }

    const R = _rot3(az, el);
    const cx = pw / 2, cy = ph / 2;
    const scale = zoom * Math.min(pw, ph) * 0.32;

    // Pre-project all vertices
    const proj = verts.map(v => {
      const nv = norm(v);
      const rv = _applyRot(R, nv);
      return { s: _project3(rv, cx, cy, scale), d: rv[1] }; // d = depth (into screen)
    });

    // Z-value normalisation for colormap
    const zMin = bnds.zmin, zMax = bnds.zmax, zRange = (zMax - zMin) || 1;

    if (geom === 'surface' && faces.length > 0) {
      // Compute per-face mean depth and mean z for colour
      const faceData = faces.map(f => {
        const d = (proj[f[0]].d + proj[f[1]].d + proj[f[2]].d) / 3;
        const zMean = (zVals[f[0]] + zVals[f[1]] + zVals[f[2]]) / 3;
        return { f, d, zMean };
      });
      // Painter's algorithm: draw back-to-front
      faceData.sort((a, b) => b.d - a.d);

      for (const { f, zMean } of faceData) {
        const t  = (zMean - zMin) / zRange;
        const fc = _colourFromLut(lut, t);
        const [ax2, ay2] = proj[f[0]].s;
        const [bx,  by ] = proj[f[1]].s;
        const [ccx2,ccy2] = proj[f[2]].s;
        ctx.beginPath();
        ctx.moveTo(ax2, ay2); ctx.lineTo(bx, by); ctx.lineTo(ccx2, ccy2);
        ctx.closePath();
        ctx.fillStyle = fc;
        ctx.fill();
        ctx.strokeStyle = 'rgba(0,0,0,0.12)';
        ctx.lineWidth = 0.4;
        ctx.stroke();
      }

    } else if (geom === 'scatter') {
      // Sort back-to-front so nearer points draw on top
      const order = proj.map((p2, i) => ({ i, d: p2.d })).sort((a, b) => b.d - a.d);
      for (const { i } of order) {
        const [sx, sy] = proj[i].s;
        ctx.beginPath();
        ctx.arc(sx, sy, ptSize, 0, Math.PI * 2);
        ctx.fillStyle = color;
        ctx.fill();
      }

    } else if (geom === 'line') {
      ctx.beginPath();
      ctx.strokeStyle = color;
      ctx.lineWidth   = lw;
      ctx.lineJoin    = 'round';
      for (let i = 0; i < proj.length; i++) {
        const [sx, sy] = proj[i].s;
        if (i === 0) ctx.moveTo(sx, sy); else ctx.lineTo(sx, sy);
      }
      ctx.stroke();
      // Draw point markers at each vertex
      ctx.fillStyle = color;
      for (const { s } of proj) {
        ctx.beginPath(); ctx.arc(s[0], s[1], lw + 1, 0, Math.PI * 2); ctx.fill();
      }
    }

    // ── Draw axes ────────────────────────────────────────────────────────────
    const axisVerts = [
      [-1,0,0],[1,0,0],[0,-1,0],[0,1,0],[0,0,-1],[0,0,1]
    ];
    const ap = axisVerts.map(v => _project3(_applyRot(R, v), cx, cy, scale));

    const axDefs = [
      { i0:0, i1:1, label: st.x_label||'x', col:'#e06c75' },
      { i0:2, i1:3, label: st.y_label||'y', col:'#98c379' },
      { i0:4, i1:5, label: st.z_label||'z', col:'#61afef' },
    ];
    for (const { i0, i1, label, col } of axDefs) {
      ctx.beginPath();
      ctx.moveTo(ap[i0][0], ap[i0][1]);
      ctx.lineTo(ap[i1][0], ap[i1][1]);
      ctx.strokeStyle = col;
      ctx.lineWidth   = 1.5;
      ctx.setLineDash([4, 3]);
      ctx.stroke();
      ctx.setLineDash([]);
      // Positive-end label
      ctx.fillStyle   = col;
      ctx.font        = 'bold 11px sans-serif';
      ctx.textAlign   = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(label, ap[i1][0], ap[i1][1]);
    }

    // ── Tick marks on each axis (5 evenly spaced) ─────────────────────────
    ctx.font = '9px sans-serif';
    ctx.fillStyle = theme.tickText;
    const NTICK = 5;
    const axisData = [
      { lo: bnds.xmin, hi: bnds.xmax, baseN: [0,0,0], dir: [1/maxR*2,0,0] },
      { lo: bnds.ymin, hi: bnds.ymax, baseN: [0,0,0], dir: [0,1/maxR*2,0] },
      { lo: bnds.zmin, hi: bnds.zmax, baseN: [0,0,0], dir: [0,0,1/maxR*2] },
    ];
    const axisColours = ['#e06c75','#98c379','#61afef'];
    for (let ai = 0; ai < 3; ai++) {
      const { lo, hi } = axisData[ai];
      const range = hi - lo || 1;
      const step  = findNice(range / NTICK);
      ctx.fillStyle   = axisColours[ai];
      ctx.strokeStyle = axisColours[ai];
      ctx.lineWidth   = 0.8;
      for (let tv = Math.ceil(lo / step) * step; tv <= hi + step * 0.01; tv += step) {
        const t = (tv - lo) / range; // 0..1
        // Normalised position on the axis
        let nv;
        if (ai === 0) nv = [2*t*xr/maxR - xr/maxR, -yr/maxR, -zr/maxR];
        else if(ai===1) nv = [-xr/maxR, 2*t*yr/maxR - yr/maxR, -zr/maxR];
        else            nv = [-xr/maxR, -yr/maxR, 2*t*zr/maxR - zr/maxR];
        const [tx, ty] = _project3(_applyRot(R, nv), cx, cy, scale);
        // Small tick cross
        ctx.beginPath();
        ctx.arc(tx, ty, 1.5, 0, Math.PI * 2);
        ctx.fill();
        // Label (only every other tick to avoid crowding)
        ctx.textAlign = 'left';
        ctx.textBaseline = 'bottom';
        ctx.fillText(fmtVal(tv), tx + 3, ty - 1);
      }
    }
  }

  // ── event emission helper (module-scope: accessible to all attach fns) ──
  // eventType: any pointer_* or key_* event type string
  function _emitEvent(panelId, eventType, widgetId, extraData) {
    const payload = Object.assign(
      { source: 'js', panel_id: panelId, event_type: eventType,
        widget_id: widgetId || null },
      extraData || {}
    );
    model.set('event_json', JSON.stringify(payload));
    model.save_changes();
  }

  function _modifiers(e) {
    const mods = [];
    if (e.ctrlKey)  mods.push("ctrl");
    if (e.shiftKey) mods.push("shift");
    if (e.altKey)   mods.push("alt");
    if (e.metaKey)  mods.push("meta");
    return mods;
  }

  function _pointerFields(e) {
    return {
      time_stamp: performance.now() / 1000,
      modifiers:  _modifiers(e),
      button:     null,
      buttons:    e.buttons ?? 0,
    };
  }

  function _attachEvents3d(p) {
    const { overlayCanvas } = p;
    let dragStart = null;
    let commitPending = false;
    let _settledTimer = null;
    let _settledStartX = 0, _settledStartY = 0, _settledStartTs = 0;
    function _scheduleCommit() {
      if (commitPending) return; commitPending = true;
      requestAnimationFrame(() => {
        commitPending = false;
        model.save_changes();
      });
    }


    overlayCanvas.addEventListener('mousedown', (e) => {
      if (e.button !== 0) return;
      const {mx:_d3mx, my:_d3my} = _clientPos(e, overlayCanvas, p.pw, p.ph);
      dragStart = { mx: _d3mx, my: _d3my,
                    az: p.state.azimuth, el: p.state.elevation };
      overlayCanvas.style.cursor = 'grabbing';
      // Do NOT call e.preventDefault() — suppresses click → dblclick cascade.
    });
    document.addEventListener('mousemove', (e) => {
      if (!dragStart) return;
      const {mx:_d3mx2, my:_d3my2} = _clientPos(e, overlayCanvas, p.pw, p.ph);
      const dx = _d3mx2 - dragStart.mx;
      const dy = _d3my2 - dragStart.my;
      p.state.azimuth   = dragStart.az + dx * 0.5;
      p.state.elevation = Math.max(-89, Math.min(89, dragStart.el - dy * 0.5));
      draw3d(p);
      model.set(`panel_${p.id}_json`, JSON.stringify(p.state));
      _emitEvent(p.id, 'pointer_move', null,
        { azimuth: p.state.azimuth, elevation: p.state.elevation, zoom: p.state.zoom,
          ..._pointerFields(e) });
      e.preventDefault();
    });
    document.addEventListener('mouseup', (e) => {
      clearTimeout(_settledTimer); _settledTimer = null;
      if (!dragStart) return;
      dragStart = null;
      overlayCanvas.style.cursor = 'grab';
      model.set(`panel_${p.id}_json`, JSON.stringify(p.state));
      _emitEvent(p.id, 'pointer_up', null,
        { azimuth: p.state.azimuth, elevation: p.state.elevation, zoom: p.state.zoom,
          ..._pointerFields(e), button: e.button });
      _scheduleCommit();
    });

    overlayCanvas.addEventListener('wheel', (e) => {
      e.preventDefault();
      p.state.zoom = Math.max(0.1, Math.min(10, p.state.zoom * (e.deltaY > 0 ? 0.9 : 1.1)));
      draw3d(p);
      model.set(`panel_${p.id}_json`, JSON.stringify(p.state));
      _emitEvent(p.id, 'wheel', null, {
        time_stamp: performance.now() / 1000,
        modifiers: _modifiers(e),
        x: p.mouseX ?? 0, y: p.mouseY ?? 0,
        dx: e.deltaX, dy: e.deltaY,
      });
      _emitEvent(p.id, 'pointer_move', null,
        { azimuth: p.state.azimuth, elevation: p.state.elevation, zoom: p.state.zoom,
          ..._pointerFields(e) });
      _scheduleCommit();
    }, { passive: false });

    overlayCanvas.addEventListener('mousemove', (e) => {
      const {mx, my} = _clientPos(e, overlayCanvas, p.pw, p.ph);
      p.mouseX = mx;
      p.mouseY = my;
      // pointer_settled dwell timer (zero-cost when pointer_settled_ms === 0)
      const _settledMs = (p.state.pointer_settled_ms ?? 0);
      if (_settledMs > 0) {
        const _settledDelta = p.state.pointer_settled_delta ?? 4;
        clearTimeout(_settledTimer);
        _settledStartX = mx;
        _settledStartY = my;
        _settledStartTs = performance.now();
        const _settledMods = _modifiers(e);  // capture at arm time — e is the mousemove event
        _settledTimer = setTimeout(() => {
          const dist = Math.hypot(p.mouseX - _settledStartX, p.mouseY - _settledStartY);
          if (dist <= _settledDelta) {
            const _now = performance.now();
            _emitEvent(p.id, 'pointer_settled', null, {
              time_stamp: _now / 1000,
              modifiers:  _settledMods,
              button:     null,
              buttons:    0,
              x:          Math.round(p.mouseX),
              y:          Math.round(p.mouseY),
              dwell_ms:   _now - _settledStartTs,
            });
          }
        }, _settledMs);
      }
    });

    // Keyboard shortcuts
    // Built-in: r=reset view. All keys are forwarded to Python unconditionally.
    overlayCanvas.addEventListener('keydown', (e) => {
      const st = p.state; if (!st) return;
      _emitEvent(p.id, 'key_down', null, {
        time_stamp: performance.now() / 1000,
        modifiers: _modifiers(e),
        key: e.key,
        last_widget_id: p.lastWidgetId || null,
        x: p.mouseX ?? 0, y: p.mouseY ?? 0,
      });
      if (e.key.toLowerCase() === 'r') {
        p.state.azimuth = -60; p.state.elevation = 30; p.state.zoom = 1;
        draw3d(p);
        model.set(`panel_${p.id}_json`, JSON.stringify(p.state));
        model.save_changes();
        e.stopPropagation(); e.preventDefault();
      }
    });
    overlayCanvas.tabIndex = 0;
    overlayCanvas.style.outline = 'none';
    overlayCanvas.style.cursor  = 'grab';
    overlayCanvas.addEventListener('mouseenter', (e) => {
      overlayCanvas.focus();
      _emitEvent(p.id, 'pointer_enter', null, {..._pointerFields(e), x: e.offsetX, y: e.offsetY});
    });
    overlayCanvas.addEventListener('mouseleave', (e) => {
      clearTimeout(_settledTimer); _settledTimer = null;
      _emitEvent(p.id, 'pointer_leave', null, {..._pointerFields(e), x: e.offsetX, y: e.offsetY});
    });
    overlayCanvas.addEventListener('keyup', (e) => {
      _emitEvent(p.id, 'key_up', null, {
        time_stamp: performance.now() / 1000,
        modifiers: _modifiers(e),
        key: e.key,
        x: p.mouseX ?? 0, y: p.mouseY ?? 0,
      });
    });
    overlayCanvas.addEventListener('dblclick', (e) => {
      const {mx, my} = _clientPos(e, overlayCanvas, p.pw, p.ph);
      _emitEvent(p.id, 'double_click', null, {..._pointerFields(e), button: e.button, x: mx, y: my});
    });
  }

  // ── 1D drawing ───────────────────────────────────────────────────────────

  function _plotRect1d(pw,ph){return{x:PAD_L,y:PAD_T,w:Math.max(1,pw-PAD_L-PAD_R),h:Math.max(1,ph-PAD_T-PAD_B)};}

  function _xToFrac1d(xArr,val){
    if(xArr.length<2) return 0;
    const n=xArr.length, asc=xArr[n-1]>=xArr[0];
    if(asc?val<=xArr[0]:val>=xArr[0]) return 0;
    if(asc?val>=xArr[n-1]:val<=xArr[n-1]) return 1;
    let lo=0,hi=n-2;
    while(lo<hi){const mid=(lo+hi)>>1;const ok=asc?(xArr[mid]<=val&&val<xArr[mid+1]):(xArr[mid]>=val&&val>xArr[mid+1]);if(ok){lo=mid;break;}if(asc?xArr[mid+1]<=val:xArr[mid+1]>=val)lo=mid+1;else hi=mid;}
    return(lo+(val-xArr[lo])/(xArr[lo+1]-xArr[lo]))/(n-1);
  }
  function _fracToX1d(xArr,frac){
    if(xArr.length<2) return xArr.length?xArr[0]:0;
    const n=xArr.length,pos=Math.max(0,Math.min(1,frac))*(n-1),lo=Math.min(Math.floor(pos),n-2),t=pos-lo;
    return xArr[lo]+t*(xArr[lo+1]-xArr[lo]);
  }
  function _fracToPx1d(frac,x0,x1,r){return r.x+((frac-x0)/((x1-x0)||1))*r.w;}
  function _valToPy1d(val,dMin,dMax,r){return r.y+r.h-((val-dMin)/((dMax-dMin)||1))*r.h;}

  function draw1d(p) {
    const st=p.state; if(!st) return;
    _recordFrame(p);
    const {pw,ph,plotCtx:ctx} = p;
    const r=_plotRect1d(pw,ph);

    // ── decode + cache b64 arrays (keyed by b64 string; free on re-render) ──
    const xKey = st.x_axis_b64 || '';
    const dKey = st.data_b64   || '';
    if (p._1dXKey !== xKey) {
      p._1dXKey  = xKey;
      p._1dXArr  = xKey ? _decodeF64(xKey) : (st.x_axis || []);
    }
    if (p._1dDKey !== dKey) {
      p._1dDKey  = dKey;
      p._1dDArr  = dKey ? _decodeF64(dKey)  : (st.data   || []);
    }
    const xArr = p._1dXArr;   // Float64Array (or plain array fallback)
    const yData = p._1dDArr;  // Float64Array (or plain array fallback)

    const x0=st.view_x0||0, x1=st.view_x1||1;
    let dMin=st.data_min, dMax=st.data_max;
    if (st.y_range && st.y_range.length === 2) { dMin = st.y_range[0]; dMax = st.y_range[1]; }
    const units=st.units||'', yUnits=st.y_units||'';

    const isLog = st.yscale === 'log';
    const _logEps = 1e-300;
    const effDMin = isLog ? Math.log10(Math.max(_logEps, dMin)) : dMin;
    const effDMax = isLog ? Math.log10(Math.max(_logEps, dMax)) : dMax;
    function _toPlotY(v) {
      return _valToPy1d(isLog ? Math.log10(Math.max(_logEps, v)) : v, effDMin, effDMax, r);
    }

    ctx.clearRect(0,0,pw,ph);
    ctx.fillStyle=theme.bg; ctx.fillRect(0,0,pw,ph);
    ctx.fillStyle=theme.bgPlot; ctx.fillRect(r.x,r.y,r.w,r.h);

    // Grid
    ctx.strokeStyle=theme.gridStroke; ctx.lineWidth=1;
    if(xArr.length>=2){
      const xVMin=_fracToX1d(xArr,x0), xVMax=_fracToX1d(xArr,x1);
      const xStep=findNice((xVMax-xVMin)/Math.max(2,Math.floor(r.w/70)));
      for(let v=Math.ceil(xVMin/xStep)*xStep;v<=xVMax+xStep*0.01;v+=xStep){
        const px=_fracToPx1d(_xToFrac1d(xArr,v),x0,x1,r);
        if(px<r.x||px>r.x+r.w) continue;
        ctx.beginPath();ctx.moveTo(px,r.y);ctx.lineTo(px,r.y+r.h);ctx.stroke();
      }
    }
    const yRange=(effDMax-effDMin)||1;
    const yStep=findNice(yRange/Math.max(2,Math.floor(r.h/40)));
    if(isLog){
      const lo=Math.floor(effDMin), hi=Math.ceil(effDMax);
      for(let e=lo;e<=hi;e++){
        const py=_toPlotY(Math.pow(10,e));
        if(py<r.y||py>r.y+r.h) continue;
        ctx.beginPath();ctx.moveTo(r.x,py);ctx.lineTo(r.x+r.w,py);ctx.stroke();
      }
    } else {
      for(let v=Math.ceil(dMin/yStep)*yStep;v<=dMax+yStep*0.01;v+=yStep){
        const py=_valToPy1d(v,dMin,dMax,r);
        if(py<r.y||py>r.y+r.h) continue;
        ctx.beginPath();ctx.moveTo(r.x,py);ctx.lineTo(r.x+r.w,py);ctx.stroke();
      }
    }

    // Spans
    for(const sp of (st.spans||[])){
      ctx.fillStyle=sp.color||(theme.dark?'rgba(255,255,100,0.15)':'rgba(200,160,0,0.15)');
      if(sp.axis==='x'){
        const px0=_fracToPx1d(_xToFrac1d(xArr,sp.v0),x0,x1,r);
        const px1b=_fracToPx1d(_xToFrac1d(xArr,sp.v1),x0,x1,r);
        ctx.fillRect(px0,r.y,px1b-px0,r.h);
      } else {
        const py0=_toPlotY(sp.v1), py1=_toPlotY(sp.v0);
        ctx.fillRect(r.x,py0,r.w,py1-py0);
      }
    }

    // Clip
    ctx.save(); ctx.beginPath(); ctx.rect(r.x,r.y,r.w,r.h); ctx.clip();

    // Linestyle → canvas dash pattern
    const _LINESTYLE_DASH = {
      'solid':   [],
      'dashed':  [6, 3],
      'dotted':  [2, 3],
      'dashdot': [6, 3, 2, 3],
    };

    // Draw a single marker symbol centred at (px, py) with half-size ms.
    // The caller is responsible for beginPath() before and fill()/stroke() after.
    function _drawMarkerSymbol(mctx, marker, px, py, ms) {
      switch (marker) {
        case 'o':
          mctx.arc(px, py, ms, 0, Math.PI * 2);
          break;
        case 's':
          mctx.rect(px - ms, py - ms, ms * 2, ms * 2);
          break;
        case '^':
          mctx.moveTo(px, py - ms);
          mctx.lineTo(px + ms, py + ms);
          mctx.lineTo(px - ms, py + ms);
          mctx.closePath();
          break;
        case 'v':
          mctx.moveTo(px, py + ms);
          mctx.lineTo(px + ms, py - ms);
          mctx.lineTo(px - ms, py - ms);
          mctx.closePath();
          break;
        case 'D':
          mctx.moveTo(px, py - ms);
          mctx.lineTo(px + ms, py);
          mctx.lineTo(px, py + ms);
          mctx.lineTo(px - ms, py);
          mctx.closePath();
          break;
        case '+':
          mctx.moveTo(px - ms, py); mctx.lineTo(px + ms, py);
          mctx.moveTo(px, py - ms); mctx.lineTo(px, py + ms);
          break;
        case 'x':
          mctx.moveTo(px - ms, py - ms); mctx.lineTo(px + ms, py + ms);
          mctx.moveTo(px + ms, py - ms); mctx.lineTo(px - ms, py + ms);
          break;
        default:
          mctx.arc(px, py, ms, 0, Math.PI * 2);
      }
    }

    // Stroke-only markers (no meaningful fill area)
    const _MARKER_STROKE_ONLY = new Set(['+', 'x']);

    function _drawLine(yData, lineXArr, color, lw, linestyle, alpha, marker, markersize) {
      if (!yData || !yData.length) return;
      const n = yData.length;
      const isStepMid = linestyle === 'step-mid';
      const dash = isStepMid ? [] : (_LINESTYLE_DASH[linestyle || 'solid'] || []);
      const eff_alpha = (alpha != null && alpha < 1.0) ? alpha : 1.0;
      const ms = Math.max(1, markersize || 4);
      const doMarker = marker && marker !== 'none';

      // Pre-compute pixel positions
      const allPx = new Array(n), allPy = new Array(n);
      for (let i = 0; i < n; i++) {
        const xFrac = lineXArr.length >= 2
          ? (lineXArr[i] - lineXArr[0]) / ((lineXArr[lineXArr.length - 1] - lineXArr[0]) || 1)
          : i / ((n - 1) || 1);
        allPx[i] = _fracToPx1d(xFrac, x0, x1, r);
        allPy[i] = _toPlotY(yData[i]);
      }

      ctx.save();
      if (eff_alpha < 1.0) ctx.globalAlpha = eff_alpha;
      ctx.setLineDash(dash);
      ctx.beginPath();
      ctx.strokeStyle = color; ctx.lineWidth = lw; ctx.lineJoin = 'round';

      if (isStepMid && n >= 2) {
        ctx.moveTo(allPx[0], allPy[0]);
        for (let i = 0; i < n - 1; i++) {
          const midX = (allPx[i] + allPx[i + 1]) / 2;
          ctx.lineTo(midX, allPy[i]);
          ctx.lineTo(midX, allPy[i + 1]);
        }
        ctx.lineTo(allPx[n - 1], allPy[n - 1]);
      } else {
        for (let i = 0; i < n; i++) {
          if (i === 0) ctx.moveTo(allPx[i], allPy[i]);
          else ctx.lineTo(allPx[i], allPy[i]);
        }
      }
      ctx.stroke();
      ctx.setLineDash([]);

      const pts = doMarker ? allPx.map((px, i) => [px, allPy[i]]) : null;

      // Per-point marker symbols
      if (doMarker && pts && pts.length) {
        ctx.strokeStyle = color;
        ctx.fillStyle   = color;
        ctx.lineWidth   = Math.max(1, lw * 0.8);
        const strokeOnly = _MARKER_STROKE_ONLY.has(marker);
        for (const [px, py] of pts) {
          ctx.beginPath();
          _drawMarkerSymbol(ctx, marker, px, py, ms);
          if (!strokeOnly) ctx.fill();
          ctx.stroke();
        }
      }

      ctx.restore();
    }

    _drawLine(yData, xArr,
      st.line_color || '#4fc3f7', st.line_linewidth || 1.5,
      st.line_linestyle || 'solid',
      st.line_alpha != null ? st.line_alpha : 1.0,
      st.line_marker || 'none', st.line_markersize || 4);
    for (const ex of (st.extra_lines || [])) {
      const exY = ex.data_b64   ? _decodeF64(ex.data_b64)   : (ex.data   || []);
      const exX = ex.x_axis_b64 ? _decodeF64(ex.x_axis_b64) : (ex.x_axis ? ex.x_axis : xArr);
      _drawLine(exY, exX,
        ex.color || (theme.dark ? '#fff' : '#333'), ex.linewidth || 1.5,
        ex.linestyle || 'solid',
        ex.alpha != null ? ex.alpha : 1.0,
        ex.marker || 'none', ex.markersize || 4);
    }
    // ── hovered-line highlight: redraw on top with brightened colour + thicker stroke ──
    const _hovId = p._lineHoverId;
    if (_hovId !== undefined && _hovId !== '__none__') {
      if (_hovId === null) {
        _drawLine(yData, xArr,
          _brightenColor(st.line_color||'#4fc3f7'), (st.line_linewidth||1.5)+1,
          st.line_linestyle||'solid', st.line_alpha!=null?st.line_alpha:1.0,
          st.line_marker||'none', st.line_markersize||4);
      } else {
        for (const ex of (st.extra_lines||[])) {
          if (ex.id === _hovId) {
            const exY = ex.data_b64 ? _decodeF64(ex.data_b64) : (ex.data||[]);
            const exX = ex.x_axis_b64 ? _decodeF64(ex.x_axis_b64) : (ex.x_axis?ex.x_axis:xArr);
            _drawLine(exY, exX,
              _brightenColor(ex.color||(theme.dark?'#fff':'#333')), (ex.linewidth||1.5)+1,
              ex.linestyle||'solid', ex.alpha!=null?ex.alpha:1.0,
              ex.marker||'none', ex.markersize||4);
            break;
          }
        }
      }
    }
    ctx.restore();

    const axisVis1d=st.axis_visible!==false;
    const xTicksVis1d=st.x_ticks_visible!==false;
    const yTicksVis1d=st.y_ticks_visible!==false;

    // Axes
    ctx.strokeStyle=theme.axisStroke; ctx.lineWidth=1;
    ctx.beginPath();ctx.moveTo(r.x,r.y+r.h);ctx.lineTo(r.x+r.w,r.y+r.h);ctx.stroke();
    ctx.beginPath();ctx.moveTo(r.x,r.y);ctx.lineTo(r.x,r.y+r.h);ctx.stroke();

    if(axisVis1d&&xTicksVis1d){
      ctx.fillStyle=theme.tickText; ctx.font='10px monospace';
      if(xArr.length>=2){
        const xVMin=_fracToX1d(xArr,x0), xVMax=_fracToX1d(xArr,x1);
        const xStep=findNice((xVMax-xVMin)/Math.max(2,Math.floor(r.w/70)));
        ctx.textAlign='center'; ctx.textBaseline='top';
        for(let v=Math.ceil(xVMin/xStep)*xStep;v<=xVMax+xStep*0.01;v+=xStep){
          const px=_fracToPx1d(_xToFrac1d(xArr,v),x0,x1,r);
          if(px<r.x||px>r.x+r.w) continue;
          ctx.strokeStyle=theme.axisStroke;ctx.beginPath();ctx.moveTo(px,r.y+r.h);ctx.lineTo(px,r.y+r.h+5);ctx.stroke();
          ctx.fillStyle=theme.tickText;ctx.fillText(fmtVal(v),px,r.y+r.h+7);
        }
        if(units&&units!=='px'){ctx.textAlign='right';ctx.textBaseline='top';ctx.fillStyle=theme.unitText;ctx.font='9px monospace';ctx.fillText(units,r.x+r.w,r.y+r.h+24);ctx.font='10px monospace';}
      }
    }
    if(axisVis1d&&yTicksVis1d){
      ctx.font='10px monospace';ctx.textAlign='right';ctx.textBaseline='middle';
      const tickRX=r.x-8;
      if(isLog){
        const lo=Math.floor(effDMin), hi=Math.ceil(effDMax);
        for(let e=lo;e<=hi;e++){
          const v=Math.pow(10,e);
          const py=_toPlotY(v);
          if(py<r.y||py>r.y+r.h) continue;
          ctx.strokeStyle=theme.axisStroke;ctx.beginPath();ctx.moveTo(r.x,py);ctx.lineTo(r.x-5,py);ctx.stroke();
          ctx.fillStyle=theme.tickText;ctx.fillText('10^'+e,tickRX,py);
        }
      } else {
        let maxTW=0;
        for(let v=Math.ceil(dMin/yStep)*yStep;v<=dMax+yStep*0.01;v+=yStep){const tw=ctx.measureText(fmtVal(v)).width;if(tw>maxTW)maxTW=tw;}
        for(let v=Math.ceil(dMin/yStep)*yStep;v<=dMax+yStep*0.01;v+=yStep){
          const py=_valToPy1d(v,dMin,dMax,r);
          if(py<r.y||py>r.y+r.h) continue;
          ctx.strokeStyle=theme.axisStroke;ctx.beginPath();ctx.moveTo(r.x,py);ctx.lineTo(r.x-5,py);ctx.stroke();
          ctx.fillStyle=theme.tickText;ctx.fillText(fmtVal(v),tickRX,py);
        }
      }
      if(yUnits){
        ctx.save();
        // Centre the rotated label in the left gutter (x = 0..r.x).
        // Using a fixed x of PAD_L*0.28 keeps it clear of the tick numbers
        // regardless of how wide those numbers are.
        const lcx = Math.round(PAD_L * 0.28);
        ctx.translate(lcx, r.y+r.h/2); ctx.rotate(-Math.PI/2);
        ctx.textAlign='center'; ctx.textBaseline='middle';
        ctx.fillStyle=theme.unitText; ctx.font='9px monospace';
        ctx.fillText(yUnits, 0, 0);
        ctx.restore();
      }
    }

    // Legend
    const labels=[];
    if(st.line_label) labels.push({
      color: st.line_color||'#4fc3f7', text: st.line_label,
      linestyle: st.line_linestyle||'solid',
      marker: st.line_marker||'none', ms: st.line_markersize||4,
    });
    for(const ex of (st.extra_lines||[])) if(ex.label) labels.push({
      color: ex.color||(theme.dark?'#fff':'#333'), text: ex.label,
      linestyle: ex.linestyle||'solid',
      marker: ex.marker||'none', ms: ex.markersize||4,
    });
    if(labels.length){
      ctx.font='10px monospace'; let ly=r.y+6;
      for(const lb of labels){
        const ldash=_LINESTYLE_DASH[lb.linestyle||'solid']||[];
        ctx.strokeStyle=lb.color; ctx.lineWidth=2;
        ctx.setLineDash(ldash);
        ctx.beginPath(); ctx.moveTo(r.x+8,ly+5); ctx.lineTo(r.x+24,ly+5); ctx.stroke();
        ctx.setLineDash([]);
        if(lb.marker && lb.marker!=='none'){
          ctx.strokeStyle=lb.color; ctx.fillStyle=lb.color; ctx.lineWidth=1.5;
          ctx.beginPath(); _drawMarkerSymbol(ctx,lb.marker,r.x+16,ly+5,Math.min(lb.ms||4,4)); ctx.fill(); ctx.stroke();
        }
        ctx.fillStyle=theme.tickText;ctx.textAlign='left';ctx.textBaseline='top';ctx.fillText(lb.text,r.x+28,ly);ly+=16;
      }
    }

    const title1d=st.title||'';
    if(title1d){
      ctx.fillStyle=theme.tickText;
      ctx.font='bold 11px sans-serif';
      ctx.textAlign='center'; ctx.textBaseline='middle';
      ctx.fillText(title1d, r.x+r.w/2, PAD_T/2);
    }

    drawOverlay1d(p);
    drawMarkers1d(p);
  }

  function drawOverlay1d(p) {
    const st=p.state; if(!st) return;
    const {pw,ph,ovCtx} = p;
    const r=_plotRect1d(pw,ph);
    const xArr = p._1dXArr || (st.x_axis_b64 ? _decodeF64(st.x_axis_b64) : (st.x_axis||[]));
    const x0=st.view_x0||0, x1=st.view_x1||1;
    const dMin=st.data_min, dMax=st.data_max;
    ovCtx.clearRect(0,0,pw,ph);
    const widgets=st.overlay_widgets||[];
    if(!widgets.length) return;

    for(const w of widgets){
      if(w.visible === false) continue;
      const color=w.color||'#00e5ff';
      ovCtx.save();ovCtx.strokeStyle=color;ovCtx.lineWidth=2;
      if(w.type==='vline'){
        const px=_fracToPx1d(_xToFrac1d(xArr,w.x),x0,x1,r);
        ovCtx.setLineDash([5,3]);ovCtx.beginPath();ovCtx.moveTo(px,r.y);ovCtx.lineTo(px,r.y+r.h);ovCtx.stroke();ovCtx.setLineDash([]);
        _ovHandle1d(ovCtx,px,r.y+7,color);
      } else if(w.type==='hline'){
        const py=_valToPy1d(w.y,dMin,dMax,r);
        ovCtx.setLineDash([5,3]);ovCtx.beginPath();ovCtx.moveTo(r.x,py);ovCtx.lineTo(r.x+r.w,py);ovCtx.stroke();ovCtx.setLineDash([]);
        _ovHandle1d(ovCtx,r.x+r.w-7,py,color);
      } else if(w.type==='range'){
        const px0=_fracToPx1d(_xToFrac1d(xArr,w.x0),x0,x1,r);
        const px1b=_fracToPx1d(_xToFrac1d(xArr,w.x1),x0,x1,r);
        if(w.style==='fwhm'){
          // FWHM style: o-------o  two handles joined by a dashed horizontal line
          const pyHalf=_valToPy1d(w.y||0,dMin,dMax,r);
          ovCtx.setLineDash([5,4]);
          ovCtx.beginPath();ovCtx.moveTo(px0,pyHalf);ovCtx.lineTo(px1b,pyHalf);ovCtx.stroke();
          ovCtx.setLineDash([]);
          _ovHandle1d(ovCtx,px0,pyHalf,color);
          _ovHandle1d(ovCtx,px1b,pyHalf,color);
        } else {
          // band style (default)
          const left=Math.min(px0,px1b), right=Math.max(px0,px1b);
          ovCtx.save();ovCtx.globalAlpha=0.15;ovCtx.fillStyle=color;ovCtx.fillRect(left,r.y,right-left,r.h);ovCtx.restore();
          ovCtx.setLineDash([5,3]);
          ovCtx.beginPath();ovCtx.moveTo(px0,r.y);ovCtx.lineTo(px0,r.y+r.h);ovCtx.stroke();
          ovCtx.beginPath();ovCtx.moveTo(px1b,r.y);ovCtx.lineTo(px1b,r.y+r.h);ovCtx.stroke();
          ovCtx.setLineDash([]);
          _ovHandle1d(ovCtx,px0,r.y+7,color);_ovHandle1d(ovCtx,px1b,r.y+7,color);
        }
      } else if(w.type==='point'){
        const px=_fracToPx1d(_xToFrac1d(xArr,w.x),x0,x1,r);
        const py=_valToPy1d(w.y,dMin,dMax,r);
        // Dashed crosshair guide lines (skipped when show_crosshair is false)
        if(w.show_crosshair!==false){
          ovCtx.save();ovCtx.beginPath();ovCtx.rect(r.x,r.y,r.w,r.h);ovCtx.clip();
          ovCtx.setLineDash([4,3]);
          ovCtx.beginPath();ovCtx.moveTo(px,r.y);ovCtx.lineTo(px,r.y+r.h);ovCtx.stroke();
          ovCtx.beginPath();ovCtx.moveTo(r.x,py);ovCtx.lineTo(r.x+r.w,py);ovCtx.stroke();
          ovCtx.setLineDash([]);
          ovCtx.restore();
        }
        // Draw the draggable handle (larger than _ovHandle1d for easy grab)
        ovCtx.save();ovCtx.fillStyle=color;ovCtx.strokeStyle='rgba(0,0,0,0.5)';ovCtx.lineWidth=1.5;
        ovCtx.beginPath();ovCtx.arc(px,py,7,0,Math.PI*2);ovCtx.fill();ovCtx.stroke();
        ovCtx.restore();
      }
      ovCtx.restore();
    }
  }

  function _ovHandle1d(ctx,x,y,color){
    ctx.save();ctx.fillStyle=color;ctx.strokeStyle='rgba(0,0,0,0.45)';ctx.lineWidth=1.5;
    ctx.beginPath();ctx.arc(x,y,5,0,Math.PI*2);ctx.fill();ctx.stroke();ctx.restore();
  }

  function drawMarkers1d(p, hoverState) {
    const st=p.state; if(!st) return;
    const {pw,ph,mkCtx} = p;
    const r=_plotRect1d(pw,ph);
    // Use cached decoded arrays from draw1d; fall back to inline decode if needed.
    const xArr = p._1dXArr || (st.x_axis_b64 ? _decodeF64(st.x_axis_b64) : (st.x_axis||[]));
    const yData = p._1dDArr || (st.data_b64 ? _decodeF64(st.data_b64) : (st.data||[]));
    const x0=st.view_x0||0, x1=st.view_x1||1;
    let dMin=st.data_min, dMax=st.data_max;
    if (st.y_range && st.y_range.length === 2) { dMin = st.y_range[0]; dMax = st.y_range[1]; }
    mkCtx.clearRect(0,0,pw,ph);
    const sets=st.markers||[];
    if(!sets.length) return;
    const hsi = hoverState ? hoverState.si : -1;

    mkCtx.save();mkCtx.beginPath();mkCtx.rect(r.x,r.y,r.w,r.h);mkCtx.clip();

    function _offToCanvas(off){
      const xFrac=xArr.length>=2?_xToFrac1d(xArr,off[0]):(off[0]/((xArr.length-1)||1));
      const px=_fracToPx1d(xFrac,x0,x1,r);
      let py;
      if(off.length>=2&&off[1]!=null){py=_valToPy1d(off[1],dMin,dMax,r);}
      else if(yData.length>1){const idx=Math.max(0,Math.min(yData.length-1,Math.round(xFrac*(yData.length-1))));py=_valToPy1d(yData[idx],dMin,dMax,r);}
      else{py=_valToPy1d(0,dMin,dMax,r);}
      return[px,py];
    }
    function _xPx(v){return _fracToPx1d(xArr.length>=2?_xToFrac1d(xArr,v):0,x0,x1,r);}
    function _yPx(v){return _valToPy1d(v,dMin,dMax,r);}

    for(let si=0;si<sets.length;si++){
      const ms=sets[si];
      const isHov=si===hsi;
      const color=ms.color||'#ff0000', lw=ms.linewidth!=null?ms.linewidth:1.5;
      const type=ms.type||'points';
      const fc=ms.fill_color||null, fa=ms.fill_alpha!=null?ms.fill_alpha:0.3;
      // Hover colours: only applied when explicitly set — no default fallback.
      const ec  = isHov && ms.hover_color     ? ms.hover_color     : color;
      const fch = isHov && ms.hover_facecolor ? ms.hover_facecolor : fc;
      const dlw = isHov && (ms.hover_color || ms.hover_facecolor) ? lw+1 : lw;

      // Coordinate transform: "axes" and "display" map 2-D offsets to panel
      // space independently of data values; vlines/hlines stay in data coords.
      const tfm = ms.transform || 'data';
      let _tc2d;
      if(tfm==='axes'){
        _tc2d=(fx,fy)=>[r.x+fx*r.w, r.y+(1-fy)*r.h];
      } else if(tfm==='display'){
        _tc2d=(ix,iy)=>[ix,iy];
      } else {
        _tc2d=(off0,off1)=>_offToCanvas([off0,off1]);
      }

      mkCtx.save();mkCtx.strokeStyle=ec;mkCtx.fillStyle=ec;mkCtx.lineWidth=dlw;

      if(type==='points'){
        for(let i=0;i<ms.offsets.length;i++){
          const [px,py]= tfm==='data' ? _offToCanvas(ms.offsets[i]) : _tc2d(ms.offsets[i][0],ms.offsets[i][1]!=null?ms.offsets[i][1]:0);
          const sz=Math.max(1,ms.sizes[i]!=null?ms.sizes[i]:ms.sizes[0]||5);
          mkCtx.beginPath();mkCtx.arc(px,py,sz,0,Math.PI*2);
          if(fch){mkCtx.save();mkCtx.globalAlpha=fa;mkCtx.fillStyle=fch;mkCtx.fill();mkCtx.restore();}
          mkCtx.stroke();
        }
      } else if(type==='vlines'){
        for(let i=0;i<ms.offsets.length;i++){
          const px=_xPx(ms.offsets[i][0]);
          mkCtx.beginPath();mkCtx.moveTo(px,r.y);mkCtx.lineTo(px,r.y+r.h);mkCtx.stroke();
        }
      } else if(type==='hlines'){
        for(let i=0;i<ms.offsets.length;i++){
          const py=_yPx(ms.offsets[i][0]);
          mkCtx.beginPath();mkCtx.moveTo(r.x,py);mkCtx.lineTo(r.x+r.w,py);mkCtx.stroke();
        }
      } else if(type==='lines'){
        for(const seg of (ms.segments||[])){
          const [x1c,y1c]= tfm==='data' ? _offToCanvas(seg[0]) : _tc2d(seg[0][0],seg[0][1]);
          const [x2c,y2c]= tfm==='data' ? _offToCanvas(seg[1]) : _tc2d(seg[1][0],seg[1][1]);
          mkCtx.beginPath();mkCtx.moveTo(x1c,y1c);mkCtx.lineTo(x2c,y2c);mkCtx.stroke();
        }
      } else if(type==='ellipses'){
        for(let i=0;i<ms.offsets.length;i++){
          const off=ms.offsets[i];
          const [cx,cy]= tfm==='data' ? _offToCanvas(off) : _tc2d(off[0],off[1]!=null?off[1]:0);
          const wd=ms.widths[i]!=null?ms.widths[i]:(ms.widths[0]||10);
          const hd=ms.heights[i]!=null?ms.heights[i]:(ms.heights[0]||10);
          const rw=Math.max(1, tfm==='data' ? Math.abs(_xPx(off[0]+wd/2)-_xPx(off[0]-wd/2))/2 : wd/2);
          const rh=Math.max(1, tfm==='data' ? Math.abs(_yPx((off[1]||0)-hd/2)-_yPx((off[1]||0)+hd/2))/2 : hd/2);
          const ang=((ms.angles&&(ms.angles[i]!=null?ms.angles[i]:ms.angles[0])||0)*Math.PI)/180;
          mkCtx.beginPath();mkCtx.ellipse(cx,cy,rw,rh,ang,0,Math.PI*2);
          if(fch){mkCtx.save();mkCtx.globalAlpha=fa;mkCtx.fillStyle=fch;mkCtx.fill();mkCtx.restore();}
          mkCtx.stroke();
        }
      } else if(type==='rectangles'||type==='squares'){
        const heights=type==='squares'?ms.widths:ms.heights;
        for(let i=0;i<ms.offsets.length;i++){
          const off=ms.offsets[i];
          const [cx,cy]= tfm==='data' ? _offToCanvas(off) : _tc2d(off[0],off[1]!=null?off[1]:0);
          const wd=ms.widths[i]!=null?ms.widths[i]:(ms.widths[0]||10);
          const hd=heights[i]!=null?heights[i]:(heights[0]||10);
          const rw=Math.max(1, tfm==='data' ? Math.abs(_xPx(off[0]+wd/2)-_xPx(off[0]-wd/2)) : wd);
          const rh=Math.max(1, tfm==='data' ? Math.abs(_yPx((off[1]||0)-hd/2)-_yPx((off[1]||0)+hd/2)) : hd);
          const ang=((ms.angles&&(ms.angles[i]!=null?ms.angles[i]:ms.angles[0])||0)*Math.PI)/180;
          mkCtx.save();mkCtx.translate(cx,cy);mkCtx.rotate(ang);
          if(fch){mkCtx.save();mkCtx.globalAlpha=fa;mkCtx.fillStyle=fch;mkCtx.fillRect(-rw/2,-rh/2,rw,rh);mkCtx.restore();}
          mkCtx.strokeRect(-rw/2,-rh/2,rw,rh);
          mkCtx.restore();
        }
      } else if(type==='polygons'){
        for(let i=0;i<(ms.vertices_list||[]).length;i++){
          const verts=ms.vertices_list[i];
          if(!verts||verts.length<2) continue;
          const [px0,py0]= tfm==='data' ? _offToCanvas(verts[0]) : _tc2d(verts[0][0],verts[0][1]);
          mkCtx.beginPath();mkCtx.moveTo(px0,py0);
          for(let k=1;k<verts.length;k++){
            const[px,py]= tfm==='data' ? _offToCanvas(verts[k]) : _tc2d(verts[k][0],verts[k][1]);
            mkCtx.lineTo(px,py);
          }
          mkCtx.closePath();
          if(fch){mkCtx.save();mkCtx.globalAlpha=fa;mkCtx.fillStyle=fch;mkCtx.fill();mkCtx.restore();}
          mkCtx.stroke();
        }
      } else if(type==='arrows'){
        const HL=8;
        for(let i=0;i<ms.offsets.length;i++){
          const off=ms.offsets[i];
          const [x1a,y1a]= tfm==='data' ? _offToCanvas(off) : _tc2d(off[0],off[1]!=null?off[1]:0);
          const u=ms.U[i]||0, v=ms.V[i]||0;
          const x2a= tfm==='data' ? _xPx(off[0]+u) : x1a+u;
          const y2a= tfm==='data' ? _yPx((off[1]||0)+v) : y1a+v;
          const ang=Math.atan2(y2a-y1a,x2a-x1a);
          mkCtx.beginPath();mkCtx.moveTo(x1a,y1a);mkCtx.lineTo(x2a,y2a);mkCtx.stroke();
          mkCtx.beginPath();mkCtx.moveTo(x2a,y2a);
          mkCtx.lineTo(x2a-HL*Math.cos(ang-Math.PI/6),y2a-HL*Math.sin(ang-Math.PI/6));
          mkCtx.lineTo(x2a-HL*Math.cos(ang+Math.PI/6),y2a-HL*Math.sin(ang+Math.PI/6));
          mkCtx.closePath();mkCtx.fill();
        }
      } else if(type==='texts'){
        const fs=ms.fontsize||12;
        mkCtx.font=`${fs}px sans-serif`;mkCtx.textAlign='left';mkCtx.textBaseline='top';
        for(let i=0;i<ms.offsets.length;i++){
          const [px,py]= tfm==='data' ? _offToCanvas(ms.offsets[i]) : _tc2d(ms.offsets[i][0],ms.offsets[i][1]!=null?ms.offsets[i][1]:0);
          mkCtx.fillText(String((ms.texts&&ms.texts[i])||''),px,py);
        }
      }
      mkCtx.restore();
    }
    mkCtx.restore();
  }

  // Returns {lineId, canvasPx, canvasPy, x, y} for the line closest to (mx,my),
  // or null if nothing is within HIT px.
  // lineId: null = primary line, string = extra-line id.
  function _lineHitTest1d(mx, my, p) {
    const st = p.state; if (!st) return null;
    const r = _plotRect1d(p.pw, p.ph);
    if (mx < r.x || mx > r.x+r.w || my < r.y || my > r.y+r.h) return null;
    const xArr = p._1dXArr || (st.x_axis_b64 ? _decodeF64(st.x_axis_b64) : (st.x_axis||[]));
    const x0 = st.view_x0||0, x1 = st.view_x1||1;
    const dMin = st.data_min, dMax = st.data_max;
    const HIT = 6;

    function _nearestOnLine(yData, lineXArr, lineId) {
      if (!yData || yData.length < 2) return null;
      const n = yData.length;
      const span = lineXArr.length >= 2 ? (lineXArr[lineXArr.length-1] - lineXArr[0]) || 1 : (n-1)||1;
      let bestDist = HIT + 1, bx = null, by = null;
      for (let i = 0; i < n - 1; i++) {
        const f0 = lineXArr.length >= 2 ? (lineXArr[i]   - lineXArr[0]) / span : i   / ((n-1)||1);
        const f1 = lineXArr.length >= 2 ? (lineXArr[i+1] - lineXArr[0]) / span : (i+1) / ((n-1)||1);
        const px0 = _fracToPx1d(f0, x0, x1, r), py0 = _valToPy1d(yData[i],   dMin, dMax, r);
        const px1 = _fracToPx1d(f1, x0, x1, r), py1 = _valToPy1d(yData[i+1], dMin, dMax, r);
        const dx = px1-px0, dy = py1-py0, lenSq = dx*dx+dy*dy;
        const t  = lenSq > 0 ? Math.max(0, Math.min(1, ((mx-px0)*dx+(my-py0)*dy)/lenSq)) : 0;
        const nx = px0+t*dx, ny = py0+t*dy;
        const d  = Math.hypot(mx-nx, my-ny);
        if (d < bestDist) { bestDist = d; bx = nx; by = ny; }
      }
      if (bx === null) return null;
      // Convert canvas best-point back to data coords
      const frac = _canvasXToFrac1d(bx, x0, x1, r);
      const physX = lineXArr.length >= 2 ? _fracToX1d(lineXArr, frac) : frac;
      const physY = dMin + (r.y + r.h - by) / (r.h||1) * (dMax - dMin);
      return { lineId, canvasPx: bx, canvasPy: by, x: physX, y: physY };
    }

    // Check extra lines first (drawn on top), then primary
    for (let i = (st.extra_lines||[]).length - 1; i >= 0; i--) {
      const ex = st.extra_lines[i];
      const exY = ex.data_b64   ? _decodeF64(ex.data_b64)   : (ex.data   || []);
      const exX = ex.x_axis_b64 ? _decodeF64(ex.x_axis_b64) : (ex.x_axis ? ex.x_axis : xArr);
      const hit = _nearestOnLine(exY, exX, ex.id);
      if (hit) return hit;
    }
    const primY = p._1dDArr || (st.data_b64 ? _decodeF64(st.data_b64) : (st.data||[]));
    return _nearestOnLine(primY, xArr, null);
  }

  // ── marker hit-test helpers ────────────────────────────────────────────────
  const MARKER_HIT = 8;

  // Returns {si, i, collectionLabel, markerLabel} or null.
  // si/i identify the set/marker for hover; labels are for tooltips (null if unset).
  function _markerHitTest2d(mx, my, st, pw, ph) {
    const sets = st.markers || [];
    const scale = _imgScale2d(st, pw, ph);
    for (let si = sets.length-1; si >= 0; si--) {
      const ms = sets[si];
      const type = ms.type || 'circles';
      const collLabel = ms.label != null ? String(ms.label) : null;
      const perLabels = Array.isArray(ms.labels) ? ms.labels : null;
      if (type === 'circles') {
        for (let i=0;i<(ms.offsets||[]).length;i++) {
          const [cx,cy]=_imgToCanvas2d(ms.offsets[i][0],ms.offsets[i][1],st,pw,ph);
          const r=Math.max(1,(ms.sizes[i]!=null?ms.sizes[i]:ms.sizes[0]||5)*scale);
          if(Math.sqrt((mx-cx)**2+(my-cy)**2)<=r+MARKER_HIT)
            return{si,i,collectionLabel:collLabel,markerLabel:perLabels?String(perLabels[i]??''):null};
        }
      } else if (type === 'ellipses') {
        for (let i=0;i<(ms.offsets||[]).length;i++) {
          const [cx,cy]=_imgToCanvas2d(ms.offsets[i][0],ms.offsets[i][1],st,pw,ph);
          const rw=(ms.widths[i]||ms.widths[0]||10)*scale/2+MARKER_HIT;
          const rh=(ms.heights[i]||ms.heights[0]||10)*scale/2+MARKER_HIT;
          const dx=(mx-cx)/Math.max(1,rw), dy=(my-cy)/Math.max(1,rh);
          if(dx*dx+dy*dy<=1.0)
            return{si,i,collectionLabel:collLabel,markerLabel:perLabels?String(perLabels[i]??''):null};
        }
      } else if (type === 'rectangles' || type === 'squares') {
        const heights = type==='squares' ? ms.widths : ms.heights;
        for (let i=0;i<(ms.offsets||[]).length;i++) {
          const [cx,cy]=_imgToCanvas2d(ms.offsets[i][0],ms.offsets[i][1],st,pw,ph);
          const hw=(ms.widths[i]||ms.widths[0]||20)*scale/2+MARKER_HIT;
          const hh=((heights[i]||heights[0]||20))*scale/2+MARKER_HIT;
          if(Math.abs(mx-cx)<=hw&&Math.abs(my-cy)<=hh)
            return{si,i,collectionLabel:collLabel,markerLabel:perLabels?String(perLabels[i]??''):null};
        }
      } else if (type === 'arrows') {
        for (let i=0;i<(ms.offsets||[]).length;i++) {
          const [x1,y1]=_imgToCanvas2d(ms.offsets[i][0],ms.offsets[i][1],st,pw,ph);
          const mx2=x1+(ms.U[i]||0)*scale/2, my2=y1+(ms.V[i]||0)*scale/2;
          if(Math.sqrt((mx-mx2)**2+(my-my2)**2)<=MARKER_HIT*2)
            return{si,i,collectionLabel:collLabel,markerLabel:perLabels?String(perLabels[i]??''):null};
        }
      } else if (type === 'lines') {
        for (let i=0;i<(ms.segments||[]).length;i++) {
          const seg=ms.segments[i];
          const [x1,y1]=_imgToCanvas2d(seg[0][0],seg[0][1],st,pw,ph);
          const [x2,y2]=_imgToCanvas2d(seg[1][0],seg[1][1],st,pw,ph);
          const dx=x2-x1,dy=y2-y1,len2=dx*dx+dy*dy;
          const t=len2>0?Math.max(0,Math.min(1,((mx-x1)*dx+(my-y1)*dy)/len2)):0;
          if(Math.sqrt((mx-(x1+t*dx))**2+(my-(y1+t*dy))**2)<=MARKER_HIT)
            return{si,i,collectionLabel:collLabel,markerLabel:perLabels?String(perLabels[i]??''):null};
        }
      } else if (type === 'polygons') {
        for (let i=0;i<(ms.vertices_list||[]).length;i++) {
          const verts=ms.vertices_list[i]; if(!verts||!verts.length) continue;
          const [cx,cy]=_imgToCanvas2d(verts[0][0],verts[0][1],st,pw,ph);
          if(Math.sqrt((mx-cx)**2+(my-cy)**2)<=MARKER_HIT*1.5)
            return{si,i,collectionLabel:collLabel,markerLabel:perLabels?String(perLabels[i]??''):null};
        }
      } else if (type === 'texts') {
        for (let i=0;i<(ms.offsets||[]).length;i++) {
          const [cx,cy]=_imgToCanvas2d(ms.offsets[i][0],ms.offsets[i][1],st,pw,ph);
          if(Math.sqrt((mx-cx)**2+(my-cy)**2)<=MARKER_HIT*1.5)
            return{si,i,collectionLabel:collLabel,markerLabel:perLabels?String(perLabels[i]??''):null};
        }
      }
    }
    return null;
  }

  function _markerHitTest1d(mx, my, p) {
    const st=p.state; if(!st) return null;
    const r=_plotRect1d(p.pw,p.ph);
    // Use cached decoded array from draw1d; fall back to inline decode if needed.
    const xArr = p._1dXArr || (st.x_axis_b64 ? _decodeF64(st.x_axis_b64) : (st.x_axis||[]));
    const x0=st.view_x0||0, x1=st.view_x1||1;
    const dMin=st.data_min, dMax=st.data_max;
    const sets=st.markers||[];
    for(let si=sets.length-1;si>=0;si--){
      const ms=sets[si];
      const collLabel=ms.label!=null?String(ms.label):null;
      const perLabels=Array.isArray(ms.labels)?ms.labels:null;
      if(ms.type==='points'){
        for(let i=0;i<(ms.offsets||[]).length;i++){
          const frac=xArr.length>=2?_xToFrac1d(xArr,ms.offsets[i][0]):0;
          const px=_fracToPx1d(frac,x0,x1,r);
          const sz=Math.max(1,ms.sizes[i]!=null?ms.sizes[i]:ms.sizes[0]||5);
          if(Math.sqrt((mx-px)**2+(my-r.y-r.h/2)**2)<=sz+MARKER_HIT)
            return{si,i,collectionLabel:collLabel,markerLabel:perLabels?String(perLabels[i]??''):null};
        }
      } else if(ms.type==='vlines'){
        for(let i=0;i<(ms.offsets||[]).length;i++){
          const px=_fracToPx1d(xArr.length>=2?_xToFrac1d(xArr,ms.offsets[i][0]):0,x0,x1,r);
          if(Math.abs(mx-px)<=MARKER_HIT&&my>=r.y&&my<=r.y+r.h)
            return{si,i,collectionLabel:collLabel,markerLabel:perLabels?String(perLabels[i]??''):null};
        }
      } else if(ms.type==='hlines'){
        for(let i=0;i<(ms.offsets||[]).length;i++){
          const py=_valToPy1d(ms.offsets[i][0],dMin,dMax,r);
          if(Math.abs(my-py)<=MARKER_HIT&&mx>=r.x&&mx<=r.x+r.w)
            return{si,i,collectionLabel:collLabel,markerLabel:perLabels?String(perLabels[i]??''):null};
        }
      } else if(ms.type==='lines'){
        for(let i=0;i<(ms.segments||[]).length;i++){
          const seg=ms.segments[i];
          const xf1=xArr.length>=2?_xToFrac1d(xArr,seg[0][0]):0;
          const xf2=xArr.length>=2?_xToFrac1d(xArr,seg[1][0]):0;
          const x1c=_fracToPx1d(xf1,x0,x1,r),y1c=_valToPy1d(seg[0][1],dMin,dMax,r);
          const x2c=_fracToPx1d(xf2,x0,x1,r),y2c=_valToPy1d(seg[1][1],dMin,dMax,r);
          const dx=x2c-x1c,dy=y2c-y1c,len2=dx*dx+dy*dy;
          const t=len2>0?Math.max(0,Math.min(1,((mx-x1c)*dx+(my-y1c)*dy)/len2)):0;
          if(Math.sqrt((mx-(x1c+t*dx))**2+(my-(y1c+t*dy))**2)<=MARKER_HIT)
            return{si,i,collectionLabel:collLabel,markerLabel:perLabels?String(perLabels[i]??''):null};
        }
      }
    }
    return null;
  }

  // ── panel-level event handlers ───────────────────────────────────────────
  function _attachPanelEvents(p) {
    if (p.kind === '2d')  _attachEvents2d(p);
    else if (p.kind === '3d')  _attachEvents3d(p);
    else if (p.kind === 'bar') _attachEventsBar(p);
    else                       _attachEvents1d(p);
  }

  function _canvasToImg2d(px, py, st, pw, ph) {
    const { x, y, w, h } = _imgFitRect(st.image_width, st.image_height, pw, ph);
    const zoom = st.zoom, cx = st.center_x, cy = st.center_y;
    const iw = st.image_width, ih = st.image_height;
    if (zoom < 1.0) {
      // Zoom-out path: inverse of the centred-shrink in _blit2d.
      const dstW = w * zoom, dstH = h * zoom;
      const dstX = x + (w - dstW) / 2, dstY = y + (h - dstH) / 2;
      return [(px - dstX) / dstW * iw, (py - dstY) / dstH * ih];
    }
    const visW = iw / zoom, visH = ih / zoom;
    const srcX = Math.max(0, Math.min(iw - visW, cx * iw - visW / 2));
    const srcY = Math.max(0, Math.min(ih - visH, cy * ih - visH / 2));
    return [srcX + (px - x) / w * visW, srcY + (py - y) / h * visH];
  }

  function _attachEvents2d(p) {
    const { overlayCanvas } = p;
    let localOnly=false, commitPending=false;
    let _settledTimer = null;
    let _settledStartX = 0, _settledStartY = 0, _settledStartTs = 0;
    function _scheduleCommit(){
      if(commitPending) return; commitPending=true;
      requestAnimationFrame(()=>{commitPending=false;localOnly=true;model.save_changes();setTimeout(()=>{localOnly=false;},200);});
    }

    // Wheel zoom — anchored on the image point under the cursor
    overlayCanvas.addEventListener('wheel',(e)=>{
      e.preventDefault();
      const st=p.state; if(!st) return;
      const imgW=p.imgW||Math.max(1,p.pw-PAD_L-PAD_R), imgH=p.imgH||Math.max(1,p.ph-PAD_T-PAD_B);
      const {mx,my}=_clientPos(e,overlayCanvas,imgW,imgH);
      // Image point under cursor before zoom change
      const [anchorX,anchorY]=_canvasToImg2d(mx,my,st,imgW,imgH);
      const curZ=st.zoom, newZ=Math.max(0.75,Math.min(100,curZ*(e.deltaY>0?0.9:1.1)));
      st.zoom=newZ;
      // Reposition center so the same image point stays under the cursor
      const iw=st.image_width, ih=st.image_height;
      const fr=_imgFitRect(iw,ih,imgW,imgH);
      const newVisW=iw/newZ, newVisH=ih/newZ;
      const newSrcX=anchorX-(mx-fr.x)/fr.w*newVisW;
      const newSrcY=anchorY-(my-fr.y)/fr.h*newVisH;
      st.center_x=Math.max(0,Math.min(1,(newSrcX+newVisW/2)/iw));
      st.center_y=Math.max(0,Math.min(1,(newSrcY+newVisH/2)/ih));
      draw2d(p);
      _propagateZoom2d(p);
      model.set(`panel_${p.id}_json`, JSON.stringify(p.state));
      _scheduleCommit();
    },{passive:false});

    // Pan + widget drag
    let panStart={};
    overlayCanvas.addEventListener('mousedown',(e)=>{
      if(e.button!==0) return;
      const st=p.state; if(!st) return;
      overlayCanvas.focus();
      const imgW=p.imgW||Math.max(1,p.pw-PAD_L-PAD_R), imgH=p.imgH||Math.max(1,p.ph-PAD_T-PAD_B);
      const {mx,my}=_clientPos(e,overlayCanvas,imgW,imgH);
      const hit=_ovHitTest2d(mx, my, p);
      if(hit){
        p.ovDrag2d=hit;
        p.lastWidgetId=(st.overlay_widgets||[])[hit.idx]?.id||null;
        overlayCanvas.style.cursor='move';
        e.preventDefault(); return;
      }
      // Store pan start in canvas-pixel coords so the drag delta is also
      // in canvas-pixel space and matches fr.w/fr.h (both canvas-pixel).
      panStart={mx,my,cx:st.center_x,cy:st.center_y};
      // Track potential click: distance + time guards distinguish click from pan.
      p.clickCandidate={mx,my,t:Date.now(),shiftKey:e.shiftKey};
      p.isPanning=true; overlayCanvas.style.cursor='grabbing';
      // Do NOT call e.preventDefault() here: Chrome suppresses the click event
      // when mousedown is cancelled, which in turn prevents dblclick from firing.
      // Panning's preventDefault lives in the mousemove handler (prevents scroll).
    });
    document.addEventListener('mousemove',(e)=>{
      if(p.ovDrag2d){
        _doDrag2d(e,p);
        const _dw=(p.state.overlay_widgets||[])[p.ovDrag2d.idx]||{};
        _emitEvent(p.id,'pointer_move',_dw.id||null,{..._dw,..._pointerFields(e)});
        return;
      }
      if(!p.isPanning) return;
      const st=p.state; if(!st) return;
      const imgW=p.imgW||Math.max(1,p.pw-PAD_L-PAD_R), imgH=p.imgH||Math.max(1,p.ph-PAD_T-PAD_B);
      const fr=_imgFitRect(st.image_width,st.image_height,imgW,imgH);
      const z=st.zoom;
      const {mx:cmx,my:cmy}=_clientPos(e,overlayCanvas,imgW,imgH);
      // Invalidate click candidate once the cursor has clearly moved (>4 px).
      if(p.clickCandidate){const _dx=cmx-p.clickCandidate.mx,_dy=cmy-p.clickCandidate.my;if(_dx*_dx+_dy*_dy>16)p.clickCandidate=null;}
      localOnly=true;
      st.center_x=Math.max(0,Math.min(1,panStart.cx-(cmx-panStart.mx)/fr.w/z));
      st.center_y=Math.max(0,Math.min(1,panStart.cy-(cmy-panStart.my)/fr.h/z));
      draw2d(p);
      _propagateZoom2d(p);
      model.set(`panel_${p.id}_json`, JSON.stringify(p.state));
      _scheduleCommit(); e.preventDefault();
    });
    document.addEventListener('mouseup',(e)=>{
      clearTimeout(_settledTimer); _settledTimer = null;
      if(p.ovDrag2d){
        const _idx=p.ovDrag2d.idx;
        const _dw=(p.state.overlay_widgets||[])[_idx]||{};
        const _did=_dw.id||null;
        p.ovDrag2d=null; overlayCanvas.style.cursor='default';
        model.set(`panel_${p.id}_json`, JSON.stringify(p.state));
        _emitEvent(p.id,'pointer_up',_did,{..._dw,..._pointerFields(e),button:e.button});
        return;
      }
      if(!p.isPanning) return;
      p.isPanning=false; overlayCanvas.style.cursor='default';
      const st=p.state; if(!st) return;
      const imgW=p.imgW||Math.max(1,p.pw-PAD_L-PAD_R), imgH=p.imgH||Math.max(1,p.ph-PAD_T-PAD_B);
      const fr=_imgFitRect(st.image_width,st.image_height,imgW,imgH);
      const {mx:cmx,my:cmy}=_clientPos(e,overlayCanvas,imgW,imgH);
      // ── Click detection: short-duration + small-movement mousedown/up ────────
      // Criteria: candidate still alive (not cleared by mousemove) AND ≤300 ms.
      // We also re-check final distance as a safety net for document-level moves
      // that didn't fire our mousemove guard (e.g. rapid trackpad flicks).
      if(p.clickCandidate){
        const _cc=p.clickCandidate; p.clickCandidate=null;
        const _dx=cmx-_cc.mx, _dy=cmy-_cc.my;
        const _dist2=_dx*_dx+_dy*_dy;
        const _dt=Date.now()-_cc.t;
        if(_dist2<=25&&_dt<=350){
          // Genuine click — skip pan-settle, emit pointer_down with image coords.
          const [imgX,imgY]=_canvasToImg2d(_cc.mx,_cc.my,st,imgW,imgH);
          const xArr=st.x_axis||[], yArr=st.y_axis||[];
          const _iw=st.image_width||1, _ih=st.image_height||1;
          const physX=xArr.length>=2?_axisFracToVal(xArr,imgX/_iw):imgX;
          const physY=yArr.length>=2?_axisFracToVal(yArr,imgY/_ih):imgY;
          _emitEvent(p.id,'pointer_down',null,{
            img_x:imgX, img_y:imgY,
            xdata:physX, ydata:physY,
            x:_cc.mx, y:_cc.my,
            ..._pointerFields(e),
            button:e.button,
          });
          // _emitEvent already calls model.save_changes() — no duplicate needed.
          return;
        }
      }
      // ── Normal pan settle ───────────────────────────────────────────────────
      st.center_x=Math.max(0,Math.min(1,panStart.cx-(cmx-panStart.mx)/fr.w/st.zoom));
      st.center_y=Math.max(0,Math.min(1,panStart.cy-(cmy-panStart.my)/fr.h/st.zoom));
      model.set(`panel_${p.id}_json`, JSON.stringify(p.state));
      _emitEvent(p.id,'pointer_up',null,{center_x:st.center_x,center_y:st.center_y,zoom:st.zoom,..._pointerFields(e),button:e.button});
      model.save_changes();
    });

    // Status bar + tooltip + widget hover cursor
    overlayCanvas.addEventListener('mousemove',(e)=>{
      const imgW=p.imgW||Math.max(1,p.pw-PAD_L-PAD_R), imgH=p.imgH||Math.max(1,p.ph-PAD_T-PAD_B);
      const {mx,my}=_clientPos(e,overlayCanvas,imgW,imgH);
      p.mouseX=mx; p.mouseY=my;
      if(p.ovDrag2d) return; // handled by document mousemove
      const st=p.state; if(!st) return;

      // Update cursor based on widget hit
      const whit=_ovHitTest2d(mx, my, p);
      if(whit){
        const m=whit.mode;
        overlayCanvas.style.cursor = m==='move' ? 'move'
          : (m==='resize_br'||m==='resize_tl') ? 'nwse-resize'
          : (m==='resize_bl'||m==='resize_tr') ? 'nesw-resize'
          : (m==='resize_r'||m==='resize_ir')  ? 'ew-resize'
          : m.startsWith('vertex_')            ? 'crosshair'
          : 'move';
      } else if(!p.isPanning){
        overlayCanvas.style.cursor='default';
      }

      const [ix,iy]=_canvasToImg2d(mx,my,st,imgW,imgH);
      if(ix>=0&&ix<st.image_width&&iy>=0&&iy<st.image_height){
        const xArr=st.x_axis||[], yArr=st.y_axis||[];
        const iw=st.image_width, ih=st.image_height;
        // For both imshow (centre arrays) and pcolormesh (edge arrays),
        // ix/iw maps the pixel fraction into the axis array via binary search.
        const physX=xArr.length>=2?_axisFracToVal(xArr,ix/iw):ix;
        const physY=yArr.length>=2?_axisFracToVal(yArr,iy/ih):iy;
        const units=st.units||'px';
        const showPhys=xArr.length>=2||yArr.length>=2;
        p.statusBar.textContent = showPhys
          ? `x:${fmtVal(physX)} y:${fmtVal(physY)}${units?' '+units:''}  [${Math.floor(ix)}, ${Math.floor(iy)}]`
          : `x:${Math.floor(ix)}  y:${Math.floor(iy)}`;
        p.statusBar.style.display='block';
        const mhit=_markerHitTest2d(mx,my,st,imgW,imgH);
        const newSi=mhit?mhit.si:-1;
        if(newSi!==p._hoverSi){
          p._hoverSi=newSi; p._hoverI=mhit?mhit.i:-1;
          drawMarkers2d(p, mhit?{si:newSi}:null);
        }
        if(mhit&&(mhit.collectionLabel||mhit.markerLabel)){const parts=[];if(mhit.collectionLabel)parts.push(mhit.collectionLabel);if(mhit.markerLabel)parts.push(mhit.markerLabel);_showTooltip(parts.join('\n'),e.clientX,e.clientY);clearTimeout(_settledTimer); _settledTimer = null;return;}
        tooltip.style.display='none';
      } else { p.statusBar.style.display='none'; tooltip.style.display='none';
        if(p._hoverSi!==-1){p._hoverSi=-1;p._hoverI=-1;drawMarkers2d(p,null);}
      }
      // pointer_settled dwell timer (zero-cost when pointer_settled_ms === 0)
      const _settledMs = (p.state.pointer_settled_ms ?? 0);
      if (_settledMs > 0) {
        const _settledDelta = p.state.pointer_settled_delta ?? 4;
        clearTimeout(_settledTimer);
        _settledStartX = mx;
        _settledStartY = my;
        _settledStartTs = performance.now();
        const _settledMods = _modifiers(e);  // capture at arm time — e is the mousemove event
        _settledTimer = setTimeout(() => {
          const dist = Math.hypot(p.mouseX - _settledStartX, p.mouseY - _settledStartY);
          if (dist <= _settledDelta) {
            const _now = performance.now();
            const st2 = p.state; if (!st2) return;
            const imgW2 = p.imgW || Math.max(1, p.pw - PAD_L - PAD_R);
            const imgH2 = p.imgH || Math.max(1, p.ph - PAD_T - PAD_B);
            const [sImgX, sImgY] = _canvasToImg2d(p.mouseX, p.mouseY, st2, imgW2, imgH2);
            const sXArr = st2.x_axis || [], sYArr = st2.y_axis || [];
            const _siw = st2.image_width || 1, _sih = st2.image_height || 1;
            const sPhysX = sXArr.length >= 2 ? _axisFracToVal(sXArr, sImgX / _siw) : sImgX;
            const sPhysY = sYArr.length >= 2 ? _axisFracToVal(sYArr, sImgY / _sih) : sImgY;
            _emitEvent(p.id, 'pointer_settled', null, {
              time_stamp: _now / 1000,
              modifiers:  _settledMods,
              button:     null,
              buttons:    0,
              x:          Math.round(p.mouseX),
              y:          Math.round(p.mouseY),
              img_x:      sImgX,
              img_y:      sImgY,
              xdata:      sPhysX,
              ydata:      sPhysY,
              dwell_ms:   _now - _settledStartTs,
            });
          }
        }, _settledMs);
      }
    });
    overlayCanvas.addEventListener('mouseleave',(e)=>{
      clearTimeout(_settledTimer); _settledTimer = null;
      _emitEvent(p.id,'pointer_leave',null,{..._pointerFields(e),x:e.offsetX,y:e.offsetY});
      p.statusBar.style.display='none';tooltip.style.display='none';
      if(p._hoverSi!==-1){p._hoverSi=-1;p._hoverI=-1;drawMarkers2d(p,null);}
    });
    overlayCanvas.addEventListener('dblclick',(e)=>{
      const st=p.state; if(!st) return;
      const imgW=p.imgW||Math.max(1,p.pw-PAD_L-PAD_R), imgH=p.imgH||Math.max(1,p.ph-PAD_T-PAD_B);
      const {mx,my}=_clientPos(e,overlayCanvas,imgW,imgH);
      const [imgX,imgY]=_canvasToImg2d(mx,my,st,imgW,imgH);
      const xArr=st.x_axis||[], yArr=st.y_axis||[];
      const _iw=st.image_width||1, _ih=st.image_height||1;
      const physX=xArr.length>=2?_axisFracToVal(xArr,imgX/_iw):imgX;
      const physY=yArr.length>=2?_axisFracToVal(yArr,imgY/_ih):imgY;
      _emitEvent(p.id,'double_click',null,{..._pointerFields(e),button:e.button,x:mx,y:my,img_x:imgX,img_y:imgY,xdata:physX,ydata:physY});
    });
    overlayCanvas.addEventListener('wheel',(e)=>{
      _emitEvent(p.id,'wheel',null,{
        time_stamp:performance.now()/1000,
        modifiers:_modifiers(e),
        x:p.mouseX??0, y:p.mouseY??0,
        dx:e.deltaX, dy:e.deltaY,
      });
    },{passive:true});

    // Keyboard shortcuts
    // Built-ins: r=reset zoom, c=colorbar toggle, l=log scale, s=symlog scale.
    // All keys are forwarded to Python unconditionally.
    overlayCanvas.addEventListener('keydown',(e)=>{
      const st=p.state; if(!st) return;
      const imgW=p.imgW||Math.max(1,p.pw-PAD_L-PAD_R), imgH=p.imgH||Math.max(1,p.ph-PAD_T-PAD_B);
      const [imgX,imgY]=_canvasToImg2d(p.mouseX,p.mouseY,st,imgW,imgH);
      const xArr=st.x_axis||[], yArr=st.y_axis||[];
      const iw=st.image_width||1, ih=st.image_height||1;
      const physX=xArr.length>=2?_axisFracToVal(xArr,imgX/iw):imgX;
      const physY=yArr.length>=2?_axisFracToVal(yArr,imgY/ih):imgY;
      _emitEvent(p.id,'key_down',null,{
        time_stamp:performance.now()/1000,
        modifiers:_modifiers(e),
        key:e.key,
        last_widget_id:p.lastWidgetId||null,
        x:p.mouseX ?? 0, y:p.mouseY ?? 0,
        img_x:imgX, img_y:imgY,
        xdata:physX, ydata:physY,
      });
      const key=e.key.toLowerCase();
      if(key==='r'){
        st.zoom=1; st.center_x=0.5; st.center_y=0.5;
        draw2d(p); model.set(`panel_${p.id}_json`,JSON.stringify(st)); model.save_changes();
        e.stopPropagation(); e.preventDefault();
      } else if(key==='c'){
        st.show_colorbar=!st.show_colorbar;
        draw2d(p);
        model.set(`panel_${p.id}_json`,JSON.stringify(st)); model.save_changes();
        e.stopPropagation(); e.preventDefault();
      } else if(key==='l'){
        st.scale_mode=st.scale_mode==='log'?'linear':'log';
        draw2d(p); model.set(`panel_${p.id}_json`,JSON.stringify(st)); model.save_changes();
        e.stopPropagation(); e.preventDefault();
      } else if(key==='s'){
        st.scale_mode=st.scale_mode==='symlog'?'linear':'symlog';
        draw2d(p); model.set(`panel_${p.id}_json`,JSON.stringify(st)); model.save_changes();
        e.stopPropagation(); e.preventDefault();
      }
    });
    overlayCanvas.addEventListener('keyup',(e)=>{
      _emitEvent(p.id,'key_up',null,{
        time_stamp:performance.now()/1000,
        modifiers:_modifiers(e),
        key:e.key,
        x:p.mouseX??0, y:p.mouseY??0,
      });
    });
    overlayCanvas.addEventListener('mouseenter',(e)=>{
      overlayCanvas.focus();
      _emitEvent(p.id,'pointer_enter',null,{..._pointerFields(e),x:e.offsetX,y:e.offsetY});
    });
  }

  function _attachEvents1d(p) {
    const { overlayCanvas } = p;
    let localOnly=false, commitPending=false;
    let _settledTimer = null;
    let _settledStartX = 0, _settledStartY = 0, _settledStartTs = 0;
    function _scheduleCommit(){
      if(commitPending) return; commitPending=true;
      requestAnimationFrame(()=>{commitPending=false;localOnly=true;model.save_changes();setTimeout(()=>{localOnly=false;},200);});
    }

    // Wheel zoom
    overlayCanvas.addEventListener('wheel',(e)=>{
      e.preventDefault();
      const st=p.state; if(!st) return;
      const r=_plotRect1d(p.pw,p.ph);
      const {mx}=_clientPos(e,overlayCanvas,p.pw,p.ph);
      const frac=_canvasXToFrac1d(mx,st.view_x0,st.view_x1,r);
      const x0=st.view_x0, x1=st.view_x1, span=x1-x0;
      const factor=e.deltaY>0?1.15:0.87;
      let ns=Math.min(1,span*factor);
      let nx0=frac-(frac-x0)*(ns/span), nx1=nx0+ns;
      if(nx0<0){nx0=0;nx1=ns;}if(nx1>1){nx1=1;nx0=1-ns;}
      st.view_x0=nx0;st.view_x1=nx1;
      draw1d(p);
      _propagateView1d(p);
      model.set(`panel_${p.id}_json`,JSON.stringify(st));
      _scheduleCommit();
    },{passive:false});

    // Pan
    let panStart={};
    overlayCanvas.addEventListener('mousedown',(e)=>{
      if(e.button!==0) return;
      const st=p.state; if(!st) return;
      // Store raw client coords for the drag-vs-click threshold (visual pixels
      // are fine for that comparison — both endpoints use the same space).
      p._mousedownX=e.clientX; p._mousedownY=e.clientY;
      const {mx:_emx,my:_emy}=_clientPos(e,overlayCanvas,p.pw,p.ph);
      const hit=_ovHitTest1d(_emx, _emy, p);
      if(hit){p.ovDrag=hit;p.lastWidgetId=(p.state.overlay_widgets||[])[hit.idx]?.id||null;overlayCanvas.style.cursor=(hit.mode==='edge0'||hit.mode==='edge1')?'ew-resize':'move';e.preventDefault();return;}
      // Store pan start in canvas-px so pan delta in mousemove is canvas-px.
      panStart={mx:_emx,x0:st.view_x0,x1:st.view_x1};
      p.isPanning=true;overlayCanvas.style.cursor='grabbing';
      // Do NOT call e.preventDefault() — see 2D note: suppresses click → dblclick.
    });
    document.addEventListener('mousemove',(e)=>{
      if(p.ovDrag){
        _doDrag1d(e,p);
        const _dw=(p.state.overlay_widgets||[])[p.ovDrag.idx]||{};
        _emitEvent(p.id,'pointer_move',_dw.id||null,{..._dw,..._pointerFields(e)});
        return;
      }
      if(!p.isPanning) return;
      const st=p.state; if(!st) return;
      const r=_plotRect1d(p.pw,p.ph);
      const {mx:cmx}=_clientPos(e,overlayCanvas,p.pw,p.ph);
      const dx=(cmx-panStart.mx)/(r.w||1);
      const span=panStart.x1-panStart.x0;
      let nx0=panStart.x0-dx*span, nx1=panStart.x1-dx*span;
      if(nx0<0){nx0=0;nx1=span;}if(nx1>1){nx1=1;nx0=1-span;}
      st.view_x0=nx0;st.view_x1=nx1;
      draw1d(p);_propagateView1d(p);
      model.set(`panel_${p.id}_json`,JSON.stringify(st));_scheduleCommit();e.preventDefault();
    });
    document.addEventListener('mouseup',(e)=>{
      clearTimeout(_settledTimer); _settledTimer = null;
      const wasWidgetDragging=!!p.ovDrag;   // capture BEFORE clearing
      const wasDragging=wasWidgetDragging||!!p.isPanning;
      if(p.ovDrag){
        const _idx=p.ovDrag.idx;
        const _dw=(p.state.overlay_widgets||[])[_idx]||{};
        const _did=_dw.id||null;
        p.ovDrag=null; overlayCanvas.style.cursor='crosshair';
        model.set(`panel_${p.id}_json`,JSON.stringify(p.state));
        _emitEvent(p.id,'pointer_up',_did,{..._dw,..._pointerFields(e),button:e.button});
      }
      if(p.isPanning){
        p.isPanning=false; overlayCanvas.style.cursor='crosshair';
        const st=p.state;
        if(st) _emitEvent(p.id,'pointer_up',null,{view_x0:st.view_x0,view_x1:st.view_x1,..._pointerFields(e),button:e.button});
      }
      // Line click: fire when no widget was being dragged and mouse barely moved.
      // NOTE: p.isPanning is always set true on mousedown (pan start), so we
      // deliberately only block on wasWidgetDragging here — the distance
      // threshold below already excludes real pan gestures.
      if(!wasWidgetDragging && p._mousedownX!=null){
        const mdx=e.clientX-p._mousedownX, mdy=e.clientY-p._mousedownY;
        if(Math.hypot(mdx,mdy)<5){
          const {mx,my}=_clientPos(e,overlayCanvas,p.pw,p.ph);
          const lhit=_lineHitTest1d(mx,my,p);
          if(lhit) _emitEvent(p.id,'pointer_down',null,{line_id:lhit.lineId,x:lhit.x,y:lhit.y,..._pointerFields(e),button:e.button});
        }
      }
      p._mousedownX=null;
    });

    // Keyboard shortcuts
    // Built-in: r=reset view. All keys are forwarded to Python unconditionally.
    overlayCanvas.addEventListener('keydown',(e)=>{
      const st=p.state; if(!st) return;
      const r=_plotRect1d(p.pw,p.ph);
      const xArr = p._1dXArr || (st.x_axis_b64 ? _decodeF64(st.x_axis_b64) : (st.x_axis||[]));
      const frac=_canvasXToFrac1d(p.mouseX,st.view_x0,st.view_x1,r);
      const physX=xArr.length>=2?_fracToX1d(xArr,frac):frac;
      _emitEvent(p.id,'key_down',null,{
        time_stamp:performance.now()/1000,
        modifiers:_modifiers(e),
        key:e.key,
        last_widget_id:p.lastWidgetId||null,
        x:p.mouseX ?? 0, y:p.mouseY ?? 0,
        xdata:physX,
      });
      if(e.key.toLowerCase()==='r'){st.view_x0=0;st.view_x1=1;draw1d(p);model.set(`panel_${p.id}_json`,JSON.stringify(st));model.save_changes();e.stopPropagation();e.preventDefault();}
    });
    overlayCanvas.addEventListener('keyup',(e)=>{
      _emitEvent(p.id,'key_up',null,{
        time_stamp:performance.now()/1000,
        modifiers:_modifiers(e),
        key:e.key,
        x:p.mouseX??0, y:p.mouseY??0,
      });
    });
    overlayCanvas.tabIndex=0;overlayCanvas.style.outline='none';
    overlayCanvas.addEventListener('mouseenter',(e)=>{
      overlayCanvas.focus();
      _emitEvent(p.id,'pointer_enter',null,{..._pointerFields(e),x:e.offsetX,y:e.offsetY});
    });
    overlayCanvas.addEventListener('mousemove',(e)=>{
      const st=p.state;if(!st)return;
      const {mx,my}=_clientPos(e,overlayCanvas,p.pw,p.ph);
      p.mouseX=mx; p.mouseY=my;
      const r=_plotRect1d(p.pw,p.ph);
      if(mx<r.x||mx>r.x+r.w||my<r.y||my>r.y+r.h){
        p.statusBar.style.display='none';tooltip.style.display='none';
        if(p._hoverSi!==-1){p._hoverSi=-1;p._hoverI=-1;drawMarkers1d(p,null);}
        clearTimeout(_settledTimer); _settledTimer = null;
        return;
      }
      const xArr = p._1dXArr || (st.x_axis_b64 ? _decodeF64(st.x_axis_b64) : (st.x_axis||[]));
      const frac=_canvasXToFrac1d(mx,st.view_x0,st.view_x1,r);
      const phys=xArr.length>=2?_fracToX1d(xArr,frac):frac;
      p.statusBar.textContent=`x:${fmtVal(phys)}`;p.statusBar.style.display='block';
      const mhit=_markerHitTest1d(mx,my,p);
      const newSi=mhit?mhit.si:-1;
      if(newSi!==p._hoverSi){
        p._hoverSi=newSi; p._hoverI=mhit?mhit.i:-1;
        drawMarkers1d(p, mhit?{si:newSi}:null);
      }
      if(mhit&&(mhit.collectionLabel||mhit.markerLabel)){const parts=[];if(mhit.collectionLabel)parts.push(mhit.collectionLabel);if(mhit.markerLabel)parts.push(mhit.markerLabel);_showTooltip(parts.join('\n'),e.clientX,e.clientY);return;}
      tooltip.style.display='none';
      // Line hover — only when no widget is being dragged
      if(!p.ovDrag){
        const lhit=_lineHitTest1d(mx,my,p);
        const newLid=lhit?lhit.lineId:'__none__';
        if(newLid!==p._lineHoverId){
          p._lineHoverId=newLid;
          draw1d(p);  // redraw so hovered line is brightened
          drawOverlay1d(p);
          overlayCanvas.style.cursor=lhit?'pointer':'crosshair';
          if(lhit){
            p.ovCtx.save();p.ovCtx.fillStyle='rgba(255,255,255,0.9)';
            p.ovCtx.strokeStyle='rgba(0,0,0,0.5)';p.ovCtx.lineWidth=1.5;
            p.ovCtx.beginPath();p.ovCtx.arc(lhit.canvasPx,lhit.canvasPy,4,0,Math.PI*2);
            p.ovCtx.fill();p.ovCtx.stroke();p.ovCtx.restore();
          }
        }
        if(lhit) _emitEvent(p.id,'pointer_move',null,{line_id:lhit.lineId,x:lhit.x,y:lhit.y,..._pointerFields(e)});
      }
      // pointer_settled dwell timer (zero-cost when pointer_settled_ms === 0)
      const _settledMs = (p.state.pointer_settled_ms ?? 0);
      if (_settledMs > 0) {
        const _settledDelta = p.state.pointer_settled_delta ?? 4;
        clearTimeout(_settledTimer);
        _settledStartX = mx;
        _settledStartY = my;
        _settledStartTs = performance.now();
        const _settledMods = _modifiers(e);  // capture at arm time — e is the mousemove event
        _settledTimer = setTimeout(() => {
          const dist = Math.hypot(p.mouseX - _settledStartX, p.mouseY - _settledStartY);
          if (dist <= _settledDelta) {
            const _now = performance.now();
            _emitEvent(p.id, 'pointer_settled', null, {
              time_stamp: _now / 1000,
              modifiers:  _settledMods,
              button:     null,
              buttons:    0,
              x:          Math.round(p.mouseX),
              y:          Math.round(p.mouseY),
              dwell_ms:   _now - _settledStartTs,
            });
          }
        }, _settledMs);
      }
    });
    overlayCanvas.addEventListener('mouseleave',(e)=>{
      clearTimeout(_settledTimer); _settledTimer = null;
      _emitEvent(p.id,'pointer_leave',null,{..._pointerFields(e),x:e.offsetX,y:e.offsetY});
      p.statusBar.style.display='none';tooltip.style.display='none';
      if(p._hoverSi!==-1){p._hoverSi=-1;p._hoverI=-1;drawMarkers1d(p,null);}
      if(p._lineHoverId!=='__none__'){p._lineHoverId='__none__';draw1d(p);drawOverlay1d(p);overlayCanvas.style.cursor='crosshair';}
    });
    overlayCanvas.addEventListener('dblclick',(e)=>{
      const {mx,my}=_clientPos(e,overlayCanvas,p.pw,p.ph);
      const st=p.state;
      let xdata=null;
      if(st){
        const r=_plotRect1d(p.pw,p.ph);
        const xArr=p._1dXArr||(st.x_axis_b64?_decodeF64(st.x_axis_b64):(st.x_axis||[]));
        const frac=_canvasXToFrac1d(mx,st.view_x0,st.view_x1,r);
        xdata=xArr.length>=2?_fracToX1d(xArr,frac):frac;
      }
      _emitEvent(p.id,'double_click',null,{..._pointerFields(e),button:e.button,x:mx,y:my,xdata});
    });
    overlayCanvas.addEventListener('wheel',(e)=>{
      _emitEvent(p.id,'wheel',null,{
        time_stamp:performance.now()/1000,
        modifiers:_modifiers(e),
        x:p.mouseX??0, y:p.mouseY??0,
        dx:e.deltaX, dy:e.deltaY,
      });
    },{passive:true});
  }

  // ── 2D overlay widget hit-test & drag ────────────────────────────────────
  // Returns {idx, mode, snapW, ...} describing which widget and handle was hit.
  // mode values:
  //   'move'       – drag the whole widget body
  //   'resize_r'   – circle/annular outer-radius handle (right)
  //   'resize_ir'  – annular inner-radius handle
  //   'resize_br'  – rectangle bottom-right corner
  //   'resize_bl'  – rectangle bottom-left corner
  //   'resize_tr'  – rectangle top-right corner
  //   'resize_tl'  – rectangle top-left corner
  //   'vertex_N'   – polygon vertex N
  function _ovHitTest2d(mx, my, p) {
    const st = p.state; if (!st) return null;
    const imgW = p.imgW||Math.max(1, p.pw - PAD_L - PAD_R);
    const imgH = p.imgH||Math.max(1, p.ph - PAD_T - PAD_B);
    const widgets = st.overlay_widgets || [];
    const scale   = _imgScale2d(st, imgW, imgH);
    const HR = 9; // handle grab radius (px)

    // iterate top-to-bottom (last drawn = topmost)
    for (let i = widgets.length - 1; i >= 0; i--) {
      const w = widgets[i];
      if(w.visible === false) continue;
      if (w.type === 'circle') {
        const [ccx, ccy] = _imgToCanvas2d(w.cx, w.cy, st, imgW, imgH);
        const cr = w.r * scale;
        // outer radius handle
        if (Math.hypot(mx - (ccx + cr), my - ccy) <= HR)
          return { idx:i, mode:'resize_r', snapW:{...w}, startMX:mx, startMY:my };
        // body (inside ring ± tolerance)
        if (Math.abs(Math.hypot(mx-ccx, my-ccy) - cr) <= Math.max(HR, cr*0.18) ||
            Math.hypot(mx-ccx, my-ccy) <= HR)
          return { idx:i, mode:'move', snapW:{...w}, startMX:mx, startMY:my };

      } else if (w.type === 'annular') {
        const [ccx, ccy] = _imgToCanvas2d(w.cx, w.cy, st, imgW, imgH);
        const ro = w.r_outer * scale, ri = w.r_inner * scale;
        // inner-radius handle (above centre, inside inner ring)
        if (Math.hypot(mx - (ccx + ri), my - (ccy - ri * 0.3)) <= HR)
          return { idx:i, mode:'resize_ir', snapW:{...w}, startMX:mx, startMY:my };
        // outer-radius handle
        if (Math.hypot(mx - (ccx + ro), my - ccy) <= HR)
          return { idx:i, mode:'resize_r', snapW:{...w}, startMX:mx, startMY:my };
        // body (annular band)
        const d = Math.hypot(mx - ccx, my - ccy);
        if (d >= ri - HR && d <= ro + HR)
          return { idx:i, mode:'move', snapW:{...w}, startMX:mx, startMY:my };

      } else if (w.type === 'rectangle') {
        const [rx, ry] = _imgToCanvas2d(w.x, w.y, st, imgW, imgH);
        const rw = w.w * scale, rh = w.h * scale;
        if (Math.hypot(mx-(rx+rw), my-(ry+rh)) <= HR) return { idx:i, mode:'resize_br', snapW:{...w}, startMX:mx, startMY:my };
        if (Math.hypot(mx-rx,      my-(ry+rh)) <= HR) return { idx:i, mode:'resize_bl', snapW:{...w}, startMX:mx, startMY:my };
        if (Math.hypot(mx-(rx+rw), my-ry)      <= HR) return { idx:i, mode:'resize_tr', snapW:{...w}, startMX:mx, startMY:my };
        if (Math.hypot(mx-rx,      my-ry)      <= HR) return { idx:i, mode:'resize_tl', snapW:{...w}, startMX:mx, startMY:my };
        if (mx >= rx-HR && mx <= rx+rw+HR && my >= ry-HR && my <= ry+rh+HR)
          return { idx:i, mode:'move', snapW:{...w}, startMX:mx, startMY:my };

      } else if (w.type === 'crosshair') {
        const [ccx, ccy] = _imgToCanvas2d(w.cx, w.cy, st, imgW, imgH);
        if (Math.hypot(mx-ccx, my-ccy) <= HR + 4)
          return { idx:i, mode:'move', snapW:{...w}, startMX:mx, startMY:my };

      } else if (w.type === 'polygon') {
        const verts = w.vertices || [];
        for (let k = 0; k < verts.length; k++) {
          const [px, py] = _imgToCanvas2d(verts[k][0], verts[k][1], st, imgW, imgH);
          if (Math.hypot(mx-px, my-py) <= HR)
            return { idx:i, mode:`vertex_${k}`, snapW:{...w, vertices: verts.map(v=>[...v])}, startMX:mx, startMY:my };
        }
        // hit inside polygon → move whole polygon
        if (_pointInPolygon2d(mx, my, verts, st, imgW, imgH))
          return { idx:i, mode:'move', snapW:{...w, vertices: verts.map(v=>[...v])}, startMX:mx, startMY:my };

      } else if (w.type === 'label') {
        const [lx, ly] = _imgToCanvas2d(w.x, w.y, st, imgW, imgH);
        if (Math.hypot(mx-lx, my-ly) <= HR + 6)
          return { idx:i, mode:'move', snapW:{...w}, startMX:mx, startMY:my };
      }
    }
    return null;
  }

  function _pointInPolygon2d(mx, my, verts, st, imgW, imgH) {
    let inside = false;
    const cverts = verts.map(v => _imgToCanvas2d(v[0], v[1], st, imgW, imgH));
    for (let i = 0, j = cverts.length-1; i < cverts.length; j = i++) {
      const [xi,yi] = cverts[i], [xj,yj] = cverts[j];
      if (((yi>my)!==(yj>my)) && (mx < (xj-xi)*(my-yi)/(yj-yi)+xi)) inside = !inside;
    }
    return inside;
  }

  function _doDrag2d(e, p) {
    const st = p.state; if (!st) return;
    const imgW = p.imgW||Math.max(1, p.pw - PAD_L - PAD_R);
    const imgH = p.imgH||Math.max(1, p.ph - PAD_T - PAD_B);
    const {mx, my} = _clientPos(e, p.overlayCanvas, imgW, imgH);
    const d     = p.ovDrag2d;
    const s     = d.snapW;
    const w     = st.overlay_widgets[d.idx];
    const scale = _imgScale2d(st, imgW, imgH);

    // Convert current mouse to image coords
    const [imgMX, imgMY] = _canvasToImg2d(mx, my, st, imgW, imgH);
    // delta in image pixels from drag-start
    const [imgSX, imgSY] = _canvasToImg2d(d.startMX, d.startMY, st, imgW, imgH);
    const dix = imgMX - imgSX, diy = imgMY - imgSY;

    if (w.type === 'circle') {
      if (d.mode === 'move') {
        w.cx = s.cx + dix; w.cy = s.cy + diy;
      } else if (d.mode === 'resize_r') {
        // distance from centre in image-px
        const [ccx, ccy] = _imgToCanvas2d(s.cx, s.cy, st, imgW, imgH);
        w.r = Math.max(1, Math.hypot(mx-ccx, my-ccy) / scale);
      }
    } else if (w.type === 'annular') {
      if (d.mode === 'move') {
        w.cx = s.cx + dix; w.cy = s.cy + diy;
      } else if (d.mode === 'resize_r') {
        const [ccx, ccy] = _imgToCanvas2d(s.cx, s.cy, st, imgW, imgH);
        const newR = Math.max(s.r_inner + 1, Math.hypot(mx-ccx, my-ccy) / scale);
        w.r_outer = newR;
      } else if (d.mode === 'resize_ir') {
        const [ccx, ccy] = _imgToCanvas2d(s.cx, s.cy, st, imgW, imgH);
        const newR = Math.max(1, Math.min(s.r_outer - 1, Math.hypot(mx-ccx, my-ccy) / scale));
        w.r_inner = newR;
      }
    } else if (w.type === 'rectangle') {
      if (d.mode === 'move') {
        w.x = s.x + dix; w.y = s.y + diy;
      } else if (d.mode === 'resize_br') {
        w.w = Math.max(1, s.w + dix); w.h = Math.max(1, s.h + diy);
      } else if (d.mode === 'resize_bl') {
        const newW = Math.max(1, s.w - dix);
        w.x = s.x + (s.w - newW); w.w = newW;
        w.h = Math.max(1, s.h + diy);
      } else if (d.mode === 'resize_tr') {
        w.w = Math.max(1, s.w + dix);
        const newH = Math.max(1, s.h - diy);
        w.y = s.y + (s.h - newH); w.h = newH;
      } else if (d.mode === 'resize_tl') {
        const newW = Math.max(1, s.w - dix);
        w.x = s.x + (s.w - newW); w.w = newW;
        const newH = Math.max(1, s.h - diy);
        w.y = s.y + (s.h - newH); w.h = newH;
      }
    } else if (w.type === 'crosshair') {
      w.cx = s.cx + dix; w.cy = s.cy + diy;
    } else if (w.type === 'polygon') {
      if (d.mode === 'move') {
        w.vertices = s.vertices.map(v => [v[0]+dix, v[1]+diy]);
      } else if (d.mode.startsWith('vertex_')) {
        const k = parseInt(d.mode.slice(7));
        w.vertices = s.vertices.map((v,j) => j===k ? [imgMX, imgMY] : [...v]);
      }
    } else if (w.type === 'label') {
      w.x = s.x + dix; w.y = s.y + diy;
    }

    drawOverlay2d(p);
    model.set(`panel_${p.id}_json`, JSON.stringify(st));
    model.save_changes();
    e.preventDefault();
  }

  function _canvasXToFrac1d(px,x0,x1,r){return x0+((px-r.x)/(r.w||1))*(x1-x0);}

  function _ovHitTest1d(mx,my,p){
    const st=p.state;if(!st)return null;
    const r=_plotRect1d(p.pw,p.ph);
    const xArr = p._1dXArr || (st.x_axis_b64 ? _decodeF64(st.x_axis_b64) : (st.x_axis||[]));
    const x0=st.view_x0||0,x1=st.view_x1||1;
    const widgets=st.overlay_widgets||[];
    const HR=7;
    // First pass: point widgets have highest drag priority so that a point
    // handle sitting inside a range band is always reachable.
    for(let i=widgets.length-1;i>=0;i--){
      const w=widgets[i];
      if(w.visible===false) continue;
      if(w.type==='point'){
        const px=_fracToPx1d(_xToFrac1d(xArr,w.x),x0,x1,r);
        const py=_valToPy1d(w.y,st.data_min,st.data_max,r);
        if(Math.hypot(mx-px,my-py)<=HR+4)
          return{idx:i,mode:'move',wtype:'point',startMX:mx,startMY:my,snapW:{...w}};
      }
    }
    // Second pass: everything else
    for(let i=widgets.length-1;i>=0;i--){
      const w=widgets[i];
      if(w.visible===false) continue;
      if(w.type==='vline'){
        const px=_fracToPx1d(_xToFrac1d(xArr,w.x),x0,x1,r);
        if(Math.sqrt((mx-px)**2+(my-(r.y+7))**2)<=HR||Math.abs(mx-px)<=5)
          return{idx:i,mode:'move',wtype:'vline',startMX:mx,snapW:{...w}};
      } else if(w.type==='hline'){
        const py=_valToPy1d(w.y,st.data_min,st.data_max,r);
        if(Math.abs(my-py)<=5) return{idx:i,mode:'move',wtype:'hline',startMY:my,snapW:{...w}};
      } else if(w.type==='range'){
        const px0=_fracToPx1d(_xToFrac1d(xArr,w.x0),x0,x1,r);
        const px1b=_fracToPx1d(_xToFrac1d(xArr,w.x1),x0,x1,r);
        if(w.style==='fwhm'){
          // FWHM style: hit-test the two circular handles
          const pyHalf=_valToPy1d(w.y||0,st.data_min,st.data_max,r);
          if(Math.hypot(mx-px0,my-pyHalf)<=HR+5)
            return{idx:i,mode:'edge0',wtype:'range',startMX:mx,snapW:{...w}};
          if(Math.hypot(mx-px1b,my-pyHalf)<=HR+5)
            return{idx:i,mode:'edge1',wtype:'range',startMX:mx,snapW:{...w}};
        } else {
          if(Math.abs(mx-px0)<=HR+5) return{idx:i,mode:'edge0',wtype:'range',startMX:mx,snapW:{...w}};
          if(Math.abs(mx-px1b)<=HR+5) return{idx:i,mode:'edge1',wtype:'range',startMX:mx,snapW:{...w}};
          const left=Math.min(px0,px1b),right=Math.max(px0,px1b);
          if(mx>=left&&mx<=right&&my>=r.y&&my<=r.y+r.h) return{idx:i,mode:'move',wtype:'range',startMX:mx,snapW:{...w}};
        }
      }
    }
    return null;
  }

  function _doDrag1d(e,p){
    const st=p.state;if(!st)return;
    const r=_plotRect1d(p.pw,p.ph);
    const {mx,my:py}=_clientPos(e,p.overlayCanvas,p.pw,p.ph);
    const xArr = p._1dXArr || (st.x_axis_b64 ? _decodeF64(st.x_axis_b64) : (st.x_axis||[]));
    const x0=st.view_x0||0,x1=st.view_x1||1;
    const xUnit=xArr.length>=2?_fracToX1d(xArr,_canvasXToFrac1d(mx,x0,x1,r)):_canvasXToFrac1d(mx,x0,x1,r);
    const widgets=st.overlay_widgets;
    const d=p.ovDrag, s=d.snapW, w=widgets[d.idx];
    if(w.type==='vline'){w.x=xUnit;}
    else if(w.type==='hline'){w.y=st.data_max-((py-r.y)/(r.h||1))*(st.data_max-st.data_min);}
    else if(w.type==='range'){
      if(d.mode==='edge0') w.x0=xUnit;
      else if(d.mode==='edge1') w.x1=xUnit;
      else {
        const snapPx=_fracToPx1d(xArr.length>=2?_xToFrac1d(xArr,s.x0):0,x0,x1,r);
        const dxUnit=xArr.length>=2?_fracToX1d(xArr,_canvasXToFrac1d(snapPx+(mx-d.startMX),x0,x1,r))-s.x0:(mx-d.startMX)/(r.w||1);
        w.x0=s.x0+dxUnit;w.x1=s.x1+dxUnit;
      }
    } else if(w.type==='point'){
      // Clamp to plot rectangle
      const clampX=Math.max(r.x,Math.min(r.x+r.w,mx));
      const clampY=Math.max(r.y,Math.min(r.y+r.h,py));
      w.x=xArr.length>=2?_fracToX1d(xArr,_canvasXToFrac1d(clampX,x0,x1,r)):_canvasXToFrac1d(clampX,x0,x1,r);
      w.y=st.data_max-((clampY-r.y)/(r.h||1))*(st.data_max-st.data_min);
    }
    drawOverlay1d(p);
    model.set(`panel_${p.id}_json`,JSON.stringify(st));model.save_changes();
    e.preventDefault();
  }

  // ── shared-axis propagation ───────────────────────────────────────────────
  function _getShareGroups() {
    try { return JSON.parse(model.get('layout_json')).share_groups||{}; } catch(_){ return {}; }
  }

  function _propagateZoom2d(srcPanel) {
    const sg=_getShareGroups();
    const srcId=srcPanel.id, st=srcPanel.state;
    for(const [axis,groups] of Object.entries(sg)){
      for(const group of groups){
        if(!group.includes(srcId)) continue;
        for(const pid of group){
          if(pid===srcId) continue;
          const tp=panels.get(pid); if(!tp||!tp.state) continue;
          if(axis==='x'||axis==='both'){tp.state.zoom=st.zoom;tp.state.center_x=st.center_x;}
          if(axis==='y'||axis==='both'){tp.state.center_y=st.center_y;}
          _redrawPanel(tp);
          model.set(`panel_${pid}_json`,JSON.stringify(tp.state));
        }
      }
    }
  }

  function _propagateView1d(srcPanel) {
    const sg=_getShareGroups();
    const srcId=srcPanel.id, st=srcPanel.state;
    for(const [axis,groups] of Object.entries(sg)){
      if(axis!=='x'&&axis!=='both') continue;
      for(const group of groups){
        if(!group.includes(srcId)) continue;
        for(const pid of group){
          if(pid===srcId) continue;
          const tp=panels.get(pid); if(!tp||!tp.state) continue;
          tp.state.view_x0=st.view_x0; tp.state.view_x1=st.view_x1;
          _redrawPanel(tp);
          model.set(`panel_${pid}_json`,JSON.stringify(tp.state));
        }
      }
    }
  }

  // ── figure-level resize ───────────────────────────────────────────────────
  let isResizing = false;
  let resizeStart = {};
  let _cachedLayout = null;   // layout parsed once at mousedown — avoids per-frame JSON.parse
  let _rafPending = false;    // rAF throttle flag
  let _pendingNfw = 0, _pendingNfh = 0;

  resizeHandle.addEventListener('mousedown', (e) => {
    isResizing = true;
    _suppressLayoutUpdate = true;
    const fw = model.get('fig_width'), fh = model.get('fig_height');
    // Capture the current CSS scale so drag deltas (in visual/page pixels) can
    // be converted back to native figure pixels.  offsetWidth is pre-transform.
    const _oRect = outerDiv.getBoundingClientRect();
    const _sfFig = (_oRect.width > 0) ? outerDiv.offsetWidth / _oRect.width : 1;
    resizeStart = { mx: e.clientX, my: e.clientY, fw, fh, sfFig: _sfFig };
    // Cache the layout once so mousemove never needs to parse JSON
    try { _cachedLayout = JSON.parse(model.get('layout_json')); } catch(_) { _cachedLayout = null; }
    sizeLabel.style.display = 'block';
    e.preventDefault();
  });

  // Low-level resize: only moves DOM geometry, no pixel drawing.
  // This is cheap enough to call every rAF (~16 ms).
  function _applyFigResizeDOM(nfw, nfh) {
    const layout = _cachedLayout;
    if (!layout) return;
    const { nrows, ncols, width_ratios, height_ratios, panel_specs } = layout;
    const wsum = width_ratios.reduce((a,b)=>a+b,0);
    const hsum = height_ratios.reduce((a,b)=>a+b,0);

    const col_px = width_ratios.map(w => nfw * w / wsum);
    const row_px = height_ratios.map(h => nfh * h / hsum);


    // Resize canvases (CSS size only — no pixel content redrawn)
    const colPx = new Array(ncols).fill(0);
    const rowPx = new Array(nrows).fill(0);
    for (const spec of panel_specs) {
      const p = panels.get(spec.id); if (!p) continue;
      let cw=0, ch=0;
      for(let c=spec.col_start;c<spec.col_stop;c++) cw+=col_px[c];
      for(let r=spec.row_start;r<spec.row_stop;r++) ch+=row_px[r];
      cw = Math.max(64, Math.round(cw));
      ch = Math.max(64, Math.round(ch));
      p.pw = cw; p.ph = ch;

      // Resize only CSS dimensions — don't touch canvas.width/height yet
      // (that clears the pixel buffer and forces a redraw)
      _resizePanelCSS(spec.id, cw, ch);

      const perC=Math.round(cw/(spec.col_stop-spec.col_start));
      const perR=Math.round(ch/(spec.row_stop-spec.row_start));
      for(let c=spec.col_start;c<spec.col_stop;c++) colPx[c]=Math.max(colPx[c],perC);
      for(let r=spec.row_start;r<spec.row_stop;r++) rowPx[r]=Math.max(rowPx[r],perR);
    }

    gridDiv.style.gridTemplateColumns = colPx.map(px=>px+'px').join(' ');
    gridDiv.style.gridTemplateRows    = rowPx.map(px=>px+'px').join(' ');
    gridDiv.style.width  = '';
    gridDiv.style.height = '';

    // CSS-only reposition of insets (no canvas redraw during live drag)
    insetsContainer.style.width  = nfw + 'px';
    insetsContainer.style.height = nfh + 'px';
    const insetSpecs = layout.inset_specs || [];
    for (const spec of insetSpecs) {
      const pi = panels.get(spec.id);
      if (!pi || !pi.isInset) continue;
      const pw = Math.max(64, Math.round(nfw * spec.w_frac));
      const ph = Math.max(64, Math.round(nfh * spec.h_frac));
      pi.pw = pw; pi.ph = ph;
      // Reuse _applyAllInsetStates logic inline (CSS only) by temporarily
      // patching spec dimensions and calling the function with a fake layout.
      spec.panel_width  = pw;
      spec.panel_height = ph;
    }
    if (insetSpecs.length) {
      _applyAllInsetStates({ ...layout, fig_width: nfw, fig_height: nfh });
    }
  }

  // CSS-only resize: move/size elements without clearing canvas buffers.
  // The canvas still renders its old content scaled by CSS — which looks
  // slightly blurry but is instantaneous. A full redraw follows on mouseup.
  function _resizePanelCSS(id, pw, ph) {
    const p = panels.get(id); if (!p) return;

    function _szCSS(c, w, h) {
      c.style.width  = w + 'px';
      c.style.height = h + 'px';
      // Do NOT set c.width / c.height — that would clear the canvas buffer
    }

    if (p.kind === '2d') {
      const st = p.state;
      const hasPhysAxis = st && (st.is_mesh || st.has_axes)
                       && st.x_axis && st.x_axis.length >= 2
                       && st.y_axis && st.y_axis.length >= 2;
      const imgX = hasPhysAxis ? PAD_L : 0;
      const imgY = hasPhysAxis ? PAD_T : 0;
      const imgW = hasPhysAxis ? Math.max(1, pw - PAD_L - PAD_R) : pw;
      const imgH = hasPhysAxis ? Math.max(1, ph - PAD_T - PAD_B) : ph;
      // Update stored dims so event handlers stay consistent during CSS resize
      p.imgX = imgX; p.imgY = imgY; p.imgW = imgW; p.imgH = imgH;

      if (p.plotWrap) { p.plotWrap.style.width=pw+'px'; p.plotWrap.style.height=ph+'px'; }

      _szCSS(p.plotCanvas,    imgW, imgH);
      _szCSS(p.overlayCanvas, imgW, imgH);
      _szCSS(p.markersCanvas, imgW, imgH);

      p.plotCanvas.style.left    = imgX+'px'; p.plotCanvas.style.top    = imgY+'px';
      p.overlayCanvas.style.left = imgX+'px'; p.overlayCanvas.style.top = imgY+'px';
      p.markersCanvas.style.left = imgX+'px'; p.markersCanvas.style.top = imgY+'px';

      if (p.statusBar) { p.statusBar.style.left=(imgX+4)+'px'; p.statusBar.style.bottom=(ph-imgY-imgH+4)+'px'; }
      if (p.scaleBar)  { p.scaleBar.style.right=(pw-imgX-imgW+12)+'px'; p.scaleBar.style.bottom=(ph-imgY-imgH+12)+'px'; }

      // Axis canvases: just reposition, size handled on full redraw
      if (p.yAxisCanvas && p.yAxisCanvas.style.display !== 'none') {
        p.yAxisCanvas.style.left = '0px'; p.yAxisCanvas.style.top = imgY+'px';
        _szCSS(p.yAxisCanvas, PAD_L, imgH);
      }
      if (p.xAxisCanvas && p.xAxisCanvas.style.display !== 'none') {
        p.xAxisCanvas.style.left = imgX+'px'; p.xAxisCanvas.style.top = (ph-PAD_B)+'px';
        _szCSS(p.xAxisCanvas, imgW, PAD_B);
      }
      if (p.cbCanvas && p.cbCanvas.style.display !== 'none') {
        p.cbCanvas.style.left = (imgX + imgW + 2) + 'px'; p.cbCanvas.style.top = imgY + 'px';
        _szCSS(p.cbCanvas, 16, imgH);
      }
    } else if (p.kind === '3d') {
      _szCSS(p.plotCanvas,    pw, ph);
      _szCSS(p.overlayCanvas, pw, ph);
    } else {
      _szCSS(p.plotCanvas,    pw, ph);
      _szCSS(p.overlayCanvas, pw, ph);
      _szCSS(p.markersCanvas, pw, ph);
    }
  }

  // Full resize: update canvas pixel buffers and redraw content.
  function _applyFigResize(nfw, nfh) {
    _applyFigResizeDOM(nfw, nfh);
    for (const p of panels.values()) {
      _resizePanelDOM(p.id, p.pw, p.ph);
      _redrawPanel(p);
    }
  }

  document.addEventListener('mousemove', (e) => {
    if (!isResizing) return;
    const sf = resizeStart.sfFig || 1;
    _pendingNfw = Math.max(200, resizeStart.fw + (e.clientX - resizeStart.mx) * sf);
    _pendingNfh = Math.max(100, resizeStart.fh + (e.clientY - resizeStart.my) * sf);
    sizeLabel.textContent = `${Math.round(_pendingNfw)}×${Math.round(_pendingNfh)}`;

    // Throttle to one DOM update per animation frame
    if (!_rafPending) {
      _rafPending = true;
      requestAnimationFrame(() => {
        _rafPending = false;
        if (!isResizing) return;
        _applyFigResizeDOM(_pendingNfw, _pendingNfh);
      });
    }
    e.preventDefault();
  });

  document.addEventListener('mouseup', (e) => {
    if (!isResizing) return;
    isResizing = false;
    _rafPending = false;
    sizeLabel.style.display = 'none';
    const sf = resizeStart.sfFig || 1;
    const nfw = Math.max(200, resizeStart.fw + (e.clientX - resizeStart.mx) * sf);
    const nfh = Math.max(100, resizeStart.fh + (e.clientY - resizeStart.my) * sf);

    // Full redraw at final size
    _applyFigResize(nfw, nfh);

    // Patch layout_json so the model listener won't revert sizes
    try {
      const layout = JSON.parse(model.get('layout_json'));
      layout.fig_width  = Math.round(nfw);
      layout.fig_height = Math.round(nfh);
      for (const spec of layout.panel_specs) {
        const p = panels.get(spec.id);
        if (p) { spec.panel_width = p.pw; spec.panel_height = p.ph; }
      }
      for (const spec of (layout.inset_specs || [])) {
        const pi = panels.get(spec.id);
        if (pi) { spec.panel_width = pi.pw; spec.panel_height = pi.ph; }
      }
      model.set('layout_json', JSON.stringify(layout));
    } catch(_) {}

    _suppressLayoutUpdate = false;
    model.set('fig_width',  Math.round(nfw));
    model.set('fig_height', Math.round(nfh));
    model.save_changes();
    e.preventDefault();
  });


  // ── bar chart ─────────────────────────────────────────────────────────────
  // Shared geometry helper used by both drawBar and _attachEventsBar.
  // Returns per-slot/bar pixel sizes, coordinate mappers, and group helpers.
  function _barGeom(st, r) {
    const values   = st.values   || [];
    const n        = values.length || 1;
    const groups   = st.groups   || 1;
    const orient   = st.orient   || 'v';
    const bwFrac   = st.bar_width !== undefined ? st.bar_width : 0.8;
    const baseline = st.baseline !== undefined  ? st.baseline  : 0;
    let dMin = st.data_min, dMax = st.data_max;
    if (st.y_range && st.y_range.length === 2) { dMin = st.y_range[0]; dMax = st.y_range[1]; }
    const logScale = !!st.log_scale;
    const LC       = 1e-10; // log clamp

    // Value at category i, group g — supports 2-D [[g0,g1,...], ...] and
    // legacy 1-D [v0, v1, ...].
    function getVal(i, g) {
      const row = values[i];
      if (Array.isArray(row)) return row[g] !== undefined ? row[g] : 0;
      return (g === 0) ? (row !== undefined ? +row : 0) : 0;
    }

    // Pixel coordinate along the VALUE axis.
    function _valToPy(v) {
      if (logScale) {
        const lv   = Math.log10(Math.max(LC, v));
        const lMin = Math.log10(Math.max(LC, dMin));
        const lMax = Math.log10(Math.max(LC, dMax));
        return r.y + r.h - ((lv - lMin) / ((lMax - lMin) || 1)) * r.h;
      }
      return r.y + r.h - ((v - dMin) / ((dMax - dMin) || 1)) * r.h;
    }
    function _valToX(v) {
      if (logScale) {
        const lv   = Math.log10(Math.max(LC, v));
        const lMin = Math.log10(Math.max(LC, dMin));
        const lMax = Math.log10(Math.max(LC, dMax));
        return r.x + ((lv - lMin) / ((lMax - lMin) || 1)) * r.w;
      }
      return r.x + ((v - dMin) / ((dMax - dMin) || 1)) * r.w;
    }

    if (orient === 'h') {
      const slotPx     = r.h / n;
      const barPx      = (slotPx * bwFrac) / groups;
      function xToPx(v) { return _valToX(v); }
      function yToPx(i) { return r.y + (i + 0.5) * slotPx; }
      function groupOffsetPx(g) { return (g - (groups - 1) / 2) * barPx; }
      const bv = logScale ? Math.max(LC, baseline) : baseline;
      const basePx = Math.max(r.x, Math.min(r.x + r.w, xToPx(bv)));
      return { n, groups, orient, slotPx, barPx, dMin, dMax, baseline,
               basePx, xToPx, yToPx, groupOffsetPx, logScale, getVal, LC };
    } else {
      const slotPx     = r.w / n;
      const barPx      = (slotPx * bwFrac) / groups;
      function xToPx(i) { return r.x + (i + 0.5) * slotPx; }
      function yToPx(v) { return _valToPy(v); }
      function groupOffsetPx(g) { return (g - (groups - 1) / 2) * barPx; }
      const bv = logScale ? Math.max(LC, baseline) : baseline;
      const basePx = Math.max(r.y, Math.min(r.y + r.h, yToPx(bv)));
      return { n, groups, orient, slotPx, barPx, dMin, dMax, baseline,
               basePx, xToPx, yToPx, groupOffsetPx, logScale, getVal, LC };
    }
  }

  function drawBar(p) {
    const st = p.state; if (!st) return;
    _recordFrame(p);
    const { pw, ph, plotCtx: ctx } = p;
    const r = _plotRect1d(pw, ph);

    ctx.clearRect(0, 0, pw, ph);
    ctx.fillStyle = theme.bg;     ctx.fillRect(0, 0, pw, ph);
    ctx.fillStyle = theme.bgPlot; ctx.fillRect(r.x, r.y, r.w, r.h);

    const values      = st.values      || [];
    const xCenters    = st.x_centers   || values.map((_, i) => i);
    const xLabels     = st.x_labels    || [];
    const barColor    = st.bar_color   || '#4fc3f7';
    const barColors   = st.bar_colors  || [];
    const groupColors = st.group_colors || [];
    const groupLabels = st.group_labels || [];
    const orient      = st.orient || 'v';
    let dMin = st.data_min, dMax = st.data_max;
    if (st.y_range && st.y_range.length === 2) { dMin = st.y_range[0]; dMax = st.y_range[1]; }
    const logScale    = !!st.log_scale;
    const axisVis     = st.axis_visible !== false;
    const xTicksVis   = st.x_ticks_visible !== false;
    const yTicksVis   = st.y_ticks_visible !== false;

    if (!values.length) return;

    const g = _barGeom(st, r);
    const LC = g.LC;

    // ── log tick helper ───────────────────────────────────────────────────
    function _fmtLogTick(v) {
      const exp = Math.round(Math.log10(v));
      if (Math.abs(v - Math.pow(10, exp)) < v * 1e-6) {
        if (exp === 0) return '1';
        if (exp === 1) return '10';
        return `10^${exp}`;
      }
      return fmtVal(v);
    }

    // ── grid lines (along value axis) ─────────────────────────────────────
    ctx.strokeStyle = theme.gridStroke; ctx.lineWidth = 1;

    if (logScale) {
      const lMin = Math.log10(Math.max(LC, dMin));
      const lMax = Math.log10(Math.max(LC, dMax));
      // minor grid — 2,3,5 × decade, semi-transparent
      ctx.globalAlpha = 0.3;
      for (let exp = Math.floor(lMin); exp < Math.ceil(lMax); exp++) {
        for (const m of [2, 3, 5]) {
          const v = m * Math.pow(10, exp);
          if (v < dMin || v > dMax) continue;
          if (orient === 'h') {
            const px = g.xToPx(v);
            if (px < r.x || px > r.x + r.w) continue;
            ctx.beginPath(); ctx.moveTo(px, r.y); ctx.lineTo(px, r.y + r.h); ctx.stroke();
          } else {
            const py = g.yToPx(v);
            if (py < r.y || py > r.y + r.h) continue;
            ctx.beginPath(); ctx.moveTo(r.x, py); ctx.lineTo(r.x + r.w, py); ctx.stroke();
          }
        }
      }
      ctx.globalAlpha = 1.0;
      // major grid — decades, full opacity
      for (let exp = Math.floor(lMin); exp <= Math.ceil(lMax); exp++) {
        const v = Math.pow(10, exp);
        if (v < dMin || v > dMax) continue;
        if (orient === 'h') {
          const px = g.xToPx(v);
          if (px < r.x || px > r.x + r.w) continue;
          ctx.beginPath(); ctx.moveTo(px, r.y); ctx.lineTo(px, r.y + r.h); ctx.stroke();
        } else {
          const py = g.yToPx(v);
          if (py < r.y || py > r.y + r.h) continue;
          ctx.beginPath(); ctx.moveTo(r.x, py); ctx.lineTo(r.x + r.w, py); ctx.stroke();
        }
      }
    } else {
      const valRange = (dMax - dMin) || 1;
      const valStep  = findNice(valRange / Math.max(2, Math.floor((orient==='h' ? r.w : r.h) / 40)));
      if (orient === 'h') {
        for (let v = Math.ceil(dMin/valStep)*valStep; v <= dMax+valStep*0.01; v += valStep) {
          const px = g.xToPx(v);
          if (px < r.x || px > r.x + r.w) continue;
          ctx.beginPath(); ctx.moveTo(px, r.y); ctx.lineTo(px, r.y + r.h); ctx.stroke();
        }
      } else {
        for (let v = Math.ceil(dMin/valStep)*valStep; v <= dMax+valStep*0.01; v += valStep) {
          const py = g.yToPx(v);
          if (py < r.y || py > r.y + r.h) continue;
          ctx.beginPath(); ctx.moveTo(r.x, py); ctx.lineTo(r.x + r.w, py); ctx.stroke();
        }
      }
    }

    // ── bars ──────────────────────────────────────────────────────────────
    ctx.save(); ctx.beginPath(); ctx.rect(r.x, r.y, r.w, r.h); ctx.clip();

    for (let i = 0; i < g.n; i++) {
      for (let gi = 0; gi < g.groups; gi++) {
        const val   = g.getVal(i, gi);
        const color = groupColors[gi] || barColors[i] || barColor;
        const isHov = p._hovBar !== null &&
                      p._hovBar.slot === i && p._hovBar.group === gi;
        const dv    = logScale ? Math.max(LC, val) : val;

        if (orient === 'h') {
          const cy    = g.yToPx(i) + g.groupOffsetPx(gi);
          const valPx = g.xToPx(dv);
          const bLeft = Math.min(valPx, g.basePx);
          const bW    = Math.max(1, Math.abs(valPx - g.basePx));
          ctx.fillStyle = color;
          ctx.fillRect(bLeft, cy - g.barPx / 2, bW, g.barPx);
          if (isHov) {
            ctx.save(); ctx.fillStyle = 'rgba(255,255,255,0.22)';
            ctx.fillRect(bLeft, cy - g.barPx / 2, bW, g.barPx); ctx.restore();
          }
          ctx.strokeStyle = theme.dark ? 'rgba(0,0,0,0.25)' : 'rgba(0,0,0,0.09)';
          ctx.lineWidth = 0.5;
          ctx.strokeRect(bLeft, cy - g.barPx / 2, bW, g.barPx);
        } else {
          const cx    = g.xToPx(i) + g.groupOffsetPx(gi);
          const valPy = g.yToPx(dv);
          const bTop  = Math.min(valPy, g.basePx);
          const bH    = Math.max(1, Math.abs(valPy - g.basePx));
          ctx.fillStyle = color;
          ctx.fillRect(cx - g.barPx / 2, bTop, g.barPx, bH);
          if (isHov) {
            ctx.save(); ctx.fillStyle = 'rgba(255,255,255,0.22)';
            ctx.fillRect(cx - g.barPx / 2, bTop, g.barPx, bH); ctx.restore();
          }
          ctx.strokeStyle = theme.dark ? 'rgba(0,0,0,0.25)' : 'rgba(0,0,0,0.09)';
          ctx.lineWidth = 0.5;
          ctx.strokeRect(cx - g.barPx / 2, bTop, g.barPx, bH);
        }
      }
    }
    ctx.restore();

    // ── value annotations ─────────────────────────────────────────────────
    if (st.show_values) {
      ctx.font = '9px monospace'; ctx.fillStyle = theme.tickText;
      for (let i = 0; i < g.n; i++) {
        for (let gi = 0; gi < g.groups; gi++) {
          const val = g.getVal(i, gi);
          const dv  = logScale ? Math.max(LC, val) : val;
          if (orient === 'h') {
            const cy    = g.yToPx(i) + g.groupOffsetPx(gi);
            const valPx = g.xToPx(dv);
            const above = val >= g.baseline;
            ctx.textAlign    = above ? 'left' : 'right';
            ctx.textBaseline = 'middle';
            ctx.fillText(fmtVal(val), valPx + (above ? 3 : -3), cy);
          } else {
            const cx    = g.xToPx(i) + g.groupOffsetPx(gi);
            const valPy = g.yToPx(dv);
            const above = val >= g.baseline;
            ctx.textAlign    = 'center';
            ctx.textBaseline = above ? 'bottom' : 'top';
            ctx.fillText(fmtVal(val), cx, valPy + (above ? -2 : 2));
          }
        }
      }
    }

    // ── axis borders ──────────────────────────────────────────────────────
    if (axisVis) {
    ctx.strokeStyle = theme.axisStroke; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(r.x, r.y + r.h); ctx.lineTo(r.x + r.w, r.y + r.h); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(r.x, r.y);         ctx.lineTo(r.x, r.y + r.h);       ctx.stroke();

    // Explicit baseline (only for linear scale)
    if (!logScale) {
      if (orient === 'h') {
        if (g.basePx > r.x && g.basePx < r.x + r.w) {
          ctx.strokeStyle = theme.axisStroke; ctx.lineWidth = 1.5;
          ctx.beginPath(); ctx.moveTo(g.basePx, r.y); ctx.lineTo(g.basePx, r.y + r.h); ctx.stroke();
        }
      } else {
        if (g.basePx > r.y && g.basePx < r.y + r.h) {
          ctx.strokeStyle = theme.axisStroke; ctx.lineWidth = 1.5;
          ctx.beginPath(); ctx.moveTo(r.x, g.basePx); ctx.lineTo(r.x + r.w, g.basePx); ctx.stroke();
        }
      }
    } // end axisVis (baseline)
    } // end axisVis (borders)

    // ── tick labels ───────────────────────────────────────────────────────
    if (axisVis) {
      ctx.font = '10px monospace'; ctx.fillStyle = theme.tickText;

      if (orient === 'h') {
        // Value axis → X ticks at bottom
        if (xTicksVis) {
          ctx.textAlign = 'center'; ctx.textBaseline = 'top';
          if (logScale) {
            const lMin = Math.log10(Math.max(LC, dMin));
            const lMax = Math.log10(Math.max(LC, dMax));
            for (let exp = Math.floor(lMin); exp <= Math.ceil(lMax); exp++) {
              const v = Math.pow(10, exp);
              if (v < dMin || v > dMax) continue;
              const px = g.xToPx(v);
              if (px < r.x || px > r.x + r.w) continue;
              ctx.strokeStyle = theme.axisStroke;
              ctx.beginPath(); ctx.moveTo(px, r.y + r.h); ctx.lineTo(px, r.y + r.h + 4); ctx.stroke();
              ctx.fillStyle = theme.tickText;
              ctx.fillText(_fmtLogTick(v), px, r.y + r.h + 7);
            }
          } else {
            const valRange = (dMax - dMin) || 1;
            const valStep  = findNice(valRange / Math.max(2, Math.floor(r.w / 40)));
            for (let v = Math.ceil(dMin/valStep)*valStep; v <= dMax+valStep*0.01; v += valStep) {
              const px = g.xToPx(v);
              if (px < r.x || px > r.x + r.w) continue;
              ctx.strokeStyle = theme.axisStroke;
              ctx.beginPath(); ctx.moveTo(px, r.y + r.h); ctx.lineTo(px, r.y + r.h + 4); ctx.stroke();
              ctx.fillStyle = theme.tickText;
              ctx.fillText(fmtVal(v), px, r.y + r.h + 7);
            }
          }
          if (st.y_units) {
            ctx.textAlign='right'; ctx.textBaseline='top'; ctx.font='9px monospace';
            ctx.fillStyle=theme.unitText;
            ctx.fillText(st.y_units, r.x + r.w, r.y + r.h + 24);
            ctx.font='10px monospace';
          }
        }
        // Category axis → Y labels on left
        if (yTicksVis) {
          ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
          const maxCatLabels = Math.max(1, Math.floor(r.h / 14));
          const catStep = Math.max(1, Math.ceil(g.n / maxCatLabels));
          for (let i = 0; i < g.n; i += catStep) {
            const cy    = g.yToPx(i);
            const label = xLabels[i] !== undefined ? String(xLabels[i]) : fmtVal(xCenters[i]);
            ctx.strokeStyle = theme.axisStroke;
            ctx.beginPath(); ctx.moveTo(r.x, cy); ctx.lineTo(r.x - 4, cy); ctx.stroke();
            ctx.fillStyle = theme.tickText;
            ctx.fillText(label, r.x - 7, cy);
          }
          if (st.units) {
            ctx.save();
            ctx.translate(Math.round(PAD_L * 0.28), r.y + r.h / 2); ctx.rotate(-Math.PI/2);
            ctx.textAlign='center'; ctx.textBaseline='middle';
            ctx.fillStyle=theme.unitText; ctx.font='9px monospace';
            ctx.fillText(st.units, 0, 0);
            ctx.restore();
          }
        }
      } else {
        // Category axis → X ticks at bottom
        if (xTicksVis) {
          ctx.textAlign = 'center'; ctx.textBaseline = 'top';
          const maxCatLabels = Math.max(1, Math.floor(r.w / 42));
          const catStep = Math.max(1, Math.ceil(g.n / maxCatLabels));
          for (let i = 0; i < g.n; i += catStep) {
            const cx    = g.xToPx(i);
            const label = xLabels[i] !== undefined ? String(xLabels[i]) : fmtVal(xCenters[i]);
            ctx.strokeStyle = theme.axisStroke;
            ctx.beginPath(); ctx.moveTo(cx, r.y + r.h); ctx.lineTo(cx, r.y + r.h + 4); ctx.stroke();
            ctx.fillStyle = theme.tickText;
            ctx.fillText(label, cx, r.y + r.h + 7);
          }
          if (st.units && st.units !== 'px') {
            ctx.textAlign='right'; ctx.textBaseline='top'; ctx.font='9px monospace';
            ctx.fillStyle=theme.unitText;
            ctx.fillText(st.units, r.x + r.w, r.y + r.h + 24);
            ctx.font='10px monospace';
          }
        }
        // Value axis → Y ticks on left
        if (yTicksVis) {
          ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
          if (logScale) {
            const lMin = Math.log10(Math.max(LC, dMin));
            const lMax = Math.log10(Math.max(LC, dMax));
            for (let exp = Math.floor(lMin); exp <= Math.ceil(lMax); exp++) {
              const v = Math.pow(10, exp);
              if (v < dMin || v > dMax) continue;
              const py = g.yToPx(v);
              if (py < r.y || py > r.y + r.h) continue;
              ctx.strokeStyle = theme.axisStroke;
              ctx.beginPath(); ctx.moveTo(r.x, py); ctx.lineTo(r.x - 5, py); ctx.stroke();
              ctx.fillStyle = theme.tickText;
              ctx.fillText(_fmtLogTick(v), r.x - 8, py);
            }
          } else {
            const valRange = (dMax - dMin) || 1;
            const valStep  = findNice(valRange / Math.max(2, Math.floor(r.h / 40)));
            for (let v = Math.ceil(dMin/valStep)*valStep; v <= dMax+valStep*0.01; v += valStep) {
              const py = g.yToPx(v);
              if (py < r.y || py > r.y + r.h) continue;
              ctx.strokeStyle = theme.axisStroke;
              ctx.beginPath(); ctx.moveTo(r.x, py); ctx.lineTo(r.x - 5, py); ctx.stroke();
              ctx.fillStyle = theme.tickText;
              ctx.fillText(fmtVal(v), r.x - 8, py);
            }
          }
          if (st.y_units) {
            ctx.save();
            ctx.translate(Math.round(PAD_L * 0.28), r.y + r.h / 2); ctx.rotate(-Math.PI/2);
            ctx.textAlign='center'; ctx.textBaseline='middle';
            ctx.fillStyle=theme.unitText; ctx.font='9px monospace';
            ctx.fillText(st.y_units, 0, 0);
            ctx.restore();
          }
        }
      }
    } // end axisVis

    // ── group legend (only when group_labels are provided) ────────────────
    if (g.groups > 1 && groupLabels.length > 0) {
      ctx.font = '9px monospace';
      const swatchW = 12, swatchH = 10, pad = 4, rowH = 15;
      let legendMaxW = 0;
      for (let gi = 0; gi < Math.min(g.groups, groupLabels.length); gi++) {
        legendMaxW = Math.max(legendMaxW, ctx.measureText(String(groupLabels[gi])).width);
      }
      const legendW = swatchW + pad + legendMaxW + 6;
      const nRows   = Math.min(g.groups, groupLabels.length);
      const legendH = nRows * rowH + 4;
      const lx = r.x + r.w - legendW - 4;
      const ly = r.y + 4;
      ctx.fillStyle = theme.dark ? 'rgba(0,0,0,0.45)' : 'rgba(255,255,255,0.75)';
      ctx.fillRect(lx, ly, legendW, legendH);
      ctx.strokeStyle = theme.axisStroke; ctx.lineWidth = 0.5;
      ctx.strokeRect(lx, ly, legendW, legendH);
      for (let gi = 0; gi < nRows; gi++) {
        const label = String(groupLabels[gi]);
        const ey    = ly + 2 + gi * rowH;
        ctx.fillStyle = groupColors[gi] || barColor;
        ctx.fillRect(lx + 3, ey + (rowH - swatchH) / 2, swatchW, swatchH);
        ctx.fillStyle = theme.tickText;
        ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
        ctx.fillText(label, lx + 3 + swatchW + pad, ey + rowH / 2);
      }
    }

    // ── title ─────────────────────────────────────────────────────────────
    const titleBar = st.title || '';
    if (titleBar) {
      ctx.fillStyle = theme.tickText;
      ctx.font = 'bold 11px sans-serif';
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(titleBar, r.x + r.w / 2, PAD_T / 2);
    }

    // ── axis labels ───────────────────────────────────────────────────────
    const xLabelBar = st.x_label || '';
    const yLabelBar = st.y_label || '';
    if (xLabelBar) {
      ctx.fillStyle = theme.tickText; ctx.font = '10px sans-serif';
      ctx.textAlign = 'center'; ctx.textBaseline = 'top';
      ctx.fillText(xLabelBar, r.x + r.w / 2, r.y + r.h + 26);
    }
    if (yLabelBar) {
      ctx.save();
      ctx.translate(Math.round(PAD_L * 0.1), r.y + r.h / 2); ctx.rotate(-Math.PI / 2);
      ctx.fillStyle = theme.tickText; ctx.font = '10px sans-serif';
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(yLabelBar, 0, 0);
      ctx.restore();
    }

    // Overlay widgets (vlines, hlines) drawn on overlay canvas
    drawOverlay1d(p);
  }

  function _attachEventsBar(p) {
    const { overlayCanvas } = p;

    // Returns {slot, group} for the bar at canvas (mx,my), or null if none.
    function _barHit(mx, my) {
      const st = p.state;
      if (!st || !st.values || !st.values.length) return null;
      const r  = _plotRect1d(p.pw, p.ph);
      if (mx < r.x || mx > r.x + r.w || my < r.y || my > r.y + r.h) return null;
      const g  = _barGeom(st, r);
      const LC = g.LC;
      for (let i = 0; i < g.n; i++) {
        for (let gi = 0; gi < g.groups; gi++) {
          const val = g.getVal(i, gi);
          const dv  = g.logScale ? Math.max(LC, val) : val;
          if (g.orient === 'h') {
            const cy    = g.yToPx(i) + g.groupOffsetPx(gi);
            const valPx = g.xToPx(dv);
            const left  = Math.min(valPx, g.basePx);
            const bW    = Math.max(1, Math.abs(valPx - g.basePx));
            if (Math.abs(my - cy) <= g.barPx / 2 && mx >= left && mx <= left + bW)
              return { slot: i, group: gi };
          } else {
            const cx    = g.xToPx(i) + g.groupOffsetPx(gi);
            const valPy = g.yToPx(dv);
            const top   = Math.min(valPy, g.basePx);
            const bH    = Math.max(1, Math.abs(valPy - g.basePx));
            if (Math.abs(mx - cx) <= g.barPx / 2 && my >= top && my <= top + bH)
              return { slot: i, group: gi };
          }
        }
      }
      return null;
    }

    // Widget drag support
    let commitPending = false;
    let _settledTimer = null;
    let _settledStartX = 0, _settledStartY = 0, _settledStartTs = 0;
    function _scheduleCommit() {
      if (commitPending) return; commitPending = true;
      requestAnimationFrame(() => { commitPending = false; model.save_changes(); });
    }

    overlayCanvas.addEventListener('mousedown', (e) => {
      if (e.button !== 0) return;
      const {mx:_bmx, my:_bmy} = _clientPos(e, overlayCanvas, p.pw, p.ph);
      const hit = _ovHitTest1d(_bmx, _bmy, p);
      if (hit) {
        p.ovDrag = hit;
        p.lastWidgetId = (p.state.overlay_widgets || [])[hit.idx]?.id || null;
        overlayCanvas.style.cursor = 'ew-resize';
        e.preventDefault();
      }
    });

    document.addEventListener('mousemove', (e) => {
      if (!p.ovDrag) return;
      _doDrag1d(e, p);
      const _dw = (p.state.overlay_widgets || [])[p.ovDrag.idx] || {};
      _emitEvent(p.id, 'pointer_move', _dw.id || null, {..._dw, ..._pointerFields(e)});
    });

    document.addEventListener('mouseup', (e) => {
      clearTimeout(_settledTimer); _settledTimer = null;
      if (!p.ovDrag) return;
      const _idx = p.ovDrag.idx;
      const _dw  = (p.state.overlay_widgets || [])[_idx] || {};
      const _did = _dw.id || null;
      p.ovDrag = null;
      overlayCanvas.style.cursor = 'default';
      model.set(`panel_${p.id}_json`, JSON.stringify(p.state));
      _emitEvent(p.id, 'pointer_up', _did, {..._dw, ..._pointerFields(e), button: e.button});
      _scheduleCommit();
    });

    overlayCanvas.addEventListener('mousemove', (e) => {
      const {mx, my} = _clientPos(e, overlayCanvas, p.pw, p.ph);
      p.mouseX = mx; p.mouseY = my;
      if (p.ovDrag) return;
      const st = p.state; if (!st) return;

      // Overlay widget cursor hint
      const whit = _ovHitTest1d(mx, my, p);
      if (whit) {
        overlayCanvas.style.cursor = 'ew-resize';
        tooltip.style.display = 'none';
        if (p._hovBar !== null) { p._hovBar = null; drawBar(p); }
        return;
      }

      const hit = _barHit(mx, my);
      const prev = p._hovBar;
      const same = hit !== null && prev !== null &&
                   prev.slot === hit.slot && prev.group === hit.group;
      if (!same) { p._hovBar = hit; drawBar(p); }

      if (hit !== null) {
        const { slot: idx, group: gi } = hit;
        const label = (st.x_labels||[])[idx] !== undefined
          ? String(st.x_labels[idx])
          : fmtVal((st.x_centers||[])[idx] ?? idx);
        const gLabel = (st.group_labels||[])[gi];
        const gm  = _barGeom(st, _plotRect1d(p.pw, p.ph));
        const val = gm.getVal(idx, gi);
        const tip = (st.groups > 1 && gLabel)
          ? `${gLabel} | ${label}: ${fmtVal(val)}`
          : `${label}: ${fmtVal(val)}`;
        _showTooltip(tip, e.clientX, e.clientY);
        overlayCanvas.style.cursor = 'pointer';
      } else {
        tooltip.style.display = 'none';
        overlayCanvas.style.cursor = 'default';
      }
      // pointer_settled dwell timer (zero-cost when pointer_settled_ms === 0)
      const _settledMs = (p.state.pointer_settled_ms ?? 0);
      if (_settledMs > 0) {
        const _settledDelta = p.state.pointer_settled_delta ?? 4;
        clearTimeout(_settledTimer);
        _settledStartX = mx;
        _settledStartY = my;
        _settledStartTs = performance.now();
        const _settledMods = _modifiers(e);  // capture at arm time — e is the mousemove event
        _settledTimer = setTimeout(() => {
          const dist = Math.hypot(p.mouseX - _settledStartX, p.mouseY - _settledStartY);
          if (dist <= _settledDelta) {
            const _now = performance.now();
            _emitEvent(p.id, 'pointer_settled', null, {
              time_stamp: _now / 1000,
              modifiers:  _settledMods,
              button:     null,
              buttons:    0,
              x:          Math.round(p.mouseX),
              y:          Math.round(p.mouseY),
              dwell_ms:   _now - _settledStartTs,
            });
          }
        }, _settledMs);
      }
    });

    overlayCanvas.addEventListener('mouseleave', (e) => {
      clearTimeout(_settledTimer); _settledTimer = null;
      _emitEvent(p.id, 'pointer_leave', null, {..._pointerFields(e), x: e.offsetX, y: e.offsetY});
      if (p._hovBar !== null) { p._hovBar = null; drawBar(p); }
      tooltip.style.display = 'none';
    });

    overlayCanvas.addEventListener('mousedown', (e) => {
      if (p.ovDrag) return;
      const st = p.state; if (!st) return;
      const {mx:_cmx, my:_cmy} = _clientPos(e, overlayCanvas, p.pw, p.ph);
      const hit = _barHit(_cmx, _cmy);
      const _baseFields = {..._pointerFields(e), button: e.button, x: _cmx, y: _cmy};
      if (hit === null) {
        _emitEvent(p.id, 'pointer_down', null, {
          bar_index:   null,
          group_index: null,
          value:       null,
          x_label:     null,
          ..._baseFields,
        });
        return;
      }
      const { slot: idx, group: gi } = hit;
      const gm  = _barGeom(st, _plotRect1d(p.pw, p.ph));
      const val = gm.getVal(idx, gi);
      _emitEvent(p.id, 'pointer_down', null, {
        bar_index:   idx,
        group_index: gi,
        value:       val,
        group_value: val,
        x_center:    (st.x_centers||[])[idx] ?? idx,
        x_label:     (st.x_labels||[])[idx] !== undefined
                       ? String(st.x_labels[idx]) : null,
        ..._baseFields,
      });
    });

    // Keyboard: all keys forwarded to Python unconditionally; no built-in bar shortcuts.
    overlayCanvas.addEventListener('keydown', (e) => {
      const st = p.state; if (!st) return;
      _emitEvent(p.id, 'key_down', null, {
        time_stamp: performance.now() / 1000,
        modifiers: _modifiers(e),
        key: e.key,
        last_widget_id: p.lastWidgetId || null,
        x: p.mouseX ?? 0, y: p.mouseY ?? 0,
      });
    });
    overlayCanvas.addEventListener('keyup', (e) => {
      _emitEvent(p.id, 'key_up', null, {
        time_stamp: performance.now() / 1000,
        modifiers: _modifiers(e),
        key: e.key,
        x: p.mouseX ?? 0, y: p.mouseY ?? 0,
      });
    });
    overlayCanvas.tabIndex = 0;
    overlayCanvas.style.outline = 'none';
    overlayCanvas.addEventListener('mouseenter', (e) => {
      overlayCanvas.focus();
      _emitEvent(p.id, 'pointer_enter', null, {..._pointerFields(e), x: e.offsetX, y: e.offsetY});
    });
    overlayCanvas.addEventListener('dblclick', (e) => {
      const {mx, my} = _clientPos(e, overlayCanvas, p.pw, p.ph);
      _emitEvent(p.id, 'double_click', null, {..._pointerFields(e), button: e.button, x: mx, y: my, xdata: null});
    });
    overlayCanvas.addEventListener('wheel', (e) => {
      _emitEvent(p.id, 'wheel', null, {
        time_stamp: performance.now() / 1000,
        modifiers: _modifiers(e),
        x: p.mouseX ?? 0, y: p.mouseY ?? 0,
        dx: e.deltaX, dy: e.deltaY,
      });
    }, { passive: true });
  }

  // ── generic redraw ────────────────────────────────────────────────────────
  function _redrawPanel(p) {
    if(!p.state) return;
    if(p.kind==='2d')      draw2d(p);
    else if(p.kind==='3d') draw3d(p);
    else if(p.kind==='bar') drawBar(p);
    else                   draw1d(p);
  }

  function redrawAll() {
    for(const p of panels.values()) _redrawPanel(p);
  }

  // ── cell-aware CSS scaling ────────────────────────────────────────────────
  // When the notebook cell (or any container) is narrower than the figure's
  // native size, apply CSS transform:scale() to outerDiv so it shrinks
  // proportionally without re-rendering canvases or writing to the model.
  // Full canvas resolution is preserved; CSS transforms correctly route
  // pointer events so all interactive features (drag, zoom, pan) keep working.
  // Also called after layout/resize changes so the scale stays in sync.
  //
  // Prerequisite: .apl-outer must carry `min-width: max-content` (set in the
  // _css traitlet).  Without it, the inline-block shrinks to match its
  // constrained parent and outerDiv.offsetWidth == cellW, giving s = 1 always.
  function _applyScale() {
    const cellW = el.getBoundingClientRect().width;
    if (!cellW) return;
    // offsetWidth is the pre-transform layout width — unaffected by any
    // currently applied transform AND pinned ≥ content width by
    // min-width:max-content, so it always reflects the true native figure size.
    const nativeW = outerDiv.offsetWidth;
    const nativeH = outerDiv.offsetHeight;
    if (!nativeW) return;
    const s = Math.min(1.0, cellW / nativeW);
    // transform-origin:top left (set in _css) means scale(s) shrinks the
    // figure from the top-left corner.  With width:100% on scaleWrap the
    // scaled figure (nativeW*s ≤ cellW) always fits — no overflow, no
    // clipping, no cross-browser layout-box vs visual-box discrepancies.
    outerDiv.style.transform = s < 1 ? `scale(${s})` : '';
    // transform:scale does not affect layout — outerDiv still occupies
    // nativeH px in the flow even when visually shorter.  A negative
    // marginBottom compensates exactly, pulling subsequent content up by
    // the difference without ever touching scaleWrap's own dimensions.
    // This eliminates any ResizeObserver feedback loop.
    outerDiv.style.marginBottom = (s < 1 && nativeH)
      ? Math.round(nativeH * (s - 1)) + 'px'
      : '';
  }

  if (typeof ResizeObserver !== 'undefined') {
    let _lastCellW = 0;
    new ResizeObserver(entries => {
      // React only to width changes to avoid a feedback loop: our own
      // scaleWrap height updates would otherwise re-trigger the observer.
      const cellW = entries[0].contentRect.width;
      if (cellW === _lastCellW) return;
      _lastCellW = cellW;
      requestAnimationFrame(_applyScale);
    }).observe(el);
    requestAnimationFrame(_applyScale);
  }

  // ── model listeners ───────────────────────────────────────────────────────
  model.on('change:layout_json', () => { applyLayout(); redrawAll(); requestAnimationFrame(_applyScale); });
  model.on('change:fig_width change:fig_height', () => { applyLayout(); redrawAll(); requestAnimationFrame(_applyScale); });

  // Toggle the per-panel stats overlay when display_stats changes.
  // Hiding is immediate; showing waits for the next natural redraw to
  // populate the overlay text — but we also call redrawAll() here so the
  // stats appear instantly without having to interact with the figure first.
  model.on('change:display_stats', () => {
    const show = model.get('display_stats');
    for (const p of panels.values()) {
      if (!show && p.statsDiv) {
        p.statsDiv.style.display = 'none';
      }
    }
    if (show) redrawAll();
  });

  // Python→JS targeted widget update (source:"python" in event_json).
  // Applies changed fields directly to the widget in overlay_widgets and
  // redraws the panel — no image re-decode, no Python echo.
  model.on('change:event_json', () => {
    try {
      const msg = JSON.parse(model.get('event_json') || '{}');
      if (!msg || msg.source !== 'python') return;
      const p = panels.get(msg.panel_id);
      if (!p || !p.state) return;
      const ws = p.state.overlay_widgets || [];
      const wi = ws.findIndex(w => w.id === msg.widget_id);
      if (wi < 0) return;
      // Apply every field from the message except protocol keys
      const skip = new Set(['source', 'panel_id', 'widget_id']);
      for (const [k, v] of Object.entries(msg)) {
        if (!skip.has(k)) ws[wi][k] = v;
      }
      _redrawPanel(p);
    } catch(_) {}
  });

  // ── initial render ────────────────────────────────────────────────────────
  applyLayout();
}

export default { render };






